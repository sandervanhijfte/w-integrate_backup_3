Author: Sander van Hijfte
Last update date: 29-04-2019
The component has a connection with SDB to retrieve data using REST/xml
After retrieving medewerker it converts the medewerker to Employee and sends it to EmployeeDSS, the Data Service that processes the data and stores it the GGMDKPI database.
After retrieving dienstverband it converts the dienstverband to EmployeeContract and sends it to EmployeeDSS, the Data Service that processes the data and stores it the GGMDKPI database.
After retrieving dienstverbanden it converts the dienstverbanden to EmployeeContractLine and sends it to EmployeeDSS, the Data Service that processes the data and stores it the GGMDKPI database.
