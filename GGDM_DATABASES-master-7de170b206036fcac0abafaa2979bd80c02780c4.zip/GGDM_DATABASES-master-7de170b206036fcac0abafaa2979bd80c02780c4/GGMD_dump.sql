-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: GGMD
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `GGMD`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `GGMD` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `GGMD`;

--
-- Table structure for table `ContractsPerCustomer`
--

DROP TABLE IF EXISTS `ContractsPerCustomer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ContractsPerCustomer` (
  `CustomerIdentifier` varchar(20) DEFAULT NULL,
  `ContractId` varchar(20) DEFAULT NULL,
  `DeliveryDate` datetime DEFAULT NULL,
  `StartDateContract` date DEFAULT NULL,
  `EndDateContract` date DEFAULT NULL,
  `CustomerRegion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DiscardedContracts`
--

DROP TABLE IF EXISTS `DiscardedContracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DiscardedContracts` (
  `ContractId` varchar(50) NOT NULL,
  `CustomerIdentifier` varchar(50) NOT NULL,
  `CustomerName` varchar(100) DEFAULT NULL,
  `CustomerTitle` varchar(50) DEFAULT NULL,
  `CustomerLastName` varchar(100) DEFAULT NULL,
  `CustomerInitials` varchar(50) DEFAULT NULL,
  `CustomerFirstName` varchar(100) DEFAULT NULL,
  `CustomerInfix` varchar(50) DEFAULT NULL,
  `CustomerDateOfBirth` varchar(20) DEFAULT NULL,
  `CustomerNameAtBirth` varchar(100) DEFAULT NULL,
  `CustomerLastNameAtBirth` varchar(100) DEFAULT NULL,
  `CustomerInfixAtBirth` varchar(50) DEFAULT NULL,
  `CustomerCountryOfBirth` varchar(100) DEFAULT NULL,
  `CustomerGender` varchar(50) DEFAULT NULL,
  `CustomerRegion` varchar(100) DEFAULT NULL,
  `CustomerStreet` varchar(100) DEFAULT NULL,
  `CustomerHouseNumber` varchar(50) DEFAULT NULL,
  `CustomerHouseNumberAddition` varchar(50) DEFAULT NULL,
  `CustomerZipCode` varchar(50) DEFAULT NULL,
  `CustomerCity` varchar(100) DEFAULT NULL,
  `CustomerCountry` varchar(100) DEFAULT NULL,
  `CustomerSocialSecurityNumber` varchar(50) DEFAULT NULL,
  `CustomerMobilePhone` varchar(100) DEFAULT NULL,
  `CustomerEmailAddress` varchar(100) DEFAULT NULL,
  `DeliveryOrganizationIdentifier` varchar(50) DEFAULT NULL,
  `ContractStartDate` date NOT NULL,
  `ContractEndDate` date DEFAULT NULL,
  `ContractSubject` varchar(100) DEFAULT NULL,
  `ProductDescription` varchar(100) DEFAULT NULL,
  `ProductCode` varchar(50) DEFAULT NULL,
  `Volume` float NOT NULL,
  `UnitOfProduct2015` varchar(50) DEFAULT NULL,
  `UnitOfProduct` varchar(50) DEFAULT NULL,
  `DeliveryPeriod` varchar(50) NOT NULL,
  `VolumePerDeliveryPeriod` float DEFAULT NULL,
  `MunicipalCode` varchar(50) DEFAULT NULL,
  `IsCusomterClassified` varchar(50) DEFAULT NULL,
  `SupplierCode` varchar(50) DEFAULT NULL,
  `DateOfAssignment` date DEFAULT NULL,
  `ContractReasonToChange` varchar(100) DEFAULT NULL,
  `ContractRemark` varchar(100) DEFAULT NULL,
  `ContractReasonForEnding` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ContractId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DiscardedDelivery`
--

DROP TABLE IF EXISTS `DiscardedDelivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DiscardedDelivery` (
  `ContractId` varchar(50) DEFAULT NULL,
  `DeliveryDate` datetime NOT NULL,
  `ActivityName` varchar(100) DEFAULT NULL,
  `ActivityShortName` varchar(50) DEFAULT NULL,
  `ActivityDescription` varchar(500) DEFAULT NULL,
  `ActivityDeliveryReportingCode` varchar(50) DEFAULT NULL,
  `ActivityDeliveryInvoiceCode` varchar(50) DEFAULT NULL,
  `ActivityDeliverySalaryCode` varchar(50) DEFAULT NULL,
  `ActivityDeliveryServiceCode` varchar(50) DEFAULT NULL,
  `ProductCode` varchar(50) DEFAULT NULL,
  `ProductName` varchar(100) DEFAULT NULL,
  `ProductDescription` varchar(500) DEFAULT NULL,
  `OrganizationId` varchar(50) DEFAULT NULL,
  `OrganizationName` varchar(100) DEFAULT NULL,
  `EmployeeId` varchar(50) NOT NULL,
  `EmployeeLastName` varchar(100) DEFAULT NULL,
  `EmployeeInitials` varchar(50) DEFAULT NULL,
  `EmployeeInfix` varchar(50) DEFAULT NULL,
  `DeliveredByOtherEmployees` varchar(50) DEFAULT NULL,
  `CustomerIdentifier` varchar(50) NOT NULL,
  `CustomerLastName` varchar(100) DEFAULT NULL,
  `CustomerInitials` varchar(50) DEFAULT NULL,
  `CustomerInfix` varchar(50) DEFAULT NULL,
  `CustomerYearOfBirth` int(11) DEFAULT NULL,
  `CustomerMonthOfBirth` int(11) DEFAULT NULL,
  `CustomerZipCode` varchar(50) DEFAULT NULL,
  `IsCustomerAbsent` varchar(50) DEFAULT NULL,
  `IsCustomerAbsencePlanned` varchar(50) DEFAULT NULL,
  `CustomerReportCode` varchar(50) DEFAULT NULL,
  `IsCustomerReportSet` varchar(50) DEFAULT NULL,
  `CustomerReportDate` date DEFAULT NULL,
  `CustomerReportRun` varchar(50) DEFAULT NULL,
  `CustomerDeclarationCode` varchar(50) DEFAULT NULL,
  `IsCustomerDeclarationSet` varchar(50) DEFAULT NULL,
  `CustomerDeclarationDate` date DEFAULT NULL,
  `CustomerDeclarationRun` varchar(50) DEFAULT NULL,
  `BillableTime` int(11) NOT NULL,
  `TotalDeliveredPerDeliveryPeriod` int(11) DEFAULT NULL,
  `VollumeAssignedByContract` int(11) DEFAULT NULL,
  `DifferenceBetweenDeliveredAndAssigned` int(11) DEFAULT NULL,
  `DeliveryPeriod` varchar(50) DEFAULT NULL,
  `CustomerRegion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`DeliveryDate`,`EmployeeId`,`CustomerIdentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `MinutesDeliveredAndAssigned`
--

DROP TABLE IF EXISTS `MinutesDeliveredAndAssigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MinutesDeliveredAndAssigned` (
  `CustomerIdentifier` varchar(20) DEFAULT NULL,
  `ContractId` varchar(20) DEFAULT NULL,
  `DeliveryDate` datetime DEFAULT NULL,
  `DeliveryPeriod` varchar(50) DEFAULT NULL,
  `WeeksPerContract` int(11) DEFAULT NULL,
  `MinutesByContract` int(11) DEFAULT NULL,
  `MinutestDelivered` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SumPerPeriod`
--

DROP TABLE IF EXISTS `SumPerPeriod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SumPerPeriod` (
  `DeliveryPeriod` varchar(50) DEFAULT NULL,
  `SumPerPeriod` int(11) DEFAULT NULL,
  `CustomerIdentifier` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract` (
  `ContractId` varchar(50) NOT NULL,
  `CustomerIdentifier` varchar(50) NOT NULL,
  `CustomerName` varchar(100) DEFAULT NULL,
  `CustomerTitle` varchar(50) DEFAULT NULL,
  `CustomerLastName` varchar(100) DEFAULT NULL,
  `CustomerInitials` varchar(50) DEFAULT NULL,
  `CustomerFirstName` varchar(100) DEFAULT NULL,
  `CustomerInfix` varchar(50) DEFAULT NULL,
  `CustomerDateOfBirth` varchar(20) DEFAULT NULL,
  `CustomerNameAtBirth` varchar(100) DEFAULT NULL,
  `CustomerLastNameAtBirth` varchar(100) DEFAULT NULL,
  `CustomerInfixAtBirth` varchar(50) DEFAULT NULL,
  `CustomerCountryOfBirth` varchar(100) DEFAULT NULL,
  `CustomerGender` varchar(50) DEFAULT NULL,
  `CustomerRegion` varchar(100) DEFAULT NULL,
  `CustomerStreet` varchar(100) DEFAULT NULL,
  `CustomerHouseNumber` varchar(50) DEFAULT NULL,
  `CustomerHouseNumberAddition` varchar(50) DEFAULT NULL,
  `CustomerZipCode` varchar(50) DEFAULT NULL,
  `CustomerCity` varchar(100) DEFAULT NULL,
  `CustomerCountry` varchar(100) DEFAULT NULL,
  `CustomerSocialSecurityNumber` varchar(50) DEFAULT NULL,
  `CustomerMobilePhone` varchar(100) DEFAULT NULL,
  `CustomerEmailAddress` varchar(100) DEFAULT NULL,
  `DeliveryOrganizationIdentifier` varchar(50) DEFAULT NULL,
  `ContractStartDate` date NOT NULL,
  `ContractEndDate` date DEFAULT NULL,
  `ContractSubject` varchar(100) DEFAULT NULL,
  `ProductDescription` varchar(100) DEFAULT NULL,
  `ProductCode` varchar(50) DEFAULT NULL,
  `Volume` float NOT NULL,
  `UnitOfProduct2015` varchar(50) DEFAULT NULL,
  `UnitOfProduct` varchar(50) DEFAULT NULL,
  `DeliveryPeriod` varchar(50) NOT NULL,
  `VolumePerDeliveryPeriod` float DEFAULT NULL,
  `MunicipalCode` varchar(50) DEFAULT NULL,
  `IsCusomterClassified` varchar(50) DEFAULT NULL,
  `SupplierCode` varchar(50) DEFAULT NULL,
  `DateOfAssignment` date DEFAULT NULL,
  `ContractReasonToChange` varchar(100) DEFAULT NULL,
  `ContractRemark` varchar(100) DEFAULT NULL,
  `ContractReasonForEnding` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ContractId`),
  KEY `idx_CustomerIdentifier` (`CustomerIdentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery` (
  `ContractId` varchar(50) DEFAULT NULL,
  `DeliveryDate` datetime NOT NULL,
  `ActivityName` varchar(100) DEFAULT NULL,
  `ActivityShortName` varchar(50) DEFAULT NULL,
  `ActivityDescription` varchar(500) DEFAULT NULL,
  `ActivityDeliveryReportingCode` varchar(50) DEFAULT NULL,
  `ActivityDeliveryInvoiceCode` varchar(50) DEFAULT NULL,
  `ActivityDeliverySalaryCode` varchar(50) DEFAULT NULL,
  `ActivityDeliveryServiceCode` varchar(50) DEFAULT NULL,
  `ProductCode` varchar(50) DEFAULT NULL,
  `ProductName` varchar(100) DEFAULT NULL,
  `ProductDescription` varchar(500) DEFAULT NULL,
  `OrganizationId` varchar(50) DEFAULT NULL,
  `OrganizationName` varchar(100) DEFAULT NULL,
  `EmployeeId` varchar(50) NOT NULL,
  `EmployeeLastName` varchar(100) DEFAULT NULL,
  `EmployeeInitials` varchar(50) DEFAULT NULL,
  `EmployeeInfix` varchar(50) DEFAULT NULL,
  `DeliveredByOtherEmployees` varchar(50) DEFAULT NULL,
  `CustomerIdentifier` varchar(50) NOT NULL,
  `CustomerLastName` varchar(100) DEFAULT NULL,
  `CustomerInitials` varchar(50) DEFAULT NULL,
  `CustomerInfix` varchar(50) DEFAULT NULL,
  `CustomerYearOfBirth` int(11) DEFAULT NULL,
  `CustomerMonthOfBirth` int(11) DEFAULT NULL,
  `CustomerZipCode` varchar(50) DEFAULT NULL,
  `IsCustomerAbsent` varchar(50) DEFAULT NULL,
  `IsCustomerAbsencePlanned` varchar(50) DEFAULT NULL,
  `CustomerReportCode` varchar(50) DEFAULT NULL,
  `IsCustomerReportSet` varchar(50) DEFAULT NULL,
  `CustomerReportDate` date DEFAULT NULL,
  `CustomerReportRun` varchar(50) DEFAULT NULL,
  `CustomerDeclarationCode` varchar(50) DEFAULT NULL,
  `IsCustomerDeclarationSet` varchar(50) DEFAULT NULL,
  `CustomerDeclarationDate` date DEFAULT NULL,
  `CustomerDeclarationRun` varchar(50) DEFAULT NULL,
  `BillableTime` int(11) NOT NULL,
  `TotalDeliveredPerDeliveryPeriod` int(11) DEFAULT NULL,
  `VollumeAssignedByContract` int(11) DEFAULT NULL,
  `DifferenceBetweenDeliveredAndAssigned` int(11) DEFAULT NULL,
  `DeliveryPeriod` varchar(50) DEFAULT NULL,
  `CustomerRegion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`DeliveryDate`,`EmployeeId`,`CustomerIdentifier`),
  KEY `idx_delivery_CustomerIdentifier` (`CustomerIdentifier`),
  KEY `idx_delivery_DeliveryPeriod` (`DeliveryPeriod`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `error_log`
--

DROP TABLE IF EXISTS `error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `error_log` (
  `ErrorMessage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `viewContract`
--

DROP TABLE IF EXISTS `viewContract`;
/*!50001 DROP VIEW IF EXISTS `viewContract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `viewContract` AS SELECT 
 1 AS `ContractId`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerGender`,
 1 AS `CustomerRegion`,
 1 AS `CustomerStreet`,
 1 AS `CustomerHouseNumber`,
 1 AS `CustomerHouseNumberAddition`,
 1 AS `CustomerZipCode`,
 1 AS `CustomerCity`,
 1 AS `ContractStartDate`,
 1 AS `ContractEndDate`,
 1 AS `ContractSubject`,
 1 AS `ProductCode`,
 1 AS `Volume`,
 1 AS `UnitOfProduct2015`,
 1 AS `UnitOfProduct`,
 1 AS `DeliveryPeriod`,
 1 AS `VolumePerDeliveryPeriod`,
 1 AS `MunicipalCode`,
 1 AS `IsCusomterClassified`,
 1 AS `SupplierCode`,
 1 AS `DateOfAssignment`,
 1 AS `ContractReasonToChange`,
 1 AS `ContractRemark`,
 1 AS `ContractReasonForEnding`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `viewDelivery`
--

DROP TABLE IF EXISTS `viewDelivery`;
/*!50001 DROP VIEW IF EXISTS `viewDelivery`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `viewDelivery` AS SELECT 
 1 AS `ContractId`,
 1 AS `DeliveryDate`,
 1 AS `ProductCode`,
 1 AS `ProductName`,
 1 AS `ProductDescription`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `BillableTime`,
 1 AS `TotalDeliveredPerDeliveryPeriod`,
 1 AS `VollumeAssignedByContract`,
 1 AS `DifferenceBetweenDeliveredAndAssigned`,
 1 AS `DeliveryPeriod`,
 1 AS `CustomerRegion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_4_ForSander14042018`
--

DROP TABLE IF EXISTS `view_4_ForSander14042018`;
/*!50001 DROP VIEW IF EXISTS `view_4_ForSander14042018`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_4_ForSander14042018` AS SELECT 
 1 AS `WeekNumber`,
 1 AS `month`,
 1 AS `MonthName`,
 1 AS `year`,
 1 AS `BillableHoursPerWeek`,
 1 AS `HoursWorkedPerWeek`,
 1 AS `HoursVacationPerWeek`,
 1 AS `EmployeeId`,
 1 AS `EmployeeInFix`,
 1 AS `Employeelastname`,
 1 AS `NumberOfHoursPerWeek`,
 1 AS `MaximumHoursLeave`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Employee_ForSander21052018`
--

DROP TABLE IF EXISTS `view_Employee_ForSander21052018`;
/*!50001 DROP VIEW IF EXISTS `view_Employee_ForSander21052018`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Employee_ForSander21052018` AS SELECT 
 1 AS `WeekNumber`,
 1 AS `month`,
 1 AS `MonthName`,
 1 AS `year`,
 1 AS `BillableHoursPerWeek`,
 1 AS `HoursWorkedPerWeek`,
 1 AS `HoursVacationPerWeek`,
 1 AS `EmployeeId`,
 1 AS `EmployeeInFix`,
 1 AS `Employeelastname`,
 1 AS `NumberOfHoursPerWeek`,
 1 AS `MaximumHoursLeave`,
 1 AS `TotalNumberOfHoursVacation`,
 1 AS `EmployeeDifferenceBetweenCorrectedNormAndBillable`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Manager_ForSander21052018`
--

DROP TABLE IF EXISTS `view_Manager_ForSander21052018`;
/*!50001 DROP VIEW IF EXISTS `view_Manager_ForSander21052018`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Manager_ForSander21052018` AS SELECT 
 1 AS `WeekNumber`,
 1 AS `month`,
 1 AS `MonthName`,
 1 AS `year`,
 1 AS `BillableHoursPerWeek`,
 1 AS `HoursWorkedPerWeek`,
 1 AS `HoursVacationPerWeek`,
 1 AS `EmployeeId`,
 1 AS `EmployeeInFix`,
 1 AS `Employeelastname`,
 1 AS `NumberOfHoursPerWeek`,
 1 AS `MaximumHoursVacation`,
 1 AS `CurrentWeekNumber`,
 1 AS `TotalNumberOfHoursVacation`,
 1 AS `MaximumMinusSpentVaction`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_Manager_v1_0_0_ForSander21052018`
--

DROP TABLE IF EXISTS `view_Manager_v1_0_0_ForSander21052018`;
/*!50001 DROP VIEW IF EXISTS `view_Manager_v1_0_0_ForSander21052018`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_Manager_v1_0_0_ForSander21052018` AS SELECT 
 1 AS `WeekNumber`,
 1 AS `month`,
 1 AS `MonthName`,
 1 AS `year`,
 1 AS `BillableHoursPerWeek`,
 1 AS `HoursWorkedPerWeek`,
 1 AS `HoursVacationPerWeek`,
 1 AS `EmployeeId`,
 1 AS `EmployeeInFix`,
 1 AS `Employeelastname`,
 1 AS `NumberOfHoursPerWeek`,
 1 AS `MaximumHoursLeave`,
 1 AS `TotalNumberOfHoursVacation`,
 1 AS `DifferenceBetweenCorrectedNormAndBillable`*/;
SET character_set_client = @saved_cs_client;

--
-- Current Database: `GGMD`
--

USE `GGMD`;

--
-- Final view structure for view `viewContract`
--

/*!50001 DROP VIEW IF EXISTS `viewContract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `viewContract` AS select `contract`.`ContractId` AS `ContractId`,`contract`.`CustomerIdentifier` AS `CustomerIdentifier`,`contract`.`CustomerLastName` AS `CustomerLastName`,`contract`.`CustomerGender` AS `CustomerGender`,`contract`.`CustomerRegion` AS `CustomerRegion`,`contract`.`CustomerStreet` AS `CustomerStreet`,`contract`.`CustomerHouseNumber` AS `CustomerHouseNumber`,`contract`.`CustomerHouseNumberAddition` AS `CustomerHouseNumberAddition`,`contract`.`CustomerZipCode` AS `CustomerZipCode`,`contract`.`CustomerCity` AS `CustomerCity`,`contract`.`ContractStartDate` AS `ContractStartDate`,`contract`.`ContractEndDate` AS `ContractEndDate`,`contract`.`ContractSubject` AS `ContractSubject`,`contract`.`ProductCode` AS `ProductCode`,`contract`.`Volume` AS `Volume`,`contract`.`UnitOfProduct2015` AS `UnitOfProduct2015`,`contract`.`UnitOfProduct` AS `UnitOfProduct`,`contract`.`DeliveryPeriod` AS `DeliveryPeriod`,`contract`.`VolumePerDeliveryPeriod` AS `VolumePerDeliveryPeriod`,`contract`.`MunicipalCode` AS `MunicipalCode`,`contract`.`IsCusomterClassified` AS `IsCusomterClassified`,`contract`.`SupplierCode` AS `SupplierCode`,`contract`.`DateOfAssignment` AS `DateOfAssignment`,`contract`.`ContractReasonToChange` AS `ContractReasonToChange`,`contract`.`ContractRemark` AS `ContractRemark`,`contract`.`ContractReasonForEnding` AS `ContractReasonForEnding` from `contract` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `viewDelivery`
--

/*!50001 DROP VIEW IF EXISTS `viewDelivery`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `viewDelivery` AS select `delivery`.`ContractId` AS `ContractId`,`delivery`.`DeliveryDate` AS `DeliveryDate`,`delivery`.`ProductCode` AS `ProductCode`,`delivery`.`ProductName` AS `ProductName`,`delivery`.`ProductDescription` AS `ProductDescription`,`delivery`.`EmployeeId` AS `EmployeeId`,`delivery`.`EmployeeLastName` AS `EmployeeLastName`,`delivery`.`CustomerIdentifier` AS `CustomerIdentifier`,`delivery`.`CustomerLastName` AS `CustomerLastName`,`delivery`.`CustomerInitials` AS `CustomerInitials`,`delivery`.`BillableTime` AS `BillableTime`,`delivery`.`TotalDeliveredPerDeliveryPeriod` AS `TotalDeliveredPerDeliveryPeriod`,`delivery`.`VollumeAssignedByContract` AS `VollumeAssignedByContract`,`delivery`.`DifferenceBetweenDeliveredAndAssigned` AS `DifferenceBetweenDeliveredAndAssigned`,`delivery`.`DeliveryPeriod` AS `DeliveryPeriod`,`delivery`.`CustomerRegion` AS `CustomerRegion` from `delivery` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_4_ForSander14042018`
--

/*!50001 DROP VIEW IF EXISTS `view_4_ForSander14042018`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_4_ForSander14042018` AS select week(`delivery`.`DeliveryDate`,3) AS `WeekNumber`,month(`delivery`.`DeliveryDate`) AS `month`,monthname(`delivery`.`DeliveryDate`) AS `MonthName`,year(`delivery`.`DeliveryDate`) AS `year`,(sum(`delivery`.`BillableTime`) / 3600) AS `BillableHoursPerWeek`,((sum(`delivery`.`BillableTime`) * 1.3) / 3600) AS `HoursWorkedPerWeek`,((sum(`delivery`.`BillableTime`) / 10) / 3600) AS `HoursVacationPerWeek`,`delivery`.`EmployeeId` AS `EmployeeId`,`delivery`.`EmployeeInfix` AS `EmployeeInFix`,`delivery`.`EmployeeLastName` AS `Employeelastname`,36 AS `NumberOfHoursPerWeek`,((36 * 52) * 0.136) AS `MaximumHoursLeave` from `delivery` group by `WeekNumber`,`delivery`.`EmployeeId` order by `delivery`.`EmployeeId`,`month` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Employee_ForSander21052018`
--

/*!50001 DROP VIEW IF EXISTS `view_Employee_ForSander21052018`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Employee_ForSander21052018` AS select week(`delivery`.`DeliveryDate`,3) AS `WeekNumber`,month(`delivery`.`DeliveryDate`) AS `month`,monthname(`delivery`.`DeliveryDate`) AS `MonthName`,year(`delivery`.`DeliveryDate`) AS `year`,(sum(`delivery`.`BillableTime`) / 3600) AS `BillableHoursPerWeek`,((sum(`delivery`.`BillableTime`) * 1.3) / 3600) AS `HoursWorkedPerWeek`,((sum(`delivery`.`BillableTime`) / 10) / 3600) AS `HoursVacationPerWeek`,`delivery`.`EmployeeId` AS `EmployeeId`,`delivery`.`EmployeeInfix` AS `EmployeeInFix`,`delivery`.`EmployeeLastName` AS `Employeelastname`,36 AS `NumberOfHoursPerWeek`,((36 * 52) * 0.136) AS `MaximumHoursLeave`,249 AS `TotalNumberOfHoursVacation`,if((((36 * 52) * 0.136) > 249),(((36 * 52) * 0.136) - 249),'that') AS `EmployeeDifferenceBetweenCorrectedNormAndBillable` from `delivery` group by `WeekNumber`,`delivery`.`EmployeeId` order by `delivery`.`EmployeeId`,`month` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Manager_ForSander21052018`
--

/*!50001 DROP VIEW IF EXISTS `view_Manager_ForSander21052018`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Manager_ForSander21052018` AS select week(`delivery`.`DeliveryDate`,3) AS `WeekNumber`,month(`delivery`.`DeliveryDate`) AS `month`,monthname(`delivery`.`DeliveryDate`) AS `MonthName`,year(`delivery`.`DeliveryDate`) AS `year`,(sum(`delivery`.`BillableTime`) / 3600) AS `BillableHoursPerWeek`,((sum(`delivery`.`BillableTime`) * 1.3) / 3600) AS `HoursWorkedPerWeek`,((sum(`delivery`.`BillableTime`) / 10) / 3600) AS `HoursVacationPerWeek`,`delivery`.`EmployeeId` AS `EmployeeId`,`delivery`.`EmployeeInfix` AS `EmployeeInFix`,`delivery`.`EmployeeLastName` AS `Employeelastname`,36 AS `NumberOfHoursPerWeek`,((36 * 52) * 0.136) AS `MaximumHoursVacation`,week(curdate(),3) AS `CurrentWeekNumber`,249 AS `TotalNumberOfHoursVacation`,(249 - ((36 * 52) * 0.136)) AS `MaximumMinusSpentVaction` from `delivery` where (week(`delivery`.`DeliveryDate`,3) = week(curdate(),3)) group by `WeekNumber`,`delivery`.`EmployeeId` order by `delivery`.`EmployeeId`,`month` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_Manager_v1_0_0_ForSander21052018`
--

/*!50001 DROP VIEW IF EXISTS `view_Manager_v1_0_0_ForSander21052018`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_Manager_v1_0_0_ForSander21052018` AS select `view_Employee_ForSander21052018`.`WeekNumber` AS `WeekNumber`,`view_Employee_ForSander21052018`.`month` AS `month`,`view_Employee_ForSander21052018`.`MonthName` AS `MonthName`,`view_Employee_ForSander21052018`.`year` AS `year`,`view_Employee_ForSander21052018`.`BillableHoursPerWeek` AS `BillableHoursPerWeek`,`view_Employee_ForSander21052018`.`HoursWorkedPerWeek` AS `HoursWorkedPerWeek`,`view_Employee_ForSander21052018`.`HoursVacationPerWeek` AS `HoursVacationPerWeek`,`view_Employee_ForSander21052018`.`EmployeeId` AS `EmployeeId`,`view_Employee_ForSander21052018`.`EmployeeInFix` AS `EmployeeInFix`,`view_Employee_ForSander21052018`.`Employeelastname` AS `Employeelastname`,`view_Employee_ForSander21052018`.`NumberOfHoursPerWeek` AS `NumberOfHoursPerWeek`,`view_Employee_ForSander21052018`.`MaximumHoursLeave` AS `MaximumHoursLeave`,`view_Employee_ForSander21052018`.`TotalNumberOfHoursVacation` AS `TotalNumberOfHoursVacation`,sum(`view_Employee_ForSander21052018`.`EmployeeDifferenceBetweenCorrectedNormAndBillable`) AS `DifferenceBetweenCorrectedNormAndBillable` from `view_Employee_ForSander21052018` where (`view_Employee_ForSander21052018`.`WeekNumber` <= week(curdate(),3)) group by `view_Employee_ForSander21052018`.`EmployeeId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-14 17:23:27
