-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: GGMDKPI
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `GGMDKPI`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `GGMDKPI` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `GGMDKPI`;

--
-- Table structure for table `Calendar`
--

DROP TABLE IF EXISTS `Calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Calendar` (
  `Date` date NOT NULL,
  `MonthNumber` int(11) DEFAULT NULL,
  `WeekNumber` int(11) DEFAULT NULL,
  `DayOfTheWeek` varchar(45) DEFAULT NULL,
  `DayOfTheMonth` int(11) DEFAULT NULL,
  PRIMARY KEY (`Date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Department`
--

DROP TABLE IF EXISTS `Department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Department` (
  `DepartmentId` int(11) NOT NULL,
  `DepartmentName` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`DepartmentId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Designation`
--

DROP TABLE IF EXISTS `Designation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Designation` (
  `DesignationId` varchar(45) NOT NULL,
  `DesignationDescription` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`DesignationId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `DesignationConfiguration`
--

DROP TABLE IF EXISTS `DesignationConfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DesignationConfiguration` (
  `SDBDesignation` text,
  `GGMDDesignation` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Employee`
--

DROP TABLE IF EXISTS `Employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee` (
  `EmployeeId` varchar(45) NOT NULL DEFAULT 'No_Source_Id' COMMENT 'This identifier is the identifier used for Employee in all processes of the Organization. It is the one that must be used in the Common Data Model of an Employee.',
  `EmployeeSourceId` varchar(45) NOT NULL,
  `EmployeeFirstName` varchar(100) DEFAULT NULL,
  `EmployeeInfix` varchar(10) DEFAULT NULL,
  `EmployeeLastName` varchar(20) DEFAULT NULL,
  `DepartmentId` varchar(100) DEFAULT NULL COMMENT 'Logically this connects the Employee to it’s department',
  `EmployeeInitials` varchar(45) DEFAULT NULL,
  `EmployeeTitle` varchar(45) DEFAULT NULL,
  `EmployeeGender` varchar(45) DEFAULT NULL,
  `EmployeeDateOfBirth` date DEFAULT NULL,
  `EmployeePlaceOfBirth` varchar(45) DEFAULT NULL,
  `EmployeeSocialSecurityNumber` varchar(45) DEFAULT NULL,
  `EmployeeMaritalStatus` varchar(45) DEFAULT NULL,
  `EmployeeNationality` varchar(45) DEFAULT NULL,
  `EmployeeEmail` varchar(45) DEFAULT NULL,
  `EmployeePartnerInitials` varchar(45) DEFAULT NULL,
  `EmployeePartnerInfix` varchar(45) DEFAULT NULL,
  `EmployeePartnerLastName` varchar(100) DEFAULT NULL,
  `EmployeePartnerDateOfBirth` date DEFAULT NULL,
  PRIMARY KEY (`EmployeeSourceId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EmployeeContract`
--

DROP TABLE IF EXISTS `EmployeeContract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmployeeContract` (
  `EmployeeContractId` varchar(45) NOT NULL COMMENT 'This is the identifier of the contract.',
  `EmployeeContractEmployeeId` varchar(45) NOT NULL,
  `IsCompanyFirstAid` tinyint(4) DEFAULT NULL,
  `EmployeeDesignationId` varchar(45) DEFAULT NULL,
  `EmployeeDesignationDescription` varchar(45) DEFAULT NULL COMMENT 'We have to work around the problem that we first map from SDB to GGMD designations so for now there is no DesignationId. ',
  `EmployeeFormOfContractCode` varchar(45) DEFAULT NULL,
  `EmployeeContractIsEmployeePaid` varchar(45) DEFAULT NULL,
  `EmployeeFormOfContractDescription` varchar(45) DEFAULT NULL,
  `EmployeeIsContractPermanent` varchar(45) DEFAULT NULL,
  `EmployeeContractStartDate` date DEFAULT NULL,
  `EmployeeContractEndDate` date DEFAULT NULL,
  `EmployeeContractNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractMaxNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractNumberOfDaysPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractDepartmentId` varchar(45) DEFAULT NULL COMMENT 'This logically connect the EmployeeContract to the Department',
  `EmployeeContractWorkLocation` varchar(45) DEFAULT NULL,
  `EmployeeContractSalaryBasedOnFullTimeEmployment` varchar(45) DEFAULT NULL,
  `EmployeeContractYearSalary` varchar(45) DEFAULT NULL,
  `EmployeeContractStatus` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`EmployeeContractId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EmployeeContractLine`
--

DROP TABLE IF EXISTS `EmployeeContractLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmployeeContractLine` (
  `EmployeeContractId` varchar(45) NOT NULL COMMENT 'Last update date: 08-04-2019',
  `EmployeeContractStartDate` date NOT NULL,
  `EmployeeContractEndDate` date DEFAULT NULL,
  `EmployeeContractNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractMaxNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractNumberOfDaysPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractDepartmentId` varchar(45) DEFAULT NULL,
  `EmployeeContractSalaryBasedOnFullTimeEmployment` varchar(45) DEFAULT NULL,
  `EmployeeContractYearSalary` varchar(45) DEFAULT NULL,
  `EmployeeDesignationDescription` varchar(45) DEFAULT NULL,
  `EmployeeContractLineNormDeviation` decimal(6,2) DEFAULT NULL,
  PRIMARY KEY (`EmployeeContractId`,`EmployeeContractStartDate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EmployeePersonalNormDeviation`
--

DROP TABLE IF EXISTS `EmployeePersonalNormDeviation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmployeePersonalNormDeviation` (
  `EmployeeContractId` varchar(45) NOT NULL,
  `PersonalNormDeviation` decimal(6,2) DEFAULT NULL COMMENT 'This is a configuration table that holds the PersonalNormDeviation for GGMD. This is not stored in SDB',
  PRIMARY KEY (`EmployeeContractId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EmployeeVacation`
--

DROP TABLE IF EXISTS `EmployeeVacation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmployeeVacation` (
  `EmployeeId` varchar(50) NOT NULL,
  `MyEmployeeHoursVacation` decimal(32,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PerformanceIndicator`
--

DROP TABLE IF EXISTS `PerformanceIndicator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PerformanceIndicator` (
  `Department` varchar(100) NOT NULL,
  `Designation` varchar(50) NOT NULL,
  `PerformanceIndicator` decimal(7,2) DEFAULT NULL,
  `YearInWhichNormApplies` int(4) DEFAULT NULL,
  `Overhead` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`Department`,`Designation`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TotalDelivered`
--

DROP TABLE IF EXISTS `TotalDelivered`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TotalDelivered` (
  `CustomerIdentifier` varchar(50) NOT NULL,
  `DeliveredPerDeliveryPeriod` decimal(32,0) DEFAULT NULL,
  `DeliveryPeriod` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `UploadDate`
--

DROP TABLE IF EXISTS `UploadDate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UploadDate` (
  `UploadDate` date NOT NULL,
  PRIMARY KEY (`UploadDate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `base_view_for_ManagementV1_0_0`
--

DROP TABLE IF EXISTS `base_view_for_ManagementV1_0_0`;
/*!50001 DROP VIEW IF EXISTS `base_view_for_ManagementV1_0_0`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `base_view_for_ManagementV1_0_0` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `Update06042019`,
 1 AS `EmployeeId`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeInFix`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `YearToDateNumberOfHoursBillable`,
 1 AS `YearToDateNumberOfHoursVacation`,
 1 AS `YearToDateNumberOfHoursWorked`,
 1 AS `EmployeePersonalNorm`,
 1 AS `YearToDateDifferenceBetweenBillableAndWeekNorm`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract` (
  `ContractId` varchar(50) CHARACTER SET latin1 NOT NULL,
  `CustomerIdentifier` varchar(50) CHARACTER SET latin1 NOT NULL,
  `CustomerNumber` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerName` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerTitle` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerLastName` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerInitials` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerFirstName` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerInfix` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerDateOfBirth` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerNameAtBirth` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerLastNameAtBirth` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerInfixAtBirth` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerCountryOfBirth` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerGender` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerRegion` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerStreet` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerHouseNumber` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerHouseNumberAddition` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerZipCode` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerCity` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerCountry` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerSocialSecurityNumber` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerMobilePhone` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CustomerEmailAddress` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `DeliveryOrganizationIdentifier` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `ContractStartDate` date NOT NULL,
  `ContractEndDate` date DEFAULT NULL,
  `ContractSubject` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `ProductDescription` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `AdditionalProductDescription` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `ProductCode` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `Volume` float NOT NULL,
  `UnitOfProduct2015` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `UnitOfProduct` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `DeliveryPeriod` varchar(50) CHARACTER SET latin1 NOT NULL,
  `VolumePerDeliveryPeriod` float DEFAULT NULL,
  `MunicipalCode` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `IsCusomterClassified` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `SupplierCode` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `ContractDateOfAssignment` date DEFAULT NULL,
  `ContractReasonToChange` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `ContractRemark` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `ContractReasonForEnding` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `IsContractDiscarded` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `DiscardedReason` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `FreelanceCode` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `FreelanceCategory` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `FreelanceWayOfDelivery` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `IssuingOrganizationId` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `ContractType` varchar(45) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`ContractId`),
  KEY `idx_CustomerIdentifier` (`CustomerIdentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery` (
  `ContractId` varchar(50) DEFAULT NULL,
  `DeliveryDate` datetime NOT NULL,
  `ActivityName` varchar(100) DEFAULT NULL,
  `ActivityShortName` varchar(50) DEFAULT NULL,
  `ActivityDescription` varchar(500) DEFAULT NULL,
  `ActivityDeliveryReportingCode` varchar(50) DEFAULT NULL,
  `ActivityDeliveryInvoiceCode` varchar(50) DEFAULT NULL,
  `ActivityDeliverySalaryCode` varchar(50) DEFAULT NULL,
  `ActivityDeliveryServiceCode` varchar(50) DEFAULT NULL,
  `ProductCode` varchar(50) DEFAULT NULL,
  `ProductName` varchar(100) DEFAULT NULL,
  `ProductDescription` varchar(500) DEFAULT NULL,
  `OrganizationId` varchar(50) DEFAULT NULL,
  `OrganizationName` varchar(100) DEFAULT NULL,
  `EmployeeId` varchar(50) NOT NULL,
  `EmployeeLastName` varchar(100) DEFAULT NULL,
  `EmployeeInitials` varchar(50) DEFAULT NULL,
  `EmployeeInfix` varchar(50) DEFAULT NULL,
  `EmployeeNumberOfHoursWorked` int(11) DEFAULT NULL COMMENT 'This is stored in seconds',
  `EmployeeNumberOfHoursVacation` int(11) DEFAULT NULL COMMENT 'This is stored in seconds so we need to change the column name',
  `DeliveredByOtherEmployees` varchar(50) DEFAULT NULL,
  `CustomerIdentifier` varchar(50) NOT NULL,
  `CustomerLastName` varchar(100) DEFAULT NULL,
  `CustomerInitials` varchar(50) DEFAULT NULL,
  `CustomerInfix` varchar(50) DEFAULT NULL,
  `CustomerYearOfBirth` int(11) DEFAULT NULL,
  `CustomerMonthOfBirth` int(11) DEFAULT NULL,
  `CustomerZipCode` varchar(50) DEFAULT NULL,
  `IsCustomerAbsent` varchar(50) DEFAULT NULL,
  `IsCustomerAbsencePlanned` varchar(50) DEFAULT NULL,
  `CustomerReportCode` varchar(50) DEFAULT NULL,
  `IsCustomerReportSet` varchar(50) DEFAULT NULL,
  `CustomerReportDate` date DEFAULT NULL,
  `CustomerReportRun` varchar(50) DEFAULT NULL,
  `CustomerDeclarationCode` varchar(50) DEFAULT NULL,
  `IsCustomerDeclarationSet` varchar(50) DEFAULT NULL,
  `CustomerDeclarationDate` date DEFAULT NULL,
  `CustomerDeclarationRun` varchar(50) DEFAULT NULL,
  `BillableTime` int(11) NOT NULL,
  `TotalDeliveredPerDeliveryPeriod` int(11) DEFAULT NULL,
  `VolumeAssignedByContract` int(11) DEFAULT NULL,
  `DifferenceBetweenDeliveredAndAssigned` int(11) DEFAULT NULL,
  `DeliveryPeriod` varchar(50) DEFAULT NULL,
  `CustomerRegion` varchar(100) DEFAULT NULL,
  `ActivityId` varchar(45) DEFAULT NULL,
  `ActivityDefaultDeclarationCode` varchar(50) DEFAULT NULL,
  `EmployeeFirstName` varchar(45) DEFAULT NULL,
  `EmployeeDepartment` varchar(45) DEFAULT NULL,
  `EmployeePersonalPerformanceIndicator` decimal(6,2) DEFAULT NULL,
  `EmployeeDesignation` varchar(45) DEFAULT NULL,
  `EmployeeNumberOfHoursPerWeek` int(11) DEFAULT NULL,
  `EmployeeTotalNumberOfHoursVacation` int(11) DEFAULT NULL,
  `DateActivityLogged` date DEFAULT NULL,
  `EmployeeThatLoggedTheActivity` varchar(100) DEFAULT NULL,
  `DateThatActivityLogChanged` date DEFAULT NULL,
  `EmployeeThatChangedTheActivityLog` varchar(100) DEFAULT NULL,
  `IsDeliveryDiscarded` varchar(50) DEFAULT NULL,
  `ReasonForDiscardingDelivery` varchar(100) DEFAULT NULL,
  `ContractDeliveryPeriod` varchar(45) DEFAULT NULL,
  `DeliveryType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`DeliveryDate`,`EmployeeId`,`CustomerIdentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `error_log`
--

DROP TABLE IF EXISTS `error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `error_log` (
  `ErrorMessage` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `view_ContractLineDepartment`
--

DROP TABLE IF EXISTS `view_ContractLineDepartment`;
/*!50001 DROP VIEW IF EXISTS `view_ContractLineDepartment`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_ContractLineDepartment` AS SELECT 
 1 AS `Version`,
 1 AS `EmployeeContractId`,
 1 AS `EmployeeContractEndDate`,
 1 AS `EmployeeContractStartDate`,
 1 AS `EmployeeContractNumberOfDaysPerWeek`,
 1 AS `EmployeeContractNumberOfHoursPerWeek`,
 1 AS `EmployeeContractDepartmentId`,
 1 AS `EmployeeContractSalaryBasedOnFullTimeEmployment`,
 1 AS `EmployeeContractYearSalary`,
 1 AS `EmployeeDesignationDescription`,
 1 AS `EmployeeContractLineNormDeviation`,
 1 AS `DepartmentName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_KPI_WeekNumbers_V1_0_0`
--

DROP TABLE IF EXISTS `view_KPI_WeekNumbers_V1_0_0`;
/*!50001 DROP VIEW IF EXISTS `view_KPI_WeekNumbers_V1_0_0`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_KPI_WeekNumbers_V1_0_0` AS SELECT 
 1 AS `Version`,
 1 AS `weeknumber`,
 1 AS `year`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_PersonalPerformanceIndicator`
--

DROP TABLE IF EXISTS `view_PersonalPerformanceIndicator`;
/*!50001 DROP VIEW IF EXISTS `view_PersonalPerformanceIndicator`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_PersonalPerformanceIndicator` AS SELECT 
 1 AS `Version`,
 1 AS `EmployeeContractStartDate`,
 1 AS `EmployeeContractEndDate`,
 1 AS `EmployeeContractId`,
 1 AS `EmployeeDesignationDescription`,
 1 AS `DepartmentName`,
 1 AS `PerformanceIndicator`,
 1 AS `EmployeeContractNumberOfHoursPerWeek`,
 1 AS `PersonalPerformanceIndicator`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_contract`
--

DROP TABLE IF EXISTS `view_contract`;
/*!50001 DROP VIEW IF EXISTS `view_contract`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_contract` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `ContractId`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerNumber`,
 1 AS `CustomerName`,
 1 AS `CustomerTitle`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerFirstName`,
 1 AS `CustomerInfix`,
 1 AS `CustomerDateOfBirth`,
 1 AS `CustomerNameAtBirth`,
 1 AS `CustomerLastNameAtBirth`,
 1 AS `CustomerInfixAtBirth`,
 1 AS `CustomerCountryOfBirth`,
 1 AS `CustomerGender`,
 1 AS `CustomerRegion`,
 1 AS `CustomerStreet`,
 1 AS `CustomerHouseNumber`,
 1 AS `CustomerHouseNumberAddition`,
 1 AS `CustomerZipCode`,
 1 AS `CustomerCity`,
 1 AS `CustomerCountry`,
 1 AS `CustomerSocialSecurityNumber`,
 1 AS `CustomerMobilePhone`,
 1 AS `CustomerEmailAddress`,
 1 AS `DeliveryOrganizationIdentifier`,
 1 AS `ContractStartDate`,
 1 AS `ContractEndDate`,
 1 AS `ContractSubject`,
 1 AS `ProductDescription`,
 1 AS `AdditionalProductDescription`,
 1 AS `ProductCode`,
 1 AS `Volume`,
 1 AS `UnitOfProduct2015`,
 1 AS `UnitOfProduct`,
 1 AS `DeliveryPeriod`,
 1 AS `VolumePerDeliveryPeriod`,
 1 AS `MunicipalCode`,
 1 AS `IsCusomterClassified`,
 1 AS `SupplierCode`,
 1 AS `ContractDateOfAssignment`,
 1 AS `ContractReasonToChange`,
 1 AS `ContractRemark`,
 1 AS `ContractReasonForEnding`,
 1 AS `IsContractDiscarded`,
 1 AS `DiscardedReason`,
 1 AS `FreelanceCode`,
 1 AS `FreelanceCategory`,
 1 AS `FreelanceWayOfDelivery`,
 1 AS `IssuingOrganizationId`,
 1 AS `ContractType`,
 1 AS `CustomerAge`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_contract1_0_0`
--

DROP TABLE IF EXISTS `view_contract1_0_0`;
/*!50001 DROP VIEW IF EXISTS `view_contract1_0_0`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_contract1_0_0` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `ContractId`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerNumber`,
 1 AS `CustomerName`,
 1 AS `CustomerTitle`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerFirstName`,
 1 AS `CustomerInfix`,
 1 AS `CustomerDateOfBirth`,
 1 AS `CustomerNameAtBirth`,
 1 AS `CustomerLastNameAtBirth`,
 1 AS `CustomerInfixAtBirth`,
 1 AS `CustomerCountryOfBirth`,
 1 AS `CustomerGender`,
 1 AS `CustomerRegion`,
 1 AS `CustomerStreet`,
 1 AS `CustomerHouseNumber`,
 1 AS `CustomerHouseNumberAddition`,
 1 AS `CustomerZipCode`,
 1 AS `CustomerCity`,
 1 AS `CustomerCountry`,
 1 AS `CustomerSocialSecurityNumber`,
 1 AS `CustomerMobilePhone`,
 1 AS `CustomerEmailAddress`,
 1 AS `DeliveryOrganizationIdentifier`,
 1 AS `ContractStartDate`,
 1 AS `ContractEndDate`,
 1 AS `ContractSubject`,
 1 AS `ProductDescription`,
 1 AS `AdditionalProductDescription`,
 1 AS `ProductCode`,
 1 AS `Volume`,
 1 AS `UnitOfProduct2015`,
 1 AS `UnitOfProduct`,
 1 AS `DeliveryPeriod`,
 1 AS `VolumePerDeliveryPeriod`,
 1 AS `MunicipalCode`,
 1 AS `IsCusomterClassified`,
 1 AS `SupplierCode`,
 1 AS `ContractDateOfAssignment`,
 1 AS `ContractReasonToChange`,
 1 AS `ContractRemark`,
 1 AS `ContractReasonForEnding`,
 1 AS `FreelanceCode`,
 1 AS `FreelanceCategory`,
 1 AS `FreelanceWayOfDelivery`,
 1 AS `IssuingOrganizationId`,
 1 AS `ContractType`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_current_EmployeeContractLine`
--

DROP TABLE IF EXISTS `view_current_EmployeeContractLine`;
/*!50001 DROP VIEW IF EXISTS `view_current_EmployeeContractLine`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_current_EmployeeContractLine` AS SELECT 
 1 AS `CURRENTWEEK`,
 1 AS `EmployeeId`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeInFix`,
 1 AS `Employeelastname`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `WeekNumber`,
 1 AS `DeliveryDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_customer_birthday`
--

DROP TABLE IF EXISTS `view_customer_birthday`;
/*!50001 DROP VIEW IF EXISTS `view_customer_birthday`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_customer_birthday` AS SELECT 
 1 AS `Author: Sander van Hijfte last update: 31-07-2109`,
 1 AS `ExplanationPart1`,
 1 AS `day`,
 1 AS `month`,
 1 AS `year`,
 1 AS `CalculatedCustomerDateOfBirth`,
 1 AS `BirthDay`,
 1 AS `CustomerDateOfBirth`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_delivery1_0_0`
--

DROP TABLE IF EXISTS `view_delivery1_0_0`;
/*!50001 DROP VIEW IF EXISTS `view_delivery1_0_0`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_delivery1_0_0` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `ContractId`,
 1 AS `DeliveryDate`,
 1 AS `ActivityName`,
 1 AS `ActivityShortName`,
 1 AS `ActivityDescription`,
 1 AS `ActivityDeliveryReportingCode`,
 1 AS `ActivityDeliveryInvoiceCode`,
 1 AS `ActivityDeliverySalaryCode`,
 1 AS `ActivityDeliveryServiceCode`,
 1 AS `ProductCode`,
 1 AS `ProductName`,
 1 AS `ProductDescription`,
 1 AS `OrganizationId`,
 1 AS `OrganizationName`,
 1 AS `EmployeeId`,
 1 AS `Employeelastname`,
 1 AS `EmployeeInitials`,
 1 AS `EmployeeInFix`,
 1 AS `EmployeeNumberOfHoursWorked`,
 1 AS `EmployeeNumberOfHoursVacation`,
 1 AS `DeliveredByOtherEmployees`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerYearOfBirth`,
 1 AS `CustomerMonthOfBirth`,
 1 AS `CustomerZipCode`,
 1 AS `IsCustomerAbsent`,
 1 AS `IsCustomerAbsencePlanned`,
 1 AS `CustomerReportCode`,
 1 AS `IsCustomerReportSet`,
 1 AS `CustomerReportDate`,
 1 AS `CustomerReportRun`,
 1 AS `CustomerDeclarationCode`,
 1 AS `IsCustomerDeclarationSet`,
 1 AS `CustomerDeclarationDate`,
 1 AS `CustomerDeclarationRun`,
 1 AS `BillableTime`,
 1 AS `TotalDeliveredPerDeliveryPeriod`,
 1 AS `VollumeAssignedByContract`,
 1 AS `DifferenceBetweenDeliveredAndAssigned`,
 1 AS `DeliveryPeriod`,
 1 AS `CustomerRegion`,
 1 AS `ActivityId`,
 1 AS `ActivityDefaultDeclarationCode`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `DateActivityLogged`,
 1 AS `EmployeeThatLoggedTheActivity`,
 1 AS `DateThatActivityLogChanged`,
 1 AS `EmployeeThatChangedTheActivityLog`,
 1 AS `ContractDeliveryPeriod`,
 1 AS `DeliveryType`,
 1 AS `ReasonForDiscardingDelivery`,
 1 AS `CustomerCity`,
 1 AS `UploadDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_delivery_ForKPIV1_0_1`
--

DROP TABLE IF EXISTS `view_delivery_ForKPIV1_0_1`;
/*!50001 DROP VIEW IF EXISTS `view_delivery_ForKPIV1_0_1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_delivery_ForKPIV1_0_1` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `Update 04-04-2019`,
 1 AS `EmployeeId`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeInfix`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeDepartment`,
 1 AS `PerformanceIndicator`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeePersonalNorm`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `WeekNumber`,
 1 AS `MonthNumber`,
 1 AS `Data`,
 1 AS `year`,
 1 AS `BillableHoursPerWeek`,
 1 AS `TotalNumberOfHoursWorkedPerWeek`,
 1 AS `TotalNumberOfHoursVacationPerWeek`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeWeekNorm`,
 1 AS `DifferenceBetweenBillableAndWeekNorm`,
 1 AS `EmployeeCurrentNumberOfHoursPerWeek`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_delivery_ForKPI_ManagementV1_0_0`
--

DROP TABLE IF EXISTS `view_delivery_ForKPI_ManagementV1_0_0`;
/*!50001 DROP VIEW IF EXISTS `view_delivery_ForKPI_ManagementV1_0_0`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_delivery_ForKPI_ManagementV1_0_0` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `EmployeeId`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeInFix`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeePersonalNorm`,
 1 AS `YearToDateNumberOfHoursBillable`,
 1 AS `YearToDateNumberOfHoursVacation`,
 1 AS `YearToDateNumberOfHoursWorked`,
 1 AS `YearToDateDifferenceBetweenBillableAndWeekNorm`,
 1 AS `WeekNumber`,
 1 AS `DifferenceBetweenBillableAndWeekNorm`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_delivery_ForKPI_UpToLastWeekV1_0_0`
--

DROP TABLE IF EXISTS `view_delivery_ForKPI_UpToLastWeekV1_0_0`;
/*!50001 DROP VIEW IF EXISTS `view_delivery_ForKPI_UpToLastWeekV1_0_0`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_delivery_ForKPI_UpToLastWeekV1_0_0` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `EmployeeId`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeInFix`,
 1 AS `Employeelastname`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeePersonalNorm`,
 1 AS `WeekNumber`,
 1 AS `MonthNumber`,
 1 AS `Data`,
 1 AS `year`,
 1 AS `BillableHoursPerWeek`,
 1 AS `TotalNumberOfHoursWorkedPerWeek`,
 1 AS `TotalNumberOfHoursVacationPerWeek`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `EmployeeWeekNorm`,
 1 AS `DifferenceBetweenBillableAndWeekNorm`,
 1 AS `LastWeek`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_double_contracts`
--

DROP TABLE IF EXISTS `view_double_contracts`;
/*!50001 DROP VIEW IF EXISTS `view_double_contracts`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_double_contracts` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `EmployeeContractEmployeeId`,
 1 AS `count(*)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_double_contracts_with_dates`
--

DROP TABLE IF EXISTS `view_double_contracts_with_dates`;
/*!50001 DROP VIEW IF EXISTS `view_double_contracts_with_dates`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_double_contracts_with_dates` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `EmployeeContractId`,
 1 AS `EmployeeContractEmployeeId`,
 1 AS `EmployeeContractStartDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_productionReportV1_0_0`
--

DROP TABLE IF EXISTS `view_productionReportV1_0_0`;
/*!50001 DROP VIEW IF EXISTS `view_productionReportV1_0_0`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_productionReportV1_0_0` AS SELECT 
 1 AS `ContractId`,
 1 AS `DeliveryDate`,
 1 AS `ActivityName`,
 1 AS `ActivityShortName`,
 1 AS `ActivityDescription`,
 1 AS `ActivityDeliveryReportingCode`,
 1 AS `ActivityDeliveryInvoiceCode`,
 1 AS `ActivityDeliverySalaryCode`,
 1 AS `ActivityDeliveryServiceCode`,
 1 AS `ProductCode`,
 1 AS `ProductName`,
 1 AS `ProductDescription`,
 1 AS `OrganizationId`,
 1 AS `OrganizationName`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeInitials`,
 1 AS `EmployeeInfix`,
 1 AS `EmployeeNumberOfHoursWorked`,
 1 AS `EmployeeNumberOfHoursVacation`,
 1 AS `DeliveredByOtherEmployees`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerInfix`,
 1 AS `CustomerYearOfBirth`,
 1 AS `CustomerMonthOfBirth`,
 1 AS `CustomerZipCode`,
 1 AS `IsCustomerAbsent`,
 1 AS `IsCustomerAbsencePlanned`,
 1 AS `CustomerReportCode`,
 1 AS `IsCustomerReportSet`,
 1 AS `CustomerReportDate`,
 1 AS `CustomerReportRun`,
 1 AS `CustomerDeclarationCode`,
 1 AS `IsCustomerDeclarationSet`,
 1 AS `CustomerDeclarationDate`,
 1 AS `CustomerDeclarationRun`,
 1 AS `BillableTime`,
 1 AS `TotalDeliveredPerDeliveryPeriod`,
 1 AS `VolumeAssignedByContract`,
 1 AS `DifferenceBetweenDeliveredAndAssigned`,
 1 AS `DeliveryPeriod`,
 1 AS `CustomerRegion`,
 1 AS `ActivityId`,
 1 AS `ActivityDefaultDeclarationCode`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `DateActivityLogged`,
 1 AS `EmployeeThatLoggedTheActivity`,
 1 AS `DateThatActivityLogChanged`,
 1 AS `EmployeeThatChangedTheActivityLog`,
 1 AS `IsDeliveryDiscarded`,
 1 AS `ReasonForDiscardingDelivery`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_read_deliveries`
--

DROP TABLE IF EXISTS `view_read_deliveries`;
/*!50001 DROP VIEW IF EXISTS `view_read_deliveries`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_read_deliveries` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `ContractId`,
 1 AS `DeliveryDate`,
 1 AS `ActivityName`,
 1 AS `ActivityShortName`,
 1 AS `ActivityDescription`,
 1 AS `ActivityDeliveryReportingCode`,
 1 AS `ActivityDeliveryInvoiceCode`,
 1 AS `ActivityDeliverySalaryCode`,
 1 AS `ActivityDeliveryServiceCode`,
 1 AS `ProductCode`,
 1 AS `ProductName`,
 1 AS `ProductDescription`,
 1 AS `OrganizationId`,
 1 AS `OrganizationName`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeInitials`,
 1 AS `EmployeeInfix`,
 1 AS `EmployeeNumberOfHoursWorked`,
 1 AS `EmployeeNumberOfHoursVacation`,
 1 AS `DeliveredByOtherEmployees`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerYearOfBirth`,
 1 AS `CustomerMonthOfBirth`,
 1 AS `CustomerZipCode`,
 1 AS `IsCustomerAbsent`,
 1 AS `IsCustomerAbsencePlanned`,
 1 AS `CustomerReportCode`,
 1 AS `IsCustomerReportSet`,
 1 AS `CustomerReportDate`,
 1 AS `CustomerReportRun`,
 1 AS `CustomerDeclarationCode`,
 1 AS `IsCustomerDeclarationSet`,
 1 AS `CustomerDeclarationDate`,
 1 AS `CustomerDeclarationRun`,
 1 AS `BillableTime`,
 1 AS `TotalDeliveredPerDeliveryPeriod`,
 1 AS `VollumeAssignedByContract`,
 1 AS `DifferenceBetweenDeliveredAndAssigned`,
 1 AS `DeliveryPeriod`,
 1 AS `CustomerRegion`,
 1 AS `ActivityId`,
 1 AS `ActivityDefaultDeclarationCode`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `DateActivityLogged`,
 1 AS `EmployeeThatLoggedTheActivity`,
 1 AS `DateThatActivityLogChanged`,
 1 AS `EmployeeThatChangedTheActivityLog`,
 1 AS `ContractDeliveryPeriod`,
 1 AS `DeliveryType`,
 1 AS `ReasonForDiscardingDelivery`,
 1 AS `CustomerCity`,
 1 AS `ContractEndDate`,
 1 AS `ContractType`,
 1 AS `UploadDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_FINAL`
--

DROP TABLE IF EXISTS `vw_kpi_acc_FINAL`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_FINAL`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_FINAL` AS SELECT 
 1 AS `Version`,
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `RealistatiePNIL`,
 1 AS `RealisatiePIL_Vast`,
 1 AS `RealistatiePIL_Flex`,
 1 AS `RealisatieTOTAAL`,
 1 AS `Norm_declarabele_uren_per_fte_PIL`,
 1 AS `Norm_fte_PIL`,
 1 AS `Formatie_kader_obv_gerealiseerde_uren`,
 1 AS `Contract_PIL_Flex`,
 1 AS `Contract_PIL_Vast`,
 1 AS `Totaal_PIL`,
 1 AS `PNIL_fte_bij_norm_1400`,
 1 AS `formatief_kader_min_inzet`,
 1 AS `Verschil_declarabele_uren_tov_norm`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base` AS SELECT 
 1 AS `Version`,
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base_BILL_perm_FTE`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base_BILL_perm_FTE`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_BILL_perm_FTE`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base_BILL_perm_FTE` AS SELECT 
 1 AS `Version`,
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `PIL_Flex`,
 1 AS `PIL_Vast`,
 1 AS `Totaal_PIL`,
 1 AS `BillableHours_Permanent`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base_BILL_perm_flex_FTE`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base_BILL_perm_flex_FTE`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_BILL_perm_flex_FTE`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base_BILL_perm_flex_FTE` AS SELECT 
 1 AS `Version`,
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `PIL_Flex`,
 1 AS `PIL_Vast`,
 1 AS `Totaal_PIL`,
 1 AS `RealisatiePIL_Vast`,
 1 AS `RealistatiePIL_Flex`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base_BILL_perm_flex_agency_FTE`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base_BILL_perm_flex_agency_FTE`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_BILL_perm_flex_agency_FTE`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base_BILL_perm_flex_agency_FTE` AS SELECT 
 1 AS `Version`,
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `PIL_Flex`,
 1 AS `PIL_Vast`,
 1 AS `Totaal_PIL`,
 1 AS `RealisatiePIL_Vast`,
 1 AS `RealistatiePIL_Flex`,
 1 AS `RealistatiePNIL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base_FINAL`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base_FINAL`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_FINAL`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base_FINAL` AS SELECT 
 1 AS `Version`,
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `PIL_Flex`,
 1 AS `PIL_Vast`,
 1 AS `Totaal_PIL`,
 1 AS `RealisatiePIL_Vast`,
 1 AS `RealistatiePIL_Flex`,
 1 AS `RealistatiePNIL`,
 1 AS `RealisatieTOTAAL`,
 1 AS `Norm_declarabele_uren_per_fte_PIL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base_FTE_flex_perm`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base_FTE_flex_perm`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_FTE_flex_perm`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base_FTE_flex_perm` AS SELECT 
 1 AS `Version`,
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `PIL_Flex`,
 1 AS `PIL_Vast`,
 1 AS `Totaal_PIL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base_billagency_flex_perm`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base_billagency_flex_perm`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_billagency_flex_perm`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base_billagency_flex_perm` AS SELECT 
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `PIL_Flex`,
 1 AS `PIL_Vast`,
 1 AS `Totaal_PIL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base_flex`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base_flex`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_flex`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base_flex` AS SELECT 
 1 AS `Version`,
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `FTE_Flexable`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_base_flex_perm`
--

DROP TABLE IF EXISTS `vw_kpi_acc_base_flex_perm`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_flex_perm`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_base_flex_perm` AS SELECT 
 1 AS `OrganisatieEenheid`,
 1 AS `Functie`,
 1 AS `Norm2018`,
 1 AS `correctie_overheadtaken_CPP`,
 1 AS `PIL_Flex`,
 1 AS `PIL_Vast`,
 1 AS `Totaal_PIL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_billagency`
--

DROP TABLE IF EXISTS `vw_kpi_acc_billagency`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_billagency`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_billagency` AS SELECT 
 1 AS `Version`,
 1 AS `BillableHours_Agencyworkers`,
 1 AS `EmployeeDesignation`,
 1 AS `DepartmentName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_delivery_all_periods`
--

DROP TABLE IF EXISTS `vw_kpi_acc_delivery_all_periods`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_delivery_all_periods`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_delivery_all_periods` AS SELECT 
 1 AS `Version`,
 1 AS `Explanation`,
 1 AS `ContractId`,
 1 AS `DeliveryDate`,
 1 AS `ActivityName`,
 1 AS `ActivityShortName`,
 1 AS `ActivityDescription`,
 1 AS `ActivityDeliveryReportingCode`,
 1 AS `ActivityDeliveryInvoiceCode`,
 1 AS `ActivityDeliverySalaryCode`,
 1 AS `ActivityDeliveryServiceCode`,
 1 AS `ProductCode`,
 1 AS `ProductName`,
 1 AS `ProductDescription`,
 1 AS `OrganizationId`,
 1 AS `OrganizationName`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeInitials`,
 1 AS `EmployeeInfix`,
 1 AS `EmployeeNumberOfHoursWorked`,
 1 AS `EmployeeNumberOfHoursVacation`,
 1 AS `DeliveredByOtherEmployees`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerInfix`,
 1 AS `CustomerYearOfBirth`,
 1 AS `CustomerMonthOfBirth`,
 1 AS `CustomerZipCode`,
 1 AS `IsCustomerAbsent`,
 1 AS `IsCustomerAbsencePlanned`,
 1 AS `CustomerReportCode`,
 1 AS `IsCustomerReportSet`,
 1 AS `CustomerReportDate`,
 1 AS `CustomerReportRun`,
 1 AS `CustomerDeclarationCode`,
 1 AS `IsCustomerDeclarationSet`,
 1 AS `CustomerDeclarationDate`,
 1 AS `CustomerDeclarationRun`,
 1 AS `BillableTime`,
 1 AS `TotalDeliveredPerDeliveryPeriod`,
 1 AS `VolumeAssignedByContract`,
 1 AS `DifferenceBetweenDeliveredAndAssigned`,
 1 AS `DeliveryPeriod`,
 1 AS `CustomerRegion`,
 1 AS `ActivityId`,
 1 AS `ActivityDefaultDeclarationCode`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `DateActivityLogged`,
 1 AS `EmployeeThatLoggedTheActivity`,
 1 AS `DateThatActivityLogChanged`,
 1 AS `EmployeeThatChangedTheActivityLog`,
 1 AS `IsDeliveryDiscarded`,
 1 AS `ReasonForDiscardingDelivery`,
 1 AS `ContractDeliveryPeriod`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_report_billagency`
--

DROP TABLE IF EXISTS `vw_kpi_acc_report_billagency`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_billagency`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_report_billagency` AS SELECT 
 1 AS `Version`,
 1 AS `EmployeeDesignation`,
 1 AS `DepartmentName`,
 1 AS `BillableHours_Agency`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_report_billflex`
--

DROP TABLE IF EXISTS `vw_kpi_acc_report_billflex`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_billflex`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_report_billflex` AS SELECT 
 1 AS `Version`,
 1 AS `EmployeeDesignation`,
 1 AS `DepartmentName`,
 1 AS `BillableHours_Flexible`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_report_billperm`
--

DROP TABLE IF EXISTS `vw_kpi_acc_report_billperm`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_billperm`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_report_billperm` AS SELECT 
 1 AS `Version`,
 1 AS `EmployeeDesignation`,
 1 AS `DepartmentName`,
 1 AS `BillableHours_Permanent`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_report_fteflex`
--

DROP TABLE IF EXISTS `vw_kpi_acc_report_fteflex`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_fteflex`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_report_fteflex` AS SELECT 
 1 AS `Version`,
 1 AS `FTE_Flexable`,
 1 AS `EmployeeDesignation`,
 1 AS `DepartmentName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_kpi_acc_report_fteperm`
--

DROP TABLE IF EXISTS `vw_kpi_acc_report_fteperm`;
/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_fteperm`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_kpi_acc_report_fteperm` AS SELECT 
 1 AS `DepartmentName`,
 1 AS `EmployeeDesignation`,
 1 AS `FTE_Permanent`*/;
SET character_set_client = @saved_cs_client;

--
-- Current Database: `GGMDKPI`
--

USE `GGMDKPI`;

--
-- Final view structure for view `base_view_for_ManagementV1_0_0`
--

/*!50001 DROP VIEW IF EXISTS `base_view_for_ManagementV1_0_0`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `base_view_for_ManagementV1_0_0` AS select 'Author: Sander van Hijfte Last Update Date:06-04-2019' AS `Version`,'Summation of view_delivery_ForKPI_UpToLastWeekV1_0_0 based on EmployeeId. The PerformanceIndicator need to get a proper name but that needs to be fixed later!' AS `Explanation`,'We need to retrieve the record that hold the values of the current month from view_PersonalPerformanceIndicator' AS `Update06042019`,`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeId` AS `EmployeeId`,`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeFirstName` AS `EmployeeFirstName`,`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeInFix` AS `EmployeeInFix`,`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`Employeelastname` AS `EmployeeLastName`,`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeDesignation` AS `EmployeeDesignation`,`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeDepartment` AS `EmployeeDepartment`,if(isnull(`view_PersonalPerformanceIndicator`.`PerformanceIndicator`),0,`view_PersonalPerformanceIndicator`.`PerformanceIndicator`) AS `EmployeePersonalPerformanceIndicator`,sum(`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`BillableHoursPerWeek`) AS `YearToDateNumberOfHoursBillable`,`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeTotalNumberOfHoursVacation` AS `YearToDateNumberOfHoursVacation`,sum(`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`TotalNumberOfHoursWorkedPerWeek`) AS `YearToDateNumberOfHoursWorked`,if(isnull(`view_PersonalPerformanceIndicator`.`PersonalPerformanceIndicator`),0,`view_PersonalPerformanceIndicator`.`PersonalPerformanceIndicator`) AS `EmployeePersonalNorm`,sum(`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`DifferenceBetweenBillableAndWeekNorm`) AS `YearToDateDifferenceBetweenBillableAndWeekNorm` from (`GGMDKPI`.`view_delivery_ForKPI_UpToLastWeekV1_0_0` left join `GGMDKPI`.`view_PersonalPerformanceIndicator` on((`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeId` = `view_PersonalPerformanceIndicator`.`EmployeeContractId`))) where (month(`view_PersonalPerformanceIndicator`.`EmployeeContractStartDate`) = month(curdate())) group by `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_ContractLineDepartment`
--

/*!50001 DROP VIEW IF EXISTS `view_ContractLineDepartment`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_ContractLineDepartment` AS select distinct 'Author: Sander van Hijfte Last Update Date:03-12-2018' AS `Version`,`EmployeeContractLine`.`EmployeeContractId` AS `EmployeeContractId`,`EmployeeContractLine`.`EmployeeContractEndDate` AS `EmployeeContractEndDate`,`EmployeeContractLine`.`EmployeeContractStartDate` AS `EmployeeContractStartDate`,`EmployeeContractLine`.`EmployeeContractNumberOfDaysPerWeek` AS `EmployeeContractNumberOfDaysPerWeek`,`EmployeeContractLine`.`EmployeeContractNumberOfHoursPerWeek` AS `EmployeeContractNumberOfHoursPerWeek`,`EmployeeContractLine`.`EmployeeContractDepartmentId` AS `EmployeeContractDepartmentId`,`EmployeeContractLine`.`EmployeeContractSalaryBasedOnFullTimeEmployment` AS `EmployeeContractSalaryBasedOnFullTimeEmployment`,`EmployeeContractLine`.`EmployeeContractYearSalary` AS `EmployeeContractYearSalary`,`EmployeeContractLine`.`EmployeeDesignationDescription` AS `EmployeeDesignationDescription`,`EmployeeContractLine`.`EmployeeContractLineNormDeviation` AS `EmployeeContractLineNormDeviation`,`Department`.`DepartmentName` AS `DepartmentName` from (`EmployeeContractLine` join `Department`) where (`EmployeeContractLine`.`EmployeeContractDepartmentId` = `Department`.`DepartmentId`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_KPI_WeekNumbers_V1_0_0`
--

/*!50001 DROP VIEW IF EXISTS `view_KPI_WeekNumbers_V1_0_0`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_KPI_WeekNumbers_V1_0_0` AS select distinct 'Author: Sander van Hijfte Last Update Date:17-09-2018' AS `Version`,`view_delivery_ForKPIV1_0_1`.`WeekNumber` AS `weeknumber`,`view_delivery_ForKPIV1_0_1`.`year` AS `year` from `GGMDKPI`.`view_delivery_ForKPIV1_0_1` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_PersonalPerformanceIndicator`
--

/*!50001 DROP VIEW IF EXISTS `view_PersonalPerformanceIndicator`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_PersonalPerformanceIndicator` AS select 'Author: Sander van Hijfte Last Update Date:03-04-2019' AS `Version`,`view_ContractLineDepartment`.`EmployeeContractStartDate` AS `EmployeeContractStartDate`,`view_ContractLineDepartment`.`EmployeeContractEndDate` AS `EmployeeContractEndDate`,`view_ContractLineDepartment`.`EmployeeContractId` AS `EmployeeContractId`,`view_ContractLineDepartment`.`EmployeeDesignationDescription` AS `EmployeeDesignationDescription`,`view_ContractLineDepartment`.`DepartmentName` AS `DepartmentName`,`PerformanceIndicator`.`PerformanceIndicator` AS `PerformanceIndicator`,`view_ContractLineDepartment`.`EmployeeContractNumberOfHoursPerWeek` AS `EmployeeContractNumberOfHoursPerWeek`,(round(((`view_ContractLineDepartment`.`EmployeeContractNumberOfHoursPerWeek` / 36) * `PerformanceIndicator`.`PerformanceIndicator`),2) - `view_ContractLineDepartment`.`EmployeeContractLineNormDeviation`) AS `PersonalPerformanceIndicator` from (`view_ContractLineDepartment` join `PerformanceIndicator`) where ((`view_ContractLineDepartment`.`EmployeeDesignationDescription` = `PerformanceIndicator`.`Designation`) and (`view_ContractLineDepartment`.`DepartmentName` = `PerformanceIndicator`.`Department`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_contract`
--

/*!50001 DROP VIEW IF EXISTS `view_contract`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_contract` AS select 'Author: Sander van Hijfte Last Update Date:31-07-2019' AS `Version`,'I need this view because the age of the customer' AS `Explanation`,`contract`.`ContractId` AS `ContractId`,`contract`.`CustomerIdentifier` AS `CustomerIdentifier`,`contract`.`CustomerNumber` AS `CustomerNumber`,`contract`.`CustomerName` AS `CustomerName`,`contract`.`CustomerTitle` AS `CustomerTitle`,`contract`.`CustomerLastName` AS `CustomerLastName`,`contract`.`CustomerInitials` AS `CustomerInitials`,`contract`.`CustomerFirstName` AS `CustomerFirstName`,`contract`.`CustomerInfix` AS `CustomerInfix`,`contract`.`CustomerDateOfBirth` AS `CustomerDateOfBirth`,`contract`.`CustomerNameAtBirth` AS `CustomerNameAtBirth`,`contract`.`CustomerLastNameAtBirth` AS `CustomerLastNameAtBirth`,`contract`.`CustomerInfixAtBirth` AS `CustomerInfixAtBirth`,`contract`.`CustomerCountryOfBirth` AS `CustomerCountryOfBirth`,`contract`.`CustomerGender` AS `CustomerGender`,`contract`.`CustomerRegion` AS `CustomerRegion`,`contract`.`CustomerStreet` AS `CustomerStreet`,`contract`.`CustomerHouseNumber` AS `CustomerHouseNumber`,`contract`.`CustomerHouseNumberAddition` AS `CustomerHouseNumberAddition`,`contract`.`CustomerZipCode` AS `CustomerZipCode`,`contract`.`CustomerCity` AS `CustomerCity`,`contract`.`CustomerCountry` AS `CustomerCountry`,`contract`.`CustomerSocialSecurityNumber` AS `CustomerSocialSecurityNumber`,`contract`.`CustomerMobilePhone` AS `CustomerMobilePhone`,`contract`.`CustomerEmailAddress` AS `CustomerEmailAddress`,`contract`.`DeliveryOrganizationIdentifier` AS `DeliveryOrganizationIdentifier`,`contract`.`ContractStartDate` AS `ContractStartDate`,`contract`.`ContractEndDate` AS `ContractEndDate`,`contract`.`ContractSubject` AS `ContractSubject`,`contract`.`ProductDescription` AS `ProductDescription`,`contract`.`AdditionalProductDescription` AS `AdditionalProductDescription`,`contract`.`ProductCode` AS `ProductCode`,`contract`.`Volume` AS `Volume`,`contract`.`UnitOfProduct2015` AS `UnitOfProduct2015`,`contract`.`UnitOfProduct` AS `UnitOfProduct`,`contract`.`DeliveryPeriod` AS `DeliveryPeriod`,`contract`.`VolumePerDeliveryPeriod` AS `VolumePerDeliveryPeriod`,`contract`.`MunicipalCode` AS `MunicipalCode`,`contract`.`IsCusomterClassified` AS `IsCusomterClassified`,`contract`.`SupplierCode` AS `SupplierCode`,`contract`.`ContractDateOfAssignment` AS `ContractDateOfAssignment`,`contract`.`ContractReasonToChange` AS `ContractReasonToChange`,`contract`.`ContractRemark` AS `ContractRemark`,`contract`.`ContractReasonForEnding` AS `ContractReasonForEnding`,`contract`.`IsContractDiscarded` AS `IsContractDiscarded`,`contract`.`DiscardedReason` AS `DiscardedReason`,`contract`.`FreelanceCode` AS `FreelanceCode`,`contract`.`FreelanceCategory` AS `FreelanceCategory`,`contract`.`FreelanceWayOfDelivery` AS `FreelanceWayOfDelivery`,`contract`.`IssuingOrganizationId` AS `IssuingOrganizationId`,`contract`.`ContractType` AS `ContractType`,((year(curdate()) - year(str_to_date(concat(substring_index(`contract`.`CustomerDateOfBirth`,'-',-(1)),'-',substring_index(substring_index(`contract`.`CustomerDateOfBirth`,'-',2),'-',-(1)),'-',substring_index(`contract`.`CustomerDateOfBirth`,'-',1)),'%Y-%c-%e'))) - if((concat(year(curdate()),'-',month(str_to_date(concat(substring_index(`contract`.`CustomerDateOfBirth`,'-',-(1)),'-',substring_index(substring_index(`contract`.`CustomerDateOfBirth`,'-',2),'-',-(1)),'-',substring_index(`contract`.`CustomerDateOfBirth`,'-',1)),'%Y-%c-%e')),'-',dayofmonth(str_to_date(concat(substring_index(`contract`.`CustomerDateOfBirth`,'-',-(1)),'-',substring_index(substring_index(`contract`.`CustomerDateOfBirth`,'-',2),'-',-(1)),'-',substring_index(`contract`.`CustomerDateOfBirth`,'-',1)),'%Y-%c-%e'))) > curdate()),1,0)) AS `CustomerAge` from `contract` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_contract1_0_0`
--

/*!50001 DROP VIEW IF EXISTS `view_contract1_0_0`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_contract1_0_0` AS select 'Author: Sander van Hijfte Last Update Date:04-07-2019' AS `Version`,'This view gives the reslt for undiscarded.' AS `Explanation`,`contract`.`ContractId` AS `ContractId`,`contract`.`CustomerIdentifier` AS `CustomerIdentifier`,`contract`.`CustomerNumber` AS `CustomerNumber`,`contract`.`CustomerName` AS `CustomerName`,`contract`.`CustomerTitle` AS `CustomerTitle`,`contract`.`CustomerLastName` AS `CustomerLastName`,`contract`.`CustomerInitials` AS `CustomerInitials`,`contract`.`CustomerFirstName` AS `CustomerFirstName`,`contract`.`CustomerInfix` AS `CustomerInfix`,`contract`.`CustomerDateOfBirth` AS `CustomerDateOfBirth`,`contract`.`CustomerNameAtBirth` AS `CustomerNameAtBirth`,`contract`.`CustomerLastNameAtBirth` AS `CustomerLastNameAtBirth`,`contract`.`CustomerInfixAtBirth` AS `CustomerInfixAtBirth`,`contract`.`CustomerCountryOfBirth` AS `CustomerCountryOfBirth`,`contract`.`CustomerGender` AS `CustomerGender`,`contract`.`CustomerRegion` AS `CustomerRegion`,`contract`.`CustomerStreet` AS `CustomerStreet`,`contract`.`CustomerHouseNumber` AS `CustomerHouseNumber`,`contract`.`CustomerHouseNumberAddition` AS `CustomerHouseNumberAddition`,`contract`.`CustomerZipCode` AS `CustomerZipCode`,`contract`.`CustomerCity` AS `CustomerCity`,`contract`.`CustomerCountry` AS `CustomerCountry`,`contract`.`CustomerSocialSecurityNumber` AS `CustomerSocialSecurityNumber`,`contract`.`CustomerMobilePhone` AS `CustomerMobilePhone`,`contract`.`CustomerEmailAddress` AS `CustomerEmailAddress`,`contract`.`DeliveryOrganizationIdentifier` AS `DeliveryOrganizationIdentifier`,`contract`.`ContractStartDate` AS `ContractStartDate`,`contract`.`ContractEndDate` AS `ContractEndDate`,`contract`.`ContractSubject` AS `ContractSubject`,`contract`.`ProductDescription` AS `ProductDescription`,`contract`.`AdditionalProductDescription` AS `AdditionalProductDescription`,`contract`.`ProductCode` AS `ProductCode`,`contract`.`Volume` AS `Volume`,`contract`.`UnitOfProduct2015` AS `UnitOfProduct2015`,`contract`.`UnitOfProduct` AS `UnitOfProduct`,`contract`.`DeliveryPeriod` AS `DeliveryPeriod`,`contract`.`VolumePerDeliveryPeriod` AS `VolumePerDeliveryPeriod`,`contract`.`MunicipalCode` AS `MunicipalCode`,`contract`.`IsCusomterClassified` AS `IsCusomterClassified`,`contract`.`SupplierCode` AS `SupplierCode`,`contract`.`ContractDateOfAssignment` AS `ContractDateOfAssignment`,`contract`.`ContractReasonToChange` AS `ContractReasonToChange`,`contract`.`ContractRemark` AS `ContractRemark`,`contract`.`ContractReasonForEnding` AS `ContractReasonForEnding`,`contract`.`FreelanceCode` AS `FreelanceCode`,`contract`.`FreelanceCategory` AS `FreelanceCategory`,`contract`.`FreelanceWayOfDelivery` AS `FreelanceWayOfDelivery`,`contract`.`IssuingOrganizationId` AS `IssuingOrganizationId`,`contract`.`ContractType` AS `ContractType` from `contract` where (`contract`.`IsContractDiscarded` = 'false') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_current_EmployeeContractLine`
--

/*!50001 DROP VIEW IF EXISTS `view_current_EmployeeContractLine`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_current_EmployeeContractLine` AS select week(curdate(),0) AS `CURRENTWEEK`,`GGMDRULES`.`ang_delivery`.`EmployeeId` AS `EmployeeId`,`GGMDRULES`.`ang_delivery`.`EmployeeFirstName` AS `EmployeeFirstName`,`GGMDRULES`.`ang_delivery`.`EmployeeInfix` AS `EmployeeInFix`,`GGMDRULES`.`ang_delivery`.`EmployeeLastName` AS `Employeelastname`,`GGMDRULES`.`ang_delivery`.`EmployeeDesignation` AS `EmployeeDesignation`,`GGMDRULES`.`ang_delivery`.`EmployeeDepartment` AS `EmployeeDepartment`,`GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`GGMDRULES`.`ang_delivery`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,week(`GGMDRULES`.`ang_delivery`.`DeliveryDate`,3) AS `WeekNumber`,`GGMDRULES`.`ang_delivery`.`DeliveryDate` AS `DeliveryDate` from `GGMDRULES`.`ang_delivery` where (week(curdate(),0) = week(`GGMDRULES`.`ang_delivery`.`DeliveryDate`,3)) group by `WeekNumber`,`GGMDRULES`.`ang_delivery`.`EmployeeId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_customer_birthday`
--

/*!50001 DROP VIEW IF EXISTS `view_customer_birthday`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_customer_birthday` AS select 'Author: Sander van Hijfte last update: 31-07-2109' AS `Author: Sander van Hijfte last update: 31-07-2109`,'The data of birth is stored as a string in the database and in a Dutch format.For calculating somebody age I need the date of birth in a date format.\n                                ' AS `ExplanationPart1`,substring_index(`contract`.`CustomerDateOfBirth`,'-',1) AS `day`,substring_index(substring_index(`contract`.`CustomerDateOfBirth`,'-',2),'-',-(1)) AS `month`,substring_index(`contract`.`CustomerDateOfBirth`,'-',-(1)) AS `year`,str_to_date(concat(substring_index(`contract`.`CustomerDateOfBirth`,'-',-(1)),'-',substring_index(substring_index(`contract`.`CustomerDateOfBirth`,'-',2),'-',-(1)),'-',substring_index(`contract`.`CustomerDateOfBirth`,'-',1)),'%Y-%c-%e') AS `CalculatedCustomerDateOfBirth`,concat(year(curdate()),'-',month(str_to_date(concat(substring_index(`contract`.`CustomerDateOfBirth`,'-',-(1)),'-',substring_index(substring_index(`contract`.`CustomerDateOfBirth`,'-',2),'-',-(1)),'-',substring_index(`contract`.`CustomerDateOfBirth`,'-',1)),'%Y-%c-%e')),'-',dayofmonth(str_to_date(concat(substring_index(`contract`.`CustomerDateOfBirth`,'-',-(1)),'-',substring_index(substring_index(`contract`.`CustomerDateOfBirth`,'-',2),'-',-(1)),'-',substring_index(`contract`.`CustomerDateOfBirth`,'-',1)),'%Y-%c-%e'))) AS `BirthDay`,`contract`.`CustomerDateOfBirth` AS `CustomerDateOfBirth` from `contract` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_delivery1_0_0`
--

/*!50001 DROP VIEW IF EXISTS `view_delivery1_0_0`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_delivery1_0_0` AS select 'Author: Sander van Hijfte Last Update Date:01-11-2019' AS `Version`,'This view gives the reslt for undiscarded and some the need to be taken into account anyway like NoPossibleContract and NotOnePossibleContract' AS `Explanation`,`GGMDRULES`.`ang_delivery`.`ContractId` AS `ContractId`,`GGMDRULES`.`ang_delivery`.`DeliveryDate` AS `DeliveryDate`,`GGMDRULES`.`ang_delivery`.`ActivityName` AS `ActivityName`,`GGMDRULES`.`ang_delivery`.`ActivityShortName` AS `ActivityShortName`,`GGMDRULES`.`ang_delivery`.`ActivityDescription` AS `ActivityDescription`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryReportingCode` AS `ActivityDeliveryReportingCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryInvoiceCode` AS `ActivityDeliveryInvoiceCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliverySalaryCode` AS `ActivityDeliverySalaryCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryServiceCode` AS `ActivityDeliveryServiceCode`,`GGMDRULES`.`ang_delivery`.`ProductCode` AS `ProductCode`,`GGMDRULES`.`ang_delivery`.`ProductName` AS `ProductName`,`GGMDRULES`.`ang_delivery`.`ProductDescription` AS `ProductDescription`,`GGMDRULES`.`ang_delivery`.`OrganizationId` AS `OrganizationId`,`GGMDRULES`.`ang_delivery`.`OrganizationName` AS `OrganizationName`,`GGMDRULES`.`ang_delivery`.`EmployeeId` AS `EmployeeId`,`GGMDRULES`.`ang_delivery`.`EmployeeLastName` AS `Employeelastname`,`GGMDRULES`.`ang_delivery`.`EmployeeInitials` AS `EmployeeInitials`,`GGMDRULES`.`ang_delivery`.`EmployeeInfix` AS `EmployeeInFix`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursWorked` AS `EmployeeNumberOfHoursWorked`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursVacation` AS `EmployeeNumberOfHoursVacation`,`GGMDRULES`.`ang_delivery`.`DeliveredByOtherEmployees` AS `DeliveredByOtherEmployees`,`GGMDRULES`.`ang_delivery`.`CustomerIdentifier` AS `CustomerIdentifier`,`GGMDRULES`.`ang_delivery`.`CustomerLastName` AS `CustomerLastName`,`GGMDRULES`.`ang_delivery`.`CustomerInitials` AS `CustomerInitials`,`GGMDRULES`.`ang_delivery`.`CustomerYearOfBirth` AS `CustomerYearOfBirth`,`GGMDRULES`.`ang_delivery`.`CustomerMonthOfBirth` AS `CustomerMonthOfBirth`,`GGMDRULES`.`ang_delivery`.`CustomerZipCode` AS `CustomerZipCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerAbsent` AS `IsCustomerAbsent`,`GGMDRULES`.`ang_delivery`.`IsCustomerAbsencePlanned` AS `IsCustomerAbsencePlanned`,`GGMDRULES`.`ang_delivery`.`CustomerReportCode` AS `CustomerReportCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerReportSet` AS `IsCustomerReportSet`,`GGMDRULES`.`ang_delivery`.`CustomerReportDate` AS `CustomerReportDate`,`GGMDRULES`.`ang_delivery`.`CustomerReportRun` AS `CustomerReportRun`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationCode` AS `CustomerDeclarationCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerDeclarationSet` AS `IsCustomerDeclarationSet`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationDate` AS `CustomerDeclarationDate`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationRun` AS `CustomerDeclarationRun`,`GGMDRULES`.`ang_delivery`.`BillableTime` AS `BillableTime`,`GGMDRULES`.`ang_delivery`.`TotalDeliveredPerDeliveryPeriod` AS `TotalDeliveredPerDeliveryPeriod`,`GGMDRULES`.`ang_delivery`.`VolumeAssignedByContract` AS `VollumeAssignedByContract`,`GGMDRULES`.`ang_delivery`.`DifferenceBetweenDeliveredAndAssigned` AS `DifferenceBetweenDeliveredAndAssigned`,`GGMDRULES`.`ang_delivery`.`DeliveryPeriod` AS `DeliveryPeriod`,`GGMDRULES`.`ang_delivery`.`CustomerRegion` AS `CustomerRegion`,`GGMDRULES`.`ang_delivery`.`ActivityId` AS `ActivityId`,`GGMDRULES`.`ang_delivery`.`ActivityDefaultDeclarationCode` AS `ActivityDefaultDeclarationCode`,`GGMDRULES`.`ang_delivery`.`EmployeeFirstName` AS `EmployeeFirstName`,`GGMDRULES`.`ang_delivery`.`EmployeeDepartment` AS `EmployeeDepartment`,`GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`GGMDRULES`.`ang_delivery`.`EmployeeDesignation` AS `EmployeeDesignation`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,`GGMDRULES`.`ang_delivery`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,`GGMDRULES`.`ang_delivery`.`DateActivityLogged` AS `DateActivityLogged`,`GGMDRULES`.`ang_delivery`.`EmployeeThatLoggedTheActivity` AS `EmployeeThatLoggedTheActivity`,`GGMDRULES`.`ang_delivery`.`DateThatActivityLogChanged` AS `DateThatActivityLogChanged`,`GGMDRULES`.`ang_delivery`.`EmployeeThatChangedTheActivityLog` AS `EmployeeThatChangedTheActivityLog`,`GGMDRULES`.`ang_delivery`.`ContractDeliveryPeriod` AS `ContractDeliveryPeriod`,`GGMDRULES`.`ang_delivery`.`DeliveryType` AS `DeliveryType`,`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` AS `ReasonForDiscardingDelivery`,`GGMDKPI`.`contract`.`CustomerCity` AS `CustomerCity`,`GGMDKPI`.`UploadDate`.`UploadDate` AS `UploadDate` from ((`GGMDRULES`.`ang_delivery` left join `GGMDKPI`.`contract` on((`GGMDRULES`.`ang_delivery`.`ContractId` = `GGMDKPI`.`contract`.`ContractId`))) join `GGMDKPI`.`UploadDate`) where ((`GGMDRULES`.`ang_delivery`.`IsDeliveryDiscarded` = 'false') or (`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` = 'NotOnePossibleContract') or (`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` = 'NoValidDeliveryPeriod') or (`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` = 'NoDesignationDefined')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_delivery_ForKPIV1_0_1`
--

/*!50001 DROP VIEW IF EXISTS `view_delivery_ForKPIV1_0_1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_delivery_ForKPIV1_0_1` AS select 'Author: Sander van Hijfte Last Update Date:01-11-2019' AS `Version`,'Summation of the data from delivery based on EmployeeId and WeekNumber complemented with the Performanceindicator from PerformanceIndicator' AS `Explanation`,'I have added the EmployeeContract.EmployeeContractNumberOfHoursPerWeek' AS `Update 04-04-2019`,`GGMDRULES`.`ang_delivery`.`EmployeeId` AS `EmployeeId`,`GGMDRULES`.`ang_delivery`.`EmployeeFirstName` AS `EmployeeFirstName`,`GGMDRULES`.`ang_delivery`.`EmployeeInfix` AS `EmployeeInfix`,`GGMDRULES`.`ang_delivery`.`EmployeeLastName` AS `EmployeeLastName`,`GGMDRULES`.`ang_delivery`.`EmployeeDesignation` AS `EmployeeDesignation`,`GGMDRULES`.`ang_delivery`.`EmployeeDepartment` AS `EmployeeDepartment`,`GGMDKPI`.`PerformanceIndicator`.`PerformanceIndicator` AS `PerformanceIndicator`,`GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalNorm`,`GGMDRULES`.`ang_delivery`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,week(`GGMDRULES`.`ang_delivery`.`DeliveryDate`,3) AS `WeekNumber`,month(`GGMDRULES`.`ang_delivery`.`DeliveryDate`) AS `MonthNumber`,concat(' ',monthname(`GGMDRULES`.`ang_delivery`.`DeliveryDate`)) AS `Data`,year(`GGMDRULES`.`ang_delivery`.`DeliveryDate`) AS `year`,round((sum(`GGMDRULES`.`ang_delivery`.`BillableTime`) / 3600),2) AS `BillableHoursPerWeek`,round((sum(`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursWorked`) / 3600),2) AS `TotalNumberOfHoursWorkedPerWeek`,round((sum(`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursVacation`) / 3600),2) AS `TotalNumberOfHoursVacationPerWeek`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,round((((((`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` * 3600) - sum(`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursVacation`)) / (`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` * 3600)) * `GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator`) / (52 - (52 * 0.1340))),2) AS `EmployeeWeekNorm`,round(((sum(`GGMDRULES`.`ang_delivery`.`BillableTime`) / 3600) - (((((`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` * 3600) - sum(`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursVacation`)) / (`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` * 3600)) * `GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator`) / (52 - (52 * 0.1340)))),2) AS `DifferenceBetweenBillableAndWeekNorm`,`GGMDKPI`.`EmployeeContract`.`EmployeeContractNumberOfHoursPerWeek` AS `EmployeeCurrentNumberOfHoursPerWeek` from ((`GGMDRULES`.`ang_delivery` join `GGMDKPI`.`PerformanceIndicator`) join `GGMDKPI`.`EmployeeContract`) where ((`GGMDRULES`.`ang_delivery`.`EmployeeDepartment` = `GGMDKPI`.`PerformanceIndicator`.`Department`) and (`GGMDRULES`.`ang_delivery`.`EmployeeId` = `GGMDKPI`.`EmployeeContract`.`EmployeeContractId`) and (`GGMDRULES`.`ang_delivery`.`EmployeeDesignation` = `GGMDKPI`.`PerformanceIndicator`.`Designation`) and ((`GGMDRULES`.`ang_delivery`.`IsDeliveryDiscarded` = 'false') or (`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` in ('NotOnePossibleContract','NoValidDeliveryPeriod','NoPossibleContractId','NotWMO')))) group by `WeekNumber`,`GGMDRULES`.`ang_delivery`.`EmployeeId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_delivery_ForKPI_ManagementV1_0_0`
--

/*!50001 DROP VIEW IF EXISTS `view_delivery_ForKPI_ManagementV1_0_0`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_delivery_ForKPI_ManagementV1_0_0` AS select 'Author: Sander van Hijfte Last Update Date:18-09-2018' AS `Version`,'The source of view_delivery_ForKPI_Management is base_view_for_Management, it adds the EmployeeDifferenceBetweenCorrectedNormAndBillable of the current week which it retrieves from view_delivery_ForKPI' AS `Explanation`,`base_view_for_ManagementV1_0_0`.`EmployeeId` AS `EmployeeId`,`base_view_for_ManagementV1_0_0`.`EmployeeFirstName` AS `EmployeeFirstName`,`base_view_for_ManagementV1_0_0`.`EmployeeInFix` AS `EmployeeInFix`,`base_view_for_ManagementV1_0_0`.`EmployeeLastName` AS `EmployeeLastName`,`base_view_for_ManagementV1_0_0`.`EmployeeDesignation` AS `EmployeeDesignation`,`base_view_for_ManagementV1_0_0`.`EmployeeDepartment` AS `EmployeeDepartment`,`base_view_for_ManagementV1_0_0`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`base_view_for_ManagementV1_0_0`.`EmployeePersonalNorm` AS `EmployeePersonalNorm`,`base_view_for_ManagementV1_0_0`.`YearToDateNumberOfHoursBillable` AS `YearToDateNumberOfHoursBillable`,`base_view_for_ManagementV1_0_0`.`YearToDateNumberOfHoursVacation` AS `YearToDateNumberOfHoursVacation`,`base_view_for_ManagementV1_0_0`.`YearToDateNumberOfHoursWorked` AS `YearToDateNumberOfHoursWorked`,`base_view_for_ManagementV1_0_0`.`YearToDateDifferenceBetweenBillableAndWeekNorm` AS `YearToDateDifferenceBetweenBillableAndWeekNorm`,week(curdate(),3) AS `WeekNumber`,if(isnull(`view_delivery_ForKPIV1_0_1`.`DifferenceBetweenBillableAndWeekNorm`),'GEEN',`view_delivery_ForKPIV1_0_1`.`DifferenceBetweenBillableAndWeekNorm`) AS `DifferenceBetweenBillableAndWeekNorm` from (`GGMDKPI`.`base_view_for_ManagementV1_0_0` left join `GGMDKPI`.`view_delivery_ForKPIV1_0_1` on(((`base_view_for_ManagementV1_0_0`.`EmployeeId` = `view_delivery_ForKPIV1_0_1`.`EmployeeId`) and (`view_delivery_ForKPIV1_0_1`.`WeekNumber` = (week(curdate(),3) - 1))))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_delivery_ForKPI_UpToLastWeekV1_0_0`
--

/*!50001 DROP VIEW IF EXISTS `view_delivery_ForKPI_UpToLastWeekV1_0_0`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_delivery_ForKPI_UpToLastWeekV1_0_0` AS select `view_delivery_ForKPIV1_0_1`.`Version` AS `Version`,`view_delivery_ForKPIV1_0_1`.`Explanation` AS `Explanation`,`view_delivery_ForKPIV1_0_1`.`EmployeeId` AS `EmployeeId`,`view_delivery_ForKPIV1_0_1`.`EmployeeFirstName` AS `EmployeeFirstName`,`view_delivery_ForKPIV1_0_1`.`EmployeeInfix` AS `EmployeeInFix`,`view_delivery_ForKPIV1_0_1`.`EmployeeLastName` AS `Employeelastname`,`view_delivery_ForKPIV1_0_1`.`EmployeeDesignation` AS `EmployeeDesignation`,`view_delivery_ForKPIV1_0_1`.`EmployeeDepartment` AS `EmployeeDepartment`,`view_delivery_ForKPIV1_0_1`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`view_delivery_ForKPIV1_0_1`.`EmployeePersonalNorm` AS `EmployeePersonalNorm`,`view_delivery_ForKPIV1_0_1`.`WeekNumber` AS `WeekNumber`,`view_delivery_ForKPIV1_0_1`.`MonthNumber` AS `MonthNumber`,`view_delivery_ForKPIV1_0_1`.`Data` AS `Data`,`view_delivery_ForKPIV1_0_1`.`year` AS `year`,`view_delivery_ForKPIV1_0_1`.`BillableHoursPerWeek` AS `BillableHoursPerWeek`,`view_delivery_ForKPIV1_0_1`.`TotalNumberOfHoursWorkedPerWeek` AS `TotalNumberOfHoursWorkedPerWeek`,`view_delivery_ForKPIV1_0_1`.`TotalNumberOfHoursVacationPerWeek` AS `TotalNumberOfHoursVacationPerWeek`,`view_delivery_ForKPIV1_0_1`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,`view_delivery_ForKPIV1_0_1`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,`view_delivery_ForKPIV1_0_1`.`EmployeeWeekNorm` AS `EmployeeWeekNorm`,`view_delivery_ForKPIV1_0_1`.`DifferenceBetweenBillableAndWeekNorm` AS `DifferenceBetweenBillableAndWeekNorm`,(week(curdate(),3) - 1) AS `LastWeek` from `GGMDKPI`.`view_delivery_ForKPIV1_0_1` where (`view_delivery_ForKPIV1_0_1`.`WeekNumber` < week(curdate(),3)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_double_contracts`
--

/*!50001 DROP VIEW IF EXISTS `view_double_contracts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_double_contracts` AS select 'Author: Renée van Hijfte Last Update Date:01-07-2019' AS `Version`,'craete this view to see all the double views' AS `Explanation`,`EmployeeContract`.`EmployeeContractEmployeeId` AS `EmployeeContractEmployeeId`,count(0) AS `count(*)` from `EmployeeContract` group by `EmployeeContract`.`EmployeeContractEmployeeId` having (count(0) > 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_double_contracts_with_dates`
--

/*!50001 DROP VIEW IF EXISTS `view_double_contracts_with_dates`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_double_contracts_with_dates` AS select 'Author: Renée van Hijfte Last Update Date:01-07-2019' AS `Version`,'craete this view to see all the double views' AS `Explanation`,`EmployeeContract`.`EmployeeContractId` AS `EmployeeContractId`,`EmployeeContract`.`EmployeeContractEmployeeId` AS `EmployeeContractEmployeeId`,`EmployeeContract`.`EmployeeContractStartDate` AS `EmployeeContractStartDate` from (`EmployeeContract` join `view_double_contracts` on((`EmployeeContract`.`EmployeeContractEmployeeId` = `view_double_contracts`.`EmployeeContractEmployeeId`))) order by `EmployeeContract`.`EmployeeContractEmployeeId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_productionReportV1_0_0`
--

/*!50001 DROP VIEW IF EXISTS `view_productionReportV1_0_0`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_productionReportV1_0_0` AS select `GGMDRULES`.`ang_delivery`.`ContractId` AS `ContractId`,`GGMDRULES`.`ang_delivery`.`DeliveryDate` AS `DeliveryDate`,`GGMDRULES`.`ang_delivery`.`ActivityName` AS `ActivityName`,`GGMDRULES`.`ang_delivery`.`ActivityShortName` AS `ActivityShortName`,`GGMDRULES`.`ang_delivery`.`ActivityDescription` AS `ActivityDescription`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryReportingCode` AS `ActivityDeliveryReportingCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryInvoiceCode` AS `ActivityDeliveryInvoiceCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliverySalaryCode` AS `ActivityDeliverySalaryCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryServiceCode` AS `ActivityDeliveryServiceCode`,`GGMDRULES`.`ang_delivery`.`ProductCode` AS `ProductCode`,`GGMDRULES`.`ang_delivery`.`ProductName` AS `ProductName`,`GGMDRULES`.`ang_delivery`.`ProductDescription` AS `ProductDescription`,`GGMDRULES`.`ang_delivery`.`OrganizationId` AS `OrganizationId`,`GGMDRULES`.`ang_delivery`.`OrganizationName` AS `OrganizationName`,`GGMDRULES`.`ang_delivery`.`EmployeeId` AS `EmployeeId`,`GGMDRULES`.`ang_delivery`.`EmployeeLastName` AS `EmployeeLastName`,`GGMDRULES`.`ang_delivery`.`EmployeeInitials` AS `EmployeeInitials`,`GGMDRULES`.`ang_delivery`.`EmployeeInfix` AS `EmployeeInfix`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursWorked` AS `EmployeeNumberOfHoursWorked`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursVacation` AS `EmployeeNumberOfHoursVacation`,`GGMDRULES`.`ang_delivery`.`DeliveredByOtherEmployees` AS `DeliveredByOtherEmployees`,`GGMDRULES`.`ang_delivery`.`CustomerIdentifier` AS `CustomerIdentifier`,`GGMDRULES`.`ang_delivery`.`CustomerLastName` AS `CustomerLastName`,`GGMDRULES`.`ang_delivery`.`CustomerInitials` AS `CustomerInitials`,`GGMDRULES`.`ang_delivery`.`CustomerInfix` AS `CustomerInfix`,`GGMDRULES`.`ang_delivery`.`CustomerYearOfBirth` AS `CustomerYearOfBirth`,`GGMDRULES`.`ang_delivery`.`CustomerMonthOfBirth` AS `CustomerMonthOfBirth`,`GGMDRULES`.`ang_delivery`.`CustomerZipCode` AS `CustomerZipCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerAbsent` AS `IsCustomerAbsent`,`GGMDRULES`.`ang_delivery`.`IsCustomerAbsencePlanned` AS `IsCustomerAbsencePlanned`,`GGMDRULES`.`ang_delivery`.`CustomerReportCode` AS `CustomerReportCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerReportSet` AS `IsCustomerReportSet`,`GGMDRULES`.`ang_delivery`.`CustomerReportDate` AS `CustomerReportDate`,`GGMDRULES`.`ang_delivery`.`CustomerReportRun` AS `CustomerReportRun`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationCode` AS `CustomerDeclarationCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerDeclarationSet` AS `IsCustomerDeclarationSet`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationDate` AS `CustomerDeclarationDate`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationRun` AS `CustomerDeclarationRun`,`GGMDRULES`.`ang_delivery`.`BillableTime` AS `BillableTime`,`GGMDRULES`.`ang_delivery`.`TotalDeliveredPerDeliveryPeriod` AS `TotalDeliveredPerDeliveryPeriod`,`GGMDRULES`.`ang_delivery`.`VolumeAssignedByContract` AS `VolumeAssignedByContract`,`GGMDRULES`.`ang_delivery`.`DifferenceBetweenDeliveredAndAssigned` AS `DifferenceBetweenDeliveredAndAssigned`,`GGMDRULES`.`ang_delivery`.`DeliveryPeriod` AS `DeliveryPeriod`,`GGMDRULES`.`ang_delivery`.`CustomerRegion` AS `CustomerRegion`,`GGMDRULES`.`ang_delivery`.`ActivityId` AS `ActivityId`,`GGMDRULES`.`ang_delivery`.`ActivityDefaultDeclarationCode` AS `ActivityDefaultDeclarationCode`,`GGMDRULES`.`ang_delivery`.`EmployeeFirstName` AS `EmployeeFirstName`,`GGMDRULES`.`ang_delivery`.`EmployeeDepartment` AS `EmployeeDepartment`,`GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`GGMDRULES`.`ang_delivery`.`EmployeeDesignation` AS `EmployeeDesignation`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,`GGMDRULES`.`ang_delivery`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,`GGMDRULES`.`ang_delivery`.`DateActivityLogged` AS `DateActivityLogged`,`GGMDRULES`.`ang_delivery`.`EmployeeThatLoggedTheActivity` AS `EmployeeThatLoggedTheActivity`,`GGMDRULES`.`ang_delivery`.`DateThatActivityLogChanged` AS `DateThatActivityLogChanged`,`GGMDRULES`.`ang_delivery`.`EmployeeThatChangedTheActivityLog` AS `EmployeeThatChangedTheActivityLog`,`GGMDRULES`.`ang_delivery`.`IsDeliveryDiscarded` AS `IsDeliveryDiscarded`,`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` AS `ReasonForDiscardingDelivery` from `GGMDRULES`.`ang_delivery` where (`GGMDRULES`.`ang_delivery`.`ContractId` in (select distinct `GGMDKPI`.`contract`.`ContractId` from `GGMDKPI`.`contract` where (`GGMDKPI`.`contract`.`ContractEndDate` > '2018-01-01')) and (`GGMDRULES`.`ang_delivery`.`ProductCode` in (1103,2497,2499,2500,2970))) union select `GGMDRULES`.`ang_delivery`.`ContractId` AS `ContractId`,`GGMDRULES`.`ang_delivery`.`DeliveryDate` AS `DeliveryDate`,`GGMDRULES`.`ang_delivery`.`ActivityName` AS `ActivityName`,`GGMDRULES`.`ang_delivery`.`ActivityShortName` AS `ActivityShortName`,`GGMDRULES`.`ang_delivery`.`ActivityDescription` AS `ActivityDescription`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryReportingCode` AS `ActivityDeliveryReportingCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryInvoiceCode` AS `ActivityDeliveryInvoiceCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliverySalaryCode` AS `ActivityDeliverySalaryCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryServiceCode` AS `ActivityDeliveryServiceCode`,`GGMDRULES`.`ang_delivery`.`ProductCode` AS `ProductCode`,`GGMDRULES`.`ang_delivery`.`ProductName` AS `ProductName`,`GGMDRULES`.`ang_delivery`.`ProductDescription` AS `ProductDescription`,`GGMDRULES`.`ang_delivery`.`OrganizationId` AS `OrganizationId`,`GGMDRULES`.`ang_delivery`.`OrganizationName` AS `OrganizationName`,`GGMDRULES`.`ang_delivery`.`EmployeeId` AS `EmployeeId`,`GGMDRULES`.`ang_delivery`.`EmployeeLastName` AS `EmployeeLastName`,`GGMDRULES`.`ang_delivery`.`EmployeeInitials` AS `EmployeeInitials`,`GGMDRULES`.`ang_delivery`.`EmployeeInfix` AS `EmployeeInfix`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursWorked` AS `EmployeeNumberOfHoursWorked`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursVacation` AS `EmployeeNumberOfHoursVacation`,`GGMDRULES`.`ang_delivery`.`DeliveredByOtherEmployees` AS `DeliveredByOtherEmployees`,`GGMDRULES`.`ang_delivery`.`CustomerIdentifier` AS `CustomerIdentifier`,`GGMDRULES`.`ang_delivery`.`CustomerLastName` AS `CustomerLastName`,`GGMDRULES`.`ang_delivery`.`CustomerInitials` AS `CustomerInitials`,`GGMDRULES`.`ang_delivery`.`CustomerInfix` AS `CustomerInfix`,`GGMDRULES`.`ang_delivery`.`CustomerYearOfBirth` AS `CustomerYearOfBirth`,`GGMDRULES`.`ang_delivery`.`CustomerMonthOfBirth` AS `CustomerMonthOfBirth`,`GGMDRULES`.`ang_delivery`.`CustomerZipCode` AS `CustomerZipCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerAbsent` AS `IsCustomerAbsent`,`GGMDRULES`.`ang_delivery`.`IsCustomerAbsencePlanned` AS `IsCustomerAbsencePlanned`,`GGMDRULES`.`ang_delivery`.`CustomerReportCode` AS `CustomerReportCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerReportSet` AS `IsCustomerReportSet`,`GGMDRULES`.`ang_delivery`.`CustomerReportDate` AS `CustomerReportDate`,`GGMDRULES`.`ang_delivery`.`CustomerReportRun` AS `CustomerReportRun`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationCode` AS `CustomerDeclarationCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerDeclarationSet` AS `IsCustomerDeclarationSet`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationDate` AS `CustomerDeclarationDate`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationRun` AS `CustomerDeclarationRun`,`GGMDRULES`.`ang_delivery`.`BillableTime` AS `BillableTime`,`GGMDRULES`.`ang_delivery`.`TotalDeliveredPerDeliveryPeriod` AS `TotalDeliveredPerDeliveryPeriod`,(10 / 13) AS `VolumeAssignedByContract`,`GGMDRULES`.`ang_delivery`.`DifferenceBetweenDeliveredAndAssigned` AS `DifferenceBetweenDeliveredAndAssigned`,`GGMDRULES`.`ang_delivery`.`DeliveryPeriod` AS `DeliveryPeriod`,`GGMDRULES`.`ang_delivery`.`CustomerRegion` AS `CustomerRegion`,`GGMDRULES`.`ang_delivery`.`ActivityId` AS `ActivityId`,`GGMDRULES`.`ang_delivery`.`ActivityDefaultDeclarationCode` AS `ActivityDefaultDeclarationCode`,`GGMDRULES`.`ang_delivery`.`EmployeeFirstName` AS `EmployeeFirstName`,`GGMDRULES`.`ang_delivery`.`EmployeeDepartment` AS `EmployeeDepartment`,`GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`GGMDRULES`.`ang_delivery`.`EmployeeDesignation` AS `EmployeeDesignation`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,`GGMDRULES`.`ang_delivery`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,`GGMDRULES`.`ang_delivery`.`DateActivityLogged` AS `DateActivityLogged`,`GGMDRULES`.`ang_delivery`.`EmployeeThatLoggedTheActivity` AS `EmployeeThatLoggedTheActivity`,`GGMDRULES`.`ang_delivery`.`DateThatActivityLogChanged` AS `DateThatActivityLogChanged`,`GGMDRULES`.`ang_delivery`.`EmployeeThatChangedTheActivityLog` AS `EmployeeThatChangedTheActivityLog`,`GGMDRULES`.`ang_delivery`.`IsDeliveryDiscarded` AS `IsDeliveryDiscarded`,`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` AS `ReasonForDiscardingDelivery` from `GGMDRULES`.`ang_delivery` where ((not(`GGMDRULES`.`ang_delivery`.`ContractId` in (select distinct `GGMDKPI`.`contract`.`ContractId` from `GGMDKPI`.`contract` where (`GGMDKPI`.`contract`.`ContractEndDate` > '2018-01-01')))) and (`GGMDRULES`.`ang_delivery`.`ProductCode` = '2500')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_read_deliveries`
--

/*!50001 DROP VIEW IF EXISTS `view_read_deliveries`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_read_deliveries` AS select 'Author: Sander van Hijfte Last Update Date:01-11-2019' AS `Version`,'This view delivers the data for the ReadDeliveries stored procedure' AS `Explanation`,`GGMDRULES`.`ang_delivery`.`ContractId` AS `ContractId`,`GGMDRULES`.`ang_delivery`.`DeliveryDate` AS `DeliveryDate`,`GGMDRULES`.`ang_delivery`.`ActivityName` AS `ActivityName`,`GGMDRULES`.`ang_delivery`.`ActivityShortName` AS `ActivityShortName`,`GGMDRULES`.`ang_delivery`.`ActivityDescription` AS `ActivityDescription`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryReportingCode` AS `ActivityDeliveryReportingCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryInvoiceCode` AS `ActivityDeliveryInvoiceCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliverySalaryCode` AS `ActivityDeliverySalaryCode`,`GGMDRULES`.`ang_delivery`.`ActivityDeliveryServiceCode` AS `ActivityDeliveryServiceCode`,`GGMDRULES`.`ang_delivery`.`ProductCode` AS `ProductCode`,`GGMDRULES`.`ang_delivery`.`ProductName` AS `ProductName`,`GGMDRULES`.`ang_delivery`.`ProductDescription` AS `ProductDescription`,`GGMDRULES`.`ang_delivery`.`OrganizationId` AS `OrganizationId`,`GGMDRULES`.`ang_delivery`.`OrganizationName` AS `OrganizationName`,`GGMDRULES`.`ang_delivery`.`EmployeeId` AS `EmployeeId`,`GGMDRULES`.`ang_delivery`.`EmployeeLastName` AS `EmployeeLastName`,`GGMDRULES`.`ang_delivery`.`EmployeeInitials` AS `EmployeeInitials`,`GGMDRULES`.`ang_delivery`.`EmployeeInfix` AS `EmployeeInfix`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursWorked` AS `EmployeeNumberOfHoursWorked`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursVacation` AS `EmployeeNumberOfHoursVacation`,`GGMDRULES`.`ang_delivery`.`DeliveredByOtherEmployees` AS `DeliveredByOtherEmployees`,`GGMDRULES`.`ang_delivery`.`CustomerIdentifier` AS `CustomerIdentifier`,`GGMDRULES`.`ang_delivery`.`CustomerLastName` AS `CustomerLastName`,`GGMDRULES`.`ang_delivery`.`CustomerInitials` AS `CustomerInitials`,`GGMDRULES`.`ang_delivery`.`CustomerYearOfBirth` AS `CustomerYearOfBirth`,`GGMDRULES`.`ang_delivery`.`CustomerMonthOfBirth` AS `CustomerMonthOfBirth`,`GGMDRULES`.`ang_delivery`.`CustomerZipCode` AS `CustomerZipCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerAbsent` AS `IsCustomerAbsent`,`GGMDRULES`.`ang_delivery`.`IsCustomerAbsencePlanned` AS `IsCustomerAbsencePlanned`,`GGMDRULES`.`ang_delivery`.`CustomerReportCode` AS `CustomerReportCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerReportSet` AS `IsCustomerReportSet`,`GGMDRULES`.`ang_delivery`.`CustomerReportDate` AS `CustomerReportDate`,`GGMDRULES`.`ang_delivery`.`CustomerReportRun` AS `CustomerReportRun`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationCode` AS `CustomerDeclarationCode`,`GGMDRULES`.`ang_delivery`.`IsCustomerDeclarationSet` AS `IsCustomerDeclarationSet`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationDate` AS `CustomerDeclarationDate`,`GGMDRULES`.`ang_delivery`.`CustomerDeclarationRun` AS `CustomerDeclarationRun`,`GGMDRULES`.`ang_delivery`.`BillableTime` AS `BillableTime`,`GGMDRULES`.`ang_delivery`.`TotalDeliveredPerDeliveryPeriod` AS `TotalDeliveredPerDeliveryPeriod`,`GGMDRULES`.`ang_delivery`.`VolumeAssignedByContract` AS `VollumeAssignedByContract`,`GGMDRULES`.`ang_delivery`.`DifferenceBetweenDeliveredAndAssigned` AS `DifferenceBetweenDeliveredAndAssigned`,`GGMDRULES`.`ang_delivery`.`DeliveryPeriod` AS `DeliveryPeriod`,if((length(`GGMDRULES`.`ang_delivery`.`CustomerRegion`) > 0),`GGMDRULES`.`ang_delivery`.`CustomerRegion`,'GEEN CONTRACT') AS `CustomerRegion`,`GGMDRULES`.`ang_delivery`.`ActivityId` AS `ActivityId`,`GGMDRULES`.`ang_delivery`.`ActivityDefaultDeclarationCode` AS `ActivityDefaultDeclarationCode`,`GGMDRULES`.`ang_delivery`.`EmployeeFirstName` AS `EmployeeFirstName`,`GGMDRULES`.`ang_delivery`.`EmployeeDepartment` AS `EmployeeDepartment`,`GGMDRULES`.`ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`GGMDRULES`.`ang_delivery`.`EmployeeDesignation` AS `EmployeeDesignation`,`GGMDRULES`.`ang_delivery`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,`GGMDRULES`.`ang_delivery`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,`GGMDRULES`.`ang_delivery`.`DateActivityLogged` AS `DateActivityLogged`,`GGMDRULES`.`ang_delivery`.`EmployeeThatLoggedTheActivity` AS `EmployeeThatLoggedTheActivity`,`GGMDRULES`.`ang_delivery`.`DateThatActivityLogChanged` AS `DateThatActivityLogChanged`,`GGMDRULES`.`ang_delivery`.`EmployeeThatChangedTheActivityLog` AS `EmployeeThatChangedTheActivityLog`,`GGMDRULES`.`ang_delivery`.`ContractDeliveryPeriod` AS `ContractDeliveryPeriod`,`GGMDRULES`.`ang_delivery`.`DeliveryType` AS `DeliveryType`,`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` AS `ReasonForDiscardingDelivery`,if(length((`GGMDKPI`.`contract`.`CustomerCity` > 0)),`GGMDKPI`.`contract`.`CustomerCity`,'GEEN CONTRACT') AS `CustomerCity`,if(length((`GGMDKPI`.`contract`.`ContractEndDate` > 0)),`GGMDKPI`.`contract`.`ContractEndDate`,'0000-00-00') AS `ContractEndDate`,if(length((`GGMDKPI`.`contract`.`ContractType` > 0)),`GGMDKPI`.`contract`.`ContractType`,'GEEN CONTRACT') AS `ContractType`,`GGMDKPI`.`UploadDate`.`UploadDate` AS `UploadDate` from ((`GGMDRULES`.`ang_delivery` left join `GGMDKPI`.`contract` on((`GGMDRULES`.`ang_delivery`.`ContractId` = `GGMDKPI`.`contract`.`ContractId`))) join `GGMDKPI`.`UploadDate`) where (((`GGMDRULES`.`ang_delivery`.`IsDeliveryDiscarded` = 'false') or (`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` = 'NotOnePossibleContract') or (`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` = 'NoDesignationDefined') or (`GGMDRULES`.`ang_delivery`.`ReasonForDiscardingDelivery` = 'NoPossibleContractId')) and (`GGMDRULES`.`ang_delivery`.`BillableTime` > 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_FINAL`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_FINAL`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_FINAL` AS select 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,`vw_kpi_acc_base_FINAL`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base_FINAL`.`Functie` AS `Functie`,`vw_kpi_acc_base_FINAL`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base_FINAL`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,`vw_kpi_acc_base_FINAL`.`RealistatiePNIL` AS `RealistatiePNIL`,`vw_kpi_acc_base_FINAL`.`RealisatiePIL_Vast` AS `RealisatiePIL_Vast`,`vw_kpi_acc_base_FINAL`.`RealistatiePIL_Flex` AS `RealistatiePIL_Flex`,`vw_kpi_acc_base_FINAL`.`RealisatieTOTAAL` AS `RealisatieTOTAAL`,`vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL` AS `Norm_declarabele_uren_per_fte_PIL`,round(if((`vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL` = 0),0,(`vw_kpi_acc_base_FINAL`.`RealisatieTOTAAL` / `vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL`)),2) AS `Norm_fte_PIL`,(round(if((`vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL` = 0),0,(`vw_kpi_acc_base_FINAL`.`RealisatieTOTAAL` / `vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL`)),2) + `vw_kpi_acc_base_FINAL`.`correctie_overheadtaken_CPP`) AS `Formatie_kader_obv_gerealiseerde_uren`,`vw_kpi_acc_base_FINAL`.`PIL_Flex` AS `Contract_PIL_Flex`,`vw_kpi_acc_base_FINAL`.`PIL_Vast` AS `Contract_PIL_Vast`,`vw_kpi_acc_base_FINAL`.`Totaal_PIL` AS `Totaal_PIL`,round((`vw_kpi_acc_base_FINAL`.`RealistatiePNIL` * ((1400 * month(curdate())) / 12)),2) AS `PNIL_fte_bij_norm_1400`,round((((if((`vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL` = 0),0,(`vw_kpi_acc_base_FINAL`.`RealisatieTOTAAL` / `vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL`)) + `vw_kpi_acc_base_FINAL`.`correctie_overheadtaken_CPP`) - `vw_kpi_acc_base_FINAL`.`Totaal_PIL`) - (`vw_kpi_acc_base_FINAL`.`RealistatiePNIL` * ((1400 * month(curdate())) / 12))),2) AS `formatief_kader_min_inzet`,round(((((if((`vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL` = 0),0,(`vw_kpi_acc_base_FINAL`.`RealisatieTOTAAL` / `vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL`)) + `vw_kpi_acc_base_FINAL`.`correctie_overheadtaken_CPP`) - `vw_kpi_acc_base_FINAL`.`Totaal_PIL`) - (`vw_kpi_acc_base_FINAL`.`RealistatiePNIL` * ((1400 * month(curdate())) / 12))) * `vw_kpi_acc_base_FINAL`.`Norm_declarabele_uren_per_fte_PIL`),2) AS `Verschil_declarabele_uren_tov_norm` from `vw_kpi_acc_base_FINAL` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base` AS select distinct 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,`PerformanceIndicator`.`Department` AS `OrganisatieEenheid`,`PerformanceIndicator`.`Designation` AS `Functie`,`PerformanceIndicator`.`PerformanceIndicator` AS `Norm2018`,`PerformanceIndicator`.`Overhead` AS `correctie_overheadtaken_CPP` from (`PerformanceIndicator` join `Department`) where (`PerformanceIndicator`.`Department` = `Department`.`DepartmentName`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base_BILL_perm_FTE`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_BILL_perm_FTE`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base_BILL_perm_FTE` AS select 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,`vw_kpi_acc_base_FTE_flex_perm`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base_FTE_flex_perm`.`Functie` AS `Functie`,`vw_kpi_acc_base_FTE_flex_perm`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base_FTE_flex_perm`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,`vw_kpi_acc_base_FTE_flex_perm`.`PIL_Flex` AS `PIL_Flex`,`vw_kpi_acc_base_FTE_flex_perm`.`PIL_Vast` AS `PIL_Vast`,`vw_kpi_acc_base_FTE_flex_perm`.`Totaal_PIL` AS `Totaal_PIL`,`vw_kpi_acc_report_billperm`.`BillableHours_Permanent` AS `BillableHours_Permanent` from (`vw_kpi_acc_base_FTE_flex_perm` left join `vw_kpi_acc_report_billperm` on(((`vw_kpi_acc_report_billperm`.`DepartmentName` = `vw_kpi_acc_base_FTE_flex_perm`.`OrganisatieEenheid`) and (`vw_kpi_acc_report_billperm`.`EmployeeDesignation` = `vw_kpi_acc_base_FTE_flex_perm`.`Functie`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base_BILL_perm_flex_FTE`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_BILL_perm_flex_FTE`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base_BILL_perm_flex_FTE` AS select 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,`vw_kpi_acc_base_BILL_perm_FTE`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base_BILL_perm_FTE`.`Functie` AS `Functie`,`vw_kpi_acc_base_BILL_perm_FTE`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base_BILL_perm_FTE`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,`vw_kpi_acc_base_BILL_perm_FTE`.`PIL_Flex` AS `PIL_Flex`,`vw_kpi_acc_base_BILL_perm_FTE`.`PIL_Vast` AS `PIL_Vast`,`vw_kpi_acc_base_BILL_perm_FTE`.`Totaal_PIL` AS `Totaal_PIL`,`vw_kpi_acc_base_BILL_perm_FTE`.`BillableHours_Permanent` AS `RealisatiePIL_Vast`,`vw_kpi_acc_report_billflex`.`BillableHours_Flexible` AS `RealistatiePIL_Flex` from (`vw_kpi_acc_base_BILL_perm_FTE` left join `vw_kpi_acc_report_billflex` on(((`vw_kpi_acc_report_billflex`.`DepartmentName` = `vw_kpi_acc_base_BILL_perm_FTE`.`OrganisatieEenheid`) and (`vw_kpi_acc_report_billflex`.`EmployeeDesignation` = `vw_kpi_acc_base_BILL_perm_FTE`.`Functie`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base_BILL_perm_flex_agency_FTE`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_BILL_perm_flex_agency_FTE`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base_BILL_perm_flex_agency_FTE` AS select 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`Functie` AS `Functie`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`PIL_Flex` AS `PIL_Flex`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`PIL_Vast` AS `PIL_Vast`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`Totaal_PIL` AS `Totaal_PIL`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`RealisatiePIL_Vast` AS `RealisatiePIL_Vast`,`vw_kpi_acc_base_BILL_perm_flex_FTE`.`RealistatiePIL_Flex` AS `RealistatiePIL_Flex`,`vw_kpi_acc_report_billagency`.`BillableHours_Agency` AS `RealistatiePNIL` from (`vw_kpi_acc_base_BILL_perm_flex_FTE` left join `vw_kpi_acc_report_billagency` on(((`vw_kpi_acc_report_billagency`.`DepartmentName` = `vw_kpi_acc_base_BILL_perm_flex_FTE`.`OrganisatieEenheid`) and (`vw_kpi_acc_report_billagency`.`EmployeeDesignation` = `vw_kpi_acc_base_BILL_perm_flex_FTE`.`Functie`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base_FINAL`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_FINAL`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base_FINAL` AS select 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`Functie` AS `Functie`,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,if(isnull(`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`PIL_Flex`),0,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`PIL_Flex`) AS `PIL_Flex`,if(isnull(`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`PIL_Vast`),0,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`PIL_Vast`) AS `PIL_Vast`,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`Totaal_PIL` AS `Totaal_PIL`,if(isnull(`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealisatiePIL_Vast`),0,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealisatiePIL_Vast`) AS `RealisatiePIL_Vast`,if(isnull(`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealistatiePIL_Flex`),0,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealistatiePIL_Flex`) AS `RealistatiePIL_Flex`,if(isnull(`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealistatiePNIL`),0,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealistatiePNIL`) AS `RealistatiePNIL`,((if(isnull(`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealisatiePIL_Vast`),0,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealisatiePIL_Vast`) + if(isnull(`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealistatiePIL_Flex`),0,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealistatiePIL_Flex`)) + if(isnull(`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealistatiePNIL`),0,`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`RealistatiePNIL`)) AS `RealisatieTOTAAL`,round(((`vw_kpi_acc_base_BILL_perm_flex_agency_FTE`.`Norm2018` * month(curdate())) / 12),2) AS `Norm_declarabele_uren_per_fte_PIL` from `vw_kpi_acc_base_BILL_perm_flex_agency_FTE` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base_FTE_flex_perm`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_FTE_flex_perm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base_FTE_flex_perm` AS select 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,`vw_kpi_acc_base_flex`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base_flex`.`Functie` AS `Functie`,`vw_kpi_acc_base_flex`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base_flex`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,`vw_kpi_acc_base_flex`.`FTE_Flexable` AS `PIL_Flex`,`vw_kpi_acc_report_fteperm`.`FTE_Permanent` AS `PIL_Vast`,(if(isnull(`vw_kpi_acc_base_flex`.`FTE_Flexable`),0,`vw_kpi_acc_base_flex`.`FTE_Flexable`) + if(isnull(`vw_kpi_acc_report_fteperm`.`FTE_Permanent`),0,`vw_kpi_acc_report_fteperm`.`FTE_Permanent`)) AS `Totaal_PIL` from (`vw_kpi_acc_base_flex` left join `vw_kpi_acc_report_fteperm` on(((`vw_kpi_acc_base_flex`.`OrganisatieEenheid` = `vw_kpi_acc_report_fteperm`.`DepartmentName`) and (`vw_kpi_acc_base_flex`.`Functie` = `vw_kpi_acc_report_fteperm`.`EmployeeDesignation`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base_billagency_flex_perm`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_billagency_flex_perm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base_billagency_flex_perm` AS select `vw_kpi_acc_base_flex_perm`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base_flex_perm`.`Functie` AS `Functie`,`vw_kpi_acc_base_flex_perm`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base_flex_perm`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,`vw_kpi_acc_base_flex_perm`.`PIL_Flex` AS `PIL_Flex`,`vw_kpi_acc_base_flex_perm`.`PIL_Vast` AS `PIL_Vast`,`vw_kpi_acc_base_flex_perm`.`Totaal_PIL` AS `Totaal_PIL` from `vw_kpi_acc_base_flex_perm` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base_flex`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_flex`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base_flex` AS select 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,`vw_kpi_acc_base`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base`.`Functie` AS `Functie`,`vw_kpi_acc_base`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,if(isnull(`vw_kpi_acc_report_fteflex`.`FTE_Flexable`),0,`vw_kpi_acc_report_fteflex`.`FTE_Flexable`) AS `FTE_Flexable` from (`vw_kpi_acc_base` left join `vw_kpi_acc_report_fteflex` on(((`vw_kpi_acc_base`.`OrganisatieEenheid` = `vw_kpi_acc_report_fteflex`.`DepartmentName`) and (`vw_kpi_acc_base`.`Functie` = `vw_kpi_acc_report_fteflex`.`EmployeeDesignation`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_base_flex_perm`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_base_flex_perm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_base_flex_perm` AS select `vw_kpi_acc_base_flex`.`OrganisatieEenheid` AS `OrganisatieEenheid`,`vw_kpi_acc_base_flex`.`Functie` AS `Functie`,`vw_kpi_acc_base_flex`.`Norm2018` AS `Norm2018`,`vw_kpi_acc_base_flex`.`correctie_overheadtaken_CPP` AS `correctie_overheadtaken_CPP`,`vw_kpi_acc_base_flex`.`FTE_Flexable` AS `PIL_Flex`,if(isnull(`vw_kpi_acc_report_fteperm`.`FTE_Permanent`),0,`vw_kpi_acc_report_fteperm`.`FTE_Permanent`) AS `PIL_Vast`,(if(isnull(`vw_kpi_acc_base_flex`.`FTE_Flexable`),0,`vw_kpi_acc_base_flex`.`FTE_Flexable`) + if(isnull(`vw_kpi_acc_report_fteperm`.`FTE_Permanent`),0,`vw_kpi_acc_report_fteperm`.`FTE_Permanent`)) AS `Totaal_PIL` from (`vw_kpi_acc_base_flex` left join `vw_kpi_acc_report_fteperm` on(((`vw_kpi_acc_base_flex`.`OrganisatieEenheid` = `vw_kpi_acc_report_fteperm`.`DepartmentName`) and (`vw_kpi_acc_base_flex`.`Functie` = `vw_kpi_acc_report_fteperm`.`EmployeeDesignation`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_billagency`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_billagency`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_billagency` AS select 'Author: Sander van Hijfte Last Update Date:10-09-2018' AS `Version`,round((`vw_kpi_acc_delivery_all_periods`.`BillableTime` / 3600),2) AS `BillableHours_Agencyworkers`,`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` AS `EmployeeDesignation`,`Department`.`DepartmentName` AS `DepartmentName` from ((`vw_kpi_acc_delivery_all_periods` join `EmployeeContract`) join `Department`) where ((`EmployeeContract`.`EmployeeContractDepartmentId` = `Department`.`DepartmentId`) and (`vw_kpi_acc_delivery_all_periods`.`EmployeeId` = `EmployeeContract`.`EmployeeContractEmployeeId`) and (`EmployeeContract`.`EmployeeFormOfContractDescription` in ('Oproepkracht met voorovereenkomst','Oproepkracht zonder voorovereenkomst','Vrijwilliger','Overig personeel niet in loondienst'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_delivery_all_periods`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_delivery_all_periods`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_delivery_all_periods` AS select 'Author: Sander van Hijfte Last Update Date:26-10-2018' AS `Version`,'This is a copy of delivery used for the KPI Report views.' AS `Explanation`,`delivery`.`ContractId` AS `ContractId`,`delivery`.`DeliveryDate` AS `DeliveryDate`,`delivery`.`ActivityName` AS `ActivityName`,`delivery`.`ActivityShortName` AS `ActivityShortName`,`delivery`.`ActivityDescription` AS `ActivityDescription`,`delivery`.`ActivityDeliveryReportingCode` AS `ActivityDeliveryReportingCode`,`delivery`.`ActivityDeliveryInvoiceCode` AS `ActivityDeliveryInvoiceCode`,`delivery`.`ActivityDeliverySalaryCode` AS `ActivityDeliverySalaryCode`,`delivery`.`ActivityDeliveryServiceCode` AS `ActivityDeliveryServiceCode`,`delivery`.`ProductCode` AS `ProductCode`,`delivery`.`ProductName` AS `ProductName`,`delivery`.`ProductDescription` AS `ProductDescription`,`delivery`.`OrganizationId` AS `OrganizationId`,`delivery`.`OrganizationName` AS `OrganizationName`,`delivery`.`EmployeeId` AS `EmployeeId`,`delivery`.`EmployeeLastName` AS `EmployeeLastName`,`delivery`.`EmployeeInitials` AS `EmployeeInitials`,`delivery`.`EmployeeInfix` AS `EmployeeInfix`,`delivery`.`EmployeeNumberOfHoursWorked` AS `EmployeeNumberOfHoursWorked`,`delivery`.`EmployeeNumberOfHoursVacation` AS `EmployeeNumberOfHoursVacation`,`delivery`.`DeliveredByOtherEmployees` AS `DeliveredByOtherEmployees`,`delivery`.`CustomerIdentifier` AS `CustomerIdentifier`,`delivery`.`CustomerLastName` AS `CustomerLastName`,`delivery`.`CustomerInitials` AS `CustomerInitials`,`delivery`.`CustomerInfix` AS `CustomerInfix`,`delivery`.`CustomerYearOfBirth` AS `CustomerYearOfBirth`,`delivery`.`CustomerMonthOfBirth` AS `CustomerMonthOfBirth`,`delivery`.`CustomerZipCode` AS `CustomerZipCode`,`delivery`.`IsCustomerAbsent` AS `IsCustomerAbsent`,`delivery`.`IsCustomerAbsencePlanned` AS `IsCustomerAbsencePlanned`,`delivery`.`CustomerReportCode` AS `CustomerReportCode`,`delivery`.`IsCustomerReportSet` AS `IsCustomerReportSet`,`delivery`.`CustomerReportDate` AS `CustomerReportDate`,`delivery`.`CustomerReportRun` AS `CustomerReportRun`,`delivery`.`CustomerDeclarationCode` AS `CustomerDeclarationCode`,`delivery`.`IsCustomerDeclarationSet` AS `IsCustomerDeclarationSet`,`delivery`.`CustomerDeclarationDate` AS `CustomerDeclarationDate`,`delivery`.`CustomerDeclarationRun` AS `CustomerDeclarationRun`,`delivery`.`BillableTime` AS `BillableTime`,`delivery`.`TotalDeliveredPerDeliveryPeriod` AS `TotalDeliveredPerDeliveryPeriod`,`delivery`.`VolumeAssignedByContract` AS `VolumeAssignedByContract`,`delivery`.`DifferenceBetweenDeliveredAndAssigned` AS `DifferenceBetweenDeliveredAndAssigned`,`delivery`.`DeliveryPeriod` AS `DeliveryPeriod`,`delivery`.`CustomerRegion` AS `CustomerRegion`,`delivery`.`ActivityId` AS `ActivityId`,`delivery`.`ActivityDefaultDeclarationCode` AS `ActivityDefaultDeclarationCode`,`delivery`.`EmployeeFirstName` AS `EmployeeFirstName`,`delivery`.`EmployeeDepartment` AS `EmployeeDepartment`,`delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`delivery`.`EmployeeDesignation` AS `EmployeeDesignation`,`delivery`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,`delivery`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,`delivery`.`DateActivityLogged` AS `DateActivityLogged`,`delivery`.`EmployeeThatLoggedTheActivity` AS `EmployeeThatLoggedTheActivity`,`delivery`.`DateThatActivityLogChanged` AS `DateThatActivityLogChanged`,`delivery`.`EmployeeThatChangedTheActivityLog` AS `EmployeeThatChangedTheActivityLog`,`delivery`.`IsDeliveryDiscarded` AS `IsDeliveryDiscarded`,`delivery`.`ReasonForDiscardingDelivery` AS `ReasonForDiscardingDelivery`,`delivery`.`ContractDeliveryPeriod` AS `ContractDeliveryPeriod` from `delivery` where (`delivery`.`DeliveryDate` < '2019-02-01') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_report_billagency`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_billagency`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_report_billagency` AS select 'Author: Sander van Hijfte Last Update Date:26-11-2018' AS `Version`,`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` AS `EmployeeDesignation`,`Department`.`DepartmentName` AS `DepartmentName`,round(sum((`vw_kpi_acc_delivery_all_periods`.`BillableTime` / 3600)),2) AS `BillableHours_Agency` from ((`vw_kpi_acc_delivery_all_periods` join `EmployeeContract`) join `Department`) where ((`vw_kpi_acc_delivery_all_periods`.`EmployeeId` = `EmployeeContract`.`EmployeeContractId`) and (`EmployeeContract`.`EmployeeContractDepartmentId` = `Department`.`DepartmentId`) and (`EmployeeContract`.`EmployeeFormOfContractDescription` in ('Oproepkracht zonder voorovereenkomst','Vrijwilliger','Overig personeel niet in loondienst'))) group by `Department`.`DepartmentName`,`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_report_billflex`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_billflex`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_report_billflex` AS select 'Author: Sander van Hijfte Last Update Date:26-11-2018' AS `Version`,`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` AS `EmployeeDesignation`,`Department`.`DepartmentName` AS `DepartmentName`,round(sum((`vw_kpi_acc_delivery_all_periods`.`BillableTime` / 3600)),2) AS `BillableHours_Flexible` from ((`vw_kpi_acc_delivery_all_periods` join `EmployeeContract`) join `Department`) where ((`vw_kpi_acc_delivery_all_periods`.`EmployeeId` = `EmployeeContract`.`EmployeeContractId`) and (`EmployeeContract`.`EmployeeContractDepartmentId` = `Department`.`DepartmentId`) and (`EmployeeContract`.`EmployeeIsContractPermanent` = 'False') and (`EmployeeContract`.`EmployeeFormOfContractDescription` in ('Parttime','Fulltime','Stagiair in loondienst')) and (`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` not in ('null','NullDesignation'))) group by `Department`.`DepartmentName`,`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_report_billperm`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_billperm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_report_billperm` AS select 'Author: Sander van Hijfte Last Update Date:26-11-2018' AS `Version`,`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` AS `EmployeeDesignation`,`Department`.`DepartmentName` AS `DepartmentName`,round(sum((`vw_kpi_acc_delivery_all_periods`.`BillableTime` / 3600)),2) AS `BillableHours_Permanent` from ((`vw_kpi_acc_delivery_all_periods` join `EmployeeContract`) join `Department`) where ((`vw_kpi_acc_delivery_all_periods`.`EmployeeId` = `EmployeeContract`.`EmployeeContractId`) and (`EmployeeContract`.`EmployeeContractDepartmentId` = `Department`.`DepartmentId`) and (`EmployeeContract`.`EmployeeIsContractPermanent` = 'True') and (`EmployeeContract`.`EmployeeFormOfContractDescription` in ('Parttime','Fulltime','Stagiair in loondienst')) and (`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` <> 'null')) group by `Department`.`DepartmentName`,`vw_kpi_acc_delivery_all_periods`.`EmployeeDesignation` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_report_fteflex`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_fteflex`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_report_fteflex` AS select 'Author: Sander van Hijfte Last Update Date:06-08-2018' AS `Version`,sum(if((`EmployeeContract`.`EmployeeContractNumberOfHoursPerWeek` = 0),0,`EmployeeContract`.`EmployeeContractNumberOfHoursPerWeek`)) AS `FTE_Flexable`,`EmployeeContract`.`EmployeeDesignationDescription` AS `EmployeeDesignation`,`Department`.`DepartmentName` AS `DepartmentName` from (`EmployeeContract` join `Department`) where ((`EmployeeContract`.`EmployeeContractDepartmentId` = `Department`.`DepartmentId`) and (`EmployeeContract`.`EmployeeIsContractPermanent` = 'False') and ((`EmployeeContract`.`EmployeeContractEndDate` > curdate()) or (`EmployeeContract`.`EmployeeContractEndDate` = '0000-00-00') or isnull(`EmployeeContract`.`EmployeeContractEndDate`)) and (`EmployeeContract`.`EmployeeDesignationDescription` not in ('null',''))) group by `EmployeeDesignation`,`Department`.`DepartmentName` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_kpi_acc_report_fteperm`
--

/*!50001 DROP VIEW IF EXISTS `vw_kpi_acc_report_fteperm`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_kpi_acc_report_fteperm` AS select `Department`.`DepartmentName` AS `DepartmentName`,`EmployeeContract`.`EmployeeDesignationDescription` AS `EmployeeDesignation`,sum(`EmployeeContract`.`EmployeeContractNumberOfHoursPerWeek`) AS `FTE_Permanent` from (`EmployeeContract` join `Department`) where ((`EmployeeContract`.`EmployeeContractDepartmentId` = `Department`.`DepartmentId`) and (`EmployeeContract`.`EmployeeIsContractPermanent` = 'True') and ((`EmployeeContract`.`EmployeeContractEndDate` > curdate()) or (`EmployeeContract`.`EmployeeContractEndDate` = '0000-00-00') or isnull(`EmployeeContract`.`EmployeeContractEndDate`)) and (`EmployeeContract`.`EmployeeDesignationDescription` not in ('null',''))) group by `EmployeeDesignation`,`Department`.`DepartmentName` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-14 16:48:23
