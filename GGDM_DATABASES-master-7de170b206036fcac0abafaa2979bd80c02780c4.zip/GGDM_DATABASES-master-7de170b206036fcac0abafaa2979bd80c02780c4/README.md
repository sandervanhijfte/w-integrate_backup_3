These files hold the create statements of all components in the GGMD databases.
GGMD, GGMDKPI, GGMDLOAD and GGMDRULES