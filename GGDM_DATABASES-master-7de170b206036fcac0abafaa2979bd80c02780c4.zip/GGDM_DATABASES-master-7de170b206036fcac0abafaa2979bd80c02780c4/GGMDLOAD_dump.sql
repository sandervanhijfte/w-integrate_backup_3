-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: GGMDLOAD
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `GGMDLOAD`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `GGMDLOAD` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `GGMDLOAD`;

--
-- Table structure for table `Employee`
--

DROP TABLE IF EXISTS `Employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee` (
  `EmployeeId` varchar(45) NOT NULL,
  `EmployeeSourceId` varchar(45) NOT NULL,
  `EmployeeFirstName` varchar(100) DEFAULT NULL,
  `EmployeeInfix` varchar(10) DEFAULT NULL,
  `EmployeeLastName` varchar(20) DEFAULT NULL,
  `DepartmentId` varchar(100) DEFAULT NULL,
  `EmployeeInitials` varchar(45) DEFAULT NULL,
  `EmployeeTitle` varchar(45) DEFAULT NULL,
  `EmployeeGender` varchar(45) DEFAULT NULL,
  `EmployeeDateOfBirth` date DEFAULT NULL,
  `EmployeePlaceOfBirth` varchar(45) DEFAULT NULL,
  `EmployeeSocialSecurityNumber` varchar(45) DEFAULT NULL,
  `EmployeeMaritalStatus` varchar(45) DEFAULT NULL,
  `EmployeeNationality` varchar(45) DEFAULT NULL,
  `EmployeeEmail` varchar(45) DEFAULT NULL,
  `EmployeePartnerInitials` varchar(45) DEFAULT NULL,
  `EmployeePartnerInfix` varchar(45) DEFAULT NULL,
  `EmployeePartnerLastName` varchar(100) DEFAULT NULL,
  `EmployeePartnerDateOfBirth` date DEFAULT NULL,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`EmployeeSourceId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EmployeeContract`
--

DROP TABLE IF EXISTS `EmployeeContract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmployeeContract` (
  `EmployeeContractId` varchar(45) NOT NULL,
  `EmployeeContractEmployeeId` varchar(45) NOT NULL,
  `IsCompanyFirstAid` tinyint(4) DEFAULT NULL,
  `EmployeeDesignationId` varchar(45) DEFAULT NULL,
  `EmployeeDesignationDescription` varchar(45) DEFAULT NULL,
  `EmployeeFormOfContractCode` varchar(45) DEFAULT NULL,
  `EmployeeContractIsEmployeePaid` varchar(45) DEFAULT NULL,
  `EmployeeFormOfContractDescription` varchar(45) DEFAULT NULL,
  `EmployeeIsContractPermanent` varchar(45) DEFAULT NULL,
  `EmployeeContractStartDate` date DEFAULT NULL,
  `EmployeeContractEndDate` date DEFAULT NULL,
  `EmployeeContractNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractMaxNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractNumberOfDaysPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractDepartmentId` varchar(45) DEFAULT NULL,
  `EmployeeContractWorkLocation` varchar(45) DEFAULT NULL,
  `EmployeeContractSalaryBasedOnFullTimeEmployment` varchar(45) DEFAULT NULL,
  `EmployeeContractYearSalary` varchar(45) DEFAULT NULL,
  `EmployeeContractStatus` varchar(45) DEFAULT NULL,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`EmployeeContractId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EmployeeContractLine`
--

DROP TABLE IF EXISTS `EmployeeContractLine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmployeeContractLine` (
  `EmployeeContractId` varchar(45) NOT NULL,
  `EmployeeContractStartDate` date NOT NULL,
  `EmployeeContractEndDate` date DEFAULT NULL,
  `EmployeeContractNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractMaxNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractNumberOfDaysPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeContractDepartmentId` varchar(45) DEFAULT NULL,
  `EmployeeContractSalaryBasedOnFullTimeEmployment` varchar(45) DEFAULT NULL,
  `EmployeeContractYearSalary` varchar(45) DEFAULT NULL,
  `EmployeeDesignationDescription` varchar(45) DEFAULT NULL,
  `EmployeeContractLineNormDeviation` decimal(6,2) DEFAULT NULL,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`EmployeeContractId`,`EmployeeContractStartDate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_contracts`
--

DROP TABLE IF EXISTS `load_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_contracts` (
  `ID` int(11) DEFAULT NULL,
  `PID` int(11) DEFAULT NULL,
  `Naam` text,
  `Titel` text,
  `Achternaam` text,
  `Voorletters` text,
  `Voornaam` text,
  `Tussenvoegsels` text,
  `Geboortedatum` text,
  `Geboortenaam` text,
  `Geboorteachternaam` text,
  `Geboortetussenvoegsels` text,
  `Geboorteland` text,
  `Geslacht` text,
  `Ident` text,
  `Straat` text,
  `Huisnummer` text,
  `Toevoeging` text,
  `Postcode` text,
  `Woonplaats` text,
  `Land` text,
  `BSN` int(11) DEFAULT NULL,
  `Mobiel telefoonnummer` text,
  `E-mailadres` text,
  `Organisatie-ID` int(11) DEFAULT NULL,
  `Startdatum` text,
  `Einddatum` text,
  `Onderwerp` text,
  `Beschikkingsnummer` text,
  `Kies productcategorie of zzp` text,
  `Extra gegevens productcategorie?` text,
  `. Productcode` text,
  `. Volume` text,
  `. Eenheid (2015)` text,
  `. Eenheid` text,
  `. Frequentie` text,
  `. zzp-code` text,
  `. zzp klasse` text,
  `. zzp leveringsvorm` text,
  `Extra gegevens beschikking/toewijzing?` text,
  `. Gemeente code` text,
  `. Indicatie orgaan code` text,
  `. Cliëntnummer` text,
  `. Geheime cliënt` text,
  `. Geboortedatum gebruik` text,
  `. Aanvraagnummer beschikking` text,
  `. Aanbieder AGB-code` text,
  `. Toewijzingsdatumtijd` text,
  `. Reden wijziging` text,
  `. Opmerkingen` text,
  `Aanvangsdatum zorg:` text,
  `Einddatum zorg` text,
  `Reden beeindiging` text,
  `Uitzonderen van automatische aanlevering berichten` text,
  `Uitzonderen van berichtenverkeer` text,
  `ROW_ID` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_cw_deliveries_2019`
--

DROP TABLE IF EXISTS `load_cw_deliveries_2019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_cw_deliveries_2019` (
  `production_id` text,
  `production_change_date` text,
  `production_start_date` text,
  `production_end_date` text,
  `activity_id` text,
  `activity_name` text,
  `activity_short_name` text,
  `activity_description` text,
  `activity_default_declaration_code` text,
  `activity_default_reporting_code` text,
  `activity_invoice_code` text,
  `activity_salary_code` text,
  `activity_service_code` text,
  `product_id` text,
  `product_name` text,
  `product_description` text,
  `product_organisation_name` text,
  `caretaker_id` text,
  `caretaker_last_name` text,
  `caretaker_initials` text,
  `caretaker_infix` text,
  `caretaker_employee_codes` text,
  `client_id` text,
  `client_year_of_birth` text,
  `client_month_of_birth` text,
  `client_zip_code` text,
  `client_absent` text,
  `client_absence_planned` text,
  `total_involved_caretakers` int(11) DEFAULT NULL,
  `total_present_caretakers` int(11) DEFAULT NULL,
  `total_involved_clients` int(11) DEFAULT NULL,
  `total_present_clients` int(11) DEFAULT NULL,
  `total_involved_contacts` int(11) DEFAULT NULL,
  `total_present_contacts` int(11) DEFAULT NULL,
  `total_involved_others` int(11) DEFAULT NULL,
  `total_present_others` int(11) DEFAULT NULL,
  `appointment_time` int(11) DEFAULT NULL,
  `direct_time` int(11) DEFAULT NULL,
  `indirect_time` int(11) DEFAULT NULL,
  `overhead_time` int(11) DEFAULT NULL,
  `multi_disp_time` int(11) DEFAULT NULL,
  `cb_face_to_face_time` int(11) DEFAULT NULL,
  `cg_face_to_face_time` int(11) DEFAULT NULL,
  `cb_presence_time` int(11) DEFAULT NULL,
  `cg_presence_time` int(11) DEFAULT NULL,
  `coupled_regime` text,
  `coupled_form_id` text,
  `ROW_ID` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_deliveries`
--

DROP TABLE IF EXISTS `load_deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_deliveries` (
  `production_id` int(11) DEFAULT NULL,
  `production_creation_date` text,
  `production_creation_name` text,
  `production_change_date` text,
  `production_change_name` text,
  `production_start_date` text,
  `production_end_date` text,
  `production_remarks` text,
  `production_medium` int(11) DEFAULT NULL,
  `production_organisation_id` int(11) DEFAULT NULL,
  `production_organisation_name` text,
  `activity_id` int(11) DEFAULT NULL,
  `activity_creation_date` text,
  `activity_creation_name` text,
  `activity_change_date` text,
  `activity_change_name` text,
  `activity_name` text,
  `activity_short_name` text,
  `activity_description` text,
  `activity_start_date` text,
  `activity_end_date` text,
  `activity_default_declaration_code` text,
  `activity_default_reporting_code` text,
  `activity_invoice_code` text,
  `activity_salary_code` text,
  `activity_service_code` text,
  `product_id` int(11) DEFAULT NULL,
  `product_name` text,
  `product_description` text,
  `product_organisation_id` int(11) DEFAULT NULL,
  `product_organisation_name` text,
  `caretaker_id` int(11) DEFAULT NULL,
  `caretaker_last_name` text,
  `caretaker_initials` text,
  `caretaker_infix` text,
  `caretaker_employee_codes` text,
  `client_id` text,
  `client_last_name` text,
  `client_initials` text,
  `client_infix` text,
  `client_year_of_birth` text,
  `client_month_of_birth` text,
  `client_zip_code` text,
  `client_absent` text,
  `client_absence_planned` text,
  `client_report_code` text,
  `client_report_set` text,
  `client_report_date` text,
  `client_report_run` text,
  `client_declaration_code` text,
  `client_declaration_set` text,
  `client_declaration_date` text,
  `client_declaration_run` text,
  `total_involved_caretakers` int(11) DEFAULT NULL,
  `total_present_caretakers` int(11) DEFAULT NULL,
  `total_involved_clients` int(11) DEFAULT NULL,
  `total_present_clients` int(11) DEFAULT NULL,
  `total_involved_contacts` int(11) DEFAULT NULL,
  `total_present_contacts` int(11) DEFAULT NULL,
  `total_involved_others` int(11) DEFAULT NULL,
  `total_present_others` int(11) DEFAULT NULL,
  `appointment_time` int(11) DEFAULT NULL,
  `direct_time` int(11) DEFAULT NULL,
  `indirect_time` int(11) DEFAULT NULL,
  `overhead_time` int(11) DEFAULT NULL,
  `multi_disp_time` int(11) DEFAULT NULL,
  `cb_face_to_face_time` int(11) DEFAULT NULL,
  `cg_face_to_face_time` int(11) DEFAULT NULL,
  `cb_presence_time` int(11) DEFAULT NULL,
  `cg_presence_time` int(11) DEFAULT NULL,
  `coupled_regime` text,
  `coupled_form_id` text,
  `ROW_ID` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_jwcontracts`
--

DROP TABLE IF EXISTS `load_jwcontracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_jwcontracts` (
  `ID` int(11) DEFAULT NULL,
  `PID` int(11) DEFAULT NULL,
  `Naam` text,
  `Titel` text,
  `Achternaam` text,
  `Voorletters` text,
  `Voornaam` text,
  `Tussenvoegsels` text,
  `Geboortedatum` text,
  `Geboortenaam` text,
  `Geboorteachternaam` text,
  `Geboortetussenvoegsels` text,
  `Geboorteland` text,
  `Geslacht` text,
  `Ident` text,
  `Straat` text,
  `Huisnummer` text,
  `Toevoeging` text,
  `Postcode` text,
  `Woonplaats` text,
  `Land` text,
  `BSN` text,
  `Mobiel telefoonnummer` text,
  `E-mailadres` text,
  `Organisatie-ID` int(11) DEFAULT NULL,
  `Startdatum` text,
  `Einddatum` text,
  `Wijzigingsdatum` text,
  `Onderwerp` text,
  `Beschikkingsnummer` int(11) DEFAULT NULL,
  `Toewijzingnummer` int(11) DEFAULT NULL,
  `Kies productcategorie of ZZP` text,
  `Extra gegevens productcategorie?` text,
  `. Productcode` int(11) DEFAULT NULL,
  `. Volume` int(11) DEFAULT NULL,
  `. Eenheid (2015)` text,
  `. Eenheid` text,
  `. Frequentie` text,
  `. Aftoppen prestaties` text,
  `. Plafond vaststelling per` text,
  `. ZZP-code` text,
  `. ZZP Klasse` text,
  `. ZZP Leveringsvorm` text,
  `Extra gegevens beschikking/toewijzing?` text,
  `. Gemeente code` int(11) DEFAULT NULL,
  `. Indicatie orgaan code` text,
  `. Cliëntnummer` int(11) DEFAULT NULL,
  `. Geheime cliënt` text,
  `. Geboortedatum gebruik` text,
  `. Aanvraagnummer beschikking` text,
  `. Aanbieder AGB-code` int(11) DEFAULT NULL,
  `. Toewijzingsdatumtijd` text,
  `. Reden wijziging` text,
  `. Opmerkingen` text,
  `Aanvangsdatum zorg:` text,
  `Einddatum zorg` text,
  `Reden beeindiging` text,
  `Uitzonderen van automatische aanlevering berichten` text,
  `Uitzonderen van berichtenverkeer` text,
  `ROW_ID` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sdb_dienstverbanden`
--

DROP TABLE IF EXISTS `load_sdb_dienstverbanden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_sdb_dienstverbanden` (
  `Id` varchar(45) NOT NULL,
  `MedewerkerId` varchar(45) DEFAULT NULL,
  `FunctieCode` varchar(45) DEFAULT NULL,
  `FunctieOmschrijving` varchar(100) DEFAULT NULL,
  `FunctieKostprijs` varchar(45) DEFAULT NULL,
  `FunctieProductiviteitsfactor` varchar(45) DEFAULT NULL,
  `FunctieEindDatum` datetime DEFAULT NULL,
  `DatumInDienst` datetime DEFAULT NULL,
  `DatumUitDienst` datetime DEFAULT NULL,
  `UrenPerWeek` varchar(45) DEFAULT NULL,
  `ParttimeFactor` varchar(45) DEFAULT NULL,
  `UrenPerWeekMax` varchar(45) DEFAULT NULL,
  `DagenPerWeek` varchar(45) DEFAULT NULL,
  `IsOnbepaald` varchar(45) DEFAULT NULL,
  `ORTBerekenenUit` varchar(45) DEFAULT NULL,
  `ContractvormCode` varchar(45) DEFAULT NULL,
  `ContractvormIsSalaris` varchar(45) DEFAULT NULL,
  `ContractvormOmschrijving` varchar(100) DEFAULT NULL,
  `ContractNummer` varchar(45) DEFAULT NULL,
  `ContractBeginDatum` datetime DEFAULT NULL,
  `ContractEindDatum` datetime DEFAULT NULL,
  `AfdelingCode` varchar(45) DEFAULT NULL,
  `AfdelingOmschrijving` varchar(100) DEFAULT NULL,
  `AfdelingEindDatum` datetime DEFAULT NULL,
  `AfdelingHoofdAfdelingCode` varchar(45) DEFAULT NULL,
  `AfdelingHoofdAfdelingOmschrijving` varchar(100) DEFAULT NULL,
  `Werklocatie` varchar(45) DEFAULT NULL,
  `SalarisNominaal` varchar(45) DEFAULT NULL,
  `SalarisJaarloon` varchar(45) DEFAULT NULL,
  `CAOCode` varchar(45) DEFAULT NULL,
  `CAOOmschrijving` varchar(100) DEFAULT NULL,
  `SchaalTredeId` varchar(45) DEFAULT NULL,
  `SchaalTredeSchaal` varchar(45) DEFAULT NULL,
  `SchaalTredeTrede` varchar(45) DEFAULT NULL,
  `SchaalTredeInpassingCode` varchar(45) DEFAULT NULL,
  `SchaalTredeBedrag` varchar(45) DEFAULT NULL,
  `SchaalTredeOmschrijving` varchar(100) DEFAULT NULL,
  `SchaalTredeBeginDatum` datetime DEFAULT NULL,
  `SchaalTredeEindDatum` datetime DEFAULT NULL,
  `GarantieCAO` varchar(45) DEFAULT NULL,
  `GarantieSchaal` varchar(45) DEFAULT NULL,
  `AncienniteitsMaand` varchar(45) DEFAULT NULL,
  `ExtraPeriodiek` varchar(45) DEFAULT NULL,
  `BlokkerenPeriodiek` varchar(45) DEFAULT NULL,
  `OntslagCodeCode` varchar(45) DEFAULT NULL,
  `OntslagCodeOmschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort1Code` varchar(45) DEFAULT NULL,
  `Kostensoort1Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort1EindDatum` datetime DEFAULT NULL,
  `Kostensoort2Code` varchar(45) DEFAULT NULL,
  `Kostensoort2Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort2EindDatum` datetime DEFAULT NULL,
  `Kostensoort3Code` varchar(45) DEFAULT NULL,
  `Kostensoort3Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort3EindDatum` datetime DEFAULT NULL,
  `Kostensoort4Code` varchar(45) DEFAULT NULL,
  `Kostensoort4Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort4EindDatum` datetime DEFAULT NULL,
  `Kostenplaats1Code` varchar(45) DEFAULT NULL,
  `Kostenplaats1Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats1EindDatum` datetime DEFAULT NULL,
  `Kostenplaats2Code` varchar(45) DEFAULT NULL,
  `Kostenplaats2Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats2EindDatum` datetime DEFAULT NULL,
  `Kostenplaats3Code` varchar(45) DEFAULT NULL,
  `Kostenplaats3Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats3EindDatum` datetime DEFAULT NULL,
  `Kostenplaats4Code` varchar(45) DEFAULT NULL,
  `Kostenplaats4Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats4EindDatum` datetime DEFAULT NULL,
  `Kostenverdeling1` varchar(45) DEFAULT NULL,
  `Kostenverdeling2` varchar(45) DEFAULT NULL,
  `Kostenverdeling3` varchar(45) DEFAULT NULL,
  `Kostenverdeling4` varchar(45) DEFAULT NULL,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sdb_dienstverbandperiodes`
--

DROP TABLE IF EXISTS `load_sdb_dienstverbandperiodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_sdb_dienstverbandperiodes` (
  `DienstverbandId` int(11) NOT NULL,
  `PeriodeBeginDatum` datetime NOT NULL,
  `PeriodeEindDatum` datetime DEFAULT NULL,
  `AfdelingCode` varchar(45) DEFAULT NULL,
  `AfdelingOmschrijving` varchar(45) DEFAULT NULL,
  `AfdelingEindDatum` datetime DEFAULT NULL,
  `AfdelingHoofdAfdelingCode` varchar(45) DEFAULT NULL,
  `AfdelingHoodfAfdelingOmschrijving` varchar(45) DEFAULT NULL,
  `FunctieCode` varchar(45) DEFAULT NULL,
  `FunctieOmschrijving` varchar(45) DEFAULT NULL,
  `FunctieKostprijs` varchar(45) DEFAULT NULL,
  `FunctieProductiviteitsfactor` varchar(45) DEFAULT NULL,
  `FunctieEindDatum` datetime DEFAULT NULL,
  `ContractvormCode` varchar(45) DEFAULT NULL,
  `ContractvormIsSalaris` varchar(45) DEFAULT NULL,
  `ContractvormOmschrijving` varchar(45) DEFAULT NULL,
  `UrenPerWeek` varchar(45) DEFAULT NULL,
  `UrenPerWeekMax` varchar(45) DEFAULT NULL,
  `SchaalTredeId` varchar(45) DEFAULT NULL,
  `SchaalTredeSchaal` varchar(45) DEFAULT NULL,
  `SchaalTredeTrede` varchar(45) DEFAULT NULL,
  `SchaalTredeInpassingCode` varchar(45) DEFAULT NULL,
  `SchaalTredeBedrag` varchar(45) DEFAULT NULL,
  `SchaalTredeOmschrijving` varchar(100) DEFAULT NULL,
  `SchaalTredeBeginDatum` datetime DEFAULT NULL,
  `SchaalTredeEindDatum` datetime DEFAULT NULL,
  `SalarisNominaal` varchar(45) DEFAULT NULL,
  `CAOCode` varchar(45) DEFAULT NULL,
  `CAOOmschrijving` varchar(45) DEFAULT NULL,
  `Kostensoort1Code` varchar(45) DEFAULT NULL,
  `Kostensoort1Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort1EindDatum` datetime DEFAULT NULL,
  `Kostensoort2Code` varchar(45) DEFAULT NULL,
  `Kostensoort2Omschrijving` varchar(45) DEFAULT NULL,
  `Kostensoort2EindDatum` datetime DEFAULT NULL,
  `Kostensoort3Code` varchar(45) DEFAULT NULL,
  `Kostensoort3Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort3EindDatum` datetime DEFAULT NULL,
  `Kostensoort4Code` varchar(45) DEFAULT NULL,
  `Kostensoort4Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort4EindDatum` datetime DEFAULT NULL,
  `Kostenplaats1Code` varchar(45) DEFAULT NULL,
  `Kostenplaats1Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats1EindDatum` datetime DEFAULT NULL,
  `Kostenplaats2Code` varchar(45) DEFAULT NULL,
  `Kostenplaats2Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats2EindDatum` datetime DEFAULT NULL,
  `Kostenplaats3Code` varchar(45) DEFAULT NULL,
  `Kostenplaats3Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats3EindDatum` datetime DEFAULT NULL,
  `Kostenplaats4Code` varchar(45) DEFAULT NULL,
  `Kostenplaats4Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats4EindDatum` datetime DEFAULT NULL,
  `Kostenverdeling1` varchar(45) DEFAULT NULL,
  `Kostenverdeling2` varchar(45) DEFAULT NULL,
  `Kostenverdeling3` varchar(45) DEFAULT NULL,
  `Kostenverdeling4` varchar(45) DEFAULT NULL,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`DienstverbandId`,`PeriodeBeginDatum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sdb_medewerkeradressen`
--

DROP TABLE IF EXISTS `load_sdb_medewerkeradressen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_sdb_medewerkeradressen` (
  `medewerkerId` varchar(20) NOT NULL,
  `Straatnaam` varchar(100) DEFAULT NULL,
  `Postcode` varchar(10) DEFAULT NULL,
  `Woonplaats` varchar(45) DEFAULT NULL,
  `LandCode2Tekens` varchar(5) DEFAULT NULL,
  `LandCode3Tekens` varchar(5) DEFAULT NULL,
  `LandISOCode` varchar(20) DEFAULT NULL,
  `LandOmschrijving` varchar(100) DEFAULT NULL,
  `Huisnummer` varchar(10) DEFAULT NULL,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`medewerkerId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sdb_medewerkers`
--

DROP TABLE IF EXISTS `load_sdb_medewerkers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_sdb_medewerkers` (
  `Id` varchar(45) NOT NULL,
  `Voorletters` varchar(45) DEFAULT NULL,
  `Tussenvoegsel` varchar(45) DEFAULT NULL,
  `AchterNaam` varchar(45) DEFAULT NULL,
  `RoepNaam` varchar(45) DEFAULT NULL,
  `Geslacht` varchar(45) DEFAULT NULL,
  `GeboorteDatum` datetime DEFAULT NULL,
  `DatumInSector` varchar(45) DEFAULT NULL,
  `GeboortePlaats` varchar(45) DEFAULT NULL,
  `BurgerServiceNummer` varchar(45) DEFAULT NULL,
  `BurgerlijkestaatCode` varchar(45) DEFAULT NULL,
  `BurgerlijkestaatOmschrijving` varchar(100) DEFAULT NULL,
  `NationaliteitCode` varchar(45) DEFAULT NULL,
  `NationaliteitOmschrijving` varchar(100) DEFAULT NULL,
  `Titel` varchar(45) DEFAULT NULL,
  `IsBedrijfsHulpVerlener` varchar(45) DEFAULT NULL,
  `TenaamstellingCode` varchar(45) DEFAULT NULL,
  `TenaamstellingOmschrijving` varchar(100) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `PartnerVoorletters` varchar(45) DEFAULT NULL,
  `PartnerTussenvoegsel` varchar(45) DEFAULT NULL,
  `PartnerAchternaam` varchar(45) DEFAULT NULL,
  `PartnerGeboortedatum` datetime DEFAULT NULL,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-14 17:15:41
