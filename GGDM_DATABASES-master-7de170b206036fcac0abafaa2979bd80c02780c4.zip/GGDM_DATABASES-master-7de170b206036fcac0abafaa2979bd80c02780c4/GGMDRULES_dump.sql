-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: GGMDRULES
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `GGMDRULES`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `GGMDRULES` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `GGMDRULES`;

--
-- Table structure for table `_Address`
--

DROP TABLE IF EXISTS `_Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_Address` (
  `ZenitAddressId` int(10) NOT NULL AUTO_INCREMENT,
  `PersonId` int(11) DEFAULT NULL,
  `OrganisationId` int(11) DEFAULT NULL,
  `SourceAddressId` varchar(45) DEFAULT NULL,
  `SourcePersonId` varchar(45) DEFAULT NULL,
  `SourceOrganisationId` varchar(45) DEFAULT NULL,
  `HouseNumber` varchar(45) DEFAULT NULL,
  `HouseNumberAddition` varchar(45) DEFAULT NULL,
  `Street` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `ZipCode` varchar(45) DEFAULT NULL,
  `CountryDescription` varchar(45) DEFAULT NULL,
  `CountryCode` varchar(45) DEFAULT NULL,
  `CountryISOCode` varchar(45) DEFAULT NULL,
  `Longitude` varchar(45) DEFAULT NULL,
  `Latitude` varchar(45) DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitAddressId_UNIQUE` (`ZenitAddressId`),
  UNIQUE KEY `SourceAddressId_UNIQUE` (`SourceAddressId`),
  UNIQUE KEY `SourcePersonId_UNIQUE` (`SourcePersonId`),
  UNIQUE KEY `SourceOrganisationId_UNIQUE` (`SourceOrganisationId`),
  KEY `ad_Person_idx` (`PersonId`),
  KEY `adr_Organisation_idx` (`OrganisationId`),
  CONSTRAINT `adr_Organisation` FOREIGN KEY (`OrganisationId`) REFERENCES `_Organisation` (`ZenitOrganisationId`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `adr_Person` FOREIGN KEY (`PersonId`) REFERENCES `_Person` (`ZenitPersonId`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8187 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_Customer`
--

DROP TABLE IF EXISTS `_Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_Customer` (
  `ZenitCustomerId` int(11) NOT NULL AUTO_INCREMENT,
  `PersonId` int(11) DEFAULT NULL,
  `OrganisationId` int(11) DEFAULT NULL,
  `SourcePersonId` varchar(45) DEFAULT NULL,
  `SourceCustomerId` varchar(45) DEFAULT NULL,
  `CustomerOrganisationUnit` varchar(45) DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitCustomerId_UNIQUE` (`ZenitCustomerId`),
  UNIQUE KEY `SourcePersonId_UNIQUE` (`SourcePersonId`),
  UNIQUE KEY `SourceCustomerId_UNIQUE` (`SourceCustomerId`),
  KEY `c_Organisation_idx` (`OrganisationId`),
  KEY `c_Person_idx` (`PersonId`),
  CONSTRAINT `c_Organisation` FOREIGN KEY (`OrganisationId`) REFERENCES `_Organisation` (`ZenitOrganisationId`),
  CONSTRAINT `c_Person` FOREIGN KEY (`PersonId`) REFERENCES `_Person` (`ZenitPersonId`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4096 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_Employee`
--

DROP TABLE IF EXISTS `_Employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_Employee` (
  `ZenitEmployeeId` int(11) NOT NULL AUTO_INCREMENT,
  `PersonId` int(11) DEFAULT NULL,
  `OrganisationId` int(11) DEFAULT NULL,
  `SourceEmployeeId` varchar(45) DEFAULT NULL,
  `WorkEmail` varchar(45) DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitEmployeeId_UNIQUE` (`ZenitEmployeeId`),
  UNIQUE KEY `SourceEmployeeId_UNIQUE` (`SourceEmployeeId`),
  KEY `em_Person_idx` (`PersonId`),
  KEY `em_Organisation_idx` (`OrganisationId`),
  CONSTRAINT `em_Organisation` FOREIGN KEY (`OrganisationId`) REFERENCES `_Organisation` (`ZenitOrganisationId`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `em_Person` FOREIGN KEY (`PersonId`) REFERENCES `_Person` (`ZenitPersonId`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1667 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_EmployeeContract`
--

DROP TABLE IF EXISTS `_EmployeeContract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_EmployeeContract` (
  `ZenitEmployeeContractId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceEmployeeContractId` varchar(45) DEFAULT NULL,
  `SourceEmployeeId` varchar(45) DEFAULT NULL,
  `EmployeeId` int(11) DEFAULT NULL,
  `DesignationId` varchar(45) DEFAULT NULL,
  `DesignationDescription` varchar(45) DEFAULT NULL,
  `FormOfContractCode` varchar(45) DEFAULT NULL,
  `FormOfContractDescription` varchar(45) DEFAULT NULL,
  `IsContractIndefinite` varchar(45) DEFAULT NULL,
  `IsEmployeePaid` varchar(45) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `NumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `MaxNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `NumberOfDaysPerWeek` decimal(4,2) DEFAULT NULL,
  `DepartmentId` varchar(45) DEFAULT NULL,
  `Department` varchar(45) DEFAULT NULL,
  `WorkLocation` varchar(45) DEFAULT NULL,
  `SalaryBasedOnFullTimeEmployment` varchar(45) DEFAULT NULL,
  `YearSalary` varchar(45) DEFAULT NULL,
  `Status` varchar(45) DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitEmployeeContractId_UNIQUE` (`ZenitEmployeeContractId`),
  UNIQUE KEY `SourceEmployeeContractId_UNIQUE` (`SourceEmployeeContractId`),
  KEY `emc_Employee_idx` (`EmployeeId`),
  CONSTRAINT `emc_Employee` FOREIGN KEY (`EmployeeId`) REFERENCES `_Employee` (`ZenitEmployeeId`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=639 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_EmployeeContractPeriod`
--

DROP TABLE IF EXISTS `_EmployeeContractPeriod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_EmployeeContractPeriod` (
  `ZenitEmployeeContractPeriodId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceEmployeeContractPeriodId` varchar(45) DEFAULT NULL,
  `SourceEmployeeContractId` varchar(45) DEFAULT NULL,
  `EmployeeContractId` int(11) DEFAULT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `NumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `MaxNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `NumberOfDaysPerWeek` decimal(4,2) DEFAULT NULL,
  `DepartmentId` varchar(45) DEFAULT NULL,
  `SalaryBasedOnFullTimeEmployment` varchar(45) DEFAULT NULL,
  `YearSalary` varchar(45) DEFAULT NULL,
  `DesignationDescription` varchar(45) DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitEmployeeContractPeriodId_UNIQUE` (`ZenitEmployeeContractPeriodId`),
  KEY `emcp_EmployeeContract_idx` (`EmployeeContractId`),
  CONSTRAINT `emcp_EmployeeContract` FOREIGN KEY (`EmployeeContractId`) REFERENCES `_EmployeeContract` (`ZenitEmployeeContractId`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8318 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_Organisation`
--

DROP TABLE IF EXISTS `_Organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_Organisation` (
  `ZenitOrganisationId` int(10) NOT NULL AUTO_INCREMENT,
  `SourceOrganisationId` varchar(45) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `FoundingDate` text,
  `RegisteredOffice` varchar(45) DEFAULT NULL,
  `Street` varchar(45) DEFAULT NULL,
  `HouseNumber` varchar(45) DEFAULT NULL,
  `HouseNumberAddition` varchar(45) DEFAULT NULL,
  `ZipCode` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `OrganisationPhone` varchar(100) DEFAULT NULL,
  `OrganisationEmail` varchar(45) DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitOrganizationId_UNIQUE` (`ZenitOrganisationId`),
  UNIQUE KEY `SourceOrganisationId_UNIQUE` (`SourceOrganisationId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_Person`
--

DROP TABLE IF EXISTS `_Person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_Person` (
  `ZenitPersonId` int(11) NOT NULL AUTO_INCREMENT,
  `SourcePersonId` varchar(45) DEFAULT NULL,
  `FirstName` varchar(45) DEFAULT NULL,
  `Infix` varchar(45) DEFAULT NULL,
  `LastName` varchar(45) DEFAULT NULL,
  `Initials` varchar(45) DEFAULT NULL,
  `Title` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `PlaceOfBirth` varchar(45) DEFAULT NULL,
  `SocialSecurityNumber` varchar(45) DEFAULT NULL,
  `MaritalStatus` varchar(45) DEFAULT NULL,
  `Nationality` varchar(45) DEFAULT NULL,
  `Street` varchar(45) DEFAULT NULL,
  `HouseNumber` varchar(45) DEFAULT NULL,
  `HouseNumberAddition` varchar(45) DEFAULT NULL,
  `ZipCode` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `PersonalPhone` varchar(100) DEFAULT NULL,
  `PersonalEmail` varchar(45) DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitPersonId_UNIQUE` (`ZenitPersonId`),
  UNIQUE KEY `SourcePersonId_UNIQUE` (`SourcePersonId`)
) ENGINE=InnoDB AUTO_INCREMENT=6011 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_WorkAssignment`
--

DROP TABLE IF EXISTS `_WorkAssignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_WorkAssignment` (
  `ZenitWorkAssignmentId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceWorkAssignmentId` varchar(45) DEFAULT NULL,
  `CustomerId` int(11) DEFAULT NULL,
  `SourceCustomerId` varchar(45) DEFAULT NULL,
  `SourceCustomerRegion` varchar(45) DEFAULT NULL,
  `Assignee` varchar(45) DEFAULT NULL,
  `Assigner` varchar(45) DEFAULT NULL,
  `AssignmentDeclarationId` varchar(45) DEFAULT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `ProductId` varchar(99) DEFAULT NULL,
  `ProductDescription` varchar(99) DEFAULT NULL,
  `MinutesOfWorkAssignedPerPeriod` float DEFAULT NULL,
  `OriginalVolume` int(11) DEFAULT NULL,
  `OriginalUnit` varchar(45) DEFAULT NULL,
  `OriginalFrequence` varchar(45) DEFAULT NULL,
  `DateOfAssignment` date DEFAULT NULL,
  `AssignmentFinancingType` varchar(45) DEFAULT NULL,
  `RowQualityRank` int(11) DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitWorkAssignmentId_UNIQUE` (`ZenitWorkAssignmentId`),
  UNIQUE KEY `SourceWorkAssignmentId_UNIQUE` (`SourceWorkAssignmentId`),
  KEY `wa_Customer_idx` (`CustomerId`),
  KEY `DateOfAssignment` (`DateOfAssignment`),
  KEY `FindAssignment` (`SourceCustomerId`,`StartDate`,`EndDate`),
  CONSTRAINT `wa_Customer` FOREIGN KEY (`CustomerId`) REFERENCES `_Customer` (`ZenitCustomerId`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3071 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_WorkDelivery`
--

DROP TABLE IF EXISTS `_WorkDelivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_WorkDelivery` (
  `ZenitWorkDeliveryId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceWorkDeliveryId` varchar(45) DEFAULT NULL,
  `WorkAssignmentId` int(11) DEFAULT NULL,
  `EmployeeContractId` int(11) DEFAULT NULL,
  `CustomerId` int(11) DEFAULT NULL,
  `SourceEmployeeContractId` varchar(45) DEFAULT NULL,
  `SourceCustomerId` varchar(45) DEFAULT NULL,
  `SourceCustomerLastName` varchar(45) DEFAULT NULL,
  `SourceCustomerInitials` varchar(45) DEFAULT NULL,
  `SourceCustomerZipCode` varchar(45) DEFAULT NULL,
  `SourceWorkerId` varchar(45) DEFAULT NULL,
  `SourceWorkerLastName` varchar(45) DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `ActivityId` varchar(45) DEFAULT NULL,
  `ActivityName` varchar(100) DEFAULT NULL,
  `ProductId` varchar(45) DEFAULT NULL,
  `ProductName` varchar(100) DEFAULT NULL,
  `DeliveryDeclarationCode` varchar(45) DEFAULT NULL,
  `DeliveryFinancingType` varchar(45) DEFAULT NULL,
  `DirectCustomerTime` varchar(45) DEFAULT NULL,
  `IndirectCustomerTime` varchar(45) DEFAULT NULL,
  `DeliveryTime` varchar(45) DEFAULT NULL,
  `DeliveryRegistrationDate` datetime DEFAULT NULL,
  `DeliveryRegistrationChangeDate` datetime DEFAULT NULL,
  `RowSource` varchar(45) DEFAULT NULL,
  `SourceRowId` varchar(45) NOT NULL,
  `RowInsertDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `RowStatus` varchar(45) DEFAULT 'active',
  PRIMARY KEY (`SourceRowId`),
  UNIQUE KEY `ZenitWorkDeliveryId_UNIQUE` (`ZenitWorkDeliveryId`),
  KEY `wd_Customer_idx` (`CustomerId`),
  KEY `FindWorkAssignment` (`SourceCustomerId`,`StartTime`),
  KEY `wd_EmployeeContract_idx` (`EmployeeContractId`),
  CONSTRAINT `wd_Customer` FOREIGN KEY (`CustomerId`) REFERENCES `_Customer` (`ZenitCustomerId`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `wd_EmployeeContract` FOREIGN KEY (`EmployeeContractId`) REFERENCES `_EmployeeContract` (`ZenitEmployeeContractId`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=393211 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `ang_DeliveriesForAssignedHealthcare`
--

DROP TABLE IF EXISTS `ang_DeliveriesForAssignedHealthcare`;
/*!50001 DROP VIEW IF EXISTS `ang_DeliveriesForAssignedHealthcare`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ang_DeliveriesForAssignedHealthcare` AS SELECT 
 1 AS `ZenitWorkDeliveryId`,
 1 AS `SourceWorkDeliveryId`,
 1 AS `DeliveryDate`,
 1 AS `ProductId`,
 1 AS `ProductName`,
 1 AS `SourceWorkerId`,
 1 AS `SourceCustomerId`,
 1 AS `DeliveryFinancingType`,
 1 AS `ZenitWorkAssignmentId`,
 1 AS `SourceWorkAssignmentId`,
 1 AS `AssignmentStartDate`,
 1 AS `AssignmentEndDate`,
 1 AS `MinutesOfWorkAssignedPerPeriod`,
 1 AS `DateOfAssignment`,
 1 AS `SourceCustomerRegion`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `ang_delivery`
--

DROP TABLE IF EXISTS `ang_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ang_delivery` (
  `ContractId` varchar(50) DEFAULT NULL,
  `DeliveryDate` datetime NOT NULL,
  `ActivityName` varchar(100) DEFAULT NULL,
  `ActivityShortName` varchar(50) DEFAULT NULL,
  `ActivityDescription` varchar(500) DEFAULT NULL,
  `ActivityDeliveryReportingCode` varchar(50) DEFAULT NULL,
  `ActivityDeliveryInvoiceCode` varchar(50) DEFAULT NULL,
  `ActivityDeliverySalaryCode` varchar(50) DEFAULT NULL,
  `ActivityDeliveryServiceCode` varchar(50) DEFAULT NULL,
  `ProductCode` varchar(50) DEFAULT NULL,
  `ProductName` varchar(100) DEFAULT NULL,
  `ProductDescription` varchar(500) DEFAULT NULL,
  `OrganizationId` varchar(50) DEFAULT NULL,
  `OrganizationName` varchar(100) DEFAULT NULL,
  `EmployeeId` varchar(50) NOT NULL,
  `EmployeeLastName` varchar(100) DEFAULT NULL,
  `EmployeeInitials` varchar(50) DEFAULT NULL,
  `EmployeeInfix` varchar(50) DEFAULT NULL,
  `EmployeeNumberOfHoursWorked` int(11) DEFAULT NULL COMMENT 'This is stored in seconds',
  `EmployeeNumberOfHoursVacation` int(11) DEFAULT NULL COMMENT 'This is stored in seconds so we need to change the column name',
  `DeliveredByOtherEmployees` varchar(50) DEFAULT NULL,
  `CustomerIdentifier` varchar(50) NOT NULL,
  `CustomerLastName` varchar(100) DEFAULT NULL,
  `CustomerInitials` varchar(50) DEFAULT NULL,
  `CustomerInfix` varchar(50) DEFAULT NULL,
  `CustomerYearOfBirth` int(11) DEFAULT NULL,
  `CustomerMonthOfBirth` int(11) DEFAULT NULL,
  `CustomerZipCode` varchar(50) DEFAULT NULL,
  `IsCustomerAbsent` varchar(50) DEFAULT NULL,
  `IsCustomerAbsencePlanned` varchar(50) DEFAULT NULL,
  `CustomerReportCode` varchar(50) DEFAULT NULL,
  `IsCustomerReportSet` varchar(50) DEFAULT NULL,
  `CustomerReportDate` date DEFAULT NULL,
  `CustomerReportRun` varchar(50) DEFAULT NULL,
  `CustomerDeclarationCode` varchar(50) DEFAULT NULL,
  `IsCustomerDeclarationSet` varchar(50) DEFAULT NULL,
  `CustomerDeclarationDate` date DEFAULT NULL,
  `CustomerDeclarationRun` varchar(50) DEFAULT NULL,
  `BillableTime` int(11) NOT NULL,
  `TotalDeliveredPerDeliveryPeriod` int(11) DEFAULT NULL,
  `VolumeAssignedByContract` int(11) DEFAULT NULL,
  `DifferenceBetweenDeliveredAndAssigned` int(11) DEFAULT NULL,
  `DeliveryPeriod` varchar(50) DEFAULT NULL,
  `CustomerRegion` varchar(100) DEFAULT NULL,
  `ActivityId` varchar(45) DEFAULT NULL,
  `ActivityDefaultDeclarationCode` varchar(50) DEFAULT NULL,
  `EmployeeFirstName` varchar(45) DEFAULT NULL,
  `EmployeeDepartment` varchar(45) DEFAULT NULL,
  `EmployeePersonalPerformanceIndicator` decimal(6,2) DEFAULT NULL,
  `EmployeeDesignation` varchar(45) DEFAULT NULL,
  `EmployeeNumberOfHoursPerWeek` int(11) DEFAULT NULL,
  `EmployeeTotalNumberOfHoursVacation` int(11) DEFAULT NULL,
  `DateActivityLogged` date DEFAULT NULL,
  `EmployeeThatLoggedTheActivity` varchar(100) DEFAULT NULL,
  `DateThatActivityLogChanged` date DEFAULT NULL,
  `EmployeeThatChangedTheActivityLog` varchar(100) DEFAULT NULL,
  `IsDeliveryDiscarded` varchar(50) DEFAULT NULL,
  `ReasonForDiscardingDelivery` varchar(100) DEFAULT NULL,
  `ContractDeliveryPeriod` varchar(45) DEFAULT NULL COMMENT 'This will be filed with the DeliveryPeriod from Contract. in contract the delivery period has the number of days, weeks or any other period, in which the delivery is supposed to be done. So for instance ‘per week’. This means that the agreed volume is delivered every week.',
  `DeliveryType` varchar(45) DEFAULT NULL,
  `CustomerAge` int(11) DEFAULT NULL,
  PRIMARY KEY (`DeliveryDate`,`EmployeeId`,`CustomerIdentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `ang_delivery_discarding`
--

DROP TABLE IF EXISTS `ang_delivery_discarding`;
/*!50001 DROP VIEW IF EXISTS `ang_delivery_discarding`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ang_delivery_discarding` AS SELECT 
 1 AS `ContractId`,
 1 AS `DeliveryDate`,
 1 AS `ActivityName`,
 1 AS `ActivityShortName`,
 1 AS `ActivityDescription`,
 1 AS `ActivityDeliveryReportingCode`,
 1 AS `ActivityDeliveryInvoiceCode`,
 1 AS `ActivityDeliverySalaryCode`,
 1 AS `ActivityDeliveryServiceCode`,
 1 AS `ProductCode`,
 1 AS `ProductName`,
 1 AS `ProductDescription`,
 1 AS `OrganizationId`,
 1 AS `OrganizationName`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeInitials`,
 1 AS `EmployeeInfix`,
 1 AS `EmployeeNumberOfHoursWorked`,
 1 AS `EmployeeNumberOfHoursVacation`,
 1 AS `DeliveredByOtherEmployees`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerInfix`,
 1 AS `CustomerYearOfBirth`,
 1 AS `CustomerMonthOfBirth`,
 1 AS `CustomerZipCode`,
 1 AS `IsCustomerAbsent`,
 1 AS `IsCustomerAbsencePlanned`,
 1 AS `CustomerReportCode`,
 1 AS `IsCustomerReportSet`,
 1 AS `CustomerReportDate`,
 1 AS `CustomerReportRun`,
 1 AS `CustomerDeclarationCode`,
 1 AS `IsCustomerDeclarationSet`,
 1 AS `CustomerDeclarationDate`,
 1 AS `CustomerDeclarationRun`,
 1 AS `BillableTime`,
 1 AS `TotalDeliveredPerDeliveryPeriod`,
 1 AS `VolumeAssignedByContract`,
 1 AS `DifferenceBetweenDeliveredAndAssigned`,
 1 AS `DeliveryPeriod`,
 1 AS `CustomerRegion`,
 1 AS `ActivityId`,
 1 AS `ActivityDefaultDeclarationCode`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `DateActivityLogged`,
 1 AS `EmployeeThatLoggedTheActivity`,
 1 AS `DateThatActivityLogChanged`,
 1 AS `EmployeeThatChangedTheActivityLog`,
 1 AS `IsDeliveryDiscarded`,
 1 AS `ReasonForDiscardingDelivery`,
 1 AS `ContractDeliveryPeriod`,
 1 AS `DeliveryType`,
 1 AS `CustomerAge`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `ang_delivery_transformation`
--

DROP TABLE IF EXISTS `ang_delivery_transformation`;
/*!50001 DROP VIEW IF EXISTS `ang_delivery_transformation`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ang_delivery_transformation` AS SELECT 
 1 AS `ContractId`,
 1 AS `DeliveryDate`,
 1 AS `ActivityName`,
 1 AS `ActivityShortName`,
 1 AS `ActivityDescription`,
 1 AS `ActivityDeliveryReportingCode`,
 1 AS `ActivityDeliveryInvoiceCode`,
 1 AS `ActivityDeliverySalaryCode`,
 1 AS `ActivityDeliveryServiceCode`,
 1 AS `ProductCode`,
 1 AS `ProductName`,
 1 AS `ProductDescription`,
 1 AS `OrganizationId`,
 1 AS `OrganizationName`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeInitials`,
 1 AS `EmployeeInfix`,
 1 AS `EmployeeNumberOfHoursWorked`,
 1 AS `EmployeeNumberOfHoursVacation`,
 1 AS `DeliveredByOtherEmployees`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerInfix`,
 1 AS `CustomerYearOfBirth`,
 1 AS `CustomerMonthOfBirth`,
 1 AS `CustomerZipCode`,
 1 AS `IsCustomerAbsent`,
 1 AS `IsCustomerAbsencePlanned`,
 1 AS `CustomerReportCode`,
 1 AS `IsCustomerReportSet`,
 1 AS `CustomerReportDate`,
 1 AS `CustomerReportRun`,
 1 AS `CustomerDeclarationCode`,
 1 AS `IsCustomerDeclarationSet`,
 1 AS `CustomerDeclarationDate`,
 1 AS `CustomerDeclarationRun`,
 1 AS `BillableTime`,
 1 AS `TotalDeliveredPerDeliveryPeriod`,
 1 AS `VolumeAssignedByContract`,
 1 AS `DifferenceBetweenDeliveredAndAssigned`,
 1 AS `DeliveryPeriod`,
 1 AS `CustomerRegion`,
 1 AS `ActivityId`,
 1 AS `ActivityDefaultDeclarationCode`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `DateActivityLogged`,
 1 AS `EmployeeThatLoggedTheActivity`,
 1 AS `DateThatActivityLogChanged`,
 1 AS `EmployeeThatChangedTheActivityLog`,
 1 AS `ContractDeliveryPeriod`,
 1 AS `DeliveryType`,
 1 AS `CustomerAge`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `ang_delivery_transformation_tbl`
--

DROP TABLE IF EXISTS `ang_delivery_transformation_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ang_delivery_transformation_tbl` (
  `ContractId` varchar(45) NOT NULL DEFAULT '',
  `DeliveryDate` datetime DEFAULT NULL,
  `ActivityName` char(0) NOT NULL DEFAULT '',
  `ActivityShortName` char(0) NOT NULL DEFAULT '',
  `ActivityDescription` char(0) NOT NULL DEFAULT '',
  `ActivityDeliveryReportingCode` varchar(45) DEFAULT NULL,
  `ActivityDeliveryInvoiceCode` char(0) NOT NULL DEFAULT '',
  `ActivityDeliverySalaryCode` char(0) NOT NULL DEFAULT '',
  `ActivityDeliveryServiceCode` char(0) NOT NULL DEFAULT '',
  `ProductCode` varchar(45) DEFAULT NULL,
  `ProductName` varchar(100) DEFAULT NULL,
  `ProductDescription` char(0) NOT NULL DEFAULT '',
  `OrganizationId` char(0) NOT NULL DEFAULT '',
  `OrganizationName` char(0) NOT NULL DEFAULT '',
  `EmployeeId` varchar(45) NOT NULL DEFAULT '',
  `EmployeeLastName` varchar(45) NOT NULL DEFAULT '',
  `EmployeeInitials` char(0) NOT NULL DEFAULT '',
  `EmployeeInfix` char(0) NOT NULL DEFAULT '',
  `EmployeeNumberOfHoursWorked` double(17,0) DEFAULT NULL,
  `EmployeeNumberOfHoursVacation` double(17,0) DEFAULT NULL,
  `DeliveredByOtherEmployees` char(0) NOT NULL DEFAULT '',
  `CustomerIdentifier` varchar(45) DEFAULT NULL,
  `CustomerLastName` varchar(45) DEFAULT NULL,
  `CustomerInitials` varchar(45) DEFAULT NULL,
  `CustomerInfix` char(0) NOT NULL DEFAULT '',
  `CustomerYearOfBirth` char(0) NOT NULL DEFAULT '',
  `CustomerMonthOfBirth` char(0) NOT NULL DEFAULT '',
  `CustomerZipCode` varchar(45) DEFAULT NULL,
  `IsCustomerAbsent` char(0) NOT NULL DEFAULT '',
  `IsCustomerAbsencePlanned` char(0) NOT NULL DEFAULT '',
  `CustomerReportCode` varchar(45) DEFAULT NULL,
  `IsCustomerReportSet` char(0) NOT NULL DEFAULT '',
  `CustomerReportDate` char(0) NOT NULL DEFAULT '',
  `CustomerReportRun` char(0) NOT NULL DEFAULT '',
  `CustomerDeclarationCode` char(0) NOT NULL DEFAULT '',
  `IsCustomerDeclarationSet` char(0) NOT NULL DEFAULT '',
  `CustomerDeclarationDate` char(0) NOT NULL DEFAULT '',
  `CustomerDeclarationRun` char(0) NOT NULL DEFAULT '',
  `BillableTime` double(22,0) NOT NULL DEFAULT '0',
  `TotalDeliveredPerDeliveryPeriod` char(0) NOT NULL DEFAULT '',
  `VolumeAssignedByContract` double(22,0) NOT NULL DEFAULT '0',
  `DifferenceBetweenDeliveredAndAssigned` char(0) NOT NULL DEFAULT '',
  `DeliveryPeriod` varchar(30) DEFAULT NULL,
  `CustomerRegion` varchar(45) NOT NULL DEFAULT '',
  `ActivityId` varchar(45) DEFAULT NULL,
  `ActivityDefaultDeclarationCode` char(0) NOT NULL DEFAULT '',
  `EmployeeFirstName` varchar(45) DEFAULT NULL,
  `EmployeeDepartment` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `EmployeePersonalPerformanceIndicator` double DEFAULT NULL,
  `EmployeeDesignation` varchar(45) DEFAULT NULL,
  `EmployeeNumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `EmployeeTotalNumberOfHoursVacation` double(17,0) DEFAULT NULL,
  `DateActivityLogged` char(0) NOT NULL DEFAULT '',
  `EmployeeThatLoggedTheActivity` char(0) NOT NULL DEFAULT '',
  `DateThatActivityLogChanged` char(0) NOT NULL DEFAULT '',
  `EmployeeThatChangedTheActivityLog` char(0) NOT NULL DEFAULT '',
  `ContractDeliveryPeriod` binary(0) DEFAULT NULL,
  `DeliveryType` varchar(8) NOT NULL DEFAULT '',
  `CustomerAge` binary(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `ang_delivery_view`
--

DROP TABLE IF EXISTS `ang_delivery_view`;
/*!50001 DROP VIEW IF EXISTS `ang_delivery_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ang_delivery_view` AS SELECT 
 1 AS `ContractId`,
 1 AS `DeliveryDate`,
 1 AS `ActivityName`,
 1 AS `ActivityShortName`,
 1 AS `ActivityDescription`,
 1 AS `ActivityDeliveryReportingCode`,
 1 AS `ActivityDeliveryInvoiceCode`,
 1 AS `ActivityDeliverySalaryCode`,
 1 AS `ActivityDeliveryServiceCode`,
 1 AS `ProductCode`,
 1 AS `ProductName`,
 1 AS `ProductDescription`,
 1 AS `OrganizationId`,
 1 AS `OrganizationName`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `EmployeeInitials`,
 1 AS `EmployeeInfix`,
 1 AS `EmployeeNumberOfHoursWorked`,
 1 AS `EmployeeNumberOfHoursVacation`,
 1 AS `DeliveredByOtherEmployees`,
 1 AS `CustomerIdentifier`,
 1 AS `CustomerLastName`,
 1 AS `CustomerInitials`,
 1 AS `CustomerInfix`,
 1 AS `CustomerYearOfBirth`,
 1 AS `CustomerMonthOfBirth`,
 1 AS `CustomerZipCode`,
 1 AS `IsCustomerAbsent`,
 1 AS `IsCustomerAbsencePlanned`,
 1 AS `CustomerReportCode`,
 1 AS `IsCustomerReportSet`,
 1 AS `CustomerReportDate`,
 1 AS `CustomerReportRun`,
 1 AS `CustomerDeclarationCode`,
 1 AS `IsCustomerDeclarationSet`,
 1 AS `CustomerDeclarationDate`,
 1 AS `CustomerDeclarationRun`,
 1 AS `BillableTime`,
 1 AS `TotalDeliveredPerDeliveryPeriod`,
 1 AS `VolumeAssignedByContract`,
 1 AS `DifferenceBetweenDeliveredAndAssigned`,
 1 AS `DeliveryPeriod`,
 1 AS `CustomerRegion`,
 1 AS `ActivityId`,
 1 AS `ActivityDefaultDeclarationCode`,
 1 AS `EmployeeFirstName`,
 1 AS `EmployeeDepartment`,
 1 AS `EmployeePersonalPerformanceIndicator`,
 1 AS `EmployeeDesignation`,
 1 AS `EmployeeNumberOfHoursPerWeek`,
 1 AS `EmployeeTotalNumberOfHoursVacation`,
 1 AS `DateActivityLogged`,
 1 AS `EmployeeThatLoggedTheActivity`,
 1 AS `DateThatActivityLogChanged`,
 1 AS `EmployeeThatChangedTheActivityLog`,
 1 AS `IsDeliveryDiscarded`,
 1 AS `ReasonForDiscardingDelivery`,
 1 AS `ContractDeliveryPeriod`,
 1 AS `DeliveryType`,
 1 AS `CustomerAge`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `ang_employee_vacation_untill_last_week`
--

DROP TABLE IF EXISTS `ang_employee_vacation_untill_last_week`;
/*!50001 DROP VIEW IF EXISTS `ang_employee_vacation_untill_last_week`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ang_employee_vacation_untill_last_week` AS SELECT 
 1 AS `SourceEmployeeContractId`,
 1 AS `EmployeeTotalNumberOfHoursVacation`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `ang_sum_not_discarded`
--

DROP TABLE IF EXISTS `ang_sum_not_discarded`;
/*!50001 DROP VIEW IF EXISTS `ang_sum_not_discarded`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ang_sum_not_discarded` AS SELECT 
 1 AS `CustomerIdentifier`,
 1 AS `DeliveryPeriod`,
 1 AS `BillableTime`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_AssignedVsDelivered`
--

DROP TABLE IF EXISTS `b_AssignedVsDelivered`;
/*!50001 DROP VIEW IF EXISTS `b_AssignedVsDelivered`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_AssignedVsDelivered` AS SELECT 
 1 AS `CakDeliveryPeriod`,
 1 AS `CakDeliveryPeriodShort`,
 1 AS `SourceWorkAssignmentId`,
 1 AS `SourceCustomerId`,
 1 AS `CustomerOrganisationUnit`,
 1 AS `AssignmentFinancingType`,
 1 AS `AssignedHours`,
 1 AS `DeliveredHours`,
 1 AS `AssignedEuros`,
 1 AS `DeliveredEuros`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_AssignedVsDelivered_t1`
--

DROP TABLE IF EXISTS `b_AssignedVsDelivered_t1`;
/*!50001 DROP VIEW IF EXISTS `b_AssignedVsDelivered_t1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_AssignedVsDelivered_t1` AS SELECT 
 1 AS `CakDeliveryPeriod`,
 1 AS `CakDeliveryPeriodShort`,
 1 AS `SourceWorkAssignmentId`,
 1 AS `SourceCustomerId`,
 1 AS `CustomerOrganisationUnit`,
 1 AS `AssignmentFinancingType`,
 1 AS `AssignedHours`,
 1 AS `DeliveredHours`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `b_Customer`
--

DROP TABLE IF EXISTS `b_Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_Customer` (
  `ZenitCustomerId` int(11) NOT NULL DEFAULT '0',
  `ClientId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ClientLastName` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ClientCity` varchar(45) DEFAULT NULL,
  `CustomerOrganisationUnit` varchar(45) DEFAULT NULL,
  `FinancingType(s)` varchar(45) DEFAULT NULL,
  `CurrentWorkAssignmentId` varchar(45) DEFAULT NULL,
  `CurrentWorkAssignmentEndDate` date DEFAULT NULL,
  `InvolvedCaretaker(s)` varchar(999) DEFAULT NULL,
  `EarliestClientAppointment` datetime DEFAULT NULL,
  `LatestClientAppointment` datetime DEFAULT NULL,
  `LatestCommunicationCheck` datetime DEFAULT NULL,
  `NumberOfCommunicationChecks` int(11) DEFAULT NULL,
  `TotalBillableTime` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `b_DeliveriesForAssignedHealthcare`
--

DROP TABLE IF EXISTS `b_DeliveriesForAssignedHealthcare`;
/*!50001 DROP VIEW IF EXISTS `b_DeliveriesForAssignedHealthcare`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_DeliveriesForAssignedHealthcare` AS SELECT 
 1 AS `ZenitWorkDeliveryId`,
 1 AS `SourceWorkDeliveryId`,
 1 AS `DeliveryDate`,
 1 AS `ProductId`,
 1 AS `ProductName`,
 1 AS `SourceWorkerId`,
 1 AS `SourceCustomerId`,
 1 AS `DeliveryFinancingType`,
 1 AS `ZenitWorkAssignmentId`,
 1 AS `SourceWorkAssignmentId`,
 1 AS `AssignmentStartDate`,
 1 AS `AssignmentEndDate`,
 1 AS `MinutesOfWorkAssignedPerPeriod`,
 1 AS `DateOfAssignment`,
 1 AS `SourceCustomerRegion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_DeliveriesPerCustomerPerPeriod`
--

DROP TABLE IF EXISTS `b_DeliveriesPerCustomerPerPeriod`;
/*!50001 DROP VIEW IF EXISTS `b_DeliveriesPerCustomerPerPeriod`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_DeliveriesPerCustomerPerPeriod` AS SELECT 
 1 AS `CustomerId`,
 1 AS `SourceCustomerId`,
 1 AS `DeliveryPeriod`,
 1 AS `BillableTime`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_DeliveriesPerWorkerPerMonth`
--

DROP TABLE IF EXISTS `b_DeliveriesPerWorkerPerMonth`;
/*!50001 DROP VIEW IF EXISTS `b_DeliveriesPerWorkerPerMonth`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_DeliveriesPerWorkerPerMonth` AS SELECT 
 1 AS `SourceWorkerId`,
 1 AS `SourceEmployeeContractId`,
 1 AS `Year`,
 1 AS `Month`,
 1 AS `MonthName`,
 1 AS `RegisteredTime`,
 1 AS `BillableTime`,
 1 AS `LeaveTime`,
 1 AS `ParentalLeaveTime`,
 1 AS `PregnancyAbsenceTime`,
 1 AS `AbsenceHours`,
 1 AS `BillableTravelTime`,
 1 AS `NonBillableTravelTime`,
 1 AS `SchoolingTime`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_Employee`
--

DROP TABLE IF EXISTS `b_Employee`;
/*!50001 DROP VIEW IF EXISTS `b_Employee`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_Employee` AS SELECT 
 1 AS `ZenitEmployeeId`,
 1 AS `SourceEmployeeId`,
 1 AS `ZenitEmployeeContractId`,
 1 AS `SourceEmployeeContractId`,
 1 AS `FirstName`,
 1 AS `Name`,
 1 AS `WorkEmail`,
 1 AS `Designation`,
 1 AS `IsCareDesignation`,
 1 AS `IsContractIndefinite`,
 1 AS `FormOfContractDescription`,
 1 AS `NumberOfHoursPerWeek`,
 1 AS `DepartmentId`,
 1 AS `Department`,
 1 AS `CurrentContractStartDate`,
 1 AS `CurrentContractEndDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_EmployeeContractPeriod`
--

DROP TABLE IF EXISTS `b_EmployeeContractPeriod`;
/*!50001 DROP VIEW IF EXISTS `b_EmployeeContractPeriod`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_EmployeeContractPeriod` AS SELECT 
 1 AS `ZenitEmployeeContractPeriodId`,
 1 AS `ZenitEmployeeContractId`,
 1 AS `SourceEmployeeContractId`,
 1 AS `StartDate`,
 1 AS `EndDate`,
 1 AS `NumberOfHoursPerWeek`,
 1 AS `DepartmentId`,
 1 AS `Department`,
 1 AS `DesignationTarget`,
 1 AS `TargetDeviation`,
 1 AS `DesignationDescription`,
 1 AS `IsCareDesignation`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_WorkAssignment`
--

DROP TABLE IF EXISTS `b_WorkAssignment`;
/*!50001 DROP VIEW IF EXISTS `b_WorkAssignment`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_WorkAssignment` AS SELECT 
 1 AS `ZenitWorkAssignmentId`,
 1 AS `SourceWorkAssignmentId`,
 1 AS `CustomerId`,
 1 AS `SourceCustomerId`,
 1 AS `SourceCustomerRegion`,
 1 AS `Assignee`,
 1 AS `Assigner`,
 1 AS `AssignmentDeclarationId`,
 1 AS `StartDate`,
 1 AS `EndDate`,
 1 AS `ProductId`,
 1 AS `ProductDescription`,
 1 AS `MinutesOfWorkAssignedPerDay`,
 1 AS `OriginalVolume`,
 1 AS `OriginalUnit`,
 1 AS `OriginalFrequence`,
 1 AS `DateOfAssignment`,
 1 AS `AssignmentFinancingType`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_WorkDelivery`
--

DROP TABLE IF EXISTS `b_WorkDelivery`;
/*!50001 DROP VIEW IF EXISTS `b_WorkDelivery`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_WorkDelivery` AS SELECT 
 1 AS `ZenitWorkDeliveryId`,
 1 AS `SourceEmployeeContractId`,
 1 AS `SourceWorkerId`,
 1 AS `SourceWorkerLastName`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `WorkAssignmentId`,
 1 AS `CustomerId`,
 1 AS `SourceCustomerId`,
 1 AS `SourceCustomerLastName`,
 1 AS `SourceCustomerInitials`,
 1 AS `CustomerLastName`,
 1 AS `SourceCustomerZipCode`,
 1 AS `StartTime`,
 1 AS `EndTime`,
 1 AS `DeliveryPeriod`,
 1 AS `ActivityId`,
 1 AS `ActivityName`,
 1 AS `ProductId`,
 1 AS `ProductName`,
 1 AS `DeliveryDeclarationCode`,
 1 AS `DeliveryFinancingType`,
 1 AS `DeliveryHourlyRate`,
 1 AS `DeliveryTime`,
 1 AS `DirectCustomerTime`,
 1 AS `IndirectCustomerTime`,
 1 AS `RegisteredTime`,
 1 AS `BillableTime`,
 1 AS `LeaveTime`,
 1 AS `ParentalLeaveTime`,
 1 AS `PregnancyAbsenceTime`,
 1 AS `AbsenceTime`,
 1 AS `BillableTravelTime`,
 1 AS `NonBillableTravelTime`,
 1 AS `SchoolingTime`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `b_WorkDelivery_SinceLastUpdate`
--

DROP TABLE IF EXISTS `b_WorkDelivery_SinceLastUpdate`;
/*!50001 DROP VIEW IF EXISTS `b_WorkDelivery_SinceLastUpdate`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `b_WorkDelivery_SinceLastUpdate` AS SELECT 
 1 AS `ZenitWorkDeliveryId`,
 1 AS `SourceEmployeeContractId`,
 1 AS `SourceWorkerId`,
 1 AS `SourceWorkerLastName`,
 1 AS `EmployeeId`,
 1 AS `EmployeeLastName`,
 1 AS `WorkAssignmentId`,
 1 AS `CustomerId`,
 1 AS `SourceCustomerId`,
 1 AS `SourceCustomerLastName`,
 1 AS `SourceCustomerInitials`,
 1 AS `CustomerLastName`,
 1 AS `SourceCustomerZipCode`,
 1 AS `StartTime`,
 1 AS `EndTime`,
 1 AS `DeliveryPeriod`,
 1 AS `ActivityId`,
 1 AS `ActivityName`,
 1 AS `ProductId`,
 1 AS `ProductName`,
 1 AS `DeliveryDeclarationCode`,
 1 AS `DeliveryFinancingType`,
 1 AS `DeliveryHourlyRate`,
 1 AS `DeliveryTime`,
 1 AS `DirectCustomerTime`,
 1 AS `IndirectCustomerTime`,
 1 AS `RegisteredTime`,
 1 AS `BillableTime`,
 1 AS `LeaveTime`,
 1 AS `ParentalLeaveTime`,
 1 AS `PregnancyAbsenceTime`,
 1 AS `AbsenceTime`,
 1 AS `BillableTravelTime`,
 1 AS `NonBillableTravelTime`,
 1 AS `SchoolingTime`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `br_WorkDelivery_BillableTime`
--

DROP TABLE IF EXISTS `br_WorkDelivery_BillableTime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `br_WorkDelivery_BillableTime` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `Rule` varchar(999) DEFAULT NULL,
  `EffectiveStartDate` datetime DEFAULT NULL,
  `EffectiveEndDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_CalendarTable`
--

DROP TABLE IF EXISTS `cf_CalendarTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_CalendarTable` (
  `dt` date NOT NULL,
  `y` smallint(6) DEFAULT NULL,
  `q` tinyint(4) DEFAULT NULL,
  `m` tinyint(4) DEFAULT NULL,
  `d` tinyint(4) DEFAULT NULL,
  `dw` tinyint(4) DEFAULT NULL,
  `month_name` varchar(9) DEFAULT NULL,
  `day_name` varchar(9) DEFAULT NULL,
  `week_number` tinyint(4) DEFAULT NULL,
  `is_weekday` tinytext,
  `is_holiday` tinytext,
  `holiday_description` varchar(32) DEFAULT NULL,
  `is_payday` tinytext,
  `CakDeliveryPeriod` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`dt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_CustomerOrganisationUnit`
--

DROP TABLE IF EXISTS `cf_CustomerOrganisationUnit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_CustomerOrganisationUnit` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceOrganisationUnit` varchar(45) DEFAULT NULL,
  `OrganisationUnit` varchar(45) DEFAULT NULL,
  `EffectiveStartDate` datetime DEFAULT NULL,
  `EffectiveEndDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_DeliveryHourlyRate`
--

DROP TABLE IF EXISTS `cf_DeliveryHourlyRate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_DeliveryHourlyRate` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `OrganisationUnit` varchar(45) DEFAULT NULL,
  `ActivityDefaultReportingCode` varchar(45) DEFAULT NULL,
  `ProductId` varchar(45) DEFAULT NULL,
  `FinancingType` varchar(45) DEFAULT NULL,
  `HourlyRate` double DEFAULT NULL,
  `EffectiveStartDateTime` datetime DEFAULT NULL,
  `EffectiveEndDateTime` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`),
  KEY `index1` (`OrganisationUnit`,`ActivityDefaultReportingCode`,`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_DutchZipCodes`
--

DROP TABLE IF EXISTS `cf_DutchZipCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_DutchZipCodes` (
  `PC4` int(4) NOT NULL,
  `Municipality` text,
  PRIMARY KEY (`PC4`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_EmployeeBillableHoursTarget`
--

DROP TABLE IF EXISTS `cf_EmployeeBillableHoursTarget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_EmployeeBillableHoursTarget` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `Department` varchar(45) DEFAULT NULL,
  `Designation` varchar(45) DEFAULT NULL,
  `Target` varchar(45) DEFAULT NULL,
  `TotalOverheadFTE` varchar(45) DEFAULT NULL,
  `EffectiveStartDateTime` datetime DEFAULT NULL,
  `EffectiveEndDateTime` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_EmployeeContractTargetDeviation`
--

DROP TABLE IF EXISTS `cf_EmployeeContractTargetDeviation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_EmployeeContractTargetDeviation` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceEmployeeContractId` varchar(45) DEFAULT NULL,
  `EmployeeLastName` varchar(45) DEFAULT NULL,
  `TargetDeviation` varchar(45) DEFAULT NULL,
  `EffectiveStartDateTime` datetime DEFAULT NULL,
  `EffectiveEndDateTime` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_EmployeeContractType`
--

DROP TABLE IF EXISTS `cf_EmployeeContractType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_EmployeeContractType` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceContractType` varchar(45) DEFAULT NULL,
  `ContractType` varchar(45) DEFAULT NULL,
  `IsSalariedStaff` varchar(45) DEFAULT NULL,
  `EffectiveStartDate` datetime DEFAULT NULL,
  `EffectiveEndDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_EmployeeDepartment`
--

DROP TABLE IF EXISTS `cf_EmployeeDepartment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_EmployeeDepartment` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `DepartmentId` varchar(45) DEFAULT NULL,
  `Department` varchar(45) DEFAULT NULL,
  `DepartmentRstmutFormat` varchar(45) DEFAULT NULL,
  `EffectiveStartDateTime` datetime DEFAULT NULL,
  `EffectiveEndDateTime` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`),
  UNIQUE KEY `DepartmentId_UNIQUE` (`DepartmentId`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_EmployeeDesignation`
--

DROP TABLE IF EXISTS `cf_EmployeeDesignation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_EmployeeDesignation` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceDesignation` varchar(45) DEFAULT NULL,
  `Designation` varchar(45) DEFAULT NULL,
  `IsCareDesignation` varchar(45) DEFAULT NULL,
  `EffectiveStartDateTime` datetime DEFAULT NULL,
  `EffectiveEndDateTime` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_IsEmployeeOrganisation`
--

DROP TABLE IF EXISTS `cf_IsEmployeeOrganisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_IsEmployeeOrganisation` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceEmployeeId` varchar(45) DEFAULT NULL,
  `SourceEmployeeLastName` varchar(45) DEFAULT NULL,
  `IsEmployeeOrganisation` varchar(45) DEFAULT NULL,
  `EffectiveStartDateTime` datetime DEFAULT NULL,
  `EffectiveEndDateTime` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`),
  KEY `index1` (`SourceEmployeeId`,`IsEmployeeOrganisation`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_OfficeLocations`
--

DROP TABLE IF EXISTS `cf_OfficeLocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_OfficeLocations` (
  `ConfigId` int(11) NOT NULL AUTO_INCREMENT,
  `LocationName` varchar(45) DEFAULT NULL,
  `HouseNumber` varchar(45) DEFAULT NULL,
  `HouseNumberAddition` varchar(45) DEFAULT NULL,
  `Street` varchar(45) DEFAULT NULL,
  `ZipCode` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `CountryCode` varchar(45) DEFAULT NULL,
  `Description` varchar(45) DEFAULT NULL,
  `EffectiveStartDate` datetime DEFAULT NULL,
  `EffectiveEndDate` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ConfigId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_WorkDeliveryActivity`
--

DROP TABLE IF EXISTS `cf_WorkDeliveryActivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_WorkDeliveryActivity` (
  `RuleId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceActivityId` varchar(45) DEFAULT NULL,
  `SourceActivityName` varchar(45) DEFAULT NULL,
  `ActivityName` varchar(45) DEFAULT NULL,
  `EffectiveStartDateTime` datetime DEFAULT NULL,
  `EffectiveEndDateTime` datetime DEFAULT NULL,
  `RowChangeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`RuleId`),
  UNIQUE KEY `ActivityId_UNIQUE` (`SourceActivityId`)
) ENGINE=InnoDB AUTO_INCREMENT=237 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_rstm_sdbkostenplaatssoort`
--

DROP TABLE IF EXISTS `cf_rstm_sdbkostenplaatssoort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_rstm_sdbkostenplaatssoort` (
  `Personeelsnummer` text,
  `Kostenplaats 1` text,
  `Kostensoort 1` text,
  `Afdelingscode` text,
  `Afdeling` text,
  `In dienst` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_general_log`
--

DROP TABLE IF EXISTS `db_general_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_general_log` (
  `event_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_host` mediumtext NOT NULL,
  `thread_id` bigint(21) unsigned NOT NULL,
  `server_id` int(10) unsigned NOT NULL,
  `command_type` varchar(64) NOT NULL,
  `argument` mediumtext NOT NULL
) ENGINE=CSV DEFAULT CHARSET=utf8 COMMENT='General log';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_slow_log`
--

DROP TABLE IF EXISTS `db_slow_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_slow_log` (
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_host` mediumtext NOT NULL,
  `query_time` time NOT NULL,
  `lock_time` time NOT NULL,
  `rows_sent` int(11) NOT NULL,
  `rows_examined` int(11) NOT NULL,
  `db` varchar(512) NOT NULL,
  `last_insert_id` int(11) NOT NULL,
  `insert_id` int(11) NOT NULL,
  `server_id` int(10) unsigned NOT NULL,
  `sql_text` mediumtext NOT NULL,
  `thread_id` bigint(21) unsigned NOT NULL
) ENGINE=CSV DEFAULT CHARSET=utf8 COMMENT='Slow log';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_cw_Deliveries_t1_Customer`
--

DROP TABLE IF EXISTS `load_cw_Deliveries_t1_Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_cw_Deliveries_t1_Customer` (
  `client_id` text,
  `client_last_name` text,
  `client_initials` text,
  `client_infix` text,
  `client_year_of_birth` text,
  `client_month_of_birth` text,
  `client_zip_code` text,
  `production_organisation_name` text,
  `ROW_ID` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_cw_ZorgtoewijzingenJW_t1_Address`
--

DROP TABLE IF EXISTS `load_cw_ZorgtoewijzingenJW_t1_Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_cw_ZorgtoewijzingenJW_t1_Address` (
  `PID` int(11) DEFAULT NULL,
  `Straat` text,
  `Huisnummer` text,
  `Toevoeging` text,
  `Postcode` text,
  `Woonplaats` text,
  `Land` text,
  `ROW_ID` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_cw_ZorgtoewijzingenWMO_t1_Address`
--

DROP TABLE IF EXISTS `load_cw_ZorgtoewijzingenWMO_t1_Address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_cw_ZorgtoewijzingenWMO_t1_Address` (
  `PID` int(11) DEFAULT NULL,
  `Straat` text,
  `Huisnummer` text,
  `Toevoeging` text,
  `Postcode` text,
  `Woonplaats` text,
  `Land` text,
  `ROW_ID` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sdb_HRMExport`
--

DROP TABLE IF EXISTS `load_sdb_HRMExport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_sdb_HRMExport` (
  `kostenplaats` int(11) DEFAULT NULL,
  `kostenplaats omschr.` text,
  `organisatie-eenheid` text,
  `functie` text,
  `soort dienstverband` text,
  `werknemer naam` text,
  `dienst verband code` int(11) NOT NULL,
  `type` text,
  `datum in dienst` text,
  `datum afloop contract` text,
  `datum uitdienst` text,
  `uren kostenverdeling` double DEFAULT NULL,
  `arbeids uren` double DEFAULT NULL,
  `fte` double DEFAULT NULL,
  `e-mail intern` text,
  `Functiehuis` text,
  `PID` text,
  `Functie CW` text,
  `Relatiefprofiel` text,
  PRIMARY KEY (`dienst verband code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sdb_HRMExport_t1`
--

DROP TABLE IF EXISTS `load_sdb_HRMExport_t1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_sdb_HRMExport_t1` (
  `kostenplaats` int(11) DEFAULT NULL,
  `kostenplaats omschr.` text,
  `organisatie-eenheid` text,
  `functie` text,
  `soort dienstverband` text,
  `werknemer naam` text,
  `dienst verband code` int(11) NOT NULL,
  `type` text,
  `datum in dienst` text,
  `datum afloop contract` text,
  `datum uitdienst` text,
  `uren kostenverdeling` double DEFAULT NULL,
  `arbeids uren` double DEFAULT NULL,
  `fte` double DEFAULT NULL,
  `e-mail intern` text,
  `Functiehuis` text,
  `PID` text,
  `Functie CW` text,
  `Relatiefprofiel` text,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`dienst verband code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='In this transformation (t1) a ROW_ID is added to the source data. It is important that the ROW_ID is formed in the same way as in load_sdb_dienstverbanden as both sources partly contain the same records an the ROW_ID is used to uniquely identify them. ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `load_sdb_dienstverbandperiodes_2019`
--

DROP TABLE IF EXISTS `load_sdb_dienstverbandperiodes_2019`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `load_sdb_dienstverbandperiodes_2019` (
  `DienstverbandId` int(11) NOT NULL,
  `PeriodeBeginDatum` datetime NOT NULL,
  `PeriodeEindDatum` datetime DEFAULT NULL,
  `AfdelingCode` varchar(45) DEFAULT NULL,
  `AfdelingOmschrijving` varchar(45) DEFAULT NULL,
  `AfdelingEindDatum` datetime DEFAULT NULL,
  `AfdelingHoofdAfdelingCode` varchar(45) DEFAULT NULL,
  `AfdelingHoodfAfdelingOmschrijving` varchar(45) DEFAULT NULL,
  `FunctieCode` varchar(45) DEFAULT NULL,
  `FunctieOmschrijving` varchar(45) DEFAULT NULL,
  `FunctieKostprijs` varchar(45) DEFAULT NULL,
  `FunctieProductiviteitsfactor` varchar(45) DEFAULT NULL,
  `FunctieEindDatum` datetime DEFAULT NULL,
  `ContractvormCode` varchar(45) DEFAULT NULL,
  `ContractvormIsSalaris` varchar(45) DEFAULT NULL,
  `ContractvormOmschrijving` varchar(45) DEFAULT NULL,
  `UrenPerWeek` varchar(45) DEFAULT NULL,
  `UrenPerWeekMax` varchar(45) DEFAULT NULL,
  `SchaalTredeId` varchar(45) DEFAULT NULL,
  `SchaalTredeSchaal` varchar(45) DEFAULT NULL,
  `SchaalTredeTrede` varchar(45) DEFAULT NULL,
  `SchaalTredeInpassingCode` varchar(45) DEFAULT NULL,
  `SchaalTredeBedrag` varchar(45) DEFAULT NULL,
  `SchaalTredeOmschrijving` varchar(100) DEFAULT NULL,
  `SchaalTredeBeginDatum` datetime DEFAULT NULL,
  `SchaalTredeEindDatum` datetime DEFAULT NULL,
  `SalarisNominaal` varchar(45) DEFAULT NULL,
  `CAOCode` varchar(45) DEFAULT NULL,
  `CAOOmschrijving` varchar(45) DEFAULT NULL,
  `Kostensoort1Code` varchar(45) DEFAULT NULL,
  `Kostensoort1Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort1EindDatum` datetime DEFAULT NULL,
  `Kostensoort2Code` varchar(45) DEFAULT NULL,
  `Kostensoort2Omschrijving` varchar(45) DEFAULT NULL,
  `Kostensoort2EindDatum` datetime DEFAULT NULL,
  `Kostensoort3Code` varchar(45) DEFAULT NULL,
  `Kostensoort3Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort3EindDatum` datetime DEFAULT NULL,
  `Kostensoort4Code` varchar(45) DEFAULT NULL,
  `Kostensoort4Omschrijving` varchar(100) DEFAULT NULL,
  `Kostensoort4EindDatum` datetime DEFAULT NULL,
  `Kostenplaats1Code` varchar(45) DEFAULT NULL,
  `Kostenplaats1Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats1EindDatum` datetime DEFAULT NULL,
  `Kostenplaats2Code` varchar(45) DEFAULT NULL,
  `Kostenplaats2Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats2EindDatum` datetime DEFAULT NULL,
  `Kostenplaats3Code` varchar(45) DEFAULT NULL,
  `Kostenplaats3Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats3EindDatum` datetime DEFAULT NULL,
  `Kostenplaats4Code` varchar(45) DEFAULT NULL,
  `Kostenplaats4Omschrijving` varchar(100) DEFAULT NULL,
  `Kostenplaats4EindDatum` datetime DEFAULT NULL,
  `Kostenverdeling1` varchar(45) DEFAULT NULL,
  `Kostenverdeling2` varchar(45) DEFAULT NULL,
  `Kostenverdeling3` varchar(45) DEFAULT NULL,
  `Kostenverdeling4` varchar(45) DEFAULT NULL,
  `ROW_ID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`DienstverbandId`,`PeriodeBeginDatum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `m_ExecutedMappings`
--

DROP TABLE IF EXISTS `m_ExecutedMappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_ExecutedMappings` (
  `se` longtext CHARACTER SET utf8mb4,
  `te` varchar(101) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `m_ExecutedReferences`
--

DROP TABLE IF EXISTS `m_ExecutedReferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_ExecutedReferences` (
  `referenced_table_name` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `referenced_column_name` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `column_name` varchar(64) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `target_column_name` varchar(70) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `source_column_name` varchar(101) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `m_MappingRules`
--

DROP TABLE IF EXISTS `m_MappingRules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_MappingRules` (
  `MappingRuleId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceTable` varchar(99) DEFAULT NULL,
  `TargetTable` varchar(99) DEFAULT NULL,
  `ForeignKeysInTargetTable` varchar(99) DEFAULT NULL,
  `MappingOrder` int(11) DEFAULT NULL,
  `MappingFilter` varchar(5000) DEFAULT NULL,
  `RowChangeDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`MappingRuleId`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `m_MappingSheet`
--

DROP TABLE IF EXISTS `m_MappingSheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_MappingSheet` (
  `MappingId` int(11) NOT NULL AUTO_INCREMENT,
  `SourceTable` varchar(99) DEFAULT NULL,
  `SourceElement` varchar(99) DEFAULT NULL,
  `TransformationStatement` varchar(9999) DEFAULT NULL,
  `TargetTable` varchar(99) DEFAULT NULL,
  `TargetElement` varchar(99) DEFAULT NULL,
  `IsUpdateElement` tinyint(4) DEFAULT '0',
  `RowChangeDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`MappingId`)
) ENGINE=InnoDB AUTO_INCREMENT=891 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pbi_Employee`
--

DROP TABLE IF EXISTS `pbi_Employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbi_Employee` (
  `ZenitEmployeeId` int(11) DEFAULT '0',
  `SourceEmployeeId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ZenitEmployeeContractId` int(11) NOT NULL DEFAULT '0',
  `SourceEmployeeContractId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `FirstName` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Name` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `WorkEmail` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Designation` varchar(45) DEFAULT NULL,
  `IsCareDesignation` varchar(45) DEFAULT NULL,
  `IsContractIndefinite` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `FormOfContractDescription` varchar(45) DEFAULT NULL,
  `NumberOfHoursPerWeek` int(6) unsigned DEFAULT NULL,
  `DepartmentId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Department` varchar(45) DEFAULT NULL,
  `CurrentContractStartDate` date DEFAULT NULL,
  `CurrentContractEndDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pbi_EmployeeContractPeriod`
--

DROP TABLE IF EXISTS `pbi_EmployeeContractPeriod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbi_EmployeeContractPeriod` (
  `ZenitEmployeeContractPeriodId` int(11) NOT NULL DEFAULT '0',
  `ZenitEmployeeContractId` int(11) DEFAULT NULL,
  `SourceEmployeeContractId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `NumberOfHoursPerWeek` decimal(4,2) DEFAULT NULL,
  `DepartmentId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Department` varchar(45) DEFAULT NULL,
  `DesignationTarget` varchar(45) DEFAULT NULL,
  `TargetDeviation` varchar(45) NOT NULL DEFAULT '',
  `DesignationDescription` varchar(45) DEFAULT NULL,
  `IsCareDesignation` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pbi_WorkDelivery`
--

DROP TABLE IF EXISTS `pbi_WorkDelivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pbi_WorkDelivery` (
  `ZenitWorkDeliveryId` int(11) NOT NULL DEFAULT '0',
  `SourceEmployeeContractId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `SourceWorkerId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `SourceWorkerLastName` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `EmployeeId` int(11) DEFAULT '0',
  `EmployeeLastName` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `WorkAssignmentId` int(11) DEFAULT NULL,
  `CustomerId` int(11) DEFAULT NULL,
  `SourceCustomerId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `SourceCustomerLastName` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `SourceCustomerInitials` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `CustomerLastName` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `SourceCustomerZipCode` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `DeliveryPeriod` varchar(29) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ActivityId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ActivityName` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ProductId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ProductName` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `DeliveryDeclarationCode` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `DeliveryFinancingType` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `DeliveryHourlyRate` double DEFAULT NULL,
  `DeliveryTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `DirectCustomerTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `IndirectCustomerTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `RegisteredTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `BillableTime` double DEFAULT NULL,
  `LeaveTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ParentalLeaveTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `PregnancyAbsenceTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `AbsenceTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `BillableTravelTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `NonBillableTravelTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `SchoolingTime` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `rstm_FileGenerator`
--

DROP TABLE IF EXISTS `rstm_FileGenerator`;
/*!50001 DROP VIEW IF EXISTS `rstm_FileGenerator`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rstm_FileGenerator` AS SELECT 
 1 AS `Klantnummer`,
 1 AS `Personeelsnummer`,
 1 AS `Broncode`,
 1 AS `AfdelingCode`,
 1 AS `Kostensoort`,
 1 AS `Kostenplaats`,
 1 AS `Datum`,
 1 AS `Dienstcode`,
 1 AS `Dienstnummer`,
 1 AS `Diensttype`,
 1 AS `Aanvangtijd`,
 1 AS `Eindtijd`,
 1 AS `Begintijd pauze`,
 1 AS `Eindtijd pauze`,
 1 AS `Indicatie ziek`,
 1 AS `Indicatie zwanger`,
 1 AS `Indicatie vorige dag`,
 1 AS `Indicatie overwerk uitbetalen`,
 1 AS `Indicatie ort uitbetalen`,
 1 AS `Indicatie compensatie diensten uitbetalen`,
 1 AS `Indicatie slaapdienst volledig in tijd`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `rstm_FileGenerator_tbl`
--

DROP TABLE IF EXISTS `rstm_FileGenerator_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rstm_FileGenerator_tbl` (
  `Klantnummer` varchar(5) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Personeelsnummer` longtext CHARACTER SET utf8mb4,
  `Broncode` varchar(2) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `AfdelingCode` mediumtext,
  `Kostensoort` varchar(8) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Kostenplaats` varchar(8) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Datum` varchar(8) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Dienstcode` varchar(4) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Dienstnummer` varchar(2) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Diensttype` varchar(3) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Aanvangtijd` varchar(9) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Eindtijd` varchar(9) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Begintijd pauze` varchar(4) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Eindtijd pauze` varchar(4) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Indicatie ziek` varchar(1) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Indicatie zwanger` varchar(1) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Indicatie vorige dag` varchar(1) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Indicatie overwerk uitbetalen` varchar(1) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Indicatie ort uitbetalen` varchar(1) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Indicatie compensatie diensten uitbetalen` varchar(1) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `Indicatie slaapdienst volledig in tijd` varchar(1) CHARACTER SET utf8mb4 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `rstm_HolidayRegistrations`
--

DROP TABLE IF EXISTS `rstm_HolidayRegistrations`;
/*!50001 DROP VIEW IF EXISTS `rstm_HolidayRegistrations`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rstm_HolidayRegistrations` AS SELECT 
 1 AS `DienstverbandId`,
 1 AS `Achternaam`,
 1 AS `OrganisatieEenheid`,
 1 AS `Product`,
 1 AS `Activiteit`,
 1 AS `Datum`,
 1 AS `Duur`,
 1 AS `Feestdag`,
 1 AS `Toelichting`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `rstm_HolidayRegistrations_tbl`
--

DROP TABLE IF EXISTS `rstm_HolidayRegistrations_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rstm_HolidayRegistrations_tbl` (
  `DienstverbandId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Achternaam` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `OrganisatieEenheid` varchar(45) DEFAULT NULL,
  `Product` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Activiteit` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Duur` double DEFAULT NULL,
  `Feestdag` varchar(45) DEFAULT NULL,
  `Toelichting` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `rstm_ORT_LastMonth`
--

DROP TABLE IF EXISTS `rstm_ORT_LastMonth`;
/*!50001 DROP VIEW IF EXISTS `rstm_ORT_LastMonth`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rstm_ORT_LastMonth` AS SELECT 
 1 AS `medewerker_id`,
 1 AS `medewerker_naam`,
 1 AS `initialen`,
 1 AS `regio`,
 1 AS `datum`,
 1 AS `activiteit`,
 1 AS `client_id`,
 1 AS `client_naam`,
 1 AS `start_tijd`,
 1 AS `eind_tijd`,
 1 AS `start_ort`,
 1 AS `eind_ort`,
 1 AS `ort_uren`,
 1 AS `ort_percentage`,
 1 AS `opmerking`,
 1 AS `e-mail`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `rstm_ORT_LastMonth_tbl`
--

DROP TABLE IF EXISTS `rstm_ORT_LastMonth_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rstm_ORT_LastMonth_tbl` (
  `medewerker_id` bigint(21) unsigned DEFAULT NULL,
  `medewerker_naam` text,
  `initialen` text,
  `regio` varchar(45) DEFAULT NULL,
  `datum` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `activiteit` text,
  `client_id` text,
  `client_naam` text,
  `start_tijd` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `eind_tijd` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `start_ort` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `eind_ort` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ort_uren` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ort_percentage` varchar(25) CHARACTER SET utf8mb4 DEFAULT NULL,
  `opmerking` varchar(8) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  `e-mail` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `rstm_ParentalLeave`
--

DROP TABLE IF EXISTS `rstm_ParentalLeave`;
/*!50001 DROP VIEW IF EXISTS `rstm_ParentalLeave`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rstm_ParentalLeave` AS SELECT 
 1 AS `DienstverbandId`,
 1 AS `Achternaam`,
 1 AS `OrganisatieEenheid`,
 1 AS `Product`,
 1 AS `Activiteit`,
 1 AS `Datum`,
 1 AS `Duur`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `rstm_ParentalLeave_tbl`
--

DROP TABLE IF EXISTS `rstm_ParentalLeave_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rstm_ParentalLeave_tbl` (
  `DienstverbandId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Achternaam` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `OrganisatieEenheid` varchar(45) DEFAULT NULL,
  `Product` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Activiteit` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Duur` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `rstm_SpecialLeave`
--

DROP TABLE IF EXISTS `rstm_SpecialLeave`;
/*!50001 DROP VIEW IF EXISTS `rstm_SpecialLeave`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rstm_SpecialLeave` AS SELECT 
 1 AS `DienstverbandId`,
 1 AS `Achternaam`,
 1 AS `OrganisatieEenheid`,
 1 AS `Product`,
 1 AS `Activiteit`,
 1 AS `Datum`,
 1 AS `Duur`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `rstm_SpecialLeave_tbl`
--

DROP TABLE IF EXISTS `rstm_SpecialLeave_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rstm_SpecialLeave_tbl` (
  `DienstverbandId` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Achternaam` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `OrganisatieEenheid` varchar(45) DEFAULT NULL,
  `Product` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Activiteit` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Duur` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `rstm_deliveries`
--

DROP TABLE IF EXISTS `rstm_deliveries`;
/*!50001 DROP VIEW IF EXISTS `rstm_deliveries`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rstm_deliveries` AS SELECT 
 1 AS `production_id`,
 1 AS `production_start_date`,
 1 AS `production_end_date`,
 1 AS `activity_id`,
 1 AS `activity_name`,
 1 AS `activity_default_reporting_code`,
 1 AS `product_id`,
 1 AS `product_name`,
 1 AS `caretaker_id`,
 1 AS `caretaker_employee_codes`,
 1 AS `caretaker_last_name`,
 1 AS `caretaker_initials`,
 1 AS `client_zip_code`,
 1 AS `client_id`,
 1 AS `client_last_name`,
 1 AS `appointment_time`,
 1 AS `direct_time`,
 1 AS `indirect_time`,
 1 AS `registered_hours`,
 1 AS `billable_hours`,
 1 AS `leave_hours`,
 1 AS `parental_leave_hours`,
 1 AS `pregnancy_absence_hours`,
 1 AS `absence_hours`,
 1 AS `billable_travel_hours`,
 1 AS `non_billable_travel_hours`,
 1 AS `schooling_hours`,
 1 AS `ort_time`,
 1 AS `weekday`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `s_AddressesToBeGeocoded_view`
--

DROP TABLE IF EXISTS `s_AddressesToBeGeocoded_view`;
/*!50001 DROP VIEW IF EXISTS `s_AddressesToBeGeocoded_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `s_AddressesToBeGeocoded_view` AS SELECT 
 1 AS `ZenitAddressId`,
 1 AS `GoogleFormattedAddress`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `test_activity_planning`
--

DROP TABLE IF EXISTS `test_activity_planning`;
/*!50001 DROP VIEW IF EXISTS `test_activity_planning`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `test_activity_planning` AS SELECT 
 1 AS `vehicle_id`,
 1 AS `activities.id`,
 1 AS `activities.start_time`,
 1 AS `activities.end_time`,
 1 AS `driving_time`,
 1 AS `driving_seconds`,
 1 AS `activities.distance`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `test_caseload`
--

DROP TABLE IF EXISTS `test_caseload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_caseload` (
  `ActivityType` text,
  `ActivityName` text,
  `CustomerId` int(11) DEFAULT NULL,
  `Duration` int(11) DEFAULT NULL,
  `MinimumTimesPerWeek` double DEFAULT NULL,
  `Lon` double DEFAULT NULL,
  `Lat` double DEFAULT NULL,
  `TimewindowStart` text,
  `TimewindowEnd` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `test_employee_availability`
--

DROP TABLE IF EXISTS `test_employee_availability`;
/*!50001 DROP VIEW IF EXISTS `test_employee_availability`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `test_employee_availability` AS SELECT 
 1 AS `SourceEmployeeContractId`,
 1 AS `Lon`,
 1 AS `Lat`,
 1 AS `Weekday`,
 1 AS `Start`,
 1 AS `End`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `test_employee_working_days`
--

DROP TABLE IF EXISTS `test_employee_working_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_employee_working_days` (
  `SourceEmployeeContractId` text,
  `Lon` double DEFAULT NULL,
  `Lat` double DEFAULT NULL,
  `MondayStart` int(11) DEFAULT NULL,
  `MondayEnd` int(11) DEFAULT NULL,
  `TuesdayStart` int(11) DEFAULT NULL,
  `TuesdayEnd` int(11) DEFAULT NULL,
  `WednesdayStart` int(11) DEFAULT NULL,
  `WednesdayEnd` int(11) DEFAULT NULL,
  `ThursdayStart` int(11) DEFAULT NULL,
  `ThursdayEnd` int(11) DEFAULT NULL,
  `FridayStart` int(11) DEFAULT NULL,
  `FridayEnd` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_graphopper_response`
--

DROP TABLE IF EXISTS `test_graphopper_response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_graphopper_response` (
  `vehicle_id` text,
  `distance` int(11) DEFAULT NULL,
  `transport_time` int(11) DEFAULT NULL,
  `completion_time` int(11) DEFAULT NULL,
  `waiting_time` int(11) DEFAULT NULL,
  `service_duration` int(11) DEFAULT NULL,
  `preparation_time` int(11) DEFAULT NULL,
  `activities.type` text,
  `activities.location_id` text,
  `activities.address` text,
  `activities.end_time` text,
  `activities.end_date_time` text,
  `activities.distance` int(11) DEFAULT NULL,
  `activities.driving_time` int(11) DEFAULT NULL,
  `activities.preparation_time` int(11) DEFAULT NULL,
  `activities.waiting_time` int(11) DEFAULT NULL,
  `activities.load_after` text,
  `activities.id` text,
  `activities.arr_time` text,
  `activities.arr_date_time` text,
  `activities.load_before` text,
  `points` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `test_required_activities`
--

DROP TABLE IF EXISTS `test_required_activities`;
/*!50001 DROP VIEW IF EXISTS `test_required_activities`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `test_required_activities` AS SELECT 
 1 AS `ActivityType`,
 1 AS `ActivityName`,
 1 AS `CustomerId`,
 1 AS `Duration`,
 1 AS `Lon`,
 1 AS `Lat`,
 1 AS `TimewindowStart`,
 1 AS `TimewindowEnd`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `test_s_graphhopper_services`
--

DROP TABLE IF EXISTS `test_s_graphhopper_services`;
/*!50001 DROP VIEW IF EXISTS `test_s_graphhopper_services`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `test_s_graphhopper_services` AS SELECT 
 1 AS `ActivityType`,
 1 AS `ActivityName`,
 1 AS `CustomerId`,
 1 AS `Duration`,
 1 AS `Lon`,
 1 AS `Lat`,
 1 AS `TimewindowStart`,
 1 AS `TimewindowEnd`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `test_s_graphhopper_vehicles`
--

DROP TABLE IF EXISTS `test_s_graphhopper_vehicles`;
/*!50001 DROP VIEW IF EXISTS `test_s_graphhopper_vehicles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `test_s_graphhopper_vehicles` AS SELECT 
 1 AS `vehicles_vehicle_id`,
 1 AS `vehicles_type_id`,
 1 AS `vehicles_start_address_location_id`,
 1 AS `vehicles_start_address_lon`,
 1 AS `vehicles_start_address_lat`,
 1 AS `vehicles_end_address_location_id`,
 1 AS `vehicles_end_address_lon`,
 1 AS `vehicles_end_address_lat`,
 1 AS `vehicles_earliest_start`,
 1 AS `vehicles_latest_end`*/;
SET character_set_client = @saved_cs_client;

--
-- Current Database: `GGMDRULES`
--

USE `GGMDRULES`;

--
-- Final view structure for view `ang_DeliveriesForAssignedHealthcare`
--

/*!50001 DROP VIEW IF EXISTS `ang_DeliveriesForAssignedHealthcare`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ang_DeliveriesForAssignedHealthcare` AS select `_WorkDelivery`.`ZenitWorkDeliveryId` AS `ZenitWorkDeliveryId`,`_WorkDelivery`.`SourceWorkDeliveryId` AS `SourceWorkDeliveryId`,cast(`_WorkDelivery`.`StartTime` as date) AS `DeliveryDate`,`_WorkDelivery`.`ProductId` AS `ProductId`,`_WorkDelivery`.`ProductName` AS `ProductName`,`_WorkDelivery`.`SourceWorkerId` AS `SourceWorkerId`,`_WorkDelivery`.`SourceCustomerId` AS `SourceCustomerId`,`_WorkDelivery`.`DeliveryFinancingType` AS `DeliveryFinancingType`,`_WorkAssignment`.`ZenitWorkAssignmentId` AS `ZenitWorkAssignmentId`,`_WorkAssignment`.`SourceWorkAssignmentId` AS `SourceWorkAssignmentId`,`_WorkAssignment`.`StartDate` AS `AssignmentStartDate`,`_WorkAssignment`.`EndDate` AS `AssignmentEndDate`,max(`_WorkAssignment`.`MinutesOfWorkAssignedPerPeriod`) AS `MinutesOfWorkAssignedPerPeriod`,`_WorkAssignment`.`DateOfAssignment` AS `DateOfAssignment`,`_WorkAssignment`.`SourceCustomerRegion` AS `SourceCustomerRegion` from (`_WorkDelivery` left join `_WorkAssignment` on(((`_WorkAssignment`.`SourceCustomerId` = `_WorkDelivery`.`SourceCustomerId`) and (cast(`_WorkDelivery`.`StartTime` as date) between `_WorkAssignment`.`StartDate` and `_WorkAssignment`.`EndDate`) and ((`_WorkDelivery`.`DeliveryFinancingType` = `_WorkAssignment`.`AssignmentFinancingType`) or isnull(`_WorkDelivery`.`DeliveryFinancingType`))))) group by `_WorkDelivery`.`ZenitWorkDeliveryId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ang_delivery_discarding`
--

/*!50001 DROP VIEW IF EXISTS `ang_delivery_discarding`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ang_delivery_discarding` AS select `ang_delivery_transformation_tbl`.`ContractId` AS `ContractId`,`ang_delivery_transformation_tbl`.`DeliveryDate` AS `DeliveryDate`,`ang_delivery_transformation_tbl`.`ActivityName` AS `ActivityName`,`ang_delivery_transformation_tbl`.`ActivityShortName` AS `ActivityShortName`,`ang_delivery_transformation_tbl`.`ActivityDescription` AS `ActivityDescription`,`ang_delivery_transformation_tbl`.`ActivityDeliveryReportingCode` AS `ActivityDeliveryReportingCode`,`ang_delivery_transformation_tbl`.`ActivityDeliveryInvoiceCode` AS `ActivityDeliveryInvoiceCode`,`ang_delivery_transformation_tbl`.`ActivityDeliverySalaryCode` AS `ActivityDeliverySalaryCode`,`ang_delivery_transformation_tbl`.`ActivityDeliveryServiceCode` AS `ActivityDeliveryServiceCode`,`ang_delivery_transformation_tbl`.`ProductCode` AS `ProductCode`,`ang_delivery_transformation_tbl`.`ProductName` AS `ProductName`,`ang_delivery_transformation_tbl`.`ProductDescription` AS `ProductDescription`,`ang_delivery_transformation_tbl`.`OrganizationId` AS `OrganizationId`,`ang_delivery_transformation_tbl`.`OrganizationName` AS `OrganizationName`,`ang_delivery_transformation_tbl`.`EmployeeId` AS `EmployeeId`,`ang_delivery_transformation_tbl`.`EmployeeLastName` AS `EmployeeLastName`,`ang_delivery_transformation_tbl`.`EmployeeInitials` AS `EmployeeInitials`,`ang_delivery_transformation_tbl`.`EmployeeInfix` AS `EmployeeInfix`,`ang_delivery_transformation_tbl`.`EmployeeNumberOfHoursWorked` AS `EmployeeNumberOfHoursWorked`,`ang_delivery_transformation_tbl`.`EmployeeNumberOfHoursVacation` AS `EmployeeNumberOfHoursVacation`,`ang_delivery_transformation_tbl`.`DeliveredByOtherEmployees` AS `DeliveredByOtherEmployees`,`ang_delivery_transformation_tbl`.`CustomerIdentifier` AS `CustomerIdentifier`,`ang_delivery_transformation_tbl`.`CustomerLastName` AS `CustomerLastName`,`ang_delivery_transformation_tbl`.`CustomerInitials` AS `CustomerInitials`,`ang_delivery_transformation_tbl`.`CustomerInfix` AS `CustomerInfix`,`ang_delivery_transformation_tbl`.`CustomerYearOfBirth` AS `CustomerYearOfBirth`,`ang_delivery_transformation_tbl`.`CustomerMonthOfBirth` AS `CustomerMonthOfBirth`,`ang_delivery_transformation_tbl`.`CustomerZipCode` AS `CustomerZipCode`,`ang_delivery_transformation_tbl`.`IsCustomerAbsent` AS `IsCustomerAbsent`,`ang_delivery_transformation_tbl`.`IsCustomerAbsencePlanned` AS `IsCustomerAbsencePlanned`,`ang_delivery_transformation_tbl`.`CustomerReportCode` AS `CustomerReportCode`,`ang_delivery_transformation_tbl`.`IsCustomerReportSet` AS `IsCustomerReportSet`,`ang_delivery_transformation_tbl`.`CustomerReportDate` AS `CustomerReportDate`,`ang_delivery_transformation_tbl`.`CustomerReportRun` AS `CustomerReportRun`,`ang_delivery_transformation_tbl`.`CustomerDeclarationCode` AS `CustomerDeclarationCode`,`ang_delivery_transformation_tbl`.`IsCustomerDeclarationSet` AS `IsCustomerDeclarationSet`,`ang_delivery_transformation_tbl`.`CustomerDeclarationDate` AS `CustomerDeclarationDate`,`ang_delivery_transformation_tbl`.`CustomerDeclarationRun` AS `CustomerDeclarationRun`,`ang_delivery_transformation_tbl`.`BillableTime` AS `BillableTime`,'' AS `TotalDeliveredPerDeliveryPeriod`,`ang_delivery_transformation_tbl`.`VolumeAssignedByContract` AS `VolumeAssignedByContract`,'' AS `DifferenceBetweenDeliveredAndAssigned`,`ang_delivery_transformation_tbl`.`DeliveryPeriod` AS `DeliveryPeriod`,`ang_delivery_transformation_tbl`.`CustomerRegion` AS `CustomerRegion`,`ang_delivery_transformation_tbl`.`ActivityId` AS `ActivityId`,`ang_delivery_transformation_tbl`.`ActivityDefaultDeclarationCode` AS `ActivityDefaultDeclarationCode`,`ang_delivery_transformation_tbl`.`EmployeeFirstName` AS `EmployeeFirstName`,`ang_delivery_transformation_tbl`.`EmployeeDepartment` AS `EmployeeDepartment`,`ang_delivery_transformation_tbl`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,`ang_delivery_transformation_tbl`.`EmployeeDesignation` AS `EmployeeDesignation`,`ang_delivery_transformation_tbl`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,`ang_delivery_transformation_tbl`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,`ang_delivery_transformation_tbl`.`DateActivityLogged` AS `DateActivityLogged`,`ang_delivery_transformation_tbl`.`EmployeeThatLoggedTheActivity` AS `EmployeeThatLoggedTheActivity`,`ang_delivery_transformation_tbl`.`DateThatActivityLogChanged` AS `DateThatActivityLogChanged`,`ang_delivery_transformation_tbl`.`EmployeeThatChangedTheActivityLog` AS `EmployeeThatChangedTheActivityLog`,(case when ((`ang_delivery_transformation_tbl`.`EmployeeNumberOfHoursWorked` = 0) or isnull(`ang_delivery_transformation_tbl`.`EmployeeNumberOfHoursPerWeek`) or isnull(`ang_delivery_transformation_tbl`.`EmployeeDepartment`) or (`ang_delivery_transformation_tbl`.`EmployeeDesignation` in ('null','')) or isnull(`ang_delivery_transformation_tbl`.`EmployeePersonalPerformanceIndicator`) or (`ang_delivery_transformation_tbl`.`ContractId` = '') or (`ang_delivery_transformation_tbl`.`DeliveryType` not in ('Jeugdwet','WMO'))) then 'true' else 'false' end) AS `IsDeliveryDiscarded`,(case when (`ang_delivery_transformation_tbl`.`EmployeeNumberOfHoursWorked` = 0) then 'NothingDelivered' when isnull(`ang_delivery_transformation_tbl`.`EmployeeNumberOfHoursPerWeek`) then 'NoEmployeeFoundInSDB' when isnull(`ang_delivery_transformation_tbl`.`EmployeeDepartment`) then 'NoValidDepartment' when (`ang_delivery_transformation_tbl`.`EmployeeDesignation` in ('null','')) then 'NoDesignationDefined' when isnull(`ang_delivery_transformation_tbl`.`EmployeePersonalPerformanceIndicator`) then 'NotRelevantForDashboard' when (`ang_delivery_transformation_tbl`.`DeliveryType` not in ('Jeugdwet','WMO')) then 'NotWMO' when (`ang_delivery_transformation_tbl`.`ContractId` = '') then 'NotOnePossibleContract' else '' end) AS `ReasonForDiscardingDelivery`,`ang_delivery_transformation_tbl`.`ContractDeliveryPeriod` AS `ContractDeliveryPeriod`,`ang_delivery_transformation_tbl`.`DeliveryType` AS `DeliveryType`,`ang_delivery_transformation_tbl`.`CustomerAge` AS `CustomerAge` from `ang_delivery_transformation_tbl` group by `ang_delivery_transformation_tbl`.`DeliveryDate`,`ang_delivery_transformation_tbl`.`EmployeeId`,`ang_delivery_transformation_tbl`.`CustomerIdentifier` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ang_delivery_transformation`
--

/*!50001 DROP VIEW IF EXISTS `ang_delivery_transformation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ang_delivery_transformation` AS select ifnull(`b_DeliveriesForAssignedHealthcare`.`SourceWorkAssignmentId`,'') AS `ContractId`,`b_WorkDelivery`.`StartTime` AS `DeliveryDate`,'' AS `ActivityName`,'' AS `ActivityShortName`,'' AS `ActivityDescription`,`b_WorkDelivery`.`DeliveryDeclarationCode` AS `ActivityDeliveryReportingCode`,'' AS `ActivityDeliveryInvoiceCode`,'' AS `ActivityDeliverySalaryCode`,'' AS `ActivityDeliveryServiceCode`,`b_WorkDelivery`.`ProductId` AS `ProductCode`,`b_WorkDelivery`.`ProductName` AS `ProductName`,'' AS `ProductDescription`,'' AS `OrganizationId`,'' AS `OrganizationName`,ifnull(`b_WorkDelivery`.`SourceEmployeeContractId`,'') AS `EmployeeId`,ifnull(`b_WorkDelivery`.`SourceWorkerLastName`,'') AS `EmployeeLastName`,'' AS `EmployeeInitials`,'' AS `EmployeeInfix`,round(`b_WorkDelivery`.`RegisteredTime`,0) AS `EmployeeNumberOfHoursWorked`,round(((((`b_WorkDelivery`.`LeaveTime` + `b_WorkDelivery`.`ParentalLeaveTime`) + `b_WorkDelivery`.`SchoolingTime`) + `b_WorkDelivery`.`AbsenceTime`) + `b_WorkDelivery`.`PregnancyAbsenceTime`),0) AS `EmployeeNumberOfHoursVacation`,'' AS `DeliveredByOtherEmployees`,`b_WorkDelivery`.`SourceCustomerId` AS `CustomerIdentifier`,`b_WorkDelivery`.`SourceCustomerLastName` AS `CustomerLastName`,`b_WorkDelivery`.`SourceCustomerInitials` AS `CustomerInitials`,'' AS `CustomerInfix`,'' AS `CustomerYearOfBirth`,'' AS `CustomerMonthOfBirth`,`b_WorkDelivery`.`SourceCustomerZipCode` AS `CustomerZipCode`,'' AS `IsCustomerAbsent`,'' AS `IsCustomerAbsencePlanned`,`b_WorkDelivery`.`DeliveryDeclarationCode` AS `CustomerReportCode`,'' AS `IsCustomerReportSet`,'' AS `CustomerReportDate`,'' AS `CustomerReportRun`,'' AS `CustomerDeclarationCode`,'' AS `IsCustomerDeclarationSet`,'' AS `CustomerDeclarationDate`,'' AS `CustomerDeclarationRun`,ifnull(round(`b_WorkDelivery`.`BillableTime`,0),0) AS `BillableTime`,'' AS `TotalDeliveredPerDeliveryPeriod`,ifnull(round(`b_DeliveriesForAssignedHealthcare`.`MinutesOfWorkAssignedPerPeriod`,0),0) AS `VolumeAssignedByContract`,'' AS `DifferenceBetweenDeliveredAndAssigned`,`b_WorkDelivery`.`DeliveryPeriod` AS `DeliveryPeriod`,ifnull(`b_DeliveriesForAssignedHealthcare`.`SourceCustomerRegion`,'') AS `CustomerRegion`,`b_WorkDelivery`.`ActivityId` AS `ActivityId`,'' AS `ActivityDefaultDeclarationCode`,`b_Employee`.`FirstName` AS `EmployeeFirstName`,`b_EmployeeContractPeriod`.`Department` AS `EmployeeDepartment`,((`b_EmployeeContractPeriod`.`DesignationTarget` * (`b_EmployeeContractPeriod`.`NumberOfHoursPerWeek` / 36)) + `b_EmployeeContractPeriod`.`TargetDeviation`) AS `EmployeePersonalPerformanceIndicator`,`b_EmployeeContractPeriod`.`DesignationDescription` AS `EmployeeDesignation`,`b_EmployeeContractPeriod`.`NumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,round(`ang_employee_vacation_untill_last_week`.`EmployeeTotalNumberOfHoursVacation`,0) AS `EmployeeTotalNumberOfHoursVacation`,'' AS `DateActivityLogged`,'' AS `EmployeeThatLoggedTheActivity`,'' AS `DateThatActivityLogChanged`,'' AS `EmployeeThatChangedTheActivityLog`,NULL AS `ContractDeliveryPeriod`,(case when (`b_WorkDelivery`.`DeliveryFinancingType` = 'JW') then 'Jeugdwet' when (`b_WorkDelivery`.`DeliveryFinancingType` = 'JW_DBC') then 'Jeugdwet' when (`b_WorkDelivery`.`DeliveryFinancingType` = 'WMO') then 'WMO' else '' end) AS `DeliveryType`,NULL AS `CustomerAge` from ((((`b_WorkDelivery` left join `b_Employee` on((`b_WorkDelivery`.`SourceEmployeeContractId` = `b_Employee`.`SourceEmployeeContractId`))) left join `b_EmployeeContractPeriod` on(((`b_Employee`.`SourceEmployeeContractId` = `b_EmployeeContractPeriod`.`SourceEmployeeContractId`) and (cast(`b_WorkDelivery`.`StartTime` as date) between `b_EmployeeContractPeriod`.`StartDate` and `b_EmployeeContractPeriod`.`EndDate`)))) left join `ang_employee_vacation_untill_last_week` on((`ang_employee_vacation_untill_last_week`.`SourceEmployeeContractId` = `b_WorkDelivery`.`SourceEmployeeContractId`))) left join `b_DeliveriesForAssignedHealthcare` on((`b_WorkDelivery`.`ZenitWorkDeliveryId` = `b_DeliveriesForAssignedHealthcare`.`ZenitWorkDeliveryId`))) where (year(`b_WorkDelivery`.`StartTime`) = year(curdate())) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ang_delivery_view`
--

/*!50001 DROP VIEW IF EXISTS `ang_delivery_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ang_delivery_view` AS select `ang_delivery_discarding`.`ContractId` AS `ContractId`,`ang_delivery_discarding`.`DeliveryDate` AS `DeliveryDate`,`ang_delivery_discarding`.`ActivityName` AS `ActivityName`,`ang_delivery_discarding`.`ActivityShortName` AS `ActivityShortName`,`ang_delivery_discarding`.`ActivityDescription` AS `ActivityDescription`,`ang_delivery_discarding`.`ActivityDeliveryReportingCode` AS `ActivityDeliveryReportingCode`,`ang_delivery_discarding`.`ActivityDeliveryInvoiceCode` AS `ActivityDeliveryInvoiceCode`,`ang_delivery_discarding`.`ActivityDeliverySalaryCode` AS `ActivityDeliverySalaryCode`,`ang_delivery_discarding`.`ActivityDeliveryServiceCode` AS `ActivityDeliveryServiceCode`,`ang_delivery_discarding`.`ProductCode` AS `ProductCode`,`ang_delivery_discarding`.`ProductName` AS `ProductName`,`ang_delivery_discarding`.`ProductDescription` AS `ProductDescription`,`ang_delivery_discarding`.`OrganizationId` AS `OrganizationId`,`ang_delivery_discarding`.`OrganizationName` AS `OrganizationName`,`ang_delivery_discarding`.`EmployeeId` AS `EmployeeId`,`ang_delivery_discarding`.`EmployeeLastName` AS `EmployeeLastName`,`ang_delivery_discarding`.`EmployeeInitials` AS `EmployeeInitials`,`ang_delivery_discarding`.`EmployeeInfix` AS `EmployeeInfix`,`ang_delivery_discarding`.`EmployeeNumberOfHoursWorked` AS `EmployeeNumberOfHoursWorked`,`ang_delivery_discarding`.`EmployeeNumberOfHoursVacation` AS `EmployeeNumberOfHoursVacation`,`ang_delivery_discarding`.`DeliveredByOtherEmployees` AS `DeliveredByOtherEmployees`,`ang_delivery_discarding`.`CustomerIdentifier` AS `CustomerIdentifier`,`ang_delivery_discarding`.`CustomerLastName` AS `CustomerLastName`,`ang_delivery_discarding`.`CustomerInitials` AS `CustomerInitials`,`ang_delivery_discarding`.`CustomerInfix` AS `CustomerInfix`,NULL AS `CustomerYearOfBirth`,NULL AS `CustomerMonthOfBirth`,`ang_delivery_discarding`.`CustomerZipCode` AS `CustomerZipCode`,`ang_delivery_discarding`.`IsCustomerAbsent` AS `IsCustomerAbsent`,`ang_delivery_discarding`.`IsCustomerAbsencePlanned` AS `IsCustomerAbsencePlanned`,`ang_delivery_discarding`.`CustomerReportCode` AS `CustomerReportCode`,`ang_delivery_discarding`.`IsCustomerReportSet` AS `IsCustomerReportSet`,NULL AS `CustomerReportDate`,`ang_delivery_discarding`.`CustomerReportRun` AS `CustomerReportRun`,`ang_delivery_discarding`.`CustomerDeclarationCode` AS `CustomerDeclarationCode`,`ang_delivery_discarding`.`IsCustomerDeclarationSet` AS `IsCustomerDeclarationSet`,NULL AS `CustomerDeclarationDate`,`ang_delivery_discarding`.`CustomerDeclarationRun` AS `CustomerDeclarationRun`,`ang_delivery_discarding`.`BillableTime` AS `BillableTime`,ifnull(`ang_sum_not_discarded`.`BillableTime`,0) AS `TotalDeliveredPerDeliveryPeriod`,`ang_delivery_discarding`.`VolumeAssignedByContract` AS `VolumeAssignedByContract`,((`ang_sum_not_discarded`.`BillableTime` / 60) - `ang_delivery_discarding`.`VolumeAssignedByContract`) AS `DifferenceBetweenDeliveredAndAssigned`,`ang_delivery_discarding`.`DeliveryPeriod` AS `DeliveryPeriod`,`ang_delivery_discarding`.`CustomerRegion` AS `CustomerRegion`,`ang_delivery_discarding`.`ActivityId` AS `ActivityId`,`ang_delivery_discarding`.`ActivityDefaultDeclarationCode` AS `ActivityDefaultDeclarationCode`,`ang_delivery_discarding`.`EmployeeFirstName` AS `EmployeeFirstName`,`ang_delivery_discarding`.`EmployeeDepartment` AS `EmployeeDepartment`,ifnull(`ang_delivery_discarding`.`EmployeePersonalPerformanceIndicator`,0) AS `EmployeePersonalPerformanceIndicator`,`ang_delivery_discarding`.`EmployeeDesignation` AS `EmployeeDesignation`,`ang_delivery_discarding`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,`ang_delivery_discarding`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,NULL AS `DateActivityLogged`,`ang_delivery_discarding`.`EmployeeThatLoggedTheActivity` AS `EmployeeThatLoggedTheActivity`,NULL AS `DateThatActivityLogChanged`,`ang_delivery_discarding`.`EmployeeThatChangedTheActivityLog` AS `EmployeeThatChangedTheActivityLog`,`ang_delivery_discarding`.`IsDeliveryDiscarded` AS `IsDeliveryDiscarded`,`ang_delivery_discarding`.`ReasonForDiscardingDelivery` AS `ReasonForDiscardingDelivery`,`ang_delivery_discarding`.`ContractDeliveryPeriod` AS `ContractDeliveryPeriod`,`ang_delivery_discarding`.`DeliveryType` AS `DeliveryType`,`ang_delivery_discarding`.`CustomerAge` AS `CustomerAge` from (`ang_delivery_discarding` left join `ang_sum_not_discarded` on(((`ang_delivery_discarding`.`CustomerIdentifier` = `ang_sum_not_discarded`.`CustomerIdentifier`) and (`ang_delivery_discarding`.`DeliveryPeriod` = `ang_sum_not_discarded`.`DeliveryPeriod`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ang_employee_vacation_untill_last_week`
--

/*!50001 DROP VIEW IF EXISTS `ang_employee_vacation_untill_last_week`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ang_employee_vacation_untill_last_week` AS select `b_WorkDelivery`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,sum(((((`b_WorkDelivery`.`LeaveTime` + `b_WorkDelivery`.`ParentalLeaveTime`) + `b_WorkDelivery`.`SchoolingTime`) + `b_WorkDelivery`.`AbsenceTime`) + `b_WorkDelivery`.`PregnancyAbsenceTime`)) AS `EmployeeTotalNumberOfHoursVacation` from `b_WorkDelivery` where (week(`b_WorkDelivery`.`StartTime`,0) < week(curdate(),0)) group by `b_WorkDelivery`.`SourceEmployeeContractId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ang_sum_not_discarded`
--

/*!50001 DROP VIEW IF EXISTS `ang_sum_not_discarded`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ang_sum_not_discarded` AS select `ang_delivery_discarding`.`CustomerIdentifier` AS `CustomerIdentifier`,`ang_delivery_discarding`.`DeliveryPeriod` AS `DeliveryPeriod`,sum(`ang_delivery_discarding`.`BillableTime`) AS `BillableTime` from `ang_delivery_discarding` where ((`ang_delivery_discarding`.`IsDeliveryDiscarded` = 'false') or (`ang_delivery_discarding`.`ReasonForDiscardingDelivery` = 'NotOnePossibleContract')) group by `ang_delivery_discarding`.`CustomerIdentifier`,`ang_delivery_discarding`.`DeliveryPeriod` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_AssignedVsDelivered`
--

/*!50001 DROP VIEW IF EXISTS `b_AssignedVsDelivered`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_AssignedVsDelivered` AS select `b_AssignedVsDelivered_t1`.`CakDeliveryPeriod` AS `CakDeliveryPeriod`,`b_AssignedVsDelivered_t1`.`CakDeliveryPeriodShort` AS `CakDeliveryPeriodShort`,`b_AssignedVsDelivered_t1`.`SourceWorkAssignmentId` AS `SourceWorkAssignmentId`,`b_AssignedVsDelivered_t1`.`SourceCustomerId` AS `SourceCustomerId`,`b_AssignedVsDelivered_t1`.`CustomerOrganisationUnit` AS `CustomerOrganisationUnit`,`b_AssignedVsDelivered_t1`.`AssignmentFinancingType` AS `AssignmentFinancingType`,`b_AssignedVsDelivered_t1`.`AssignedHours` AS `AssignedHours`,`b_AssignedVsDelivered_t1`.`DeliveredHours` AS `DeliveredHours`,(`b_AssignedVsDelivered_t1`.`AssignedHours` * (select `cf_DeliveryHourlyRate`.`HourlyRate` from `cf_DeliveryHourlyRate` where (`b_AssignedVsDelivered_t1`.`AssignmentFinancingType` = convert(`cf_DeliveryHourlyRate`.`FinancingType` using utf8mb4)))) AS `AssignedEuros`,(`b_AssignedVsDelivered_t1`.`DeliveredHours` * (select `cf_DeliveryHourlyRate`.`HourlyRate` from `cf_DeliveryHourlyRate` where (`b_AssignedVsDelivered_t1`.`AssignmentFinancingType` = convert(`cf_DeliveryHourlyRate`.`FinancingType` using utf8mb4)))) AS `DeliveredEuros` from `b_AssignedVsDelivered_t1` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_AssignedVsDelivered_t1`
--

/*!50001 DROP VIEW IF EXISTS `b_AssignedVsDelivered_t1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_AssignedVsDelivered_t1` AS select `cf_CalendarTable`.`CakDeliveryPeriod` AS `CakDeliveryPeriod`,if((left(`cf_CalendarTable`.`CakDeliveryPeriod`,8) = 'CAK_2020'),14,right(left(`cf_CalendarTable`.`CakDeliveryPeriod`,11),2)) AS `CakDeliveryPeriodShort`,`_WorkAssignment`.`SourceWorkAssignmentId` AS `SourceWorkAssignmentId`,`_WorkAssignment`.`SourceCustomerId` AS `SourceCustomerId`,(select (case when (left(`_WorkAssignment`.`SourceCustomerRegion`,3) in ('K&J','KIN')) then 'KindJeugd' when (left(`_WorkAssignment`.`SourceCustomerRegion`,9) = 'NoordOost') then 'NoordOost' when (left(`_WorkAssignment`.`SourceCustomerRegion`,9) = 'NoordWest') then 'NoordWest' when (left(`_WorkAssignment`.`SourceCustomerRegion`,4) = 'Zuid') then 'Zuid' when (left(`_WorkAssignment`.`SourceCustomerRegion`,2) in ('NW','NI','We')) then 'NieuwWest' end)) AS `CustomerOrganisationUnit`,`_WorkAssignment`.`AssignmentFinancingType` AS `AssignmentFinancingType`,(((`_WorkAssignment`.`MinutesOfWorkAssignedPerPeriod` / 60) / 28) * count(`_WorkAssignment`.`SourceWorkAssignmentId`)) AS `AssignedHours`,(select (sum(`b_WorkDelivery`.`BillableTime`) / 3600) from `b_WorkDelivery` where ((`_WorkAssignment`.`SourceCustomerId` = `b_WorkDelivery`.`SourceCustomerId`) and (`cf_CalendarTable`.`CakDeliveryPeriod` = `b_WorkDelivery`.`DeliveryPeriod`) and (`b_WorkDelivery`.`DeliveryFinancingType` in ('WMO','JW','JW_DBC')) and (year(`b_WorkDelivery`.`StartTime`) = 2019))) AS `DeliveredHours` from (`cf_CalendarTable` left join `_WorkAssignment` on((`cf_CalendarTable`.`dt` between `_WorkAssignment`.`StartDate` and `_WorkAssignment`.`EndDate`))) where ((`cf_CalendarTable`.`dt` between (select min(`_WorkAssignment`.`StartDate`) from `_WorkAssignment`) and (select max(`_WorkAssignment`.`EndDate`) from `_WorkAssignment`)) and (`cf_CalendarTable`.`y` = 2019)) group by `_WorkAssignment`.`SourceWorkAssignmentId`,`cf_CalendarTable`.`CakDeliveryPeriod` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_DeliveriesForAssignedHealthcare`
--

/*!50001 DROP VIEW IF EXISTS `b_DeliveriesForAssignedHealthcare`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_DeliveriesForAssignedHealthcare` AS select `_WorkDelivery`.`ZenitWorkDeliveryId` AS `ZenitWorkDeliveryId`,`_WorkDelivery`.`SourceWorkDeliveryId` AS `SourceWorkDeliveryId`,cast(`_WorkDelivery`.`StartTime` as date) AS `DeliveryDate`,`_WorkDelivery`.`ProductId` AS `ProductId`,`_WorkDelivery`.`ProductName` AS `ProductName`,`_WorkDelivery`.`SourceWorkerId` AS `SourceWorkerId`,`_WorkDelivery`.`SourceCustomerId` AS `SourceCustomerId`,`_WorkDelivery`.`DeliveryFinancingType` AS `DeliveryFinancingType`,`_WorkAssignment`.`ZenitWorkAssignmentId` AS `ZenitWorkAssignmentId`,`_WorkAssignment`.`SourceWorkAssignmentId` AS `SourceWorkAssignmentId`,`_WorkAssignment`.`StartDate` AS `AssignmentStartDate`,`_WorkAssignment`.`EndDate` AS `AssignmentEndDate`,max(`_WorkAssignment`.`MinutesOfWorkAssignedPerPeriod`) AS `MinutesOfWorkAssignedPerPeriod`,`_WorkAssignment`.`DateOfAssignment` AS `DateOfAssignment`,`_WorkAssignment`.`SourceCustomerRegion` AS `SourceCustomerRegion` from (`_WorkDelivery` left join `_WorkAssignment` on(((`_WorkAssignment`.`SourceCustomerId` = `_WorkDelivery`.`SourceCustomerId`) and (cast(`_WorkDelivery`.`StartTime` as date) between `_WorkAssignment`.`StartDate` and `_WorkAssignment`.`EndDate`) and (`_WorkDelivery`.`DeliveryFinancingType` = `_WorkAssignment`.`AssignmentFinancingType`)))) where (`_WorkDelivery`.`DeliveryFinancingType` in ('WMO','JW','JW_DBC')) group by `_WorkDelivery`.`ZenitWorkDeliveryId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_DeliveriesPerCustomerPerPeriod`
--

/*!50001 DROP VIEW IF EXISTS `b_DeliveriesPerCustomerPerPeriod`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_DeliveriesPerCustomerPerPeriod` AS select `b_WorkDelivery`.`CustomerId` AS `CustomerId`,`b_WorkDelivery`.`SourceCustomerId` AS `SourceCustomerId`,`b_WorkDelivery`.`DeliveryPeriod` AS `DeliveryPeriod`,sum(`b_WorkDelivery`.`BillableTime`) AS `BillableTime` from `b_WorkDelivery` group by `b_WorkDelivery`.`CustomerId`,`b_WorkDelivery`.`DeliveryPeriod` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_DeliveriesPerWorkerPerMonth`
--

/*!50001 DROP VIEW IF EXISTS `b_DeliveriesPerWorkerPerMonth`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_DeliveriesPerWorkerPerMonth` AS select `b_WorkDelivery`.`SourceWorkerId` AS `SourceWorkerId`,`b_WorkDelivery`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`c`.`y` AS `Year`,`c`.`m` AS `Month`,`c`.`month_name` AS `MonthName`,sum(`b_WorkDelivery`.`RegisteredTime`) AS `RegisteredTime`,sum(`b_WorkDelivery`.`BillableTime`) AS `BillableTime`,sum(`b_WorkDelivery`.`LeaveTime`) AS `LeaveTime`,sum(`b_WorkDelivery`.`ParentalLeaveTime`) AS `ParentalLeaveTime`,sum(`b_WorkDelivery`.`PregnancyAbsenceTime`) AS `PregnancyAbsenceTime`,sum(`b_WorkDelivery`.`AbsenceTime`) AS `AbsenceHours`,sum(`b_WorkDelivery`.`BillableTravelTime`) AS `BillableTravelTime`,sum(`b_WorkDelivery`.`NonBillableTravelTime`) AS `NonBillableTravelTime`,sum(`b_WorkDelivery`.`SchoolingTime`) AS `SchoolingTime` from (`GGMDRULES`.`b_WorkDelivery` left join (select `GGMDRULES`.`cf_CalendarTable`.`dt` AS `dt`,`GGMDRULES`.`cf_CalendarTable`.`y` AS `y`,`GGMDRULES`.`cf_CalendarTable`.`m` AS `m`,`GGMDRULES`.`cf_CalendarTable`.`month_name` AS `month_name` from `GGMDRULES`.`cf_CalendarTable` where (`GGMDRULES`.`cf_CalendarTable`.`y` in (year(curdate()),(year(curdate()) - 1)))) `c` on((`c`.`dt` = cast(`b_WorkDelivery`.`StartTime` as date)))) where (`c`.`m` is not null) group by `b_WorkDelivery`.`SourceWorkerId`,`c`.`m` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_Employee`
--

/*!50001 DROP VIEW IF EXISTS `b_Employee`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_Employee` AS select `_Employee`.`ZenitEmployeeId` AS `ZenitEmployeeId`,`_Employee`.`SourceEmployeeId` AS `SourceEmployeeId`,`_EmployeeContract`.`ZenitEmployeeContractId` AS `ZenitEmployeeContractId`,`_EmployeeContract`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`_Person`.`FirstName` AS `FirstName`,(case when isnull(`_Person`.`LastName`) then `_Organisation`.`Name` else `_Person`.`LastName` end) AS `Name`,`_Employee`.`WorkEmail` AS `WorkEmail`,`_EmployeeContract`.`DesignationDescription` AS `Designation`,ifnull(`cf_EmployeeDesignation`.`IsCareDesignation`,'false') AS `IsCareDesignation`,`_EmployeeContract`.`IsContractIndefinite` AS `IsContractIndefinite`,(case when (`_Employee`.`OrganisationId` is not null) then 'Onderaannemer' else `cf_EmployeeContractType`.`ContractType` end) AS `FormOfContractDescription`,cast(`_EmployeeContract`.`NumberOfHoursPerWeek` as unsigned) AS `NumberOfHoursPerWeek`,`_EmployeeContract`.`DepartmentId` AS `DepartmentId`,`cf_EmployeeDepartment`.`Department` AS `Department`,`_EmployeeContract`.`StartDate` AS `CurrentContractStartDate`,(case when (max(isnull(`_EmployeeContract`.`EndDate`)) = 0) then max(`_EmployeeContract`.`EndDate`) end) AS `CurrentContractEndDate` from ((((((`_EmployeeContract` left join `_Employee` on((`_EmployeeContract`.`EmployeeId` = `_Employee`.`ZenitEmployeeId`))) left join `_Person` on((`_Employee`.`PersonId` = `_Person`.`ZenitPersonId`))) left join `_Organisation` on((`_Employee`.`OrganisationId` = `_Organisation`.`ZenitOrganisationId`))) left join `cf_EmployeeDesignation` on((`_EmployeeContract`.`DesignationDescription` = convert(`cf_EmployeeDesignation`.`SourceDesignation` using utf8mb4)))) left join `cf_EmployeeDepartment` on((convert(`cf_EmployeeDepartment`.`DepartmentId` using utf8mb4) = `_EmployeeContract`.`DepartmentId`))) left join `cf_EmployeeContractType` on((`_EmployeeContract`.`FormOfContractDescription` = convert(`cf_EmployeeContractType`.`SourceContractType` using utf8mb4)))) where ((year(`_EmployeeContract`.`EndDate`) > 2018) or isnull(year(`_EmployeeContract`.`EndDate`))) group by `_EmployeeContract`.`SourceEmployeeContractId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_EmployeeContractPeriod`
--

/*!50001 DROP VIEW IF EXISTS `b_EmployeeContractPeriod`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_EmployeeContractPeriod` AS select `_EmployeeContractPeriod`.`ZenitEmployeeContractPeriodId` AS `ZenitEmployeeContractPeriodId`,`_EmployeeContract`.`ZenitEmployeeContractId` AS `ZenitEmployeeContractId`,`_EmployeeContract`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`_EmployeeContractPeriod`.`StartDate` AS `StartDate`,`_EmployeeContractPeriod`.`EndDate` AS `EndDate`,`_EmployeeContractPeriod`.`NumberOfHoursPerWeek` AS `NumberOfHoursPerWeek`,`_EmployeeContractPeriod`.`DepartmentId` AS `DepartmentId`,`cf_EmployeeDepartment`.`Department` AS `Department`,(case when ((year(`_EmployeeContractPeriod`.`StartDate`) = 2020) and (year(`_EmployeeContractPeriod`.`StartDate`) = 2020)) then (1872 * 0.58) else `cf_EmployeeBillableHoursTarget`.`Target` end) AS `DesignationTarget`,ifnull(`cf_EmployeeContractTargetDeviation`.`TargetDeviation`,0) AS `TargetDeviation`,`_EmployeeContractPeriod`.`DesignationDescription` AS `DesignationDescription`,ifnull(`cf_EmployeeDesignation`.`IsCareDesignation`,'false') AS `IsCareDesignation` from (((((`_EmployeeContractPeriod` left join `_EmployeeContract` on((`_EmployeeContractPeriod`.`EmployeeContractId` = `_EmployeeContract`.`ZenitEmployeeContractId`))) left join `cf_EmployeeDepartment` on((convert(`cf_EmployeeDepartment`.`DepartmentId` using utf8mb4) = `_EmployeeContractPeriod`.`DepartmentId`))) left join `cf_EmployeeDesignation` on((`_EmployeeContract`.`DesignationDescription` = convert(`cf_EmployeeDesignation`.`SourceDesignation` using utf8mb4)))) left join `cf_EmployeeBillableHoursTarget` on(((`cf_EmployeeBillableHoursTarget`.`Department` = `cf_EmployeeDepartment`.`Department`) and (convert(`cf_EmployeeBillableHoursTarget`.`Designation` using utf8mb4) = `_EmployeeContractPeriod`.`DesignationDescription`)))) left join `cf_EmployeeContractTargetDeviation` on((convert(`cf_EmployeeContractTargetDeviation`.`SourceEmployeeContractId` using utf8mb4) = `_EmployeeContract`.`SourceEmployeeContractId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_WorkAssignment`
--

/*!50001 DROP VIEW IF EXISTS `b_WorkAssignment`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_WorkAssignment` AS select `_WorkAssignment`.`ZenitWorkAssignmentId` AS `ZenitWorkAssignmentId`,`_WorkAssignment`.`SourceWorkAssignmentId` AS `SourceWorkAssignmentId`,`_WorkAssignment`.`CustomerId` AS `CustomerId`,`_WorkAssignment`.`SourceCustomerId` AS `SourceCustomerId`,`_WorkAssignment`.`SourceCustomerRegion` AS `SourceCustomerRegion`,`_WorkAssignment`.`Assignee` AS `Assignee`,`_WorkAssignment`.`Assigner` AS `Assigner`,`_WorkAssignment`.`AssignmentDeclarationId` AS `AssignmentDeclarationId`,`_WorkAssignment`.`StartDate` AS `StartDate`,`_WorkAssignment`.`EndDate` AS `EndDate`,`_WorkAssignment`.`ProductId` AS `ProductId`,`_WorkAssignment`.`ProductDescription` AS `ProductDescription`,(`_WorkAssignment`.`MinutesOfWorkAssignedPerPeriod` / 28) AS `MinutesOfWorkAssignedPerDay`,`_WorkAssignment`.`OriginalVolume` AS `OriginalVolume`,`_WorkAssignment`.`OriginalUnit` AS `OriginalUnit`,`_WorkAssignment`.`OriginalFrequence` AS `OriginalFrequence`,`_WorkAssignment`.`DateOfAssignment` AS `DateOfAssignment`,`_WorkAssignment`.`AssignmentFinancingType` AS `AssignmentFinancingType` from `_WorkAssignment` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_WorkDelivery`
--

/*!50001 DROP VIEW IF EXISTS `b_WorkDelivery`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_WorkDelivery` AS select `_WorkDelivery`.`ZenitWorkDeliveryId` AS `ZenitWorkDeliveryId`,`_WorkDelivery`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`_WorkDelivery`.`SourceWorkerId` AS `SourceWorkerId`,`_WorkDelivery`.`SourceWorkerLastName` AS `SourceWorkerLastName`,`_Employee`.`ZenitEmployeeId` AS `EmployeeId`,(select `_Person`.`LastName` from `_Person` where (`_Employee`.`PersonId` = `_Person`.`ZenitPersonId`)) AS `EmployeeLastName`,(select `b_DeliveriesForAssignedHealthcare`.`ZenitWorkAssignmentId` from `b_DeliveriesForAssignedHealthcare` where (`_WorkDelivery`.`ZenitWorkDeliveryId` = `b_DeliveriesForAssignedHealthcare`.`ZenitWorkDeliveryId`)) AS `WorkAssignmentId`,`_WorkDelivery`.`CustomerId` AS `CustomerId`,`_WorkDelivery`.`SourceCustomerId` AS `SourceCustomerId`,`_WorkDelivery`.`SourceCustomerLastName` AS `SourceCustomerLastName`,`_WorkDelivery`.`SourceCustomerInitials` AS `SourceCustomerInitials`,'###' AS `CustomerLastName`,`_WorkDelivery`.`SourceCustomerZipCode` AS `SourceCustomerZipCode`,`_WorkDelivery`.`StartTime` AS `StartTime`,`_WorkDelivery`.`EndTime` AS `EndTime`,concat('CAK_',if((week(`_WorkDelivery`.`StartTime`,0) = 52),convert(concat((year(`_WorkDelivery`.`StartTime`) + 1),'_01_wk_1-4') using utf8mb4),concat(year(`_WorkDelivery`.`StartTime`),'_',convert(lpad(ceiling(((week(`_WorkDelivery`.`StartTime`,0) + 1) / 4)),2,0) using utf8mb4),'_wk_',((ceiling(((week(`_WorkDelivery`.`StartTime`,0) + 1) / 4)) * 4) - 3),'-',least(52,(ceiling(((week(`_WorkDelivery`.`StartTime`,0) + 1) / 4)) * 4))))) AS `DeliveryPeriod`,`_WorkDelivery`.`ActivityId` AS `ActivityId`,(select `cf_WorkDeliveryActivity`.`ActivityName` from `cf_WorkDeliveryActivity` where (convert(`cf_WorkDeliveryActivity`.`SourceActivityId` using utf8mb4) = `_WorkDelivery`.`ActivityId`)) AS `ActivityName`,`_WorkDelivery`.`ProductId` AS `ProductId`,`_WorkDelivery`.`ProductName` AS `ProductName`,`_WorkDelivery`.`DeliveryDeclarationCode` AS `DeliveryDeclarationCode`,`_WorkDelivery`.`DeliveryFinancingType` AS `DeliveryFinancingType`,(case when (`_WorkDelivery`.`DeliveryDeclarationCode` = 'act.zg.2003') then 0 else (select `cf_DeliveryHourlyRate`.`HourlyRate` from `cf_DeliveryHourlyRate` where (`_WorkDelivery`.`DeliveryFinancingType` = convert(`cf_DeliveryHourlyRate`.`FinancingType` using utf8mb4))) end) AS `DeliveryHourlyRate`,`_WorkDelivery`.`DeliveryTime` AS `DeliveryTime`,`_WorkDelivery`.`DirectCustomerTime` AS `DirectCustomerTime`,`_WorkDelivery`.`IndirectCustomerTime` AS `IndirectCustomerTime`,(case when ((`_WorkDelivery`.`DirectCustomerTime` + `_WorkDelivery`.`IndirectCustomerTime`) = 0) then `_WorkDelivery`.`DeliveryTime` else (`_WorkDelivery`.`DirectCustomerTime` + `_WorkDelivery`.`IndirectCustomerTime`) end) AS `RegisteredTime`,(case when ((`_WorkDelivery`.`DeliveryDeclarationCode` <> '') or (`_WorkDelivery`.`ProductId` in ('1097','2513','2514','2515'))) then (`_WorkDelivery`.`DirectCustomerTime` + `_WorkDelivery`.`IndirectCustomerTime`) else 0 end) AS `BillableTime`,(case when (`_WorkDelivery`.`ActivityId` in ('4692','4699','4739','4832','5350','5381')) then `_WorkDelivery`.`DeliveryTime` else 0 end) AS `LeaveTime`,(case when (`_WorkDelivery`.`ActivityId` in ('5306','5182')) then `_WorkDelivery`.`DeliveryTime` else 0 end) AS `ParentalLeaveTime`,(case when (`_WorkDelivery`.`ActivityId` = '19530') then `_WorkDelivery`.`DeliveryTime` else 0 end) AS `PregnancyAbsenceTime`,(case when (`_WorkDelivery`.`ActivityId` = '4702') then `_WorkDelivery`.`DeliveryTime` else 0 end) AS `AbsenceTime`,(case when ((`_WorkDelivery`.`ActivityId` in (4879,10310,12436,16082,12485,14764,16071,17307,17550,16085,16094,5072,17415,16074,12471,12477,15082,17417,12447,12474,17556,16068,18085,5026,14941,19476,17541,17553)) and (`_WorkDelivery`.`DeliveryDeclarationCode` <> '')) then `_WorkDelivery`.`DeliveryTime` else 0 end) AS `BillableTravelTime`,(case when ((`_WorkDelivery`.`ActivityId` in (4879,10310,12436,16082,12485,14764,16071,17307,17550,16085,16094,5072,17415,16074,12471,12477,15082,17417,12447,12474,17556,16068,18085,5026,14941,19476,17541,17553)) and (`_WorkDelivery`.`DeliveryDeclarationCode` = '')) then `_WorkDelivery`.`DeliveryTime` else 0 end) AS `NonBillableTravelTime`,(case when (`_WorkDelivery`.`ActivityId` = '4698') then `_WorkDelivery`.`DeliveryTime` else 0 end) AS `SchoolingTime` from (((`_WorkDelivery` left join `_EmployeeContract` on((`_WorkDelivery`.`EmployeeContractId` = `_EmployeeContract`.`ZenitEmployeeContractId`))) left join `_Employee` on((`_EmployeeContract`.`EmployeeId` = `_Employee`.`ZenitEmployeeId`))) left join `_Customer` on((`_WorkDelivery`.`CustomerId` = `_Customer`.`ZenitCustomerId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `b_WorkDelivery_SinceLastUpdate`
--

/*!50001 DROP VIEW IF EXISTS `b_WorkDelivery_SinceLastUpdate`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `b_WorkDelivery_SinceLastUpdate` AS select `GGMDRULES`.`_WorkDelivery`.`ZenitWorkDeliveryId` AS `ZenitWorkDeliveryId`,`GGMDRULES`.`_WorkDelivery`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`GGMDRULES`.`_WorkDelivery`.`SourceWorkerId` AS `SourceWorkerId`,`GGMDRULES`.`_WorkDelivery`.`SourceWorkerLastName` AS `SourceWorkerLastName`,`GGMDRULES`.`_Employee`.`ZenitEmployeeId` AS `EmployeeId`,(select `GGMDRULES`.`_Person`.`LastName` from `GGMDRULES`.`_Person` where (`GGMDRULES`.`_Employee`.`PersonId` = `GGMDRULES`.`_Person`.`ZenitPersonId`)) AS `EmployeeLastName`,`GGMDRULES`.`_WorkDelivery`.`WorkAssignmentId` AS `WorkAssignmentId`,`GGMDRULES`.`_WorkDelivery`.`CustomerId` AS `CustomerId`,`GGMDRULES`.`_WorkDelivery`.`SourceCustomerId` AS `SourceCustomerId`,`GGMDRULES`.`_WorkDelivery`.`SourceCustomerLastName` AS `SourceCustomerLastName`,`GGMDRULES`.`_WorkDelivery`.`SourceCustomerInitials` AS `SourceCustomerInitials`,(select `GGMDRULES`.`_Person`.`LastName` from `GGMDRULES`.`_Person` where (`GGMDRULES`.`_Customer`.`PersonId` = `GGMDRULES`.`_Person`.`ZenitPersonId`)) AS `CustomerLastName`,`GGMDRULES`.`_WorkDelivery`.`SourceCustomerZipCode` AS `SourceCustomerZipCode`,`GGMDRULES`.`_WorkDelivery`.`StartTime` AS `StartTime`,`GGMDRULES`.`_WorkDelivery`.`EndTime` AS `EndTime`,concat('CAK_',if((week(`GGMDRULES`.`_WorkDelivery`.`StartTime`,0) = 52),convert(concat((year(`GGMDRULES`.`_WorkDelivery`.`StartTime`) + 1),'_01_wk_1-4') using utf8mb4),concat(year(`GGMDRULES`.`_WorkDelivery`.`StartTime`),'_',convert(lpad(ceiling(((week(`GGMDRULES`.`_WorkDelivery`.`StartTime`,0) + 1) / 4)),2,0) using utf8mb4),'_wk_',((ceiling(((week(`GGMDRULES`.`_WorkDelivery`.`StartTime`,0) + 1) / 4)) * 4) - 3),'-',least(52,(ceiling(((week(`GGMDRULES`.`_WorkDelivery`.`StartTime`,0) + 1) / 4)) * 4))))) AS `DeliveryPeriod`,`GGMDRULES`.`_WorkDelivery`.`ActivityId` AS `ActivityId`,`GGMDRULES`.`_WorkDelivery`.`ActivityName` AS `ActivityName`,`GGMDRULES`.`_WorkDelivery`.`ProductId` AS `ProductId`,`GGMDRULES`.`_WorkDelivery`.`ProductName` AS `ProductName`,`GGMDRULES`.`_WorkDelivery`.`DeliveryDeclarationCode` AS `DeliveryDeclarationCode`,`GGMDRULES`.`_WorkDelivery`.`DeliveryFinancingType` AS `DeliveryFinancingType`,(case when (`GGMDRULES`.`_WorkDelivery`.`DeliveryDeclarationCode` = 'act.zg.2003') then 0 else (select `GGMDRULES`.`cf_DeliveryHourlyRate`.`HourlyRate` from `GGMDRULES`.`cf_DeliveryHourlyRate` where (`GGMDRULES`.`_WorkDelivery`.`DeliveryFinancingType` = convert(`GGMDRULES`.`cf_DeliveryHourlyRate`.`FinancingType` using utf8mb4))) end) AS `DeliveryHourlyRate`,`GGMDRULES`.`_WorkDelivery`.`DeliveryTime` AS `DeliveryTime`,`GGMDRULES`.`_WorkDelivery`.`DirectCustomerTime` AS `DirectCustomerTime`,`GGMDRULES`.`_WorkDelivery`.`IndirectCustomerTime` AS `IndirectCustomerTime`,(case when ((`GGMDRULES`.`_WorkDelivery`.`DirectCustomerTime` + `GGMDRULES`.`_WorkDelivery`.`IndirectCustomerTime`) = 0) then `GGMDRULES`.`_WorkDelivery`.`DeliveryTime` else (`GGMDRULES`.`_WorkDelivery`.`DirectCustomerTime` + `GGMDRULES`.`_WorkDelivery`.`IndirectCustomerTime`) end) AS `RegisteredTime`,(case when ((`GGMDRULES`.`_WorkDelivery`.`DeliveryDeclarationCode` <> '') or (`GGMDRULES`.`_WorkDelivery`.`ProductId` in ('1097','2513','2514','2515'))) then (`GGMDRULES`.`_WorkDelivery`.`DirectCustomerTime` + `GGMDRULES`.`_WorkDelivery`.`IndirectCustomerTime`) else 0 end) AS `BillableTime`,(case when (`GGMDRULES`.`_WorkDelivery`.`ActivityId` in ('4692','4699','4739','4832','5350','5381')) then `GGMDRULES`.`_WorkDelivery`.`DeliveryTime` else 0 end) AS `LeaveTime`,(case when (`GGMDRULES`.`_WorkDelivery`.`ActivityId` in ('5306','5182')) then `GGMDRULES`.`_WorkDelivery`.`DeliveryTime` else 0 end) AS `ParentalLeaveTime`,(case when (`GGMDRULES`.`_WorkDelivery`.`ActivityId` = '19530') then `GGMDRULES`.`_WorkDelivery`.`DeliveryTime` else 0 end) AS `PregnancyAbsenceTime`,(case when (`GGMDRULES`.`_WorkDelivery`.`ActivityId` = '4702') then `GGMDRULES`.`_WorkDelivery`.`DeliveryTime` else 0 end) AS `AbsenceTime`,(case when ((`GGMDRULES`.`_WorkDelivery`.`ActivityId` in (4879,10310,12436,16082,12485,14764,16071,17307,17550,16085,16094,5072,17415,16074,12471,12477,15082,17417,12447,12474,17556,16068,18085,5026,14941,19476,17541,17553)) and (`GGMDRULES`.`_WorkDelivery`.`DeliveryDeclarationCode` <> '')) then `GGMDRULES`.`_WorkDelivery`.`DeliveryTime` else 0 end) AS `BillableTravelTime`,(case when ((`GGMDRULES`.`_WorkDelivery`.`ActivityId` in (4879,10310,12436,16082,12485,14764,16071,17307,17550,16085,16094,5072,17415,16074,12471,12477,15082,17417,12447,12474,17556,16068,18085,5026,14941,19476,17541,17553)) and (`GGMDRULES`.`_WorkDelivery`.`DeliveryDeclarationCode` = '')) then `GGMDRULES`.`_WorkDelivery`.`DeliveryTime` else 0 end) AS `NonBillableTravelTime`,(case when (`GGMDRULES`.`_WorkDelivery`.`ActivityId` = '4698') then `GGMDRULES`.`_WorkDelivery`.`DeliveryTime` else 0 end) AS `SchoolingTime` from (((`GGMDRULES`.`_WorkDelivery` left join `GGMDRULES`.`_EmployeeContract` on((`GGMDRULES`.`_WorkDelivery`.`EmployeeContractId` = `GGMDRULES`.`_EmployeeContract`.`ZenitEmployeeContractId`))) left join `GGMDRULES`.`_Employee` on((`GGMDRULES`.`_EmployeeContract`.`EmployeeId` = `GGMDRULES`.`_Employee`.`ZenitEmployeeId`))) left join `GGMDRULES`.`_Customer` on((`GGMDRULES`.`_WorkDelivery`.`CustomerId` = `GGMDRULES`.`_Customer`.`ZenitCustomerId`))) where (`GGMDRULES`.`_WorkDelivery`.`DeliveryRegistrationChangeDate` > (select ((select `GGMDKPI`.`UploadDate`.`UploadDate` from `GGMDKPI`.`UploadDate`) + interval -(8) day))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rstm_FileGenerator`
--

/*!50001 DROP VIEW IF EXISTS `rstm_FileGenerator`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rstm_FileGenerator` AS select '07460' AS `Klantnummer`,concat(repeat('0',(7 - char_length(`rstm_deliveries`.`caretaker_employee_codes`))),`rstm_deliveries`.`caretaker_employee_codes`) AS `Personeelsnummer`,'CW' AS `Broncode`,concat(ifnull(`GGMDRULES`.`cf_EmployeeDepartment`.`DepartmentRstmutFormat`,'Hoofdkanto'),convert(repeat(' ',(10 - char_length(ifnull(`GGMDRULES`.`cf_EmployeeDepartment`.`DepartmentRstmutFormat`,'Hoofdkanto')))) using latin1)) AS `AfdelingCode`,'00000000' AS `Kostensoort`,'00000000' AS `Kostenplaats`,date_format(`rstm_deliveries`.`production_start_date`,'%d%m%Y') AS `Datum`,'CW  ' AS `Dienstcode`,'11' AS `Dienstnummer`,(case when (`rstm_deliveries`.`activity_id` = '4692') then 'VF ' when (`rstm_deliveries`.`activity_id` = '4699') then 'V  ' when (`rstm_deliveries`.`activity_id` = '4739') then 'VB ' when (`rstm_deliveries`.`activity_id` = '4832') then 'LFB' when (`rstm_deliveries`.`activity_id` = '5182') then 'VOS' when (`rstm_deliveries`.`activity_id` = '5381') then 'VZ ' when (`rstm_deliveries`.`activity_id` = '5350') then 'VO ' when ((`rstm_deliveries`.`ort_time` > 0) and (`rstm_deliveries`.`activity_default_reporting_code` <> '') and ((`rstm_deliveries`.`direct_time` > 0) or (`rstm_deliveries`.`activity_id` = '4879'))) then 'DN ' else 'DZO' end) AS `Diensttype`,time_format(`rstm_deliveries`.`production_start_date`,'%H%i') AS `Aanvangtijd`,time_format(`rstm_deliveries`.`production_end_date`,'%H%i') AS `Eindtijd`,'0000' AS `Begintijd pauze`,'0000' AS `Eindtijd pauze`,(case when (`rstm_deliveries`.`activity_id` = '4702') then '1' else '0' end) AS `Indicatie ziek`,(case when (`rstm_deliveries`.`activity_id` = '5306') then '1' else '0' end) AS `Indicatie zwanger`,'0' AS `Indicatie vorige dag`,'0' AS `Indicatie overwerk uitbetalen`,(case when ((`rstm_deliveries`.`activity_id` = '4692') or (`rstm_deliveries`.`activity_id` = '4699') or (`rstm_deliveries`.`activity_id` = '4702') or (`rstm_deliveries`.`activity_id` = '4739') or (`rstm_deliveries`.`activity_id` = '4832') or (`rstm_deliveries`.`activity_id` = '5182') or (`rstm_deliveries`.`activity_id` = '5306') or (`rstm_deliveries`.`activity_id` = '5350') or (`rstm_deliveries`.`activity_id` = '5381')) then '0' else '1' end) AS `Indicatie ort uitbetalen`,'0' AS `Indicatie compensatie diensten uitbetalen`,'0' AS `Indicatie slaapdienst volledig in tijd` from ((`GGMDRULES`.`rstm_deliveries` left join `GGMDRULES`.`_EmployeeContract` on((`GGMDRULES`.`_EmployeeContract`.`SourceEmployeeContractId` = `rstm_deliveries`.`caretaker_employee_codes`))) left join `GGMDRULES`.`cf_EmployeeDepartment` on((`GGMDRULES`.`_EmployeeContract`.`DepartmentId` = convert(`GGMDRULES`.`cf_EmployeeDepartment`.`DepartmentId` using utf8mb4)))) where ((`GGMDRULES`.`_EmployeeContract`.`SourceEmployeeContractId` <> '') and (`GGMDRULES`.`_EmployeeContract`.`ZenitEmployeeContractId` is not null) and (`GGMDRULES`.`_EmployeeContract`.`IsEmployeePaid` = 'true') and (month(date_format(`rstm_deliveries`.`production_start_date`,'%Y-%m-%d')) = (month(curdate()) - 1))) group by `rstm_deliveries`.`production_start_date`,`rstm_deliveries`.`production_end_date`,`rstm_deliveries`.`caretaker_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rstm_HolidayRegistrations`
--

/*!50001 DROP VIEW IF EXISTS `rstm_HolidayRegistrations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rstm_HolidayRegistrations` AS select `_WorkDelivery`.`SourceEmployeeContractId` AS `DienstverbandId`,`_WorkDelivery`.`SourceWorkerLastName` AS `Achternaam`,`cf_EmployeeDepartment`.`Department` AS `OrganisatieEenheid`,`_WorkDelivery`.`ProductName` AS `Product`,`_WorkDelivery`.`ActivityName` AS `Activiteit`,cast(`_WorkDelivery`.`StartTime` as date) AS `Datum`,sum((`_WorkDelivery`.`DeliveryTime` / 3600)) AS `Duur`,(case when (`cf_CalendarTable`.`is_holiday` = 1) then 'TRUE' else 'FALSE' end) AS `Feestdag`,`cf_CalendarTable`.`holiday_description` AS `Toelichting` from (((`_WorkDelivery` left join `_EmployeeContract` on((`_EmployeeContract`.`SourceEmployeeContractId` = `_WorkDelivery`.`SourceEmployeeContractId`))) left join `cf_EmployeeDepartment` on((`_EmployeeContract`.`DepartmentId` = convert(`cf_EmployeeDepartment`.`DepartmentId` using utf8mb4)))) left join `cf_CalendarTable` on((`cf_CalendarTable`.`dt` = cast(`_WorkDelivery`.`StartTime` as date)))) where (`_WorkDelivery`.`ActivityId` = '4692') group by `_WorkDelivery`.`StartTime`,`_EmployeeContract`.`SourceEmployeeContractId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rstm_ORT_LastMonth`
--

/*!50001 DROP VIEW IF EXISTS `rstm_ORT_LastMonth`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rstm_ORT_LastMonth` AS select `rstm_deliveries`.`caretaker_employee_codes` AS `medewerker_id`,`rstm_deliveries`.`caretaker_last_name` AS `medewerker_naam`,`rstm_deliveries`.`caretaker_initials` AS `initialen`,if(isnull(`GGMDRULES`.`cf_EmployeeDepartment`.`Department`),'Onbekend',`GGMDRULES`.`cf_EmployeeDepartment`.`Department`) AS `regio`,date_format(`rstm_deliveries`.`production_start_date`,'%d-%m-%Y') AS `datum`,`rstm_deliveries`.`activity_name` AS `activiteit`,if((`rstm_deliveries`.`client_id` = ''),'NCGT',`rstm_deliveries`.`client_id`) AS `client_id`,if((`rstm_deliveries`.`client_last_name` = ''),'NCGT',`rstm_deliveries`.`client_last_name`) AS `client_naam`,time_format(`rstm_deliveries`.`production_start_date`,'%H:%i') AS `start_tijd`,time_format(`rstm_deliveries`.`production_end_date`,'%H:%i') AS `eind_tijd`,(case when ((dayofweek(`rstm_deliveries`.`production_start_date`) between 2 and 6) and (cast(`rstm_deliveries`.`production_start_date` as time) between '07:00' and '20:00')) then '20:00' when ((dayofweek(`rstm_deliveries`.`production_start_date`) = 7) and (cast(`rstm_deliveries`.`production_start_date` as time) between '08:00' and '12:00')) then '12:00' else convert(time_format(`rstm_deliveries`.`production_start_date`,'%H:%i') using utf8mb4) end) AS `start_ort`,(case when ((dayofweek(`rstm_deliveries`.`production_start_date`) between 2 and 6) and (cast(`rstm_deliveries`.`production_end_date` as time) between '07:00' and '20:00')) then '07:00' when ((dayofweek(`rstm_deliveries`.`production_start_date`) = 7) and (cast(`rstm_deliveries`.`production_end_date` as time) between '08:00' and '12:00')) then '08:00' else convert(time_format(`rstm_deliveries`.`production_end_date`,'%H:%i') using utf8mb4) end) AS `eind_ort`,time_format(sec_to_time(`rstm_deliveries`.`ort_time`),'%H:%i') AS `ort_uren`,concat(round(((case when ((`rstm_deliveries`.`activity_default_reporting_code` <> '') and ((`rstm_deliveries`.`direct_time` > 0) or (`rstm_deliveries`.`activity_id` = '4879'))) then (case when (`GGMDRULES`.`cf_CalendarTable`.`is_holiday` = 1) then 0.60 when ((time_to_sec(`rstm_deliveries`.`production_start_date`) >= (12 * 3600)) and ((convert(date_format(`rstm_deliveries`.`production_start_date`,'%m-%d') using utf8mb4) = '12-24') or (convert(date_format(`rstm_deliveries`.`production_start_date`,'%m-%d') using utf8mb4) = '12-31'))) then 0.60 when (dayofweek(`rstm_deliveries`.`production_start_date`) = 1) then 0.60 when (dayofweek(`rstm_deliveries`.`production_start_date`) = 7) then (((greatest((((6 * 3600) - greatest((time_to_sec(`rstm_deliveries`.`production_start_date`) - (0 * 3600)),0)) - greatest(((6 * 3600) - time_to_sec(`rstm_deliveries`.`production_end_date`)),0)),0) * 0.49) + ((greatest((((2 * 3600) - greatest((time_to_sec(`rstm_deliveries`.`production_start_date`) - (6 * 3600)),0)) - greatest(((8 * 3600) - time_to_sec(`rstm_deliveries`.`production_end_date`)),0)),0) * 0.38) + ((greatest((((10 * 3600) - greatest((time_to_sec(`rstm_deliveries`.`production_start_date`) - (12 * 3600)),0)) - greatest(((22 * 3600) - time_to_sec(`rstm_deliveries`.`production_end_date`)),0)),0) * 0.38) + (greatest((((2 * 3600) - greatest((time_to_sec(`rstm_deliveries`.`production_start_date`) - (22 * 3600)),0)) - greatest(((24 * 3600) - time_to_sec(`rstm_deliveries`.`production_end_date`)),0)),0) * 0.49)))) / `rstm_deliveries`.`ort_time`) when (dayofweek(`rstm_deliveries`.`production_start_date`) between 2 and 6) then (((((greatest((((6 * 3600) - greatest((time_to_sec(`rstm_deliveries`.`production_start_date`) - (0 * 3600)),0)) - greatest(((6 * 3600) - time_to_sec(`rstm_deliveries`.`production_end_date`)),0)),0) * 0.44) + (greatest((((1 * 3600) - greatest((time_to_sec(`rstm_deliveries`.`production_start_date`) - (6 * 3600)),0)) - greatest(((7 * 3600) - time_to_sec(`rstm_deliveries`.`production_end_date`)),0)),0) * 0.22)) + (greatest((((2 * 3600) - greatest((time_to_sec(`rstm_deliveries`.`production_start_date`) - (20 * 3600)),0)) - greatest(((22 * 3600) - time_to_sec(`rstm_deliveries`.`production_end_date`)),0)),0) * 0.22)) + (greatest((((2 * 3600) - greatest((time_to_sec(`rstm_deliveries`.`production_start_date`) - (22 * 3600)),0)) - greatest(((24 * 3600) - time_to_sec(`rstm_deliveries`.`production_end_date`)),0)),0) * 0.44)) / `rstm_deliveries`.`ort_time`) else 0 end) else 0 end) * 100),2),'%') AS `ort_percentage`,(case when (`GGMDRULES`.`cf_CalendarTable`.`is_holiday` = 1) then 'feestdag' when (dayofweek(`rstm_deliveries`.`production_start_date`) = 1) then 'zondag' when (dayofweek(`rstm_deliveries`.`production_start_date`) = 7) then 'zaterdag' else '' end) AS `opmerking`,`GGMDRULES`.`_Employee`.`WorkEmail` AS `e-mail` from ((((`GGMDRULES`.`rstm_deliveries` left join `GGMDRULES`.`_EmployeeContract` on((`GGMDRULES`.`_EmployeeContract`.`SourceEmployeeContractId` = `rstm_deliveries`.`caretaker_employee_codes`))) left join `GGMDRULES`.`cf_EmployeeDepartment` on((`GGMDRULES`.`_EmployeeContract`.`DepartmentId` = convert(`GGMDRULES`.`cf_EmployeeDepartment`.`DepartmentId` using utf8mb4)))) left join `GGMDRULES`.`_Employee` on((`GGMDRULES`.`_Employee`.`ZenitEmployeeId` = `GGMDRULES`.`_EmployeeContract`.`EmployeeId`))) left join `GGMDRULES`.`cf_CalendarTable` on((`GGMDRULES`.`cf_CalendarTable`.`dt` = date_format(`rstm_deliveries`.`production_start_date`,'%Y-%m-%d')))) where ((`rstm_deliveries`.`ort_time` > 0) and ((select `GGMDRULES`.`cf_EmployeeContractType`.`IsSalariedStaff` from `GGMDRULES`.`cf_EmployeeContractType` where (`GGMDRULES`.`_EmployeeContract`.`FormOfContractDescription` = convert(`GGMDRULES`.`cf_EmployeeContractType`.`ContractType` using utf8mb4))) = 'TRUE') and (`GGMDRULES`.`_EmployeeContract`.`SourceEmployeeContractId` <> '') and (`GGMDRULES`.`_EmployeeContract`.`SourceEmployeeContractId` is not null) and (month(date_format(`rstm_deliveries`.`production_start_date`,'%Y-%m-%d')) = (month(curdate()) - 1))) group by `rstm_deliveries`.`production_start_date`,`rstm_deliveries`.`production_end_date`,`rstm_deliveries`.`caretaker_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rstm_ParentalLeave`
--

/*!50001 DROP VIEW IF EXISTS `rstm_ParentalLeave`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rstm_ParentalLeave` AS select `_WorkDelivery`.`SourceEmployeeContractId` AS `DienstverbandId`,`_WorkDelivery`.`SourceWorkerLastName` AS `Achternaam`,`cf_EmployeeDepartment`.`Department` AS `OrganisatieEenheid`,`_WorkDelivery`.`ProductName` AS `Product`,`_WorkDelivery`.`ActivityName` AS `Activiteit`,cast(`_WorkDelivery`.`StartTime` as date) AS `Datum`,sum((`_WorkDelivery`.`DeliveryTime` / 3600)) AS `Duur` from ((`_WorkDelivery` left join `_EmployeeContract` on((`_EmployeeContract`.`SourceEmployeeContractId` = `_WorkDelivery`.`SourceEmployeeContractId`))) left join `cf_EmployeeDepartment` on((`_EmployeeContract`.`DepartmentId` = convert(`cf_EmployeeDepartment`.`DepartmentId` using utf8mb4)))) where (`_WorkDelivery`.`ActivityId` = '5182') group by `_WorkDelivery`.`StartTime`,`_EmployeeContract`.`SourceEmployeeContractId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rstm_SpecialLeave`
--

/*!50001 DROP VIEW IF EXISTS `rstm_SpecialLeave`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rstm_SpecialLeave` AS select `_WorkDelivery`.`SourceEmployeeContractId` AS `DienstverbandId`,`_WorkDelivery`.`SourceWorkerLastName` AS `Achternaam`,`cf_EmployeeDepartment`.`Department` AS `OrganisatieEenheid`,`_WorkDelivery`.`ProductName` AS `Product`,`_WorkDelivery`.`ActivityName` AS `Activiteit`,cast(`_WorkDelivery`.`StartTime` as date) AS `Datum`,sum((`_WorkDelivery`.`DeliveryTime` / 3600)) AS `Duur` from ((`_WorkDelivery` left join `_EmployeeContract` on((`_EmployeeContract`.`SourceEmployeeContractId` = `_WorkDelivery`.`SourceEmployeeContractId`))) left join `cf_EmployeeDepartment` on((`_EmployeeContract`.`DepartmentId` = convert(`cf_EmployeeDepartment`.`DepartmentId` using utf8mb4)))) where ((`_WorkDelivery`.`ActivityId` = '4739') or (`_WorkDelivery`.`ActivityId` = '5381') or (`_WorkDelivery`.`ActivityId` = '5350')) group by `_WorkDelivery`.`StartTime`,`_EmployeeContract`.`SourceEmployeeContractId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `rstm_deliveries`
--

/*!50001 DROP VIEW IF EXISTS `rstm_deliveries`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `rstm_deliveries` AS select `GGMDLOAD`.`load_deliveries`.`production_id` AS `production_id`,str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i') AS `production_start_date`,str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i') AS `production_end_date`,`GGMDLOAD`.`load_deliveries`.`activity_id` AS `activity_id`,`GGMDLOAD`.`load_deliveries`.`activity_name` AS `activity_name`,`GGMDLOAD`.`load_deliveries`.`activity_default_reporting_code` AS `activity_default_reporting_code`,`GGMDLOAD`.`load_deliveries`.`product_id` AS `product_id`,`GGMDLOAD`.`load_deliveries`.`product_name` AS `product_name`,`GGMDLOAD`.`load_deliveries`.`caretaker_id` AS `caretaker_id`,cast(`GGMDLOAD`.`load_deliveries`.`caretaker_employee_codes` as unsigned) AS `caretaker_employee_codes`,`GGMDLOAD`.`load_deliveries`.`caretaker_last_name` AS `caretaker_last_name`,`GGMDLOAD`.`load_deliveries`.`caretaker_initials` AS `caretaker_initials`,`GGMDLOAD`.`load_deliveries`.`client_zip_code` AS `client_zip_code`,`GGMDLOAD`.`load_deliveries`.`client_id` AS `client_id`,`GGMDLOAD`.`load_deliveries`.`client_last_name` AS `client_last_name`,`GGMDLOAD`.`load_deliveries`.`appointment_time` AS `appointment_time`,`GGMDLOAD`.`load_deliveries`.`direct_time` AS `direct_time`,`GGMDLOAD`.`load_deliveries`.`indirect_time` AS `indirect_time`,(case when ((`GGMDLOAD`.`load_deliveries`.`direct_time` + `GGMDLOAD`.`load_deliveries`.`indirect_time`) = 0) then (`GGMDLOAD`.`load_deliveries`.`appointment_time` / 3600) else ((`GGMDLOAD`.`load_deliveries`.`direct_time` + `GGMDLOAD`.`load_deliveries`.`indirect_time`) / 3600) end) AS `registered_hours`,(case when ((`GGMDLOAD`.`load_deliveries`.`activity_default_reporting_code` <> '') or (`GGMDLOAD`.`load_deliveries`.`product_id` in ('1097','2513','2514','2515'))) then ((`GGMDLOAD`.`load_deliveries`.`indirect_time` + `GGMDLOAD`.`load_deliveries`.`direct_time`) / 3600) else 0 end) AS `billable_hours`,sum((case when (`GGMDLOAD`.`load_deliveries`.`activity_id` in ('4692','4699','4739','4832','5350','5381')) then (`GGMDLOAD`.`load_deliveries`.`appointment_time` / 3600) else 0 end)) AS `leave_hours`,sum((case when (`GGMDLOAD`.`load_deliveries`.`activity_id` in ('5306','5182')) then (`GGMDLOAD`.`load_deliveries`.`appointment_time` / 3600) else 0 end)) AS `parental_leave_hours`,sum((case when (`GGMDLOAD`.`load_deliveries`.`activity_id` = '19530') then (`GGMDLOAD`.`load_deliveries`.`appointment_time` / 3600) else 0 end)) AS `pregnancy_absence_hours`,sum((case when (`GGMDLOAD`.`load_deliveries`.`activity_id` = '4702') then (`GGMDLOAD`.`load_deliveries`.`appointment_time` / 3600) else 0 end)) AS `absence_hours`,sum((case when ((`GGMDLOAD`.`load_deliveries`.`activity_id` in (4879,10310,12436,16082,12485,14764,16071,17307,17550,16085,16094,5072,17415,16074,12471,12477,15082,17417,12447,12474,17556,16068,18085,5026,14941,19476,17541,17553)) and (`GGMDLOAD`.`load_deliveries`.`activity_default_reporting_code` <> '')) then (`GGMDLOAD`.`load_deliveries`.`appointment_time` / 3600) else 0 end)) AS `billable_travel_hours`,sum((case when ((`GGMDLOAD`.`load_deliveries`.`activity_id` in (4879,10310,12436,16082,12485,14764,16071,17307,17550,16085,16094,5072,17415,16074,12471,12477,15082,17417,12447,12474,17556,16068,18085,5026,14941,19476,17541,17553)) and (`GGMDLOAD`.`load_deliveries`.`activity_default_reporting_code` = '')) then (`GGMDLOAD`.`load_deliveries`.`appointment_time` / 3600) else 0 end)) AS `non_billable_travel_hours`,sum((case when (`GGMDLOAD`.`load_deliveries`.`activity_id` = '4698') then (`GGMDLOAD`.`load_deliveries`.`appointment_time` / 3600) else 0 end)) AS `schooling_hours`,(case when (`GGMDRULES`.`cf_CalendarTable`.`is_holiday` = 1) then `GGMDLOAD`.`load_deliveries`.`appointment_time` when ((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) >= (18 * 3600)) and ((str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m') = '0000-12-24') or (str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m') = '0000-12-31'))) then (time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i')) - (18 * 3600)) when (dayofweek(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) = 1) then `GGMDLOAD`.`load_deliveries`.`appointment_time` when (dayofweek(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) = 7) then (greatest((((6 * 3600) - greatest((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) - (0 * 3600)),0)) - greatest(((6 * 3600) - time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i'))),0)),0) + (greatest((((2 * 3600) - greatest((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) - (6 * 3600)),0)) - greatest(((8 * 3600) - time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i'))),0)),0) + (greatest((((10 * 3600) - greatest((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) - (12 * 3600)),0)) - greatest(((22 * 3600) - time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i'))),0)),0) + greatest((((2 * 3600) - greatest((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) - (22 * 3600)),0)) - greatest(((24 * 3600) - time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i'))),0)),0)))) when (dayofweek(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) between 2 and 6) then (((greatest((((6 * 3600) - greatest((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) - (0 * 3600)),0)) - greatest(((6 * 3600) - time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i'))),0)),0) + greatest((((1 * 3600) - greatest((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) - (6 * 3600)),0)) - greatest(((7 * 3600) - time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i'))),0)),0)) + greatest((((2 * 3600) - greatest((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) - (20 * 3600)),0)) - greatest(((22 * 3600) - time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i'))),0)),0)) + greatest((((2 * 3600) - greatest((time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) - (22 * 3600)),0)) - greatest(((24 * 3600) - time_to_sec(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_end_date`,'%d-%m-%Y %H:%i'))),0)),0)) else 0 end) AS `ort_time`,dayofweek(str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y %H:%i')) AS `weekday` from (`GGMDLOAD`.`load_deliveries` left join `GGMDRULES`.`cf_CalendarTable` on((`GGMDRULES`.`cf_CalendarTable`.`dt` = str_to_date(`GGMDLOAD`.`load_deliveries`.`production_start_date`,'%d-%m-%Y')))) where (`GGMDLOAD`.`load_deliveries`.`appointment_time` > 0) group by `GGMDLOAD`.`load_deliveries`.`production_start_date`,`GGMDLOAD`.`load_deliveries`.`production_end_date`,`GGMDLOAD`.`load_deliveries`.`caretaker_id`,`GGMDLOAD`.`load_deliveries`.`client_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `s_AddressesToBeGeocoded_view`
--

/*!50001 DROP VIEW IF EXISTS `s_AddressesToBeGeocoded_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `s_AddressesToBeGeocoded_view` AS select `GGMDRULES`.`_Address`.`ZenitAddressId` AS `ZenitAddressId`,concat(`GGMDRULES`.`_Address`.`Street`,'+',`GGMDRULES`.`_Address`.`City`,'+',`GGMDRULES`.`_Address`.`ZipCode`,'+',ifnull(`GGMDRULES`.`_Address`.`CountryDescription`,'Nederland')) AS `GoogleFormattedAddress` from (`GGMDRULES`.`_Address` left join (select `GGMDRULES`.`_WorkAssignment`.`SourceCustomerId` AS `SourceCustomerId`,`GGMDRULES`.`_WorkAssignment`.`StartDate` AS `StartDate`,`GGMDRULES`.`_WorkAssignment`.`EndDate` AS `EndDate` from `GGMDRULES`.`_WorkAssignment` where (`GGMDRULES`.`_WorkAssignment`.`EndDate` > curdate()) group by `GGMDRULES`.`_WorkAssignment`.`SourceCustomerId`) `wa` on((convert(`GGMDRULES`.`_Address`.`SourcePersonId` using utf8mb4) = `wa`.`SourceCustomerId`))) where (((`GGMDRULES`.`_Address`.`RowSource` = 'load_sdb_medewerkeradressen') or (`wa`.`SourceCustomerId` is not null)) and (`GGMDRULES`.`_Address`.`PersonId` is not null)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `test_activity_planning`
--

/*!50001 DROP VIEW IF EXISTS `test_activity_planning`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `test_activity_planning` AS select `test_graphopper_response`.`vehicle_id` AS `vehicle_id`,`test_graphopper_response`.`activities.id` AS `activities.id`,if((`test_graphopper_response`.`activities.type` = 'start'),date_format(from_unixtime(`test_graphopper_response`.`activities.end_time`),'%Y-%m-%d %H:%i:%s'),date_format(from_unixtime(`test_graphopper_response`.`activities.arr_time`),'%Y-%m-%d %H:%i:%s')) AS `activities.start_time`,if((`test_graphopper_response`.`activities.type` <> 'service'),'',convert(date_format(from_unixtime(`test_graphopper_response`.`activities.end_time`),'%Y-%m-%d %H:%i:%s') using utf8mb4)) AS `activities.end_time`,sec_to_time(`test_graphopper_response`.`activities.driving_time`) AS `driving_time`,`test_graphopper_response`.`activities.driving_time` AS `driving_seconds`,(`test_graphopper_response`.`activities.distance` / 1000) AS `activities.distance` from `test_graphopper_response` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `test_employee_availability`
--

/*!50001 DROP VIEW IF EXISTS `test_employee_availability`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `test_employee_availability` AS select `test_employee_working_days`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`test_employee_working_days`.`Lon` AS `Lon`,`test_employee_working_days`.`Lat` AS `Lat`,'Monday' AS `Weekday`,if((`test_employee_working_days`.`MondayStart` = 0),0,(unix_timestamp((curdate() + interval (7 - weekday(curdate())) day)) + `test_employee_working_days`.`MondayStart`)) AS `Start`,if((`test_employee_working_days`.`MondayEnd` = 0),0,(unix_timestamp((curdate() + interval (7 - weekday(curdate())) day)) + `test_employee_working_days`.`MondayEnd`)) AS `End` from `test_employee_working_days` union select `test_employee_working_days`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`test_employee_working_days`.`Lon` AS `Lon`,`test_employee_working_days`.`Lat` AS `Lat`,'Tuesday' AS `Weekday`,if((`test_employee_working_days`.`TuesdayStart` = 0),0,(unix_timestamp((curdate() + interval ((7 - weekday(curdate())) + 1) day)) + `test_employee_working_days`.`TuesdayStart`)) AS `Start`,if((`test_employee_working_days`.`TuesdayEnd` = 0),0,(unix_timestamp((curdate() + interval ((7 - weekday(curdate())) + 1) day)) + `test_employee_working_days`.`TuesdayEnd`)) AS `End` from `test_employee_working_days` union select `test_employee_working_days`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`test_employee_working_days`.`Lon` AS `Lon`,`test_employee_working_days`.`Lat` AS `Lat`,'Wednesday' AS `Weekday`,if((`test_employee_working_days`.`WednesdayStart` = 0),0,(unix_timestamp((curdate() + interval ((7 - weekday(curdate())) + 2) day)) + `test_employee_working_days`.`WednesdayStart`)) AS `Start`,if((`test_employee_working_days`.`WednesdayEnd` = 0),0,(unix_timestamp((curdate() + interval ((7 - weekday(curdate())) + 2) day)) + `test_employee_working_days`.`WednesdayEnd`)) AS `End` from `test_employee_working_days` union select `test_employee_working_days`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`test_employee_working_days`.`Lon` AS `Lon`,`test_employee_working_days`.`Lat` AS `Lat`,'Thursday' AS `Weekday`,if((`test_employee_working_days`.`ThursdayStart` = 0),0,(unix_timestamp((curdate() + interval ((7 - weekday(curdate())) + 3) day)) + `test_employee_working_days`.`ThursdayStart`)) AS `Thursday`,if((`test_employee_working_days`.`ThursdayEnd` = 0),0,(unix_timestamp((curdate() + interval ((7 - weekday(curdate())) + 3) day)) + `test_employee_working_days`.`ThursdayEnd`)) AS `Thursday` from `test_employee_working_days` union select `test_employee_working_days`.`SourceEmployeeContractId` AS `SourceEmployeeContractId`,`test_employee_working_days`.`Lon` AS `Lon`,`test_employee_working_days`.`Lat` AS `Lat`,'Friday' AS `Weekday`,if((`test_employee_working_days`.`FridayStart` = 0),0,(unix_timestamp((curdate() + interval ((7 - weekday(curdate())) + 4) day)) + `test_employee_working_days`.`FridayStart`)) AS `Friday`,if((`test_employee_working_days`.`FridayEnd` = 0),0,(unix_timestamp((curdate() + interval ((7 - weekday(curdate())) + 4) day)) + `test_employee_working_days`.`FridayEnd`)) AS `Friday` from `test_employee_working_days` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `test_required_activities`
--

/*!50001 DROP VIEW IF EXISTS `test_required_activities`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `test_required_activities` AS select `test_caseload`.`ActivityType` AS `ActivityType`,`test_caseload`.`ActivityName` AS `ActivityName`,`test_caseload`.`CustomerId` AS `CustomerId`,(`test_caseload`.`Duration` / (`test_caseload`.`MinimumTimesPerWeek` * 2)) AS `Duration`,`test_caseload`.`Lon` AS `Lon`,`test_caseload`.`Lat` AS `Lat`,(case when (`test_caseload`.`TimewindowStart` = '') then (unix_timestamp((curdate() + interval (7 - weekday(curdate())) day)) + (9 * 3600)) end) AS `TimewindowStart`,(case when (`test_caseload`.`TimewindowEnd` = '') then ((unix_timestamp((curdate() + interval (7 - weekday(curdate())) day)) + ((((7 / `test_caseload`.`MinimumTimesPerWeek`) - 5) * 24) * 3600)) + (17 * 3600)) end) AS `TimewindowEnd` from `test_caseload` union all select `test_caseload`.`ActivityType` AS `ActivityType`,`test_caseload`.`ActivityName` AS `ActivityName`,`test_caseload`.`CustomerId` AS `CustomerId`,(`test_caseload`.`Duration` / (`test_caseload`.`MinimumTimesPerWeek` * 2)) AS `Duration`,`test_caseload`.`Lon` AS `Lon`,`test_caseload`.`Lat` AS `Lat`,((unix_timestamp((curdate() + interval (7 - weekday(curdate())) day)) + ((7 * 24) * 3600)) + (9 * 3600)) AS `TimewindowStart`,((unix_timestamp((curdate() + interval (7 - weekday(curdate())) day)) + ((12 * 24) * 3600)) + (17 * 3600)) AS `TimewindowEnd` from `test_caseload` where (`test_caseload`.`MinimumTimesPerWeek` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `test_s_graphhopper_services`
--

/*!50001 DROP VIEW IF EXISTS `test_s_graphhopper_services`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `test_s_graphhopper_services` AS select `test_required_activities`.`ActivityType` AS `ActivityType`,`test_required_activities`.`ActivityName` AS `ActivityName`,`test_required_activities`.`CustomerId` AS `CustomerId`,`test_required_activities`.`Duration` AS `Duration`,`test_required_activities`.`Lon` AS `Lon`,`test_required_activities`.`Lat` AS `Lat`,`test_required_activities`.`TimewindowStart` AS `TimewindowStart`,`test_required_activities`.`TimewindowEnd` AS `TimewindowEnd` from `test_required_activities` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `test_s_graphhopper_vehicles`
--

/*!50001 DROP VIEW IF EXISTS `test_s_graphhopper_vehicles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`pepijn`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `test_s_graphhopper_vehicles` AS select concat(cast(`test_employee_availability`.`SourceEmployeeContractId` as char charset utf8mb4),'-',left(`test_employee_availability`.`Weekday`,3),'-1') AS `vehicles_vehicle_id`,'car-type' AS `vehicles_type_id`,'EmployeeAddress' AS `vehicles_start_address_location_id`,`test_employee_availability`.`Lon` AS `vehicles_start_address_lon`,`test_employee_availability`.`Lat` AS `vehicles_start_address_lat`,'EmployeeAddress' AS `vehicles_end_address_location_id`,`test_employee_availability`.`Lon` AS `vehicles_end_address_lon`,`test_employee_availability`.`Lat` AS `vehicles_end_address_lat`,`test_employee_availability`.`Start` AS `vehicles_earliest_start`,`test_employee_availability`.`End` AS `vehicles_latest_end` from `test_employee_availability` union all select concat(cast(`test_employee_availability`.`SourceEmployeeContractId` as char charset utf8mb4),'-',left(`test_employee_availability`.`Weekday`,3),'-2') AS `vehicles_vehicle_id`,'car-type' AS `vehicles_type_id`,'EmployeeAddress' AS `vehicles_start_address_location_id`,`test_employee_availability`.`Lon` AS `vehicles_start_address_lon`,`test_employee_availability`.`Lat` AS `vehicles_start_address_lat`,'EmployeeAddress' AS `vehicles_end_address_location_id`,`test_employee_availability`.`Lon` AS `vehicles_end_address_lon`,`test_employee_availability`.`Lat` AS `vehicles_end_address_lat`,if((`test_employee_availability`.`Start` = 0),0,(`test_employee_availability`.`Start` + ((7 * 24) * 3600))) AS `vehicles_earliest_start`,if((`test_employee_availability`.`Start` = 0),0,(`test_employee_availability`.`End` + ((7 * 24) * 3600))) AS `vehicles_latest_end` from `test_employee_availability` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-14 17:21:58
