﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: This is the main class that handles un-installation
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */


/*.NET Packages*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.ServiceProcess;
using System.Collections;
using WAgentService;

namespace WAgentUninstaller
{
    public partial class UninstallerForm : Form
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private string theServiceName;
        private string thePathToNSSM;
        private bool isDeleted;
        private ServiceController theServiceController;
        public UninstallerForm uninstallerForm;

        /***************************************************************
							        METHODS
	    ****************************************************************/

        /**
         * @Usage default constructor 
        */
        public UninstallerForm()
        {

            uninstallerForm = this;
            isDeleted = true;
            theServiceController = new ServiceController(getServiceName());
            InitializeComponent();
        }


        /**
         * @Usage what happens on click of next button 
        */
        private void NextButton_Click(object sender, EventArgs e)
        {
            uninstallationDetailsLabel2.Visible = false;
            uninstallationDetailsLabel1.Visible = false;
            wAgentLogoPicture.Visible = false;
            NextButton.Enabled = false;
            CancelButton.Enabled = false;
            welcomeLabel.Visible = false;
            uninstallationProgressBar.Visible = true;
            uninstallingWAgentLabel.Visible = true;
            pleaseWaitLabel.Visible = true;
            statusLabel.Visible = true;

            /*Setup progress bar*/
            uninstallationProgressBar.Maximum = 100;
            uninstallationProgressBar.Step = 1;
            uninstallationProgressBar.Value = 0;
            UninstallationBackgroundWorker.RunWorkerAsync();
            
            /*show finish button on finish*/
            NextButton.Enabled = false;
            CancelButton.Enabled = false;
          
        }

        /**
         * @Usage to uninstall service before deleting 
        */
        private void unInstallService() {

            manageWAgentService("stop");
            manageWAgentService("uninstall");
        }

        /**
         * @Usage to manage w-agent service 
        */
        private void manageWAgentService(String aAction)
        {
            /*check if the service exists*/
            ServiceController myServiceController = checkServiceExists();
            if (myServiceController == null)
            {
                return;
            }

            string myCommand = "";
            if (aAction.Equals("stop"))
            {
                myCommand = getPathTONSSM() + " stop " + getServiceName();
            }
            else
            {
                myCommand = getPathTONSSM() + " remove " + getServiceName() + " confirm 2";
            }

            /*Run command to stop or uninstall service*/
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = myCommand;
            process.StartInfo = startInfo;
            process.Start();

            /*wait until service is uninstalled*/
            if (aAction.Equals("uninstall"))
            {
                while (true)
                {
                    ServiceController ctl = checkServiceExists();
                    if (ctl == null)
                    {
                        break;
                    }
                }
            }

        }

        /**
         * @Usage handle cancel button click 
        */
        private ServiceController checkServiceExists()
        {
            ServiceController ctl = ServiceController.GetServices().FirstOrDefault(s => s.ServiceName == getServiceName());
            return ctl;
        }

        /**
         * @Usage handle cancel button click 
        */
        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /**
         * @Usage handle finish button click 
        */
        private void FinishButton_Click(object sender, EventArgs e)
        {
            this.Close();
            deleteInstaller();
        }

        /**
         * @Usage to delete uninstaller after everything finishes 
        */
        private void deleteInstaller()
        {

            ProcessStartInfo Info = new ProcessStartInfo();
            Info.Arguments = "/C cd " +
                           System.IO.Path.GetDirectoryName(Application.ExecutablePath); 
            Info.WindowStyle = ProcessWindowStyle.Hidden;
            Info.CreateNoWindow = true;
            Info.FileName = "cmd.exe";
            Process.Start(Info);
            Info.Arguments = "/C DEL WAgentUninstaller.exe";
            Process.Start(Info);
        }

        /**
         * @Usage to get path to nssm
        */
        private string getPathTONSSM()
        {
            thePathToNSSM = "/C \"" + getPathFromCurrentDirectory() + "\\w-agent\\nssm\"";

            /*Check if nssm.exe exists*/
            if (!File.Exists(getPathFromCurrentDirectory() + "\\w-agent\\nssm.exe"))
            {
                var myForm = new AboutForm();
                myForm.StartPosition = FormStartPosition.CenterParent;
                myForm.LabelText = "Wrong Directory! Can't find nssm";

                uninstallerForm.Invoke(new Action(() => myForm.ShowDialog(uninstallerForm)));
                uninstallerForm.Invoke(new Action(() => uninstallerForm.Close()));
            }
            return thePathToNSSM;
        }

        /**
         * @Usage to get service name 
        */
        private string getServiceName()
        {
            theServiceName = getServiceNameFromFile();
            return theServiceName;
        }

        /**
         * @Usage read service name from file 
        */
        private string getServiceNameFromFile()
        {

            IDictionary myDictionary = ReadDictionaryFile("configurations.properties");
            string myServiceName = "";

            /*to check if file contains a service name*/
            try
            {
                myServiceName = myDictionary["ServiceName"].ToString();
            }
            catch (Exception e)
            {
                var myForm = new AboutForm();
                myForm.StartPosition = FormStartPosition.CenterScreen;
                myForm.LabelText = "Configuration file is wrong";
                myForm.ShowDialog(this);
                this.Close();
                throw e;
            }
            return myServiceName;
        }

        /**
         * @Usage to get current directory 
        */
        private string getPathFromCurrentDirectory()
        {
            string myCurrentDirectory = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            return myCurrentDirectory;
        }

        /**
         * @Usage to read from properties file 
        */
        public IDictionary ReadDictionaryFile (string fileName)
        {
            /*to store properties in dictionary*/
            Dictionary<string, string> dictionary = new Dictionary<string, string>();

            /*to check if file exists*/
            try
            {
                foreach (string line in File.ReadAllLines(fileName))
                {
                    /*Read from the file*/
                    if ((!string.IsNullOrEmpty(line)) &&
                        (!line.StartsWith(";")) &&
                        (!line.StartsWith("#")) &&
                        (!line.StartsWith("'")) &&
                        (line.Contains('=')))
                    {
                        int index = line.IndexOf('=');
                        string key = line.Substring(0, index).Trim();
                        string value = line.Substring(index + 1).Trim();

                        if ((value.StartsWith("\"") && value.EndsWith("\"")) ||
                            (value.StartsWith("'") && value.EndsWith("'")))
                        {
                            value = value.Substring(1, value.Length - 2);
                        }
                        dictionary.Add(key, value);
                    }
                }
            }
            catch (Exception e) {
               
                var myForm = new AboutForm();
                myForm.StartPosition = FormStartPosition.CenterScreen;
                myForm.ShowDialog(this);
                this.Close();
                throw e;
            }
            return dictionary;
        }

        /**
         * @Usage to handle deletion in background 
        */
        private void UninstallationBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {

            int backgroundWork = 0;
            var backgroundWorker = sender as BackgroundWorker;
            backgroundWork = 2;
            backgroundWorker.ReportProgress(backgroundWork);
            
            unInstallService();
            backgroundWork = 10;
            backgroundWorker.ReportProgress(backgroundWork);
            
            /*get current directory*/
            string directory = System.IO.Path.GetDirectoryName(Application.ExecutablePath);

            /*Delete all directories in current directory*/
            DirectoryInfo myDirectoryInfo = new DirectoryInfo(directory);
            foreach (DirectoryInfo dir in myDirectoryInfo.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                }
                catch (Exception ex) {
                    isDeleted = false;
                }
                
                backgroundWork += 20;
                backgroundWorker.ReportProgress(backgroundWork);
            }

            /*Delete all files from current directory*/
            foreach (FileInfo file in myDirectoryInfo.GetFiles())
            {

                if (!(file.Name.Equals("WAgentUninstaller.exe")))
                {
                    try
                    {
                        file.Delete();
                    }
                    catch (Exception ex)
                    {
                        isDeleted = false;
                    }

                    backgroundWork += 5;
                    backgroundWorker.ReportProgress(backgroundWork);
                }
            }
            backgroundWorker.ReportProgress(100);
        }

        /**
         * @Usage to change progress bar 
        */
        private void UninstallationBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            uninstallationProgressBar.Value = e.ProgressPercentage;
        }

        /**
         * @Usage to cleanup after uninstallation 
        */
        private void UninstallationBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (isDeleted == false)
            {
                var form = new AboutForm();
                form.StartPosition = FormStartPosition.CenterParent;
                form.LabelText = "Some Files May Not Be Deleted";
                form.Label1Text = "Consider Deleting them manually from Installation Path";
                //form.Label2Text = getPathFromCurrentDirectory();
                form.ShowDialog(this);

            }
            NextButton.Visible = false;
            CancelButton.Visible = false;
            FinishButton.Visible = true;

        }

    }
}
