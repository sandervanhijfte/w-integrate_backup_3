﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: Entry point to application
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */


/*.NET Packages*/
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using WAgentService;

namespace WAgentUninstaller
{
    static class Program
    {
        /***************************************************************
							        METHODS
	    ****************************************************************/

        /**
         * @Usage Main Method 
        */
        [STAThread]
        static void Main()
        {
            if (getParentDirectoryName() != "w-agent_home")
            {
                var myForm = new AboutForm();
                myForm.StartPosition = FormStartPosition.CenterParent;
                myForm.LabelText = "Uninstaller is in wrong directory";
                myForm.ShowDialog();
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                Application.Run(new UninstallerForm());
            }
            catch(Exception e)
            {

            }
            
        }

        /**
         * @Usage Get Parent Directory Name 
        */
        public static string getParentDirectoryName()
        {
            string myName;
            myName = System.IO.Directory.GetParent(Application.ExecutablePath).Name;
            return myName;
        }

    }
}
