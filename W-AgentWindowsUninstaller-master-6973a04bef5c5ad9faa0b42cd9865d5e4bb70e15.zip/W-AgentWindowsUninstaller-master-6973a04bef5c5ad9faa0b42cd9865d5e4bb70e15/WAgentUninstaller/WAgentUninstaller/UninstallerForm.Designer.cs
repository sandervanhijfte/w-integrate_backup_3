﻿namespace WAgentUninstaller
{
    partial class UninstallerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UninstallerForm));
            this.mainPanel = new System.Windows.Forms.Panel();
            this.statusLabel = new System.Windows.Forms.Label();
            this.pleaseWaitLabel = new System.Windows.Forms.Label();
            this.uninstallingWAgentLabel = new System.Windows.Forms.Label();
            this.uninstallationProgressBar = new System.Windows.Forms.ProgressBar();
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.uninstallationDetailsLabel2 = new System.Windows.Forms.Label();
            this.uninstallationDetailsLabel1 = new System.Windows.Forms.Label();
            this.wAgentLogoPicture = new System.Windows.Forms.PictureBox();
            this.NextButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.FinishButton = new System.Windows.Forms.Button();
            this.UninstallationBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.footerPanel = new System.Windows.Forms.Panel();
            this.allRightsReservedLogo = new System.Windows.Forms.Label();
            this.headerPanel = new System.Windows.Forms.Panel();
            this.wAgentAppLabel = new System.Windows.Forms.Label();
            this.wAgentTopLogoPicture = new System.Windows.Forms.PictureBox();
            this.mainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentLogoPicture)).BeginInit();
            this.footerPanel.SuspendLayout();
            this.headerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentTopLogoPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.statusLabel);
            this.mainPanel.Controls.Add(this.pleaseWaitLabel);
            this.mainPanel.Controls.Add(this.uninstallingWAgentLabel);
            this.mainPanel.Controls.Add(this.uninstallationProgressBar);
            this.mainPanel.Controls.Add(this.welcomeLabel);
            this.mainPanel.Controls.Add(this.uninstallationDetailsLabel2);
            this.mainPanel.Controls.Add(this.uninstallationDetailsLabel1);
            this.mainPanel.Controls.Add(this.wAgentLogoPicture);
            this.mainPanel.Location = new System.Drawing.Point(12, 12);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(550, 332);
            this.mainPanel.TabIndex = 0;
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.statusLabel.Location = new System.Drawing.Point(27, 117);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(45, 15);
            this.statusLabel.TabIndex = 9;
            this.statusLabel.Text = "Status :";
            this.statusLabel.Visible = false;
            // 
            // pleaseWaitLabel
            // 
            this.pleaseWaitLabel.AutoSize = true;
            this.pleaseWaitLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pleaseWaitLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pleaseWaitLabel.Location = new System.Drawing.Point(29, 80);
            this.pleaseWaitLabel.Name = "pleaseWaitLabel";
            this.pleaseWaitLabel.Size = new System.Drawing.Size(233, 15);
            this.pleaseWaitLabel.TabIndex = 8;
            this.pleaseWaitLabel.Text = "Please wait while setup Uninstalls W-Agent";
            this.pleaseWaitLabel.Visible = false;
            // 
            // uninstallingWAgentLabel
            // 
            this.uninstallingWAgentLabel.AutoSize = true;
            this.uninstallingWAgentLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uninstallingWAgentLabel.ForeColor = System.Drawing.Color.DarkBlue;
            this.uninstallingWAgentLabel.Location = new System.Drawing.Point(23, 42);
            this.uninstallingWAgentLabel.Name = "uninstallingWAgentLabel";
            this.uninstallingWAgentLabel.Size = new System.Drawing.Size(159, 21);
            this.uninstallingWAgentLabel.TabIndex = 7;
            this.uninstallingWAgentLabel.Text = "Uninstalling W-Agent";
            this.uninstallingWAgentLabel.Visible = false;
            // 
            // uninstallationProgressBar
            // 
            this.uninstallationProgressBar.Location = new System.Drawing.Point(29, 142);
            this.uninstallationProgressBar.Name = "uninstallationProgressBar";
            this.uninstallationProgressBar.Size = new System.Drawing.Size(490, 27);
            this.uninstallationProgressBar.TabIndex = 6;
            this.uninstallationProgressBar.Visible = false;
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeLabel.ForeColor = System.Drawing.Color.DarkBlue;
            this.welcomeLabel.Location = new System.Drawing.Point(21, 43);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(311, 21);
            this.welcomeLabel.TabIndex = 5;
            this.welcomeLabel.Text = "Welcome to W-Agent Uninstallation Wizard";
            // 
            // uninstallationDetailsLabel2
            // 
            this.uninstallationDetailsLabel2.AutoSize = true;
            this.uninstallationDetailsLabel2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uninstallationDetailsLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uninstallationDetailsLabel2.Location = new System.Drawing.Point(186, 209);
            this.uninstallationDetailsLabel2.Name = "uninstallationDetailsLabel2";
            this.uninstallationDetailsLabel2.Size = new System.Drawing.Size(323, 15);
            this.uninstallationDetailsLabel2.TabIndex = 4;
            this.uninstallationDetailsLabel2.Text = "Next to Uninstall  or Cancel to exit the Uninstallation  Wizard";
            // 
            // uninstallationDetailsLabel1
            // 
            this.uninstallationDetailsLabel1.AutoSize = true;
            this.uninstallationDetailsLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uninstallationDetailsLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uninstallationDetailsLabel1.Location = new System.Drawing.Point(186, 193);
            this.uninstallationDetailsLabel1.Name = "uninstallationDetailsLabel1";
            this.uninstallationDetailsLabel1.Size = new System.Drawing.Size(363, 15);
            this.uninstallationDetailsLabel1.TabIndex = 3;
            this.uninstallationDetailsLabel1.Text = "The Setup Wizard will Uninstall W-Agent from your computer. Click";
            // 
            // wAgentLogoPicture
            // 
            this.wAgentLogoPicture.Image = ((System.Drawing.Image)(resources.GetObject("wAgentLogoPicture.Image")));
            this.wAgentLogoPicture.Location = new System.Drawing.Point(29, 131);
            this.wAgentLogoPicture.Name = "wAgentLogoPicture";
            this.wAgentLogoPicture.Size = new System.Drawing.Size(146, 152);
            this.wAgentLogoPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.wAgentLogoPicture.TabIndex = 1;
            this.wAgentLogoPicture.TabStop = false;
            // 
            // NextButton
            // 
            this.NextButton.Location = new System.Drawing.Point(421, 9);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(67, 25);
            this.NextButton.TabIndex = 1;
            this.NextButton.Text = "Next";
            this.NextButton.UseVisualStyleBackColor = true;
            this.NextButton.Click += new System.EventHandler(this.NextButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(494, 9);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(67, 25);
            this.CancelButton.TabIndex = 2;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // FinishButton
            // 
            this.FinishButton.Location = new System.Drawing.Point(474, 9);
            this.FinishButton.Name = "FinishButton";
            this.FinishButton.Size = new System.Drawing.Size(67, 25);
            this.FinishButton.TabIndex = 3;
            this.FinishButton.Text = "Finish";
            this.FinishButton.UseVisualStyleBackColor = true;
            this.FinishButton.Visible = false;
            this.FinishButton.Click += new System.EventHandler(this.FinishButton_Click);
            // 
            // UninstallationBackgroundWorker
            // 
            this.UninstallationBackgroundWorker.WorkerReportsProgress = true;
            this.UninstallationBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.UninstallationBackgroundWorker_DoWork);
            this.UninstallationBackgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.UninstallationBackgroundWorker_ProgressChanged);
            this.UninstallationBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.UninstallationBackgroundWorker_RunWorkerCompleted);
            // 
            // footerPanel
            // 
            this.footerPanel.BackColor = System.Drawing.SystemColors.Control;
            this.footerPanel.Controls.Add(this.allRightsReservedLogo);
            this.footerPanel.Controls.Add(this.NextButton);
            this.footerPanel.Controls.Add(this.FinishButton);
            this.footerPanel.Controls.Add(this.CancelButton);
            this.footerPanel.Location = new System.Drawing.Point(1, 371);
            this.footerPanel.Name = "footerPanel";
            this.footerPanel.Size = new System.Drawing.Size(575, 44);
            this.footerPanel.TabIndex = 4;
            // 
            // allRightsReservedLogo
            // 
            this.allRightsReservedLogo.AutoSize = true;
            this.allRightsReservedLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allRightsReservedLogo.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.allRightsReservedLogo.Location = new System.Drawing.Point(26, 13);
            this.allRightsReservedLogo.Name = "allRightsReservedLogo";
            this.allRightsReservedLogo.Size = new System.Drawing.Size(294, 15);
            this.allRightsReservedLogo.TabIndex = 4;
            this.allRightsReservedLogo.Text = "W-Integrate © Copyright 2018   |   All Rights Reserved";
            // 
            // headerPanel
            // 
            this.headerPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.headerPanel.Controls.Add(this.wAgentAppLabel);
            this.headerPanel.Controls.Add(this.wAgentTopLogoPicture);
            this.headerPanel.Location = new System.Drawing.Point(1, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(575, 34);
            this.headerPanel.TabIndex = 7;
            // 
            // wAgentAppLabel
            // 
            this.wAgentAppLabel.AutoSize = true;
            this.wAgentAppLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wAgentAppLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.wAgentAppLabel.Location = new System.Drawing.Point(56, 12);
            this.wAgentAppLabel.Name = "wAgentAppLabel";
            this.wAgentAppLabel.Size = new System.Drawing.Size(104, 15);
            this.wAgentAppLabel.TabIndex = 8;
            this.wAgentAppLabel.Text = "W-Agent Uninstall";
            // 
            // wAgentTopLogoPicture
            // 
            this.wAgentTopLogoPicture.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("wAgentTopLogoPicture.BackgroundImage")));
            this.wAgentTopLogoPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.wAgentTopLogoPicture.Location = new System.Drawing.Point(31, 9);
            this.wAgentTopLogoPicture.Name = "wAgentTopLogoPicture";
            this.wAgentTopLogoPicture.Size = new System.Drawing.Size(18, 18);
            this.wAgentTopLogoPicture.TabIndex = 7;
            this.wAgentTopLogoPicture.TabStop = false;
            // 
            // UninstallerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(574, 415);
            this.Controls.Add(this.headerPanel);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.footerPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "UninstallerForm";
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentLogoPicture)).EndInit();
            this.footerPanel.ResumeLayout(false);
            this.footerPanel.PerformLayout();
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentTopLogoPicture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.PictureBox wAgentLogoPicture;
        private System.Windows.Forms.Button NextButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Label uninstallationDetailsLabel2;
        private System.Windows.Forms.Label uninstallationDetailsLabel1;
        private System.Windows.Forms.Button FinishButton;
        private System.Windows.Forms.ProgressBar uninstallationProgressBar;
        private System.ComponentModel.BackgroundWorker UninstallationBackgroundWorker;
        private System.Windows.Forms.Panel footerPanel;
        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.PictureBox wAgentTopLogoPicture;
        private System.Windows.Forms.Label wAgentAppLabel;
        private System.Windows.Forms.Label uninstallingWAgentLabel;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Label pleaseWaitLabel;
        private System.Windows.Forms.Label allRightsReservedLogo;
    }
}

