﻿/*
 * 	Author: Maira Tul Islam
 * 	Usage: This class is to handle the controls on InstallationWizard
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

using System;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace WAgentInstaller
{
    public partial class InstallerWizard : Form
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private string DEFAULT_INSTALLATION_PATH = "C:/w-agent_default";
        private string LOGSTASH_SOURCE_DIR = "\\assemblies\\logstash-6.3.2.zip";
        private string LOGSTASH_TARGET_DIR = "\\w-agent_home\\w-agent";
        private int INSTALLATION_PATH_MAX_LENGTH = 100;
        private string theInstallationPath;
        private WAgentInstallationHelper theInstallationHelper;
        private WAgentServiceHandler theWAgentServiceHandler;
        private BackgroundWorker theServiceStartupBackgroundWorker;
        private BackgroundWorker theInstallationProgressBackgroundWorker;

        /***************************************************************
							        METHODS
	    ****************************************************************/
        /*
         * @Usage Default Constructor
         * 
         */
        public InstallerWizard()
        {
            InitializeComponent();

            theInstallationPath = DEFAULT_INSTALLATION_PATH;
            theInstallationHelper = new WAgentInstallationHelper();
            theWAgentServiceHandler = new WAgentServiceHandler(theInstallationHelper.getCurrentDirectory(), theInstallationHelper.getServiceName());

            //process handlers
            setInstallationProcessHandler();
            setServiceStartUpHandler();

            //load the text in license agreement
            setLicenseAgreement();
        }

        /*
         * Loads the text from resources in text box
         * 
         */
        private void setLicenseAgreement()
        {
            var myAssembly = Assembly.GetExecutingAssembly();
            var myResourceName = "WAgentInstaller.EndUserLicenseAgreementWAlert.txt";

            Stream myStream = myAssembly.GetManifestResourceStream(myResourceName);
            StreamReader myReader = new StreamReader(myStream);
                
            termConditionsTextBox.Text = myReader.ReadToEnd();
        }

        /*
         * @Usage To set service startup process handler
         * 
         */
        private void setServiceStartUpHandler()
        {
            //service start up progress handling
            theServiceStartupBackgroundWorker = new BackgroundWorker();
            theServiceStartupBackgroundWorker.WorkerSupportsCancellation = true;
            theServiceStartupBackgroundWorker.WorkerReportsProgress = true;
            theServiceStartupBackgroundWorker.DoWork += new DoWorkEventHandler(serviceStartupBackgroundWorker_DoWork);
            theServiceStartupBackgroundWorker.ProgressChanged += new ProgressChangedEventHandler(serviceStartupBackgroundWorker_ProgressChanged);
            theServiceStartupBackgroundWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(serviceStartupBackgroundWorker_RunWorkerCompleted);
        }

        /*
         * @Usage To set installation process handler
         * 
         */
        private void setInstallationProcessHandler()
        {
            //installation progress handling
            theInstallationProgressBackgroundWorker = new BackgroundWorker();
            theInstallationProgressBackgroundWorker.WorkerSupportsCancellation = true;
            theInstallationProgressBackgroundWorker.WorkerReportsProgress = true;
            theInstallationProgressBackgroundWorker.DoWork += new DoWorkEventHandler(installationProgressBackgroundWorker_DoWork);
            theInstallationProgressBackgroundWorker.ProgressChanged += new ProgressChangedEventHandler(installationProgressBackgroundWorker_ProgressChanged);
            theInstallationProgressBackgroundWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(installationProgressBackgroundWorker_RunWorkerCompleted);
        }

        /*
         * @Usage To handle page selection in installaer wizard
         * 
         */
        private void installaterWizardControl_SelectedPageChanged(object sender, EventArgs e)
        {
            if(installerWizardControl.SelectedPage == installationInProgressPage)
            {
                theInstallationProgressBackgroundWorker.RunWorkerAsync();
            }

            if (installerWizardControl.SelectedPage == serviceStartInProgressPage)
            {
                theServiceStartupBackgroundWorker.RunWorkerAsync();
            }

            if (installerWizardControl.SelectedPage == installationFolderPage)
            {
                checkIfWAgentExists();
            }
        }

        /*
         * @Usage To handle text change in org id text box
         * 
         */
        private void organizationIdTextBox_TextChanged(object sender, EventArgs e)
        {
            setButtonVisibility();
        }

        /*
         * @Usage To handle text change in application id text box
         * 
         */
        private void applicationGroupIdTextBox_TextChanged(object sender, EventArgs e)
        {
            setButtonVisibility();
        }

        /*
         * @Usage To handle text change in environment name text box
         * 
         */
        private void environmentNameTextBox_TextChanged(object sender, EventArgs e)
        {
            setButtonVisibility();
        }

        /*
         * @Usage To set button visibility on config page
         * 
         */
        private void setButtonVisibility()
        {
            if ((organizationIdTextBox.Text != String.Empty) && (applicationGroupIdTextBox.Text != String.Empty) && (environmentNameTextBox.Text != String.Empty))
            {
                configPage.AllowNext = true;
            }
            else
            {
                configPage.AllowNext = false;
            }
        }

        /*
         * @Usage To handle check change on accept conditions check box
         * 
         */
        private void acceptConditionsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (acceptConditionsCheckBox.Checked)
            {
                termsConditionPage.AllowNext = true;
            }
            else
            {
                termsConditionPage.AllowNext = false;
            }
        }

        /*
         * @Usage To handle installation page commit
         * 
         */
        private void installationPage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            installationInProgressPage.AllowBack = false;
            installationFolderPage.AllowBack = false;
            installationPage.AllowBack = false;
            serviceStartInProgressPage.AllowBack = false;
            servicePage.AllowBack = false;
            setupCompletePage.AllowBack = false;
        }

        /*
         * @Usage To handle text hange in log file path text box
         * 
         */
        private void logFilePathTextBox_TextChanged(object sender, EventArgs e)
        {
            if (logFilePathTextBox.Text != String.Empty && File.Exists(logFilePathTextBox.Text))
            {
                logFilePage.AllowNext = true;
            }
            else
            {
                logFilePage.AllowNext = false;
            }
        }

        /*
         * @Usage To handle button click on log file browse button
         * 
         */
        private void logFileBrowseButton_Click(object sender, EventArgs e)
        {
            openLogFileDialog.Filter = "Log File (.log, .txt) | *.log;*.txt";
            openLogFileDialog.Title = "Select a Log File";
            DialogResult myResult = openLogFileDialog.ShowDialog();

            if (myResult == DialogResult.OK)
            { 
                logFilePathTextBox.Text = openLogFileDialog.FileName;
            }
        }

        /*
         * @Usage To handle click on installation path button 
         * 
         */
        private void chooseInstallationPathButton_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                installationPathTextBox.Text = folderBrowserDialog.SelectedPath;
            }
        }

        /*
         * @Usage To handle change on default path radio button 
         * 
         */
        private void defaultPathRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            handleRadioButtons();
        }

        /*
         * @Usage To handle change on custom installation path radio button 
         * 
         */
        private void customInstallationPathRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            handleRadioButtons();
        }

        /*
         * @Usage To handle change on radio buttons on installation path page 
         * 
         */
        private void handleRadioButtons()
        {
            if(defaultPathRadioButton.Checked)
            {
                theInstallationPath = defaultPathTextBox.Text.Replace("/", "\\"); ;
                installationPathTextBox.Enabled = false;
                chooseInstallationPathButton.Enabled = false;
                installationFolderPage.AllowNext = true;
                checkIfWAgentExists();
            }
            else
            {
                theInstallationPath = installationPathTextBox.Text.Replace("/", "\\"); ;
                installationPathTextBox.Enabled = true;
                chooseInstallationPathButton.Enabled = true;
                checkIfinstallationPathValid();
            }
        }

        /*
         * @Usage To check if selected installation path is valid 
         * 
         */
        private void checkIfinstallationPathValid()
        {
            if (installationPathTextBox.Text != String.Empty && Directory.Exists(installationPathTextBox.Text))
            {
                if (installationPathTextBox.Text.Length > INSTALLATION_PATH_MAX_LENGTH)
                {
                    invalidPathLabel.Visible = true;
                    installationFolderPage.AllowNext = false;
                }
                else
                {
                    invalidPathLabel.Visible = false;
                    noteTextBox.Visible = false;
                    installationFolderPage.AllowNext = true;
                    checkIfWAgentExists();
                }
            }
            else
            {
                installationFolderPage.AllowNext = false;
                noteTextBox.Visible = false;
            }
        }

        /*
         * @Usage To check if w-agent already installed
         * 
         */
        private void checkIfWAgentExists()
        {
            if (Directory.Exists(theInstallationPath + "\\w-agent_home"))
            {
                noteTextBox.Text = "W-Agent is already installed in the selected directory, If you choose to continue, the current installation will be overwritten.";
                installationFolderPage.AllowNext = true;
                noteTextBox.Visible = true;

            }
            else
            {
                noteTextBox.Visible = false;
                installationFolderPage.AllowNext = true;
            }
        }

        /*
         * @Usage To handle installtion folder page commit
         * 
         */
        private void installationFolderPage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            showAppIdTextBox.Text = applicationGroupIdTextBox.Text;
            showOrgIdTextBox.Text = organizationIdTextBox.Text;
            showEnvNameTextBox.Text = environmentNameTextBox.Text;
            showLogFileTextBox.Text = logFilePathTextBox.Text;
            showInstallationPathTextBox.Text = theInstallationPath;
        }

        /*
         * @Usage To handle service page commit
         * 
         */
        private void servicePage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            if(noRadioButton.Checked)
            {
                setupCompletionDetailsRichTextBox.Text = "W-Agent has been successfully installed. You chose not to start W-Agent. Now you can start the w-agent manually. For further instructions, read the installation guide. Click the Finish to exit the Setup Wizard.";
                servicePage.NextPage = setupCompletePage;
            }
        }

        /*
         * @Usage To handle work on installation progress background worker 
         * 
         */
        private void installationProgressBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
            	theInstallationHelper.createWeAgentFolderAndCopyFiles(theInstallationPath);
            	theInstallationProgressBackgroundWorker.ReportProgress(20);
            	theInstallationHelper.extractZipFile(theInstallationHelper.getCurrentDirectory() + LOGSTASH_SOURCE_DIR, theInstallationPath + LOGSTASH_TARGET_DIR);
            	theInstallationProgressBackgroundWorker.ReportProgress(35);
            	theInstallationHelper.copyFilesInWAgentLogstash(theInstallationPath);
            	theInstallationProgressBackgroundWorker.ReportProgress(50);
            	theInstallationHelper.replaceVariableInConf(organizationIdTextBox.Text, applicationGroupIdTextBox.Text, environmentNameTextBox.Text, logFilePathTextBox.Text, theInstallationPath);
            	theInstallationProgressBackgroundWorker.ReportProgress(60);
            	theWAgentServiceHandler.replaceVariablesInServiceInstaller(theInstallationPath);
            	theInstallationProgressBackgroundWorker.ReportProgress(70);
            	theInstallationHelper.installLogstash();
            	Thread.Sleep(300);
            	theInstallationProgressBackgroundWorker.ReportProgress(100);
            	theWAgentServiceHandler.removeServiceInstallerTmpFile();
            }
            catch (Exception ex)
            {
                Application.Run(new ErrorBox());
            }
        }

        /*
         * @Usage To handle progress change on installation progress background worker 
         * 
         */
        void installationProgressBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            installationProgressBar.Value = e.ProgressPercentage;
        }

        /*
         * @Usage To handle task completion on installation progress background worker 
         * 
         */
        private void installationProgressBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            installationInProgressPage.AllowNext = true;
        }

        /*
         * @Usage To handle work on service start up background worker 
         * 
         */
        private void serviceStartupBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            serviceDetailsTextBox.Text = "Starting Service... ";
            theServiceStartupBackgroundWorker.ReportProgress(50);
            theWAgentServiceHandler.startService(theInstallationPath);
            waitUntilAgentStarts();

            theServiceStartupBackgroundWorker.ReportProgress(100);
        }

        /*
         * @Usage To make user wait until the service has been started 
         * 
         */
        private void waitUntilAgentStarts()
        {
            bool checkLogFile = true;

            while (checkLogFile == true)
            {
                string text = theInstallationHelper.getWAgentLogFile(theInstallationPath);
                updateServiceDetailsStatus("Starting Service... " + "\n" + text);
                if (text.Contains("Successfully started Logstash API endpoint"))
                {
                    checkLogFile = false;
                    updateServiceDetailsStatus("Starting Service... " + "\n" + text + "\n\n" + "Succesfully Started W-Agent as a Service");
                }

                Thread.Sleep(200);
            }
        }

        /*
         * @Usage To update the service deatils status
         * 
         */
        private void updateServiceDetailsStatus(string textMessage)
        {
            if (serviceDetailsTextBox.InvokeRequired)
            {
                serviceDetailsTextBox.Invoke(new MethodInvoker(() => updateServiceDetailsStatus(textMessage)));
                return;
            }

            serviceDetailsTextBox.Text = textMessage;
        }

        /*
         * @Usage To handle progress change on service start up background worker 
         * 
         */
        private void serviceStartupBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            serviceStartUpProgressBar.Value = e.ProgressPercentage;
        }

        /*
         * @Usage To handle task completion on service start up background worker 
         * 
         */
        private void serviceStartupBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            serviceStartInProgressPage.AllowNext = true;
        }

        /*
         * @Usage To handle text change on installation path text box 
         * 
         */
        private void installationPathTextBox_TextChanged(object sender, EventArgs e)
        {
            handleRadioButtons();
        }

        /*
         * @Usage To handle click on service details button 
         * 
         */
        private void serviceDetailsButton_Click(object sender, EventArgs e)
        {
            if(!serviceDetailsTextBox.Visible)
            {
                serviceDetailsTextBox.Visible = true;
            }
            else
            {
                serviceDetailsTextBox.Visible = false;
            }
        }
    }
}
