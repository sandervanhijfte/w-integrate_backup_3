﻿/*
 * 	Author: Maira Tul Islam
 * 	Usage: This is the class that provides functions to handle the installation package for w-agent
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */
using System.IO;

namespace WAgentInstaller
{
    class WAgentPackageHandler
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private string PROPERTIES_FILE_NAME = "configurations.properties";
        private string SERVICE_FILE_NAME = "WAgentService.exe";
        private string UNINSTALL_FILE_NAME = "WAgentUninstaller.exe";
        private string NSSM_FILE_NAME = "nssm.exe";
        private string CRT_FILE_NAME = "w-agent.crt";
        private string CONF_FILE_NAME = "w-alert_shipper.conf";
        private string WAGENT_HOME = "\\w-agent_home";
        private string WAGENT_LOGSTASH_HOME = "\\w-agent_home\\w-agent";

        private string theCurrentDirectory;

        /***************************************************************
							        METHODS
	    ****************************************************************/
        /*
         * @Usage Default Constructor
         * 
         */
        public WAgentPackageHandler(string aCurrentDirectory)
        {
            this.theCurrentDirectory = aCurrentDirectory;
        }

        /*
        * @Usage To create w-agent installation package 
        * 
        * @param anInstallationPath the installation path selected by the user
        */
        public void createWAgentPackage(string anInstallationPath)
        {
            Directory.CreateDirectory(anInstallationPath);
            Directory.CreateDirectory(anInstallationPath + WAGENT_LOGSTASH_HOME);

            copyFilesInWAgentHome(anInstallationPath + WAGENT_HOME);
        }

        /*
        * @Usage To delete the given directory
        * 
        * @param aTargetDir a target directory
        */
        public void DeleteDirectory(string aTargetDir)
        {
            string[] myFiles = Directory.GetFiles(aTargetDir);
            string[] myDirs = Directory.GetDirectories(aTargetDir);

            foreach (string myFile in myFiles)
            {
                File.SetAttributes(myFile, FileAttributes.Normal);
                File.Delete(myFile);
            }

            foreach (string myDir in myDirs)
            {
                DeleteDirectory(myDir);
            }

        }

        /*
        * @Usage To copy file in w-agent home 
        * 
        * @param aWAgentHome the w-agent home directory
        */
        private void copyFilesInWAgentHome(string aWAgentHome)
        {
            string mySourcePath = theCurrentDirectory + "\\samples";
            string myTargetPath = aWAgentHome;

            copyFile(mySourcePath, myTargetPath, SERVICE_FILE_NAME);
            copyFile(mySourcePath, myTargetPath, UNINSTALL_FILE_NAME);
            copyFile(theCurrentDirectory, myTargetPath, PROPERTIES_FILE_NAME);
        }

        /*
        * @Usage To copy files in w-agent logstash 
        * 
        * @param anInstallationPath the installation path selected by the user
        */
        public void copyFilesInLogstash(string anInstallationPath)
        {
            string myLogstashHome = anInstallationPath + WAGENT_LOGSTASH_HOME;
            string myAssembliesSourcePath = theCurrentDirectory + "\\assemblies";
            string mySourcePath = theCurrentDirectory;
            string myTargetPathForNssm = myLogstashHome;
            string myTargetPath = myLogstashHome + "\\bin";

            copyFile(myAssembliesSourcePath, myTargetPathForNssm, NSSM_FILE_NAME);
            copyFile(mySourcePath, myTargetPath, CRT_FILE_NAME);
            copyFile(mySourcePath, myTargetPath, CONF_FILE_NAME);
        }

        /*
        * @Usage To copy a file 
        * 
        * @param aSourcePath a source path
        * @param aTargetPath a target path
        * @param aFileName a file name
        */
        private void copyFile(string aSourcePath, string aTargetPath, string aFileName)
        {
            string mySourceFile = System.IO.Path.Combine(aSourcePath, aFileName);
            string myDestFile = System.IO.Path.Combine(aTargetPath, aFileName);

            System.IO.File.Copy(mySourceFile, myDestFile, true);
        }
    }
}
