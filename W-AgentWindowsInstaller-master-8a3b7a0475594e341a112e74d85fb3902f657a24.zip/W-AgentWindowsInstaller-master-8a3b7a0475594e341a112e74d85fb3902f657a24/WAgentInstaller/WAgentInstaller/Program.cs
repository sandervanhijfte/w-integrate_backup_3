﻿/*
 * 	Author: Maira Tul Islam
 * 	Usage: This is the main entry point of the application
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WAgentInstaller
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            WAgentInstallationHelper myInstallationHelper = new WAgentInstallationHelper();

            if (!myInstallationHelper.checkIfJavaInstalled())
            {
                Application.Run(new JavaRequirementDialog());
            }
            else
            {
                try
                {
                Application.Run(new InstallerWizard());
                }
                catch (Exception e) {
                    Application.Run(new ErrorBox());
                }
            }
        }
    }
}
