﻿/*
 * 	Author: Maira Tul Islam
 * 	Usage: This is the class that provides help methods to perform steps of installation for w-agent
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

/*.NET Packages*/
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Windows.Forms;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace WAgentInstaller
{
    class WAgentInstallationHelper
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private string LOG_FILE_PARAMETER = "LOG_FILE_PATH";
        private string ORG_ID_PARAMETER = "ORGANIZATION_ID";
        private string APP_GROUP_ID_PARAMETER = "APPLICATIONGROUP_ID";
        private string ENV_NAME_PARAMETER = "ENVIRONMENT_NAME";
        private string TIME_ZONE_PARAMETER = "TIME_ZONE";
        private string SERVICE_NAME_PARAMETER = "ServiceName";
        private string CONF_FILE = "w-alert_shipper.conf";
        private string DEFAULT_SERVICE_NAME = "W_Agent_Service";
        private string PROPERTIES_FILE_NAME = "configurations.properties";
        private string LOG_FILE_LOCATION = "\\w-agent_home\\w-agent\\logs\\logstash-plain.log";
        private string WAGENT_HOME_FOLDER = "\\w-agent_home";
        private string WAGENT_BIN_LOCATION = "\\w-agent_home\\w-agent\\bin\\";
        private string TMP_SERVICE_INSTALLER = "tmp_w-agent_service_installer.bat";

        private string theServiceName;
        private WAgentServiceHandler theServiceHandler;
        private WAgentPackageHandler thePackageHandler;

        /***************************************************************
							        METHODS
	    ****************************************************************/
        /*
         * @Usage Default Constructor
         * 
         */
        public WAgentInstallationHelper()
        {
            if (getServiceNameFromFile() != null)
            {
                theServiceName = getServiceNameFromFile();
            }
            else
            {
                theServiceName = DEFAULT_SERVICE_NAME;
            }

            theServiceHandler = new WAgentServiceHandler(getCurrentDirectory(), theServiceName);
            thePackageHandler = new WAgentPackageHandler(getCurrentDirectory());
        }

        /*
         * @Usage To get the service name from a properties file
         * 
         */
        private string getServiceNameFromFile()
        {

            IDictionary myDict = ReadDictionaryFile(PROPERTIES_FILE_NAME);
            
            return myDict[SERVICE_NAME_PARAMETER].ToString();
        }

        /*
         * @Usage To get the w-agent service name
         * 
         */
        public string getServiceName()
        {
            return theServiceName;
        }

        /*
         * @Usage Reads a dictionary file
         * 
         * @param the name of file to read
         */
        public IDictionary ReadDictionaryFile(string aFileName)
        {
            Dictionary<string, string> myDictionary = new Dictionary<string, string>();

            foreach (string myLine in File.ReadAllLines(aFileName))
            {
                if ((!string.IsNullOrEmpty(myLine)) &&
                    (!myLine.StartsWith(";")) &&
                    (!myLine.StartsWith("#")) &&
                    (!myLine.StartsWith("'")) &&
                    (myLine.Contains("=")))
                {
                    int myIndex = myLine.IndexOf('=');
                    string myKey = myLine.Substring(0, myIndex).Trim();
                    string myValue = myLine.Substring(myIndex + 1).Trim();

                    if ((myValue.StartsWith("\"") && myValue.EndsWith("\"")) ||
                        (myValue.StartsWith("'") && myValue.EndsWith("'")))
                    {
                        myValue = myValue.Substring(1, myValue.Length - 2);
                    }
                    myDictionary.Add(myKey, myValue);
                }
            }

            return myDictionary;
        }

       /*
        * @Usage To get the current directory in which the installer is placed
        * 
        */
        public string getCurrentDirectory()
        {
            string myCurrentDirectory = Path.GetDirectoryName(Application.ExecutablePath);

            return myCurrentDirectory.Replace("/","\\");
        }

        /*
        * @Usage To check if java is installed on the system
        * 
        */
        public bool checkIfJavaInstalled()
        {
            try
            {
                ProcessStartInfo myJavaCheckProcessStartInfo = new ProcessStartInfo();
                myJavaCheckProcessStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                myJavaCheckProcessStartInfo.CreateNoWindow = true;
                myJavaCheckProcessStartInfo.FileName = "java.exe";
                myJavaCheckProcessStartInfo.Arguments = " -version";
                myJavaCheckProcessStartInfo.RedirectStandardError = true;
                myJavaCheckProcessStartInfo.UseShellExecute = false;

                Process myJavaCheckProcess = Process.Start(myJavaCheckProcessStartInfo);
                string myJavaVersion = myJavaCheckProcess.StandardError.ReadLine().Split(' ')[2].Replace("\"", "");
                
                if(myJavaVersion != null)
                {
                    return true;
                }
                return false;
            }
            catch(Exception e)
            {
                return false;
            }
        }

        /*
        * @Usage To create the w-agent package and copy files inside it
        * 
        * @param anInstallationPath the installation path selected by user
        */
        public void createWeAgentFolderAndCopyFiles(string anInstallationPath)
        {
            string myWAgentHome = anInstallationPath + WAGENT_HOME_FOLDER;

            if (Directory.Exists(myWAgentHome))
            {
               theServiceHandler.deleteService();
               thePackageHandler.DeleteDirectory(myWAgentHome);
            }

            thePackageHandler.createWAgentPackage(anInstallationPath);
        }

        /*
        * @Usage To copy files inside the extracted logstash inside w-agent package
        * 
        * @param anInstallationPath the installation path selected by user
        */
        public void copyFilesInWAgentLogstash(string anInstallationPath)
        {
            thePackageHandler.copyFilesInLogstash(anInstallationPath);
        }

        /*
        * @Usage To replace variables inside the conf file of w-agent
        * 
        * @param anOrgId an organization id 
        * @param anAppId an application id
        * @param anEnvName an environment name
        * @param aLogFilePath a log file path
        * @param anInstallationPath a path for installation
        */
        public void replaceVariableInConf(string anOrgId,
            string anAppId,
            string anEnvName,
            string aLogFilePath,
            string anInstallationPath)
        {
            string myConfFileText = File.ReadAllText(anInstallationPath + WAGENT_BIN_LOCATION + CONF_FILE);

            myConfFileText = myConfFileText.Replace(LOG_FILE_PARAMETER, aLogFilePath);
            myConfFileText = myConfFileText.Replace(ORG_ID_PARAMETER, anOrgId);
            myConfFileText = myConfFileText.Replace(APP_GROUP_ID_PARAMETER, anAppId);
            myConfFileText = myConfFileText.Replace(ENV_NAME_PARAMETER, anEnvName);
            myConfFileText = myConfFileText.Replace(TIME_ZONE_PARAMETER, getCurrentTimeZoneOffset());

            File.WriteAllText(anInstallationPath + WAGENT_BIN_LOCATION + CONF_FILE, myConfFileText);
        }

        /**
         * @Usage To get systems current timezone offset
         * 
         */
        private string getCurrentTimeZoneOffset()
        {
            String utcOffset = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).ToString();
            String offset = utcOffset.Substring(0, utcOffset.Length - 3);

            return offset.StartsWith("-") ? offset : "+" + offset;
        }

        /*
        * @Usage To extract a zip file
        * 
        * @param aZipPath the path of zip file we want to extract
        * @param anExtractPath the path where we want to place the extracted file
        */
        public void extractZipFile(string aZipPath, string anExtractPath)
        {
            ZipFile.ExtractToDirectory(aZipPath, anExtractPath);
        }

        /*
        * @Usage To install logstash as a service
        * 
        */
        public void installLogstash()
        {
            Process myInstallationProcess = new Process();

            myInstallationProcess.StartInfo.CreateNoWindow = true;
            myInstallationProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            myInstallationProcess.StartInfo.FileName = getCurrentDirectory() + "\\" + TMP_SERVICE_INSTALLER;
            myInstallationProcess.StartInfo.UseShellExecute = false;

            myInstallationProcess.Start();
            myInstallationProcess.WaitForExit();
        }

        /*
        * @Usage To get the content of log file of w-agent
        * 
        * @param anInstallationPath a path for installation
        */
        public String getWAgentLogFile(String anInstallationPath)
        {
            string myLogFile = anInstallationPath + LOG_FILE_LOCATION;
            string myLogFileText = "";

            if (File.Exists(myLogFile))
            {
                using (var myFileStream = new FileStream(myLogFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var myStreamReader = new StreamReader(myFileStream, Encoding.Default))
                {
                    myLogFileText = myStreamReader.ReadToEnd();
                }
            }

            return myLogFileText;
        }
    }
}
