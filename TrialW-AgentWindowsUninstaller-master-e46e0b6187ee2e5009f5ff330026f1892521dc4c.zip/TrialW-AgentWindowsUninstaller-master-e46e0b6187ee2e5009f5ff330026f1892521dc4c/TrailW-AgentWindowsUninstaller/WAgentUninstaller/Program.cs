﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: Entry point to application
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */


/*.NET Packages*/
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using WAgentService;

namespace WAgentUninstaller
{
    static class Program
    {
        /***************************************************************
                                   METHODS
       ****************************************************************/

        /**
         * @Usage Main Method
        */
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            /*does not uninstall if we are not in required directory*/

            
            if (getParentDirectoryName() != "w-agent_home")
            {
                var myForm = new AboutForm();
                myForm.StartPosition = FormStartPosition.CenterParent;
                myForm.LabelText = "Uninstaller is in wrong directory";
                myForm.ShowDialog();
                return;
            }
            

            try
            {
                Application.Run(new UninstallerForm());
            }
            catch(Exception e)
            {

            }
            
        }

        /**
         * @Usage to get parent directory on exe 
        */
        public static string getParentDirectoryName()
        {
            string myName;
            myName = System.IO.Directory.GetParent(Application.ExecutablePath).Name;
            return myName;
        }


    }
}
