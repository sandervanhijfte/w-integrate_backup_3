﻿using System.Drawing;

namespace WAgentUninstaller
{
    partial class UninstallerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UninstallerForm));
            this.mainPanel = new System.Windows.Forms.Panel();
            this.statusLabel = new System.Windows.Forms.Label();
            this.waitMessageLabel = new System.Windows.Forms.Label();
            this.uninstallingWAgentLabel = new System.Windows.Forms.Label();
            this.UninstallationProgressBar = new System.Windows.Forms.ProgressBar();
            this.welcomeWizardLabel = new System.Windows.Forms.Label();
            this.uninstallerDetailsLabel2 = new System.Windows.Forms.Label();
            this.uninstallerDetailsLabel1 = new System.Windows.Forms.Label();
            this.wAgentLogoPicture = new System.Windows.Forms.PictureBox();
            this.NextButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.FinishButton = new System.Windows.Forms.Button();
            this.UninstallationBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.footerPanel = new System.Windows.Forms.Panel();
            this.ExitButton = new System.Windows.Forms.Button();
            this.RestartButton = new System.Windows.Forms.Button();
            this.allRightsReservedLabel = new System.Windows.Forms.Label();
            this.headingPanel = new System.Windows.Forms.Panel();
            this.appNameLabel = new System.Windows.Forms.Label();
            this.wAgentTopLogo = new System.Windows.Forms.PictureBox();
            this.mainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentLogoPicture)).BeginInit();
            this.footerPanel.SuspendLayout();
            this.headingPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentTopLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.statusLabel);
            this.mainPanel.Controls.Add(this.waitMessageLabel);
            this.mainPanel.Controls.Add(this.uninstallingWAgentLabel);
            this.mainPanel.Controls.Add(this.UninstallationProgressBar);
            this.mainPanel.Controls.Add(this.welcomeWizardLabel);
            this.mainPanel.Controls.Add(this.uninstallerDetailsLabel2);
            this.mainPanel.Controls.Add(this.uninstallerDetailsLabel1);
            this.mainPanel.Controls.Add(this.wAgentLogoPicture);
            this.mainPanel.Location = new System.Drawing.Point(12, 12);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(550, 332);
            this.mainPanel.TabIndex = 0;
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.statusLabel.Location = new System.Drawing.Point(27, 117);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(45, 15);
            this.statusLabel.TabIndex = 9;
            this.statusLabel.Text = "Status :";
            this.statusLabel.Visible = false;
            // 
            // waitMessageLabel
            // 
            this.waitMessageLabel.AutoSize = true;
            this.waitMessageLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waitMessageLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.waitMessageLabel.Location = new System.Drawing.Point(29, 80);
            this.waitMessageLabel.Name = "waitMessageLabel";
            this.waitMessageLabel.Size = new System.Drawing.Size(233, 15);
            this.waitMessageLabel.TabIndex = 8;
            this.waitMessageLabel.Text = "Please wait while setup Uninstalls W-Agent";
            this.waitMessageLabel.Visible = false;
            // 
            // uninstallingWAgentLabel
            // 
            this.uninstallingWAgentLabel.AutoSize = true;
            this.uninstallingWAgentLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uninstallingWAgentLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(44)))), ((int)(((byte)(170)))));
            this.uninstallingWAgentLabel.Location = new System.Drawing.Point(23, 42);
            this.uninstallingWAgentLabel.Name = "uninstallingWAgentLabel";
            this.uninstallingWAgentLabel.Size = new System.Drawing.Size(159, 21);
            this.uninstallingWAgentLabel.TabIndex = 7;
            this.uninstallingWAgentLabel.Text = "Uninstalling W-Agent";
            this.uninstallingWAgentLabel.Visible = false;
            // 
            // UninstallationProgressBar
            // 
            this.UninstallationProgressBar.Location = new System.Drawing.Point(29, 142);
            this.UninstallationProgressBar.Name = "UninstallationProgressBar";
            this.UninstallationProgressBar.Size = new System.Drawing.Size(490, 27);
            this.UninstallationProgressBar.TabIndex = 6;
            this.UninstallationProgressBar.Visible = false;
            // 
            // welcomeWizardLabel
            // 
            this.welcomeWizardLabel.AutoSize = true;
            this.welcomeWizardLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeWizardLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(44)))), ((int)(((byte)(170)))));
            this.welcomeWizardLabel.Location = new System.Drawing.Point(21, 43);
            this.welcomeWizardLabel.Name = "welcomeWizardLabel";
            this.welcomeWizardLabel.Size = new System.Drawing.Size(311, 21);
            this.welcomeWizardLabel.TabIndex = 5;
            this.welcomeWizardLabel.Text = "Welcome to W-Agent Uninstallation Wizard";
            // 
            // uninstallerDetailsLabel2
            // 
            this.uninstallerDetailsLabel2.AutoSize = true;
            this.uninstallerDetailsLabel2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uninstallerDetailsLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uninstallerDetailsLabel2.Location = new System.Drawing.Point(186, 209);
            this.uninstallerDetailsLabel2.Name = "uninstallerDetailsLabel2";
            this.uninstallerDetailsLabel2.Size = new System.Drawing.Size(323, 15);
            this.uninstallerDetailsLabel2.TabIndex = 4;
            this.uninstallerDetailsLabel2.Text = "Next to Uninstall  or Cancel to exit the Uninstallation  Wizard";
            // 
            // uninstallerDetailsLabel1
            // 
            this.uninstallerDetailsLabel1.AutoSize = true;
            this.uninstallerDetailsLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uninstallerDetailsLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uninstallerDetailsLabel1.Location = new System.Drawing.Point(186, 193);
            this.uninstallerDetailsLabel1.Name = "uninstallerDetailsLabel1";
            this.uninstallerDetailsLabel1.Size = new System.Drawing.Size(363, 15);
            this.uninstallerDetailsLabel1.TabIndex = 3;
            this.uninstallerDetailsLabel1.Text = "The Setup Wizard will Uninstall W-Agent from your computer. Click";
            // 
            // wAgentLogoPicture
            // 
            this.wAgentLogoPicture.Image = ((System.Drawing.Image)(resources.GetObject("wAgentLogoPicture.Image")));
            this.wAgentLogoPicture.Location = new System.Drawing.Point(29, 131);
            this.wAgentLogoPicture.Name = "wAgentLogoPicture";
            this.wAgentLogoPicture.Size = new System.Drawing.Size(146, 152);
            this.wAgentLogoPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.wAgentLogoPicture.TabIndex = 1;
            this.wAgentLogoPicture.TabStop = false;
            // 
            // NextButton
            // 
            this.NextButton.Location = new System.Drawing.Point(421, 9);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(67, 25);
            this.NextButton.TabIndex = 1;
            this.NextButton.Text = "Next";
            this.NextButton.UseVisualStyleBackColor = true;
            this.NextButton.Click += new System.EventHandler(this.NextButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(494, 9);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(67, 25);
            this.CancelButton.TabIndex = 2;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // FinishButton
            // 
            this.FinishButton.Location = new System.Drawing.Point(481, 9);
            this.FinishButton.Name = "FinishButton";
            this.FinishButton.Size = new System.Drawing.Size(67, 25);
            this.FinishButton.TabIndex = 3;
            this.FinishButton.Text = "Finish";
            this.FinishButton.UseVisualStyleBackColor = true;
            this.FinishButton.Visible = false;
            this.FinishButton.Click += new System.EventHandler(this.FinishButton_Click);
            // 
            // UninstallationBackgroundWorker
            // 
            this.UninstallationBackgroundWorker.WorkerReportsProgress = true;
            this.UninstallationBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.UninstallationBackgroundWorker_DoWork);
            this.UninstallationBackgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.UninstallationBackgroundWorker_ProgressChanged);
            this.UninstallationBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.UninstallationBackgroundWorker_RunWorkerCompleted);
            // 
            // footerPanel
            // 
            this.footerPanel.BackColor = System.Drawing.SystemColors.Control;
            this.footerPanel.Controls.Add(this.ExitButton);
            this.footerPanel.Controls.Add(this.RestartButton);
            this.footerPanel.Controls.Add(this.allRightsReservedLabel);
            this.footerPanel.Controls.Add(this.NextButton);
            this.footerPanel.Controls.Add(this.FinishButton);
            this.footerPanel.Controls.Add(this.CancelButton);
            this.footerPanel.Location = new System.Drawing.Point(1, 371);
            this.footerPanel.Name = "footerPanel";
            this.footerPanel.Size = new System.Drawing.Size(575, 44);
            this.footerPanel.TabIndex = 4;
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(494, 10);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(67, 25);
            this.ExitButton.TabIndex = 6;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Visible = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // RestartButton
            // 
            this.RestartButton.Image = ((System.Drawing.Image)(resources.GetObject("RestartButton.Image")));
            this.RestartButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.RestartButton.Location = new System.Drawing.Point(421, 10);
            this.RestartButton.Name = "RestartButton";
            this.RestartButton.Size = new System.Drawing.Size(67, 25);
            this.RestartButton.TabIndex = 5;
            this.RestartButton.Text = "Restart";
            this.RestartButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.RestartButton.UseVisualStyleBackColor = true;
            this.RestartButton.Visible = false;
            this.RestartButton.Click += new System.EventHandler(this.RestartButton_Click);
            // 
            // allRightsReservedLabel
            // 
            this.allRightsReservedLabel.AutoSize = true;
            this.allRightsReservedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allRightsReservedLabel.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.allRightsReservedLabel.Location = new System.Drawing.Point(26, 13);
            this.allRightsReservedLabel.Name = "allRightsReservedLabel";
            this.allRightsReservedLabel.Size = new System.Drawing.Size(294, 15);
            this.allRightsReservedLabel.TabIndex = 4;
            this.allRightsReservedLabel.Text = "W-Integrate © Copyright 2018   |   All Rights Reserved";
            // 
            // headingPanel
            // 
            this.headingPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.headingPanel.Controls.Add(this.appNameLabel);
            this.headingPanel.Controls.Add(this.wAgentTopLogo);
            this.headingPanel.Location = new System.Drawing.Point(1, 0);
            this.headingPanel.Name = "headingPanel";
            this.headingPanel.Size = new System.Drawing.Size(575, 34);
            this.headingPanel.TabIndex = 7;
            // 
            // appNameLabel
            // 
            this.appNameLabel.AutoSize = true;
            this.appNameLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appNameLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.appNameLabel.Location = new System.Drawing.Point(56, 12);
            this.appNameLabel.Name = "appNameLabel";
            this.appNameLabel.Size = new System.Drawing.Size(104, 15);
            this.appNameLabel.TabIndex = 8;
            this.appNameLabel.Text = "W-Agent Uninstall";
            // 
            // wAgentTopLogo
            // 
            this.wAgentTopLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("wAgentTopLogo.BackgroundImage")));
            this.wAgentTopLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.wAgentTopLogo.Location = new System.Drawing.Point(31, 9);
            this.wAgentTopLogo.Name = "wAgentTopLogo";
            this.wAgentTopLogo.Size = new System.Drawing.Size(18, 18);
            this.wAgentTopLogo.TabIndex = 7;
            this.wAgentTopLogo.TabStop = false;
            // 
            // UninstallerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(574, 415);
            this.Controls.Add(this.headingPanel);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.footerPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "UninstallerForm";
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentLogoPicture)).EndInit();
            this.footerPanel.ResumeLayout(false);
            this.footerPanel.PerformLayout();
            this.headingPanel.ResumeLayout(false);
            this.headingPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentTopLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.PictureBox wAgentLogoPicture;
        private System.Windows.Forms.Button NextButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Label welcomeWizardLabel;
        private System.Windows.Forms.Label uninstallerDetailsLabel2;
        private System.Windows.Forms.Label uninstallerDetailsLabel1;
        private System.Windows.Forms.Button FinishButton;
        private System.Windows.Forms.ProgressBar UninstallationProgressBar;
        private System.ComponentModel.BackgroundWorker UninstallationBackgroundWorker;
        private System.Windows.Forms.Panel footerPanel;
        private System.Windows.Forms.Panel headingPanel;
        private System.Windows.Forms.PictureBox wAgentTopLogo;
        private System.Windows.Forms.Label appNameLabel;
        private System.Windows.Forms.Label uninstallingWAgentLabel;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Label waitMessageLabel;
        private System.Windows.Forms.Label allRightsReservedLabel;
        private System.Windows.Forms.Button RestartButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

