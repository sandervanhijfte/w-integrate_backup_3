CREATE TABLE `load_s_geocodes` (
  `ZenitAddressId` int NOT NULL,
  `Longitude` varchar(45) DEFAULT NULL,
  `Latitude` varchar(45) DEFAULT NULL,
  `FormattedAddress` varchar(145) DEFAULT NULL,
  PRIMARY KEY (`ZenitAddressId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1