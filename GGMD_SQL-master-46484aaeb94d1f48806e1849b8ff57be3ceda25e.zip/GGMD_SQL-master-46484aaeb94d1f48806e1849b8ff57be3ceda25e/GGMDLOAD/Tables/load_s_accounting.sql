CREATE TABLE `load_s_accounting` (
  `EntryId` bigint NOT NULL,
  `LedgerNumberDebit` varchar(45) DEFAULT NULL,
  `LedgerNumberCredit` varchar(10) DEFAULT NULL,
  `EntryDateTime` datetime DEFAULT NULL,
  `EntryType` varchar(245) DEFAULT NULL,
  `Amount` decimal(2,0) DEFAULT NULL,
  `RowId` bigint NOT NULL AUTO_INCREMENT,
  `SourceId` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`RowId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci