CREATE TABLE `load_s_gh_Route` (
  `RouteId` int NOT NULL AUTO_INCREMENT,
  `SolutionId` int NOT NULL,
  `job_id` varchar(45) NOT NULL,
  `vehicle_id` varchar(45) NOT NULL,
  `distance` int DEFAULT NULL,
  `transport_time` int DEFAULT NULL,
  `completion_time` int DEFAULT NULL,
  `waiting_time` int DEFAULT NULL,
  `serice_duration` int DEFAULT NULL,
  `preparation_time` int DEFAULT NULL,
  PRIMARY KEY (`job_id`,`vehicle_id`),
  UNIQUE KEY `RouteId` (`RouteId`),
  KEY `Route_Solution_idx` (`SolutionId`),
  CONSTRAINT `Route_Solution` FOREIGN KEY (`SolutionId`) REFERENCES `load_s_gh_Solution` (`SolutionId`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci