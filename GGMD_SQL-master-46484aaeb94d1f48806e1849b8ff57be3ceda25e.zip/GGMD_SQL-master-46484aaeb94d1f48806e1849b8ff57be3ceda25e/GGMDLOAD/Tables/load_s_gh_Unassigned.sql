CREATE TABLE `load_s_gh_Unassigned` (
  `UnassignedId` int NOT NULL AUTO_INCREMENT,
  `job_id` varchar(45) NOT NULL,
  `unassigned_service` varchar(45) DEFAULT NULL,
  `unassigned_reason_code` int DEFAULT NULL,
  `unassigned_reason` varchar(999) DEFAULT NULL,
  PRIMARY KEY (`job_id`,`UnassignedId`),
  UNIQUE KEY `UnassignedId` (`UnassignedId`),
  CONSTRAINT `Unassigned_Log` FOREIGN KEY (`job_id`) REFERENCES `load_s_gh_Log` (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci