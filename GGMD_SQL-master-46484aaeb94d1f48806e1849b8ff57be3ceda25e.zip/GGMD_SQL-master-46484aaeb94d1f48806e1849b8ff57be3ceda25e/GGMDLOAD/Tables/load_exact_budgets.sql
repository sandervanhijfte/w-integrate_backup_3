CREATE TABLE `load_exact_budgets` (
  `Year` varchar(45) DEFAULT NULL,
  `Month` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `CostCenterCode` varchar(45) DEFAULT NULL,
  `CostCenter` varchar(45) DEFAULT NULL,
  `Category1Code` varchar(45) DEFAULT NULL,
  `Category1` varchar(45) DEFAULT NULL,
  `Category2Code` varchar(45) DEFAULT NULL,
  `Category2` varchar(45) DEFAULT NULL,
  `Category3Code` varchar(45) DEFAULT NULL,
  `Category3` varchar(45) DEFAULT NULL,
  `Category4Code` varchar(45) DEFAULT NULL,
  `Category4` varchar(45) DEFAULT NULL,
  `Amount` varchar(45) DEFAULT NULL,
  `ROW_ID` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ROW_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3301 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci