CREATE TABLE `load_s_gh_Solution` (
  `SolutionId` int NOT NULL AUTO_INCREMENT,
  `job_id` varchar(45) NOT NULL,
  `transport_time` int DEFAULT NULL,
  `completion_time` int DEFAULT NULL,
  `max_operation_time` int DEFAULT NULL,
  `waiting_time` int DEFAULT NULL,
  `serice_duration` int DEFAULT NULL,
  `preparation_time` int DEFAULT NULL,
  `no_vehicles` int DEFAULT NULL,
  PRIMARY KEY (`job_id`,`SolutionId`),
  UNIQUE KEY `SolutionId` (`SolutionId`),
  CONSTRAINT `Solution_Log` FOREIGN KEY (`job_id`) REFERENCES `load_s_gh_Log` (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci