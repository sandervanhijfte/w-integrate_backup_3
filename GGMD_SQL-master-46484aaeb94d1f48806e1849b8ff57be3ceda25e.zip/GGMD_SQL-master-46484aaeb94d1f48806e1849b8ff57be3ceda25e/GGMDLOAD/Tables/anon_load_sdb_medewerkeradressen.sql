CREATE TABLE `anon_load_sdb_medewerkeradressen` (
  `medewerkerId` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Straatnaam` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `Postcode` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `Woonplaats` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `LandCode2Tekens` varchar(5) CHARACTER SET latin1 DEFAULT NULL,
  `LandCode3Tekens` varchar(5) CHARACTER SET latin1 DEFAULT NULL,
  `LandISOCode` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `LandOmschrijving` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `Huisnummer` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `ROW_ID` varchar(45) CHARACTER SET latin1 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci