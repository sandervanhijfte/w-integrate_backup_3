CREATE TABLE `load_s_gh_Log` (
  `LogId` int NOT NULL AUTO_INCREMENT,
  `ZenitEmployeeId` int NOT NULL,
  `job_id` varchar(45) NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  `waiting_time_in_queue` int DEFAULT NULL,
  `processing_time` int DEFAULT NULL,
  `is_error` tinyint(1) NOT NULL,
  `message` varchar(99) DEFAULT NULL,
  `message_details` varchar(999) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`job_id`),
  UNIQUE KEY `LogId` (`LogId`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci