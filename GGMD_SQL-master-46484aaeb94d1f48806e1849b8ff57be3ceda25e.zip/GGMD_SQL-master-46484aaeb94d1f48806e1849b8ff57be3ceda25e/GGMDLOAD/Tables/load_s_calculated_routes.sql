CREATE TABLE `load_s_calculated_routes` (
  `idA` varchar(45) NOT NULL,
  `idB` varchar(45) NOT NULL,
  `vehicle` varchar(45) NOT NULL,
  `distance` varchar(45) DEFAULT NULL,
  `time` bigint DEFAULT NULL,
  `RouteId` int DEFAULT NULL,
  `ExecutionTimeStamp` datetime DEFAULT NULL,
  PRIMARY KEY (`idA`,`idB`,`vehicle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci