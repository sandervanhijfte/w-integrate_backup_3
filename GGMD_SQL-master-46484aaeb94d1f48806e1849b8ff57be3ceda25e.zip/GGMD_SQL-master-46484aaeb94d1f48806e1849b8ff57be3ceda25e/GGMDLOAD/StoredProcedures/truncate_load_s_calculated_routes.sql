CREATE DEFINER=`root`@`localhost` PROCEDURE `truncate_load_s_calculated_routes`()
BEGIN
truncate load_s_calculated_routes;
END