CREATE DEFINER=`root`@`localhost` PROCEDURE `set_ROW_ID_load_jwcontracts`()
BEGIN



UPDATE GGMDLOAD.load_jwcontracts SET ROW_ID = CONCAT('ROW_ID_', ID);
END