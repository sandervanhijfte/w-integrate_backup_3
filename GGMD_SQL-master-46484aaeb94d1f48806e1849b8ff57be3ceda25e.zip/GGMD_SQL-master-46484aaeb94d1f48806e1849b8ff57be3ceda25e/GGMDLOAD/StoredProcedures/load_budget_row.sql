CREATE DEFINER=`root`@`localhost` PROCEDURE `load_budget_row`(
IN parYear varchar(45),
IN parMonth varchar(45),
IN parDate varchar(45),
IN parCostCenterCode varchar(45),
IN parCostCenter varchar(45),
IN parCategory1Code varchar(45),
IN parCategory1 varchar(45),
IN parCategory2Code varchar(45),
IN parCategory2 varchar(45),
IN parCategory3Code varchar(45),
IN parCategory3 varchar(45),
IN parCategory4Code varchar(45),
IN parCategory4 varchar(45),
IN parAmount varchar(45)
)
BEGIN
/*
  Author: Sander van Hijfte
  Last update date: 23-05-2020
  Version: 1.0.0
  The ROW_ID is not in this procedure because the ROW_ID can only be unique with an auto increment.
*/

INSERT INTO `GGMDLOAD`.`load_exact_budgets` 
(`Year`, 
`Month`, 
`Date`, 
`CostCenterCode`, 
`CostCenter`, 
`Category1Code`, 
`Category1`, 
`Category2Code`, 
`Category2`, 
`Category3Code`, 
`Category3`, 
`Category4Code`, 
`Category4`, 
`Amount`) 
VALUES(
parYear,
parMonth,
parDate,
parCostCenterCode,
parCostCenter,
parCategory1Code,
parCategory1,
parCategory2Code,
parCategory2,
parCategory3Code,
parCategory3,
parCategory4Code,
parCategory4,
parAmount);

END