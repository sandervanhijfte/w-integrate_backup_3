CREATE DEFINER=`root`@`localhost` PROCEDURE `load_calculated_routes`(
IN parIDA VARCHAR(45),
IN parIDB VARCHAR(45),
IN parVEHICLE VARCHAR(45),
IN parDISTANCE VARCHAR(45),
IN parTIME VARCHAR(45),
IN parROUTEID INT
)
BEGIN
/*
  Author: Renee van Hijfte, Sander van Hijfte
  Last update date: 26-03-2020
  Version: 1.0.1
*/

    INSERT into load_s_calculated_routes
    (
    idA,
	idB,
	vehicle,
    distance,
    time,
    RouteId,
    ExecutionTimeStamp
    )
    values
    (
	parIDA,
	parIDB,
	parVEHICLE,
	parDISTANCE,
	parTIME,
    parROUTEID,
    now()
	);
END