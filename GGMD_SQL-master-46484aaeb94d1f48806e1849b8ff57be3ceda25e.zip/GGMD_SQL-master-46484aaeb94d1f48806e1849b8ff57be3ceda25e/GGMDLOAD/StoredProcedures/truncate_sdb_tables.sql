CREATE DEFINER=`root`@`localhost` PROCEDURE `truncate_sdb_tables`()
BEGIN




TRUNCATE load_sdb_medewerkers;
TRUNCATE load_sdb_dienstverbanden;
TRUNCATE load_sdb_dienstverbandperiodes;
TRUNCATE load_sdb_medewerkeradressen;
 
END