CREATE DEFINER=`root`@`localhost` PROCEDURE `set_ROW_ID_S`()
BEGIN
/*
author: Sander van Hijfte
last updated: 11-06-2020
This procedure sets the ROW_ID for the load_sdb tables after they have been refreshed. 
The procedure is called by the orchestrator.
*/

/*This is the error block that will call the ErrorLogging module when an error occurs*/
DECLARE continue handler for sqlexception
BEGIN
  GET DIAGNOSTICS CONDITION 1  @sqlstate = RETURNED_SQLSTATE, 
  @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
  call ErrorLoggingV1_0_0(@errno,@text,'test');
END;

UPDATE GGMDLOAD.load_sdb_medewerkers SET ROW_ID = CONCAT('ROW_ID_', Id);
UPDATE GGMDLOAD.load_sdb_medewerkeradressen SET ROW_ID = IF(postcode IS NOT NULL, CONCAT('ROW_ID_', medewerkerId, '_', Postcode), CONCAT('ROW_ID_', medewerkerId, '_'));
UPDATE GGMDLOAD.load_sdb_dienstverbanden SET ROW_ID = CONCAT('ROW_ID_', Id);
UPDATE GGMDLOAD.load_sdb_dienstverbandperiodes SET ROW_ID = CONCAT('ROW_ID_', DienstverbandId, '_', PeriodeBeginDatum);

END