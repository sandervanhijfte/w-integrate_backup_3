CREATE DEFINER=`root`@`localhost` PROCEDURE `truncate_load_s_geocodes`()
BEGIN
TRUNCATE load_s_geocodes;
END