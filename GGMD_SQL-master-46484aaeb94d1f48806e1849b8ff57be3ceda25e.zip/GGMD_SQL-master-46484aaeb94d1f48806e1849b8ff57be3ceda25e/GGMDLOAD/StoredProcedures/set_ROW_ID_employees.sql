CREATE DEFINER=`root`@`localhost` PROCEDURE `set_ROW_ID_load_contracts`()
BEGIN



UPDATE GGMDLOAD.load_contracts SET ROW_ID = CONCAT('ROW_ID_', ID);
END