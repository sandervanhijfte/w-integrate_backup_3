CREATE DEFINER=`root`@`localhost` PROCEDURE `Load_Geocodes`(
IN parZENITADDRESSID INT(10),
IN parLONGITUDE VARCHAR(45),
IN parLATITUDE VARCHAR(45)
)
BEGIN


    INSERT into load_s_geocodes
    (
    ZenitAddressId,
	Longitude,
	Latitude
    )
    values
    (
	parZENITADDRESSID,
	parLONGITUDE,
	parLATITUDE
	);
END