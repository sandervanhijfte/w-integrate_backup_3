CREATE DEFINER=`root`@`localhost` PROCEDURE `ErrorLoggingV1_0_0`(ErrorNumber integer,ErrorMessage varchar(100),Module varchar(100))
BEGIN
/*
Author:Sander van Hijfte
Last update date: 18-11-2017
Version: 0.0.3 
*/

  insert into error_log values
  (
    concat(current_date,' ',current_time,' ',ErrorNumber,' ',ErrorMessage,' ',Module)
  );

END