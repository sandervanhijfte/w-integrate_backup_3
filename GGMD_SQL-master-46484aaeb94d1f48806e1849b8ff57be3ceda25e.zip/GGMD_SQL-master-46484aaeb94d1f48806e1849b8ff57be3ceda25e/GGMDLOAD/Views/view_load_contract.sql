CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `GGMDLOAD`.`view_load_contract` AS
    SELECT 
        `GGMDLOAD`.`load_contracts`.`ID` AS `id`,
        `GGMDLOAD`.`load_contracts`.`Einddatum` AS `Einddatum`
    FROM
        `GGMDLOAD`.`load_contracts` 
    UNION SELECT 
        `GGMDLOAD`.`load_jwcontracts`.`ID` AS `id`,
        `GGMDLOAD`.`load_jwcontracts`.`Einddatum` AS `Einddatum`
    FROM
        `GGMDLOAD`.`load_jwcontracts`