CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `GGMDKPI`.`base_view_for_ManagementV1_0_0` AS
    SELECT 
        'Author: Sander van Hijfte Last Update Date:19-06-2020' AS `Version`,
        'Summation of view_delivery_ForKPI_UpToLastWeekV1_0_0_n based on EmployeeId. The PerformanceIndicator need to get a proper name but that needs to be fixed later!' AS `Explanation`,
        `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeId` AS `EmployeeId`,
        `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeFirstName` AS `EmployeeFirstName`,
        `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeInFix` AS `EmployeeInFix`,
        `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`Employeelastname` AS `EmployeeLastName`,
        `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeDesignation` AS `EmployeeDesignation`,
        `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeDepartment` AS `EmployeeDepartment`,
        IF((`dm_EmployeeContractPeriod`.`DesignationTarget` IS NULL),
            0,
            `dm_EmployeeContractPeriod`.`DesignationTarget`) AS `EmployeePersonalPerformanceIndicator`,
        SUM(`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`BillableHoursPerWeek`) AS `YearToDateNumberOfHoursBillable`,
        `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeTotalNumberOfHoursVacation` AS `YearToDateNumberOfHoursVacation`,
        SUM(`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`TotalNumberOfHoursWorkedPerWeek`) AS `YearToDateNumberOfHoursWorked`,
        IF((`dm_EmployeeContractPeriod`.`PersonalTarget` IS NULL),
            0,
            `dm_EmployeeContractPeriod`.`PersonalTarget`) AS `EmployeePersonalNorm`,
        SUM(`view_delivery_ForKPI_UpToLastWeekV1_0_0`.`DifferenceBetweenBillableAndWeekNorm`) AS `YearToDateDifferenceBetweenBillableAndWeekNorm`
    FROM
        (`GGMDKPI`.`view_delivery_ForKPI_UpToLastWeekV1_0_0`
        LEFT JOIN `dm_EmployeeContractPeriod` ON ((CONVERT( `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeId` USING UTF8MB4) = `dm_EmployeeContractPeriod`.`SourceEmployeeContractId`)))
    WHERE
        ((MONTH(`dm_EmployeeContractPeriod`.`StartDate`) = MONTH(CURDATE()))
            AND (YEAR(`dm_EmployeeContractPeriod`.`StartDate`) = YEAR(CURDATE())))
    GROUP BY `view_delivery_ForKPI_UpToLastWeekV1_0_0`.`EmployeeId`