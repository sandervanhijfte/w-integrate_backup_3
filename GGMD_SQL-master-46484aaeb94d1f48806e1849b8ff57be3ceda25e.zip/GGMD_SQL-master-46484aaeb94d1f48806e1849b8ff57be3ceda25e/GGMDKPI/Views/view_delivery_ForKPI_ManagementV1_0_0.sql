CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `GGMDKPI`.`view_delivery_ForKPI_ManagementV1_0_0` AS
    SELECT 
        'Author: Sander van Hijfte Last Update Date:19-06-2020' AS `Version`,
        'The source of view_delivery_ForKPI_Management is base_view_for_Management, it adds the EmployeeDifferenceBetweenCorrectedNormAndBillable of the current week which it retrieves from view_delivery_ForKPI' AS `Explanation`,
        `base_view_for_ManagementV1_0_0`.`EmployeeId` AS `EmployeeId`,
        `base_view_for_ManagementV1_0_0`.`EmployeeFirstName` AS `EmployeeFirstName`,
        `base_view_for_ManagementV1_0_0`.`EmployeeInFix` AS `EmployeeInFix`,
        `base_view_for_ManagementV1_0_0`.`EmployeeLastName` AS `EmployeeLastName`,
        `base_view_for_ManagementV1_0_0`.`EmployeeDesignation` AS `EmployeeDesignation`,
        `base_view_for_ManagementV1_0_0`.`EmployeeDepartment` AS `EmployeeDepartment`,
        `base_view_for_ManagementV1_0_0`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,
        `base_view_for_ManagementV1_0_0`.`EmployeePersonalNorm` AS `EmployeePersonalNorm`,
        `base_view_for_ManagementV1_0_0`.`YearToDateNumberOfHoursBillable` AS `YearToDateNumberOfHoursBillable`,
        `base_view_for_ManagementV1_0_0`.`YearToDateNumberOfHoursVacation` AS `YearToDateNumberOfHoursVacation`,
        `base_view_for_ManagementV1_0_0`.`YearToDateNumberOfHoursWorked` AS `YearToDateNumberOfHoursWorked`,
        `base_view_for_ManagementV1_0_0`.`YearToDateDifferenceBetweenBillableAndWeekNorm` AS `YearToDateDifferenceBetweenBillableAndWeekNorm`,
        WEEK(CURDATE(), 3) AS `WeekNumber`,
        IF((`view_delivery_ForKPIV1_0_1`.`DifferenceBetweenBillableAndWeekNorm` IS NULL),
            'GEEN',
            `view_delivery_ForKPIV1_0_1`.`DifferenceBetweenBillableAndWeekNorm`) AS `DifferenceBetweenBillableAndWeekNorm`
    FROM
        (`GGMDKPI`.`base_view_for_ManagementV1_0_0`
        LEFT JOIN `GGMDKPI`.`view_delivery_ForKPIV1_0_1` ON (((`base_view_for_ManagementV1_0_0`.`EmployeeId` = `view_delivery_ForKPIV1_0_1`.`EmployeeId`)
            AND (`view_delivery_ForKPIV1_0_1`.`WeekNumber` = (WEEK(CURDATE(), 3) - 1)))))