CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `GGMDKPI`.`view_delivery_ForKPIV1_0_1` AS
    SELECT 
        'Author: Sander van Hijfte Last Update Date:17-06-2020' AS `Version`,
        'Summation of the data from delivery based on EmployeeId and WeekNumber complemented with the Performanceindicator from PerformanceIndicator' AS `Explanation`,
        'Removed GGMDKPI' AS `Update 09-06-2020`,
        `ang_delivery`.`EmployeeId` AS `EmployeeId`,
        `ang_delivery`.`EmployeeFirstName` AS `EmployeeFirstName`,
        `ang_delivery`.`EmployeeInfix` AS `EmployeeInfix`,
        `ang_delivery`.`EmployeeLastName` AS `EmployeeLastName`,
        `ang_delivery`.`EmployeeDesignation` AS `EmployeeDesignation`,
        `ang_delivery`.`EmployeeDepartment` AS `EmployeeDepartment`,
        `cf_EmployeeBillableHoursTarget`.`Target` AS `PerformanceIndicator`,
        `ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,
        `ang_delivery`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalNorm`,
        `ang_delivery`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,
        WEEK(`ang_delivery`.`DeliveryDate`, 3) AS `WeekNumber`,
        MONTH(`ang_delivery`.`DeliveryDate`) AS `MonthNumber`,
        CONCAT(' ',
                MONTHNAME(`ang_delivery`.`DeliveryDate`)) AS `Data`,
        YEAR(`ang_delivery`.`DeliveryDate`) AS `year`,
        ROUND((SUM(`ang_delivery`.`BillableTime`) / 3600),
                2) AS `BillableHoursPerWeek`,
        ROUND((SUM(`ang_delivery`.`EmployeeNumberOfHoursWorked`) / 3600),
                2) AS `TotalNumberOfHoursWorkedPerWeek`,
        ROUND((SUM(`ang_delivery`.`EmployeeNumberOfHoursVacation`) / 3600),
                2) AS `TotalNumberOfHoursVacationPerWeek`,
        `ang_delivery`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,
        ROUND((((((`ang_delivery`.`EmployeeNumberOfHoursPerWeek` * 3600) - SUM(`ang_delivery`.`EmployeeNumberOfHoursVacation`)) / (`ang_delivery`.`EmployeeNumberOfHoursPerWeek` * 3600)) * `ang_delivery`.`EmployeePersonalPerformanceIndicator`) / (52 - (52 * 0.1340))),
                2) AS `EmployeeWeekNorm`,
        ROUND(((SUM(`ang_delivery`.`BillableTime`) / 3600) - (((((`ang_delivery`.`EmployeeNumberOfHoursPerWeek` * 3600) - SUM(`ang_delivery`.`EmployeeNumberOfHoursVacation`)) / (`ang_delivery`.`EmployeeNumberOfHoursPerWeek` * 3600)) * `ang_delivery`.`EmployeePersonalPerformanceIndicator`) / (52 - (52 * 0.1340)))),
                2) AS `DifferenceBetweenBillableAndWeekNorm`,
        `dm_Employee`.`NumberOfHoursPerWeek` AS `EmployeeCurrentNumberOfHoursPerWeek`
    FROM
        ((`ang_delivery`
        JOIN `cf_EmployeeBillableHoursTarget`)
        JOIN `dm_Employee`)
    WHERE
        ((`ang_delivery`.`EmployeeDepartment` = `cf_EmployeeBillableHoursTarget`.`Department`)
            AND (CONVERT( `ang_delivery`.`EmployeeId` USING UTF8MB4) = `dm_Employee`.`SourceEmployeeContractId`)
            AND (`ang_delivery`.`EmployeeDesignation` = `cf_EmployeeBillableHoursTarget`.`Designation`)
            AND ((`ang_delivery`.`IsDeliveryDiscarded` = 'false')
            OR (`ang_delivery`.`ReasonForDiscardingDelivery` IN ('NotOnePossibleContract' , 'NoValidDeliveryPeriod',
            'NoPossibleContractId',
            'NotWMO'))))
    GROUP BY `WeekNumber` , `ang_delivery`.`EmployeeId`