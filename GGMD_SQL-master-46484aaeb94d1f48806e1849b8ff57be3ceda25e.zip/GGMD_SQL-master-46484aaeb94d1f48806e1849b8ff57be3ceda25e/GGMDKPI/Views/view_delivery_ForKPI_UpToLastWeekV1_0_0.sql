CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `GGMDKPI`.`view_delivery_ForKPI_UpToLastWeekV1_0_0` AS
    SELECT 
        `view_delivery_ForKPIV1_0_1`.`Version` AS `Version`,
        `view_delivery_ForKPIV1_0_1`.`Explanation` AS `Explanation`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeId` AS `EmployeeId`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeFirstName` AS `EmployeeFirstName`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeInfix` AS `EmployeeInFix`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeLastName` AS `Employeelastname`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeDesignation` AS `EmployeeDesignation`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeDepartment` AS `EmployeeDepartment`,
        `view_delivery_ForKPIV1_0_1`.`EmployeePersonalPerformanceIndicator` AS `EmployeePersonalPerformanceIndicator`,
        `view_delivery_ForKPIV1_0_1`.`EmployeePersonalNorm` AS `EmployeePersonalNorm`,
        `view_delivery_ForKPIV1_0_1`.`WeekNumber` AS `WeekNumber`,
        `view_delivery_ForKPIV1_0_1`.`MonthNumber` AS `MonthNumber`,
        `view_delivery_ForKPIV1_0_1`.`Data` AS `Data`,
        `view_delivery_ForKPIV1_0_1`.`year` AS `year`,
        `view_delivery_ForKPIV1_0_1`.`BillableHoursPerWeek` AS `BillableHoursPerWeek`,
        `view_delivery_ForKPIV1_0_1`.`TotalNumberOfHoursWorkedPerWeek` AS `TotalNumberOfHoursWorkedPerWeek`,
        `view_delivery_ForKPIV1_0_1`.`TotalNumberOfHoursVacationPerWeek` AS `TotalNumberOfHoursVacationPerWeek`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeNumberOfHoursPerWeek` AS `EmployeeNumberOfHoursPerWeek`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeTotalNumberOfHoursVacation` AS `EmployeeTotalNumberOfHoursVacation`,
        `view_delivery_ForKPIV1_0_1`.`EmployeeWeekNorm` AS `EmployeeWeekNorm`,
        `view_delivery_ForKPIV1_0_1`.`DifferenceBetweenBillableAndWeekNorm` AS `DifferenceBetweenBillableAndWeekNorm`,
        (WEEK(CURDATE(), 3) - 1) AS `LastWeek`
    FROM
        `GGMDKPI`.`view_delivery_ForKPIV1_0_1`
    WHERE
        (`view_delivery_ForKPIV1_0_1`.`WeekNumber` < WEEK(CURDATE(), 3))