﻿/*
 * 	Author: Maira Tul Islam
 * 	Usage: This class is to handle the controls on InstallationWizard
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace TrialWAgentInstaller
{
    public partial class InstallerWizard : Form
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private string DEFAULT_INSTALLATION_PATH = "C:/w-agent_demo_default";
        private string LOGSTASH_SOURCE_DIR = "\\assemblies\\logstash-6.3.2.zip";
        private string LOGSTASH_TARGET_DIR = "\\w-agent_home\\w-agent";
        private int INSTALLATION_PATH_MAX_LENGTH = 100;
        private string theInstallationPath;
        private WAgentInstallationHelper theInstallationHelper;
        private WAgentServiceHandler theWAgentServiceHandler;
        private BackgroundWorker theServiceStartupBackgroundWorker;
        private BackgroundWorker theInstallationProgressBackgroundWorker;
        private bool installAsService;

        /***************************************************************
							        METHODS
	    ****************************************************************/
        /*
         * @Usage Default Constructor
         * 
         */
        public InstallerWizard()
        {
            InitializeComponent();

            installAsService = false;
            theInstallationPath = DEFAULT_INSTALLATION_PATH;
            theInstallationHelper = new WAgentInstallationHelper();
            theWAgentServiceHandler = new WAgentServiceHandler(theInstallationHelper.getCurrentDirectory(), theInstallationHelper.getServiceName());

            //process handlers
            setInstallationProcessHandler();
            setServiceStartUpHandler();

            //load the text in license agreement
            setLicenseAgreement();
        }

        /*
         * Loads the text from resources in text box
         * 
         */
        private void setLicenseAgreement()
        {
            var myAssembly = Assembly.GetExecutingAssembly();
            var myResourceName = "TrialWAgentInstaller.EndUserLicenseAgreementWAlert.txt";

            Stream myStream = myAssembly.GetManifestResourceStream(myResourceName);
            StreamReader myReader = new StreamReader(myStream);

            termConditionsTextBox.Text = myReader.ReadToEnd();
        }

        /*
         * @Usage To set service startup process handler
         * 
         */
        private void setServiceStartUpHandler()
        {
            //service start up progress handling
            theServiceStartupBackgroundWorker = new BackgroundWorker();
            theServiceStartupBackgroundWorker.WorkerSupportsCancellation = true;
            theServiceStartupBackgroundWorker.WorkerReportsProgress = true;
            theServiceStartupBackgroundWorker.DoWork += new DoWorkEventHandler(serviceStartupBackgroundWorker_DoWork);
            theServiceStartupBackgroundWorker.ProgressChanged += new ProgressChangedEventHandler(serviceStartupBackgroundWorker_ProgressChanged);
            theServiceStartupBackgroundWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(serviceStartupBackgroundWorker_RunWorkerCompleted);
        }

        /*
         * @Usage To set installation process handler
         * 
         */
        private void setInstallationProcessHandler()
        {
            //installation progress handling
            theInstallationProgressBackgroundWorker = new BackgroundWorker();
            theInstallationProgressBackgroundWorker.WorkerSupportsCancellation = true;
            theInstallationProgressBackgroundWorker.WorkerReportsProgress = true;
            theInstallationProgressBackgroundWorker.DoWork += new DoWorkEventHandler(installationProgressBackgroundWorker_DoWork);
            theInstallationProgressBackgroundWorker.ProgressChanged += new ProgressChangedEventHandler(installationProgressBackgroundWorker_ProgressChanged);
            theInstallationProgressBackgroundWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(installationProgressBackgroundWorker_RunWorkerCompleted);
        }

        /*
         * @Usage To handle page selection in installaer wizard
         * 
         */
        private void installaterWizardControl_SelectedPageChanged(object sender, EventArgs e)
        {
            if(installerWizardControl.SelectedPage == installationInProgressPage)
            {
                theInstallationProgressBackgroundWorker.RunWorkerAsync();
            }

            if (installerWizardControl.SelectedPage == serviceStartInProgressPage)
            {
                theServiceStartupBackgroundWorker.RunWorkerAsync();
            }

            if(installerWizardControl.SelectedPage == installationFolderPage)
            {
                checkIfWAgentExists();
            }
        }

        /*
         * @Usage To handle text change in username text box
         * 
         */
        private void usernameTextBox_TextChanged(object sender, EventArgs e)
        {
            if (usernameTextBox.Text != String.Empty)
            {
                configPage.AllowNext = true;
            }
            else
            {
                configPage.AllowNext = false;
            }
        } 

        /*
         * @Usage To handle check change on accept conditions check box
         * 
         */
        private void acceptConditionsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (acceptConditionsCheckBox.Checked)
            {
                termsConditionPage.AllowNext = true;
            }
            else
            {
                termsConditionPage.AllowNext = false;
            }
        }

        /*
         * @Usage To handle installation page commit
         * 
         */
        private void installationPage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            installationAsServiceConfirmationPage.AllowBack = false;
            installationInProgressPage.AllowBack = false;
            installationFolderPage.AllowBack = false;
            installationPage.AllowBack = false;
            serviceStartInProgressPage.AllowBack = false;
            servicePage.AllowBack = false;
            setupCompletePage.AllowBack = false;

            setNextPage();
        }

        private void setNextPage()
        {
            if (!theInstallationHelper.checkAdminPermissions())
            {
                installationYesRadioButton.Enabled = false;
                insufficientPermissionsTextBox.Visible = true;
                installationYesRadioButton.Checked = false;
                installationNoRadioButton.Checked = true;
            }
        }

        /*
         * @Usage To handle click on installation path button 
         * 
         */
        private void chooseInstallationPathButton_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                installationPathTextBox.Text = folderBrowserDialog.SelectedPath;
            }
        }

        /*
         * @Usage To handle change on default path radio button 
         * 
         */
        private void defaultPathRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            handleRadioButtons();
        }

        /*
         * @Usage To handle change on custom installation path radio button 
         * 
         */
        private void customInstallationPathRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            handleRadioButtons();
        }

        /*
         * @Usage To handle change on radio buttons on installation path page 
         * 
         */
        private void handleRadioButtons()
        {
            if(defaultPathRadioButton.Checked)
            {
                theInstallationPath = defaultPathTextBox.Text.Replace("/", "\\"); ;
                installationPathTextBox.Enabled = false;
                chooseInstallationPathButton.Enabled = false;
                installationFolderPage.AllowNext = true;
                checkIfWAgentExists();
            }
            else
            {
                theInstallationPath = installationPathTextBox.Text.Replace("/", "\\"); ;
                installationPathTextBox.Enabled = true;
                chooseInstallationPathButton.Enabled = true;
                checkIfinstallationPathValid();
            }
        }

        /*
         * @Usage To check if w-agent already installed
         * 
         */
         private void checkIfWAgentExists()
        {
            if (Directory.Exists(theInstallationPath + "\\w-agent_home"))
            {
                if(!theInstallationHelper.checkAdminPermissions() && theWAgentServiceHandler.serviceExists())
                {
                    reinstallationTextBox.Text = "W-Agent is already installed in the selected directory, you do not have admin rights to overwrite it, Please use a different directory to continue";
                    installationFolderPage.AllowNext = false;
                }
                else
                {
                    reinstallationTextBox.Text = "W-Agent is already installed in the selected directory, If you choose to continue, the current installation will be overwritten.";
                    installationFolderPage.AllowNext = true;
                }
                reinstallationTextBox.Visible = true;

            }
            else
            {
                reinstallationTextBox.Visible = false;
                installationFolderPage.AllowNext = true;
            }
        }

        /*
         * @Usage To check if selected installation path is valid 
         * 
         */
        private void checkIfinstallationPathValid()
        {
            if (installationPathTextBox.Text != String.Empty && Directory.Exists(installationPathTextBox.Text))
            {
                if (installationPathTextBox.Text.Length > INSTALLATION_PATH_MAX_LENGTH)
                {
                    invalidPathLabel.Visible = true;
                    installationFolderPage.AllowNext = false;
                }
                else
                {
                    invalidPathLabel.Visible = false;
                    reinstallationTextBox.Visible = false;
                    installationFolderPage.AllowNext = true;
                    checkIfWAgentExists();
                }
            }
            else
            {
                installationFolderPage.AllowNext = false;
                reinstallationTextBox.Visible = false;
            }
        }

        /*
         * @Usage To handle installtion folder page commit
         * 
         */
        private void installationFolderPage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            selectedUsernameTextBox.Text = usernameTextBox.Text;
            showInstallationPathTextBox.Text = theInstallationPath;
        }

        /*
         * @Usage To handle service page commit
         * 
         */
        private void servicePage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            if(noRadioButton.Checked)
            {
                setupCompletionDetailsRichTextBox.Text = "W-Agent has been successfully installed. You chose not to start W-Agent. Now you can start the w-agent manually. For further instructions, read the installation guide. Click the Finish to exit the Setup Wizard.";
                servicePage.NextPage = setupCompletePage;
            }
        }

        /*
         * @Usage To handle work on installation progress background worker 
         * 
         */
        private void installationProgressBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            if(installAsService && theInstallationHelper.checkAdminPermissions())
            {
                installWAgentAsService();
            }
            else
            {
                installAsService = false;
                installWAgentAsApplication();
            }
        }

        private void installWAgentAsService()
        {
            try
            {
                theInstallationHelper.createWeAgentFolderAndCopyFiles(theInstallationPath);
                theInstallationProgressBackgroundWorker.ReportProgress(20);
                theInstallationHelper.extractZipFile(theInstallationHelper.getCurrentDirectory() + LOGSTASH_SOURCE_DIR, theInstallationPath + LOGSTASH_TARGET_DIR);
                theInstallationProgressBackgroundWorker.ReportProgress(35);
                theInstallationHelper.copyFilesInWAgentLogstash(theInstallationPath);
                theInstallationProgressBackgroundWorker.ReportProgress(50);
                theInstallationHelper.replaceVariableInConf(usernameTextBox.Text, theInstallationPath);
                theInstallationProgressBackgroundWorker.ReportProgress(60);
                theWAgentServiceHandler.replaceVariablesInServiceInstaller(theInstallationPath);
                theInstallationProgressBackgroundWorker.ReportProgress(70);
                theInstallationHelper.installLogstashAsService();
                Thread.Sleep(300);
                theInstallationProgressBackgroundWorker.ReportProgress(100);
                theWAgentServiceHandler.removeServiceInstallerTmpFile();
            }
            catch (Exception e)
            {
                Application.Run(new ErrorBox());
            }
        }

        private void installWAgentAsApplication()
        {
            try
            {
                theInstallationHelper.createWeAgentFolderAndCopyFiles(theInstallationPath);
                theInstallationProgressBackgroundWorker.ReportProgress(20);
                theInstallationHelper.extractZipFile(theInstallationHelper.getCurrentDirectory() + LOGSTASH_SOURCE_DIR, theInstallationPath + LOGSTASH_TARGET_DIR);
                theInstallationProgressBackgroundWorker.ReportProgress(35);
                theInstallationHelper.copyFilesInWAgentLogstash(theInstallationPath);
                theInstallationProgressBackgroundWorker.ReportProgress(50);
                theInstallationHelper.replaceVariableInConf(usernameTextBox.Text, theInstallationPath);
                theInstallationProgressBackgroundWorker.ReportProgress(60);
                Thread.Sleep(200);
                theInstallationProgressBackgroundWorker.ReportProgress(100);
            }
            catch (Exception e)
            {
                Application.Run(new ErrorBox());
            }
        }

        /*
         * @Usage To handle progress change on installation progress background worker 
         * 
         */
        void installationProgressBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            installationProgressBar.Value = e.ProgressPercentage;
        }

        /*
         * @Usage To handle task completion on installation progress background worker 
         * 
         */
        private void installationProgressBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            installationInProgressPage.AllowNext = true;
        }

        /*
         * @Usage To handle work on service start up background worker 
         * 
         */
        private void serviceStartupBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            serviceDetailsTextBox.Text = "Starting Service... ";
            theServiceStartupBackgroundWorker.ReportProgress(50);
            theWAgentServiceHandler.startService(theInstallationPath);
            waitUntilAgentStarts();

            theServiceStartupBackgroundWorker.ReportProgress(100);
        }

        /*
         * @Usage To make user wait until the service has been started 
         * 
         */
        private void waitUntilAgentStarts()
        {
            bool checkLogFile = true;

            while (checkLogFile == true)
            {
                string text = theInstallationHelper.getWAgentLogFile(theInstallationPath);
                updateServiceDetailsStatus("Starting Service... " + "\n" + text);
                if (text.Contains("Successfully started Logstash API endpoint"))
                {
                    checkLogFile = false;
                    updateServiceDetailsStatus("Starting Service... " + "\n" + text + "\n\n" + "Succesfully Started W-Agent as a Service");
                }

                Thread.Sleep(200);
            }
        }

        /*
         * @Usage To update the service deatils status
         * 
         */
        private void updateServiceDetailsStatus(string textMessage)
        {
            if (serviceDetailsTextBox.InvokeRequired)
            {
                serviceDetailsTextBox.Invoke(new MethodInvoker(() => updateServiceDetailsStatus(textMessage)));
                return;
            }

            serviceDetailsTextBox.Text = textMessage;
        }

        /*
         * @Usage To handle progress change on service start up background worker 
         * 
         */
        private void serviceStartupBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            serviceStartUpProgressBar.Value = e.ProgressPercentage;
        }

        /*
         * @Usage To handle task completion on service start up background worker 
         * 
         */
        private void serviceStartupBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            serviceStartInProgressPage.AllowNext = true;
        }

        /*
         * @Usage To handle text change on installation path text box 
         * 
         */
        private void installationPathTextBox_TextChanged(object sender, EventArgs e)
        {
            handleRadioButtons();
        }

        /*
         * @Usage To handle click on service details button 
         * 
         */
        private void serviceDetailsButton_Click(object sender, EventArgs e)
        {
            if(!serviceDetailsTextBox.Visible)
            {
                serviceDetailsTextBox.Visible = true;
            }
            else
            {
                serviceDetailsTextBox.Visible = false;
            }
        }

        /*
        * @Usage To handle installation as service page commit 
        * 
        */
        private void installationAsServiceConfirmationPage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            if (installationYesRadioButton.Checked)
            {
                installAsService = true;
            }
            else
            {
                installAsService = false;
            }
        }

        /**
         * @Usage to handle installation in progress page commit
         * 
         */
        private void installationInProgressPage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            if(!installAsService)
            {
                setupCompletionDetailsRichTextBox.Text = "W-Agent has been successfully installed as an application. Click the Finish button to exit the Setup Wizard and start the application.";
                installationInProgressPage.NextPage = setupCompletePage;
            }
        }

        /**
         * @Usage to handle setup complete page commit
         * 
         */
        private void setupCompletePage_Commit(object sender, AeroWizard.WizardPageConfirmEventArgs e)
        {
            if(!installAsService)
            {
                Process myWagentApp = new Process();
                
                myWagentApp.StartInfo.FileName = theInstallationPath + "\\w-agent_home\\WAgentService.exe";
                myWagentApp.Start();
            }
        }
    }
}
