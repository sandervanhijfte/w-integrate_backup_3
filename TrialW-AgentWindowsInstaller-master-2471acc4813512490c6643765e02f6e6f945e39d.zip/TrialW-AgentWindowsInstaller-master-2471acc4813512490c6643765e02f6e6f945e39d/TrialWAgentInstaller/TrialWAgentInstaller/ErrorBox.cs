﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: This class is to handle the controls on ErrorBox page
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */
using System;
using System.Windows.Forms;

namespace TrialWAgentInstaller
{
    public partial class ErrorBox : Form
    {
        /*
         * Default Constructor
         */
        public ErrorBox()
        {
            InitializeComponent();
        }

        /*
         * Handler to control button click
         */
        private void okButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /*
         * Handler to handle closing of form
         */
        private void ErrorBox_Closing(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
