﻿/*
 * 	Author: Maira Tul Islam
 * 	Usage: This is the class that provides help methods to perform steps of installation for w-agent
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

/*.NET Packages*/
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Windows.Forms;
using System.Text;
using System.Security.Principal;

namespace TrialWAgentInstaller
{
    class WAgentInstallationHelper
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private string LOG_FILE_PARAMETER = "LOG_FILE_PATH";
        private string CONF_FILE = "w-alert_shipper.conf";
        private string DEFAULT_SERVICE_NAME = "W_Agent_TRIAL_Service";
        private string USERNAME_PARAMETER = "USERNAME";
        private string SAMPLE_LOG_FILE_LOCATION = "\\w-agent_home\\samples\\sample.log";
        private string LOG_FILE_LOCATION = "\\w-agent_home\\w-agent\\logs\\logstash-plain.log";
        private string WAGENT_HOME_FOLDER = "\\w-agent_home";
        private string WAGENT_BIN_LOCATION = "\\w-agent_home\\w-agent\\bin\\";
        private string TMP_SERVICE_INSTALLER = "tmp_w-agent_service_installer.bat";

        private string theServiceName;
        private WAgentServiceHandler theServiceHandler;
        private WAgentPackageHandler thePackageHandler;

        /***************************************************************
							        METHODS
	    ****************************************************************/
        /*
         * @Usage Default Constructor
         * 
         */
        public WAgentInstallationHelper()
        {
            theServiceName = DEFAULT_SERVICE_NAME;
            theServiceHandler = new WAgentServiceHandler(getCurrentDirectory(), theServiceName);
            thePackageHandler = new WAgentPackageHandler(getCurrentDirectory());
        }

        /*
         * @Usage To get the w-agent service name
         * 
         */
        public string getServiceName()
        {
            return theServiceName;
        }

       /*
        * @Usage To get the current directory in which the installer is placed
        * 
        */
        public string getCurrentDirectory()
        {
            string myCurrentDirectory = Path.GetDirectoryName(Application.ExecutablePath);

            return myCurrentDirectory.Replace("/","\\");
        }

        /*
        * @Usage To check if java is installed on the system
        * 
        */
        public bool checkIfJavaInstalled()
        {
            try
            {
                ProcessStartInfo myJavaCheckProcessStartInfo = new ProcessStartInfo();
                myJavaCheckProcessStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                myJavaCheckProcessStartInfo.CreateNoWindow = true;
                myJavaCheckProcessStartInfo.FileName = "java.exe";
                myJavaCheckProcessStartInfo.Arguments = " -version";
                myJavaCheckProcessStartInfo.RedirectStandardError = true;
                myJavaCheckProcessStartInfo.UseShellExecute = false;

                Process myJavaCheckProcess = Process.Start(myJavaCheckProcessStartInfo);
                string myJavaVersion = myJavaCheckProcess.StandardError.ReadLine().Split(' ')[2].Replace("\"", "");
                
                if(myJavaVersion != null)
                {
                    return true;
                }
                return false;
            }
            catch(Exception e)
            {
                return false;
            }
        }

        /*
        * @Usage To create the w-agent package and copy files inside it
        * 
        * @param anInstallationPath the installation path selected by user
        */
        public void createWeAgentFolderAndCopyFiles(string anInstallationPath)
        {
            string myWAgentHome = anInstallationPath + WAGENT_HOME_FOLDER;

            if (Directory.Exists(myWAgentHome))
            {
               theServiceHandler.deleteService(checkAdminPermissions());
               thePackageHandler.DeleteDirectory(myWAgentHome);
            }

            thePackageHandler.createWAgentPackage(anInstallationPath);
        }

        /*
        * @Usage To copy files inside the extracted logstash inside w-agent package
        * 
        * @param anInstallationPath the installation path selected by user
        */
        public void copyFilesInWAgentLogstash(string anInstallationPath)
        {
            thePackageHandler.copyFilesInLogstash(anInstallationPath);
        }

        /*
        * @Usage To replace variables inside the conf file of w-agent
        * 
        * @param aUsername a username of the user
        * @param anInstallationPath a path for installation
        */
        public void replaceVariableInConf(string aUsername, string anInstallationPath)
        {
            string myConfFileText = File.ReadAllText(anInstallationPath + WAGENT_BIN_LOCATION + CONF_FILE);

            if(aUsername.Contains("@"))
            {
                string[] myUserText = aUsername.Split('@');

                aUsername = myUserText[0];
            }

            myConfFileText = myConfFileText.Replace(LOG_FILE_PARAMETER, anInstallationPath + SAMPLE_LOG_FILE_LOCATION);
            myConfFileText = myConfFileText.Replace(USERNAME_PARAMETER, aUsername);

            File.WriteAllText(anInstallationPath + WAGENT_BIN_LOCATION + CONF_FILE, myConfFileText);
        }

        /*
        * @Usage To extract a zip file
        * 
        * @param aZipPath the path of zip file we want to extract
        * @param anExtractPath the path where we want to place the extracted file
        */
        public void extractZipFile(string aZipPath, string anExtractPath)
        {
            ZipFile.ExtractToDirectory(aZipPath, anExtractPath);
        }

        /*
        * @Usage To install logstash as a service
        * 
        */
        public void installLogstashAsService()
        {
            Process myInstallationProcess = new Process();

            myInstallationProcess.StartInfo.CreateNoWindow = true;
            myInstallationProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            myInstallationProcess.StartInfo.FileName = getCurrentDirectory() + "\\" + TMP_SERVICE_INSTALLER;
            myInstallationProcess.StartInfo.UseShellExecute = false;

            myInstallationProcess.Start();
            myInstallationProcess.WaitForExit();
        }

        /*
        * @Usage To get the content of log file of w-agent
        * 
        * @param anInstallationPath a path for installation
        */
        public String getWAgentLogFile(String anInstallationPath)
        {
            string myLogFile = anInstallationPath + LOG_FILE_LOCATION;
            string myLogFileText = "";

            if (File.Exists(myLogFile))
            {
                using (var myFileStream = new FileStream(myLogFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var myStreamReader = new StreamReader(myFileStream, Encoding.Default))
                {
                    myLogFileText = myStreamReader.ReadToEnd();
                }
            }

            return myLogFileText;
        }

        /*
         * Checks If installer is running by a user with admin privilege
         * 
         */
         public bool checkAdminPermissions()
        {
            bool isElevated;
             using (WindowsIdentity myWindowsIdentity = WindowsIdentity.GetCurrent())
             {
                 WindowsPrincipal myPrincipal = new WindowsPrincipal(myWindowsIdentity);
                 isElevated = myPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
             }

             return isElevated;
        }
    }
}
