﻿namespace TrialWAgentInstaller
{
    partial class InstallerWizard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InstallerWizard));
            this.termsConditionPage = new AeroWizard.WizardPage();
            this.acceptConditionsCheckBox = new System.Windows.Forms.CheckBox();
            this.licenseAgreementlabel = new System.Windows.Forms.Label();
            this.termConditionsTextBox = new System.Windows.Forms.RichTextBox();
            this.installerWizardControl = new AeroWizard.WizardControl();
            this.welcomePage = new AeroWizard.WizardPage();
            this.introTextBox = new System.Windows.Forms.RichTextBox();
            this.wAgentLogoPictureBox = new System.Windows.Forms.PictureBox();
            this.configPage = new AeroWizard.WizardPage();
            this.usernameHelpButton = new System.Windows.Forms.Button();
            this.configPageLabel = new System.Windows.Forms.Label();
            this.usernameTextBox = new System.Windows.Forms.TextBox();
            this.usernameLabel = new System.Windows.Forms.Label();
            this.installationFolderPage = new AeroWizard.WizardPage();
            this.reinstallationTextBox = new System.Windows.Forms.RichTextBox();
            this.installationPathPanel = new System.Windows.Forms.Panel();
            this.invalidPathLabel = new System.Windows.Forms.Label();
            this.customInstallationPathRadioButton = new System.Windows.Forms.RadioButton();
            this.defaultPathTextBox = new System.Windows.Forms.TextBox();
            this.defaultPathRadioButton = new System.Windows.Forms.RadioButton();
            this.installationPathTextBox = new System.Windows.Forms.TextBox();
            this.chooseInstallationPathButton = new System.Windows.Forms.Button();
            this.installationPathPageLabel = new System.Windows.Forms.Label();
            this.installationPage = new AeroWizard.WizardPage();
            this.showInstallationPathTextBox = new System.Windows.Forms.TextBox();
            this.selectedUsernameTextBox = new System.Windows.Forms.TextBox();
            this.installationPathLabel = new System.Windows.Forms.Label();
            this.selectedUsernameLabel = new System.Windows.Forms.Label();
            this.reviewPageTextBox = new System.Windows.Forms.RichTextBox();
            this.installationAsServiceConfirmationPage = new AeroWizard.WizardPage();
            this.insufficientPermissionsTextBox = new System.Windows.Forms.RichTextBox();
            this.confirmInstallationPanel = new System.Windows.Forms.Panel();
            this.installationNoRadioButton = new System.Windows.Forms.RadioButton();
            this.confirmInstallationLabel = new System.Windows.Forms.RichTextBox();
            this.installationYesRadioButton = new System.Windows.Forms.RadioButton();
            this.installationInProgressPage = new AeroWizard.WizardPage();
            this.timeEstimateLabel = new System.Windows.Forms.Label();
            this.installationProgressBar = new System.Windows.Forms.ProgressBar();
            this.installationStatusLabel = new System.Windows.Forms.Label();
            this.installationLabel = new System.Windows.Forms.Label();
            this.servicePage = new AeroWizard.WizardPage();
            this.servicePanel = new System.Windows.Forms.Panel();
            this.noRadioButton = new System.Windows.Forms.RadioButton();
            this.yesRadioButton = new System.Windows.Forms.RadioButton();
            this.servicePageTextBox = new System.Windows.Forms.RichTextBox();
            this.serviceStartInProgressPage = new AeroWizard.WizardPage();
            this.serviceDetailsTextBox = new System.Windows.Forms.RichTextBox();
            this.serviceDetailsButton = new System.Windows.Forms.Button();
            this.serviceStartUpProgressBar = new System.Windows.Forms.ProgressBar();
            this.serviceStartUpStatusLabel = new System.Windows.Forms.Label();
            this.serviceStartUpLabel = new System.Windows.Forms.Label();
            this.setupCompletePage = new AeroWizard.WizardPage();
            this.setupCompletionDetailsRichTextBox = new System.Windows.Forms.RichTextBox();
            this.finishPageLogoPictureBox = new System.Windows.Forms.PictureBox();
            this.copyrightLabel = new AeroWizard.ThemedLabel();
            this.selectInstallationPathDialog = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.orgIdToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.logfilePageLabel = new System.Windows.Forms.Label();
            this.logFilePathTextBox = new System.Windows.Forms.TextBox();
            this.logFileBrowseButton = new System.Windows.Forms.Button();
            this.logFilePage = new AeroWizard.WizardPage();
            this.termsConditionPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.installerWizardControl)).BeginInit();
            this.welcomePage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentLogoPictureBox)).BeginInit();
            this.configPage.SuspendLayout();
            this.installationFolderPage.SuspendLayout();
            this.installationPathPanel.SuspendLayout();
            this.installationPage.SuspendLayout();
            this.installationAsServiceConfirmationPage.SuspendLayout();
            this.confirmInstallationPanel.SuspendLayout();
            this.installationInProgressPage.SuspendLayout();
            this.servicePage.SuspendLayout();
            this.servicePanel.SuspendLayout();
            this.serviceStartInProgressPage.SuspendLayout();
            this.setupCompletePage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.finishPageLogoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // termsConditionPage
            // 
            this.termsConditionPage.AllowNext = false;
            this.termsConditionPage.Controls.Add(this.acceptConditionsCheckBox);
            this.termsConditionPage.Controls.Add(this.licenseAgreementlabel);
            this.termsConditionPage.Controls.Add(this.termConditionsTextBox);
            this.termsConditionPage.Name = "termsConditionPage";
            this.termsConditionPage.Size = new System.Drawing.Size(527, 261);
            this.termsConditionPage.TabIndex = 0;
            this.termsConditionPage.Text = "End-User License Agreement";
            // 
            // acceptConditionsCheckBox
            // 
            this.acceptConditionsCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.acceptConditionsCheckBox.AutoSize = true;
            this.acceptConditionsCheckBox.Location = new System.Drawing.Point(6, 242);
            this.acceptConditionsCheckBox.Name = "acceptConditionsCheckBox";
            this.acceptConditionsCheckBox.Size = new System.Drawing.Size(232, 19);
            this.acceptConditionsCheckBox.TabIndex = 2;
            this.acceptConditionsCheckBox.Text = "I accept the terms in license agreement";
            this.acceptConditionsCheckBox.UseVisualStyleBackColor = true;
            this.acceptConditionsCheckBox.CheckedChanged += new System.EventHandler(this.acceptConditionsCheckBox_CheckedChanged);
            // 
            // licenseAgreementlabel
            // 
            this.licenseAgreementlabel.AutoSize = true;
            this.licenseAgreementlabel.Location = new System.Drawing.Point(3, 0);
            this.licenseAgreementlabel.Name = "licenseAgreementlabel";
            this.licenseAgreementlabel.Size = new System.Drawing.Size(286, 15);
            this.licenseAgreementlabel.TabIndex = 1;
            this.licenseAgreementlabel.Text = "Please read the following license agreement carefully";
            // 
            // termConditionsTextBox
            // 
            this.termConditionsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.termConditionsTextBox.Location = new System.Drawing.Point(6, 28);
            this.termConditionsTextBox.Name = "termConditionsTextBox";
            this.termConditionsTextBox.ReadOnly = true;
            this.termConditionsTextBox.Size = new System.Drawing.Size(518, 205);
            this.termConditionsTextBox.TabIndex = 0;
            this.termConditionsTextBox.Text = "";
            // 
            // installerWizardControl
            // 
            this.installerWizardControl.BackColor = System.Drawing.Color.White;
            this.installerWizardControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.installerWizardControl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.installerWizardControl.ForeColor = System.Drawing.Color.Black;
            this.installerWizardControl.Location = new System.Drawing.Point(0, 0);
            this.installerWizardControl.Name = "installerWizardControl";
            this.installerWizardControl.Pages.Add(this.welcomePage);
            this.installerWizardControl.Pages.Add(this.termsConditionPage);
            this.installerWizardControl.Pages.Add(this.configPage);
            this.installerWizardControl.Pages.Add(this.installationFolderPage);
            this.installerWizardControl.Pages.Add(this.installationPage);
            this.installerWizardControl.Pages.Add(this.installationAsServiceConfirmationPage);
            this.installerWizardControl.Pages.Add(this.installationInProgressPage);
            this.installerWizardControl.Pages.Add(this.servicePage);
            this.installerWizardControl.Pages.Add(this.serviceStartInProgressPage);
            this.installerWizardControl.Pages.Add(this.setupCompletePage);
            this.installerWizardControl.Size = new System.Drawing.Size(574, 415);
            this.installerWizardControl.TabIndex = 0;
            this.installerWizardControl.Title = "W-Agent Setup";
            this.installerWizardControl.TitleIcon = ((System.Drawing.Icon)(resources.GetObject("installerWizardControl.TitleIcon")));
            this.installerWizardControl.SelectedPageChanged += new System.EventHandler(this.installaterWizardControl_SelectedPageChanged);
            // 
            // welcomePage
            // 
            this.welcomePage.Controls.Add(this.introTextBox);
            this.welcomePage.Controls.Add(this.wAgentLogoPictureBox);
            this.welcomePage.Name = "welcomePage";
            this.welcomePage.Size = new System.Drawing.Size(527, 261);
            this.welcomePage.TabIndex = 3;
            this.welcomePage.Text = "Welcome to W-Agent Installation Wizard";
            // 
            // introTextBox
            // 
            this.introTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.introTextBox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.introTextBox.Location = new System.Drawing.Point(152, 103);
            this.introTextBox.Name = "introTextBox";
            this.introTextBox.Size = new System.Drawing.Size(369, 96);
            this.introTextBox.TabIndex = 1;
            this.introTextBox.Text = "The Setup Wizard will install W-Agent on your computer. Click Next to continue in" +
    "stallation or Cancel to exit the Setup Wizard";
            // 
            // wAgentLogoPictureBox
            // 
            this.wAgentLogoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("wAgentLogoPictureBox.Image")));
            this.wAgentLogoPictureBox.Location = new System.Drawing.Point(0, 47);
            this.wAgentLogoPictureBox.Name = "wAgentLogoPictureBox";
            this.wAgentLogoPictureBox.Size = new System.Drawing.Size(146, 152);
            this.wAgentLogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.wAgentLogoPictureBox.TabIndex = 0;
            this.wAgentLogoPictureBox.TabStop = false;
            // 
            // configPage
            // 
            this.configPage.AllowNext = false;
            this.configPage.Controls.Add(this.usernameHelpButton);
            this.configPage.Controls.Add(this.configPageLabel);
            this.configPage.Controls.Add(this.usernameTextBox);
            this.configPage.Controls.Add(this.usernameLabel);
            this.configPage.Name = "configPage";
            this.configPage.Size = new System.Drawing.Size(527, 261);
            this.configPage.TabIndex = 1;
            this.configPage.Text = "Configuration";
            // 
            // usernameHelpButton
            // 
            this.usernameHelpButton.BackColor = System.Drawing.Color.White;
            this.usernameHelpButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.usernameHelpButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.usernameHelpButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.usernameHelpButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.usernameHelpButton.ForeColor = System.Drawing.Color.Transparent;
            this.usernameHelpButton.Image = ((System.Drawing.Image)(resources.GetObject("usernameHelpButton.Image")));
            this.usernameHelpButton.Location = new System.Drawing.Point(466, 42);
            this.usernameHelpButton.Margin = new System.Windows.Forms.Padding(2);
            this.usernameHelpButton.Name = "usernameHelpButton";
            this.usernameHelpButton.Size = new System.Drawing.Size(38, 28);
            this.usernameHelpButton.TabIndex = 7;
            this.usernameHelpButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.orgIdToolTip.SetToolTip(this.usernameHelpButton, "The username that was sent to you by email\r\nwhen you registered at W-Alert.\r\nExam" +
        "ple: user@gmail.com\r\n");
            this.usernameHelpButton.UseVisualStyleBackColor = false;
            // 
            // configPageLabel
            // 
            this.configPageLabel.AutoSize = true;
            this.configPageLabel.Location = new System.Drawing.Point(3, 0);
            this.configPageLabel.Name = "configPageLabel";
            this.configPageLabel.Size = new System.Drawing.Size(210, 15);
            this.configPageLabel.TabIndex = 6;
            this.configPageLabel.Text = "Please enter the following to continue:";
            // 
            // usernameTextBox
            // 
            this.usernameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.usernameTextBox.Location = new System.Drawing.Point(96, 46);
            this.usernameTextBox.Name = "usernameTextBox";
            this.usernameTextBox.Size = new System.Drawing.Size(365, 23);
            this.usernameTextBox.TabIndex = 2;
            this.usernameTextBox.TextChanged += new System.EventHandler(this.usernameTextBox_TextChanged);
            // 
            // usernameLabel
            // 
            this.usernameLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.usernameLabel.AutoSize = true;
            this.usernameLabel.Location = new System.Drawing.Point(20, 49);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(60, 15);
            this.usernameLabel.TabIndex = 0;
            this.usernameLabel.Text = "Username";
            // 
            // installationFolderPage
            // 
            this.installationFolderPage.Controls.Add(this.reinstallationTextBox);
            this.installationFolderPage.Controls.Add(this.installationPathPanel);
            this.installationFolderPage.Controls.Add(this.installationPathPageLabel);
            this.installationFolderPage.Name = "installationFolderPage";
            this.installationFolderPage.Size = new System.Drawing.Size(527, 261);
            this.installationFolderPage.TabIndex = 4;
            this.installationFolderPage.Text = "Intallation Path";
            this.installationFolderPage.Commit += new System.EventHandler<AeroWizard.WizardPageConfirmEventArgs>(this.installationFolderPage_Commit);
            // 
            // reinstallationTextBox
            // 
            this.reinstallationTextBox.BackColor = System.Drawing.Color.White;
            this.reinstallationTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.reinstallationTextBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reinstallationTextBox.Location = new System.Drawing.Point(6, 223);
            this.reinstallationTextBox.Name = "reinstallationTextBox";
            this.reinstallationTextBox.ReadOnly = true;
            this.reinstallationTextBox.Size = new System.Drawing.Size(518, 35);
            this.reinstallationTextBox.TabIndex = 4;
            this.reinstallationTextBox.Text = "W-Agent is already installed in the selected directory, If you choose to continue" +
    ", the current installation will be overwritten.";
            this.reinstallationTextBox.Visible = false;
            // 
            // installationPathPanel
            // 
            this.installationPathPanel.Controls.Add(this.invalidPathLabel);
            this.installationPathPanel.Controls.Add(this.customInstallationPathRadioButton);
            this.installationPathPanel.Controls.Add(this.defaultPathTextBox);
            this.installationPathPanel.Controls.Add(this.defaultPathRadioButton);
            this.installationPathPanel.Controls.Add(this.installationPathTextBox);
            this.installationPathPanel.Controls.Add(this.chooseInstallationPathButton);
            this.installationPathPanel.Location = new System.Drawing.Point(6, 36);
            this.installationPathPanel.Name = "installationPathPanel";
            this.installationPathPanel.Size = new System.Drawing.Size(518, 180);
            this.installationPathPanel.TabIndex = 3;
            // 
            // invalidPathLabel
            // 
            this.invalidPathLabel.AutoSize = true;
            this.invalidPathLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.invalidPathLabel.Location = new System.Drawing.Point(22, 128);
            this.invalidPathLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.invalidPathLabel.Name = "invalidPathLabel";
            this.invalidPathLabel.Size = new System.Drawing.Size(388, 15);
            this.invalidPathLabel.TabIndex = 6;
            this.invalidPathLabel.Text = "Please enter a valid installation path. It should not exceed 100 characters.";
            this.invalidPathLabel.Visible = false;
            // 
            // customInstallationPathRadioButton
            // 
            this.customInstallationPathRadioButton.AutoSize = true;
            this.customInstallationPathRadioButton.Location = new System.Drawing.Point(4, 73);
            this.customInstallationPathRadioButton.Name = "customInstallationPathRadioButton";
            this.customInstallationPathRadioButton.Size = new System.Drawing.Size(158, 19);
            this.customInstallationPathRadioButton.TabIndex = 5;
            this.customInstallationPathRadioButton.Text = "Custom Installation Path:";
            this.customInstallationPathRadioButton.UseVisualStyleBackColor = true;
            this.customInstallationPathRadioButton.CheckedChanged += new System.EventHandler(this.customInstallationPathRadioButton_CheckedChanged);
            // 
            // defaultPathTextBox
            // 
            this.defaultPathTextBox.Location = new System.Drawing.Point(22, 26);
            this.defaultPathTextBox.Name = "defaultPathTextBox";
            this.defaultPathTextBox.ReadOnly = true;
            this.defaultPathTextBox.Size = new System.Drawing.Size(469, 23);
            this.defaultPathTextBox.TabIndex = 4;
            this.defaultPathTextBox.Text = "C:\\w-agent_demo_default";
            // 
            // defaultPathRadioButton
            // 
            this.defaultPathRadioButton.AutoSize = true;
            this.defaultPathRadioButton.Checked = true;
            this.defaultPathRadioButton.Location = new System.Drawing.Point(3, 0);
            this.defaultPathRadioButton.Name = "defaultPathRadioButton";
            this.defaultPathRadioButton.Size = new System.Drawing.Size(154, 19);
            this.defaultPathRadioButton.TabIndex = 3;
            this.defaultPathRadioButton.TabStop = true;
            this.defaultPathRadioButton.Text = "Default Installation Path:";
            this.defaultPathRadioButton.UseVisualStyleBackColor = true;
            this.defaultPathRadioButton.CheckedChanged += new System.EventHandler(this.defaultPathRadioButton_CheckedChanged);
            // 
            // installationPathTextBox
            // 
            this.installationPathTextBox.Enabled = false;
            this.installationPathTextBox.Location = new System.Drawing.Point(22, 98);
            this.installationPathTextBox.Name = "installationPathTextBox";
            this.installationPathTextBox.Size = new System.Drawing.Size(469, 23);
            this.installationPathTextBox.TabIndex = 1;
            this.installationPathTextBox.TextChanged += new System.EventHandler(this.installationPathTextBox_TextChanged);
            // 
            // chooseInstallationPathButton
            // 
            this.chooseInstallationPathButton.Enabled = false;
            this.chooseInstallationPathButton.Location = new System.Drawing.Point(22, 147);
            this.chooseInstallationPathButton.Name = "chooseInstallationPathButton";
            this.chooseInstallationPathButton.Size = new System.Drawing.Size(81, 23);
            this.chooseInstallationPathButton.TabIndex = 2;
            this.chooseInstallationPathButton.Text = "Browse...";
            this.chooseInstallationPathButton.UseVisualStyleBackColor = true;
            this.chooseInstallationPathButton.Click += new System.EventHandler(this.chooseInstallationPathButton_Click);
            // 
            // installationPathPageLabel
            // 
            this.installationPathPageLabel.AutoSize = true;
            this.installationPathPageLabel.Location = new System.Drawing.Point(3, 0);
            this.installationPathPageLabel.Name = "installationPathPageLabel";
            this.installationPathPageLabel.Size = new System.Drawing.Size(416, 15);
            this.installationPathPageLabel.TabIndex = 0;
            this.installationPathPageLabel.Text = "Click Next to install into the default folder or click Change to choose another. " +
    "";
            // 
            // installationPage
            // 
            this.installationPage.Controls.Add(this.showInstallationPathTextBox);
            this.installationPage.Controls.Add(this.selectedUsernameTextBox);
            this.installationPage.Controls.Add(this.installationPathLabel);
            this.installationPage.Controls.Add(this.selectedUsernameLabel);
            this.installationPage.Controls.Add(this.reviewPageTextBox);
            this.installationPage.Name = "installationPage";
            this.installationPage.Size = new System.Drawing.Size(527, 261);
            this.installationPage.TabIndex = 5;
            this.installationPage.Text = "Ready to Install";
            this.installationPage.Commit += new System.EventHandler<AeroWizard.WizardPageConfirmEventArgs>(this.installationPage_Commit);
            // 
            // showInstallationPathTextBox
            // 
            this.showInstallationPathTextBox.Location = new System.Drawing.Point(145, 109);
            this.showInstallationPathTextBox.Name = "showInstallationPathTextBox";
            this.showInstallationPathTextBox.ReadOnly = true;
            this.showInstallationPathTextBox.Size = new System.Drawing.Size(357, 23);
            this.showInstallationPathTextBox.TabIndex = 15;
            // 
            // selectedUsernameTextBox
            // 
            this.selectedUsernameTextBox.Location = new System.Drawing.Point(145, 55);
            this.selectedUsernameTextBox.Name = "selectedUsernameTextBox";
            this.selectedUsernameTextBox.ReadOnly = true;
            this.selectedUsernameTextBox.Size = new System.Drawing.Size(357, 23);
            this.selectedUsernameTextBox.TabIndex = 11;
            // 
            // installationPathLabel
            // 
            this.installationPathLabel.AutoSize = true;
            this.installationPathLabel.Location = new System.Drawing.Point(18, 112);
            this.installationPathLabel.Name = "installationPathLabel";
            this.installationPathLabel.Size = new System.Drawing.Size(95, 15);
            this.installationPathLabel.TabIndex = 10;
            this.installationPathLabel.Text = "Installation Path:";
            // 
            // selectedUsernameLabel
            // 
            this.selectedUsernameLabel.AutoSize = true;
            this.selectedUsernameLabel.Location = new System.Drawing.Point(18, 58);
            this.selectedUsernameLabel.Name = "selectedUsernameLabel";
            this.selectedUsernameLabel.Size = new System.Drawing.Size(60, 15);
            this.selectedUsernameLabel.TabIndex = 6;
            this.selectedUsernameLabel.Text = "Username";
            // 
            // reviewPageTextBox
            // 
            this.reviewPageTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.reviewPageTextBox.Location = new System.Drawing.Point(6, 0);
            this.reviewPageTextBox.Name = "reviewPageTextBox";
            this.reviewPageTextBox.Size = new System.Drawing.Size(524, 38);
            this.reviewPageTextBox.TabIndex = 2;
            this.reviewPageTextBox.Text = "Please review your installation settings below. Click next to begin installation," +
    " click back to change any of your installation settings or  click Cancel to exit" +
    " the wizard.";
            // 
            // installationAsServiceConfirmationPage
            // 
            this.installationAsServiceConfirmationPage.Controls.Add(this.insufficientPermissionsTextBox);
            this.installationAsServiceConfirmationPage.Controls.Add(this.confirmInstallationPanel);
            this.installationAsServiceConfirmationPage.Name = "installationAsServiceConfirmationPage";
            this.installationAsServiceConfirmationPage.Size = new System.Drawing.Size(527, 261);
            this.installationAsServiceConfirmationPage.TabIndex = 10;
            this.installationAsServiceConfirmationPage.Text = "W-Agent as a Service ?";
            this.installationAsServiceConfirmationPage.Commit += new System.EventHandler<AeroWizard.WizardPageConfirmEventArgs>(this.installationAsServiceConfirmationPage_Commit);
            // 
            // insufficientPermissionsTextBox
            // 
            this.insufficientPermissionsTextBox.BackColor = System.Drawing.Color.White;
            this.insufficientPermissionsTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.insufficientPermissionsTextBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insufficientPermissionsTextBox.Location = new System.Drawing.Point(4, 187);
            this.insufficientPermissionsTextBox.Name = "insufficientPermissionsTextBox";
            this.insufficientPermissionsTextBox.ReadOnly = true;
            this.insufficientPermissionsTextBox.Size = new System.Drawing.Size(510, 71);
            this.insufficientPermissionsTextBox.TabIndex = 2;
            this.insufficientPermissionsTextBox.Text = "You can only install w-agent as an application. Please click Next to continue ins" +
    "tallation as an application. You need to run the setup wizard as an administrato" +
    "r to install w-agent as a service.";
            this.insufficientPermissionsTextBox.Visible = false;
            // 
            // confirmInstallationPanel
            // 
            this.confirmInstallationPanel.Controls.Add(this.installationNoRadioButton);
            this.confirmInstallationPanel.Controls.Add(this.confirmInstallationLabel);
            this.confirmInstallationPanel.Controls.Add(this.installationYesRadioButton);
            this.confirmInstallationPanel.Location = new System.Drawing.Point(4, 3);
            this.confirmInstallationPanel.Name = "confirmInstallationPanel";
            this.confirmInstallationPanel.Size = new System.Drawing.Size(520, 155);
            this.confirmInstallationPanel.TabIndex = 1;
            // 
            // installationNoRadioButton
            // 
            this.installationNoRadioButton.AutoSize = true;
            this.installationNoRadioButton.Location = new System.Drawing.Point(3, 114);
            this.installationNoRadioButton.Name = "installationNoRadioButton";
            this.installationNoRadioButton.Size = new System.Drawing.Size(41, 19);
            this.installationNoRadioButton.TabIndex = 1;
            this.installationNoRadioButton.Text = "No";
            this.installationNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // confirmInstallationLabel
            // 
            this.confirmInstallationLabel.BackColor = System.Drawing.Color.White;
            this.confirmInstallationLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.confirmInstallationLabel.Location = new System.Drawing.Point(3, 3);
            this.confirmInstallationLabel.Name = "confirmInstallationLabel";
            this.confirmInstallationLabel.ReadOnly = true;
            this.confirmInstallationLabel.Size = new System.Drawing.Size(520, 57);
            this.confirmInstallationLabel.TabIndex = 0;
            this.confirmInstallationLabel.Text = "Do you want to install w-agent as a service ? If you select Yes, it will be insta" +
    "lled as a service, if No then it will be installed as an application.";
            // 
            // installationYesRadioButton
            // 
            this.installationYesRadioButton.AutoSize = true;
            this.installationYesRadioButton.Checked = true;
            this.installationYesRadioButton.Location = new System.Drawing.Point(3, 76);
            this.installationYesRadioButton.Name = "installationYesRadioButton";
            this.installationYesRadioButton.Size = new System.Drawing.Size(42, 19);
            this.installationYesRadioButton.TabIndex = 0;
            this.installationYesRadioButton.TabStop = true;
            this.installationYesRadioButton.Text = "Yes";
            this.installationYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // installationInProgressPage
            // 
            this.installationInProgressPage.AllowBack = false;
            this.installationInProgressPage.AllowNext = false;
            this.installationInProgressPage.Controls.Add(this.timeEstimateLabel);
            this.installationInProgressPage.Controls.Add(this.installationProgressBar);
            this.installationInProgressPage.Controls.Add(this.installationStatusLabel);
            this.installationInProgressPage.Controls.Add(this.installationLabel);
            this.installationInProgressPage.Name = "installationInProgressPage";
            this.installationInProgressPage.Size = new System.Drawing.Size(527, 261);
            this.installationInProgressPage.TabIndex = 6;
            this.installationInProgressPage.Text = "Installing W-Agent";
            this.installationInProgressPage.Commit += new System.EventHandler<AeroWizard.WizardPageConfirmEventArgs>(this.installationInProgressPage_Commit);
            // 
            // timeEstimateLabel
            // 
            this.timeEstimateLabel.AutoSize = true;
            this.timeEstimateLabel.Location = new System.Drawing.Point(7, 106);
            this.timeEstimateLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.timeEstimateLabel.Name = "timeEstimateLabel";
            this.timeEstimateLabel.Size = new System.Drawing.Size(165, 15);
            this.timeEstimateLabel.TabIndex = 3;
            this.timeEstimateLabel.Text = "This can take up to 2 minutes.";
            // 
            // installationProgressBar
            // 
            this.installationProgressBar.Location = new System.Drawing.Point(7, 64);
            this.installationProgressBar.Name = "installationProgressBar";
            this.installationProgressBar.Size = new System.Drawing.Size(504, 23);
            this.installationProgressBar.TabIndex = 2;
            // 
            // installationStatusLabel
            // 
            this.installationStatusLabel.AutoSize = true;
            this.installationStatusLabel.Location = new System.Drawing.Point(4, 37);
            this.installationStatusLabel.Name = "installationStatusLabel";
            this.installationStatusLabel.Size = new System.Drawing.Size(45, 15);
            this.installationStatusLabel.TabIndex = 1;
            this.installationStatusLabel.Text = "Status: ";
            // 
            // installationLabel
            // 
            this.installationLabel.AutoSize = true;
            this.installationLabel.Location = new System.Drawing.Point(4, 0);
            this.installationLabel.Name = "installationLabel";
            this.installationLabel.Size = new System.Drawing.Size(281, 15);
            this.installationLabel.TabIndex = 0;
            this.installationLabel.Text = "Please wait while the Setup Wizard installs W-Agent.";
            // 
            // servicePage
            // 
            this.servicePage.Controls.Add(this.servicePanel);
            this.servicePage.Controls.Add(this.servicePageTextBox);
            this.servicePage.Name = "servicePage";
            this.servicePage.Size = new System.Drawing.Size(527, 261);
            this.servicePage.TabIndex = 7;
            this.servicePage.Text = "Do you want to start the W-Agent Service ?";
            this.servicePage.Commit += new System.EventHandler<AeroWizard.WizardPageConfirmEventArgs>(this.servicePage_Commit);
            // 
            // servicePanel
            // 
            this.servicePanel.Controls.Add(this.noRadioButton);
            this.servicePanel.Controls.Add(this.yesRadioButton);
            this.servicePanel.Location = new System.Drawing.Point(2, 66);
            this.servicePanel.Margin = new System.Windows.Forms.Padding(2);
            this.servicePanel.Name = "servicePanel";
            this.servicePanel.Size = new System.Drawing.Size(150, 81);
            this.servicePanel.TabIndex = 5;
            // 
            // noRadioButton
            // 
            this.noRadioButton.AutoSize = true;
            this.noRadioButton.Location = new System.Drawing.Point(3, 41);
            this.noRadioButton.Name = "noRadioButton";
            this.noRadioButton.Size = new System.Drawing.Size(41, 19);
            this.noRadioButton.TabIndex = 3;
            this.noRadioButton.Text = "No";
            this.noRadioButton.UseVisualStyleBackColor = true;
            // 
            // yesRadioButton
            // 
            this.yesRadioButton.AutoSize = true;
            this.yesRadioButton.Checked = true;
            this.yesRadioButton.Location = new System.Drawing.Point(3, 15);
            this.yesRadioButton.Name = "yesRadioButton";
            this.yesRadioButton.Size = new System.Drawing.Size(42, 19);
            this.yesRadioButton.TabIndex = 2;
            this.yesRadioButton.TabStop = true;
            this.yesRadioButton.Text = "Yes";
            this.yesRadioButton.UseVisualStyleBackColor = true;
            // 
            // servicePageTextBox
            // 
            this.servicePageTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.servicePageTextBox.Location = new System.Drawing.Point(6, 3);
            this.servicePageTextBox.Name = "servicePageTextBox";
            this.servicePageTextBox.Size = new System.Drawing.Size(507, 151);
            this.servicePageTextBox.TabIndex = 1;
            this.servicePageTextBox.Text = "W-Agent has been installed in your computer. Please select Yes if you want to sta" +
    "rt the service, No if you don\'t want to start it now.";
            // 
            // serviceStartInProgressPage
            // 
            this.serviceStartInProgressPage.AllowNext = false;
            this.serviceStartInProgressPage.Controls.Add(this.serviceDetailsTextBox);
            this.serviceStartInProgressPage.Controls.Add(this.serviceDetailsButton);
            this.serviceStartInProgressPage.Controls.Add(this.serviceStartUpProgressBar);
            this.serviceStartInProgressPage.Controls.Add(this.serviceStartUpStatusLabel);
            this.serviceStartInProgressPage.Controls.Add(this.serviceStartUpLabel);
            this.serviceStartInProgressPage.Name = "serviceStartInProgressPage";
            this.serviceStartInProgressPage.Size = new System.Drawing.Size(527, 261);
            this.serviceStartInProgressPage.TabIndex = 8;
            this.serviceStartInProgressPage.Text = "Starting W-Agent Service";
            // 
            // serviceDetailsTextBox
            // 
            this.serviceDetailsTextBox.Location = new System.Drawing.Point(7, 113);
            this.serviceDetailsTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.serviceDetailsTextBox.Name = "serviceDetailsTextBox";
            this.serviceDetailsTextBox.ReadOnly = true;
            this.serviceDetailsTextBox.Size = new System.Drawing.Size(506, 129);
            this.serviceDetailsTextBox.TabIndex = 4;
            this.serviceDetailsTextBox.Text = "";
            this.serviceDetailsTextBox.Visible = false;
            // 
            // serviceDetailsButton
            // 
            this.serviceDetailsButton.Location = new System.Drawing.Point(7, 84);
            this.serviceDetailsButton.Margin = new System.Windows.Forms.Padding(2);
            this.serviceDetailsButton.Name = "serviceDetailsButton";
            this.serviceDetailsButton.Size = new System.Drawing.Size(65, 25);
            this.serviceDetailsButton.TabIndex = 3;
            this.serviceDetailsButton.Text = "Details..";
            this.serviceDetailsButton.UseVisualStyleBackColor = true;
            this.serviceDetailsButton.Click += new System.EventHandler(this.serviceDetailsButton_Click);
            // 
            // serviceStartUpProgressBar
            // 
            this.serviceStartUpProgressBar.Location = new System.Drawing.Point(7, 56);
            this.serviceStartUpProgressBar.Name = "serviceStartUpProgressBar";
            this.serviceStartUpProgressBar.Size = new System.Drawing.Size(505, 23);
            this.serviceStartUpProgressBar.TabIndex = 2;
            // 
            // serviceStartUpStatusLabel
            // 
            this.serviceStartUpStatusLabel.AutoSize = true;
            this.serviceStartUpStatusLabel.Location = new System.Drawing.Point(4, 27);
            this.serviceStartUpStatusLabel.Name = "serviceStartUpStatusLabel";
            this.serviceStartUpStatusLabel.Size = new System.Drawing.Size(42, 15);
            this.serviceStartUpStatusLabel.TabIndex = 1;
            this.serviceStartUpStatusLabel.Text = "Status:";
            // 
            // serviceStartUpLabel
            // 
            this.serviceStartUpLabel.AutoSize = true;
            this.serviceStartUpLabel.Location = new System.Drawing.Point(4, 0);
            this.serviceStartUpLabel.Name = "serviceStartUpLabel";
            this.serviceStartUpLabel.Size = new System.Drawing.Size(451, 15);
            this.serviceStartUpLabel.TabIndex = 0;
            this.serviceStartUpLabel.Text = "Please wait while the Setup Wizard starts the W-Agent Service. It will take some " +
    "time.";
            // 
            // setupCompletePage
            // 
            this.setupCompletePage.Controls.Add(this.setupCompletionDetailsRichTextBox);
            this.setupCompletePage.Controls.Add(this.finishPageLogoPictureBox);
            this.setupCompletePage.Name = "setupCompletePage";
            this.setupCompletePage.Size = new System.Drawing.Size(527, 261);
            this.setupCompletePage.TabIndex = 9;
            this.setupCompletePage.Text = "Completed W-Agent Setup Wizard";
            this.setupCompletePage.Commit += new System.EventHandler<AeroWizard.WizardPageConfirmEventArgs>(this.setupCompletePage_Commit);
            // 
            // setupCompletionDetailsRichTextBox
            // 
            this.setupCompletionDetailsRichTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.setupCompletionDetailsRichTextBox.Location = new System.Drawing.Point(163, 114);
            this.setupCompletionDetailsRichTextBox.Name = "setupCompletionDetailsRichTextBox";
            this.setupCompletionDetailsRichTextBox.Size = new System.Drawing.Size(339, 102);
            this.setupCompletionDetailsRichTextBox.TabIndex = 1;
            this.setupCompletionDetailsRichTextBox.Text = "W-Agent Trial version has been successfully installed and the w-agent service is " +
    "running on your system. Click the Finish to exit the Setup Wizard.";
            // 
            // finishPageLogoPictureBox
            // 
            this.finishPageLogoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("finishPageLogoPictureBox.Image")));
            this.finishPageLogoPictureBox.Location = new System.Drawing.Point(0, 49);
            this.finishPageLogoPictureBox.Name = "finishPageLogoPictureBox";
            this.finishPageLogoPictureBox.Size = new System.Drawing.Size(156, 169);
            this.finishPageLogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.finishPageLogoPictureBox.TabIndex = 0;
            this.finishPageLogoPictureBox.TabStop = false;
            // 
            // copyrightLabel
            // 
            this.copyrightLabel.BackColor = System.Drawing.SystemColors.Control;
            this.copyrightLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.copyrightLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.copyrightLabel.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.copyrightLabel.Location = new System.Drawing.Point(28, 383);
            this.copyrightLabel.Name = "copyrightLabel";
            this.copyrightLabel.Size = new System.Drawing.Size(349, 32);
            this.copyrightLabel.TabIndex = 1;
            this.copyrightLabel.Text = "W-Integrate © Copyright 2018   |   All Rights Reserved";
            // 
            // logfilePageLabel
            // 
            this.logfilePageLabel.Location = new System.Drawing.Point(0, 0);
            this.logfilePageLabel.Name = "logfilePageLabel";
            this.logfilePageLabel.Size = new System.Drawing.Size(100, 23);
            this.logfilePageLabel.TabIndex = 0;
            // 
            // logFilePathTextBox
            // 
            this.logFilePathTextBox.Location = new System.Drawing.Point(0, 0);
            this.logFilePathTextBox.Name = "logFilePathTextBox";
            this.logFilePathTextBox.Size = new System.Drawing.Size(100, 20);
            this.logFilePathTextBox.TabIndex = 0;
            // 
            // logFileBrowseButton
            // 
            this.logFileBrowseButton.Location = new System.Drawing.Point(0, 0);
            this.logFileBrowseButton.Name = "logFileBrowseButton";
            this.logFileBrowseButton.Size = new System.Drawing.Size(75, 23);
            this.logFileBrowseButton.TabIndex = 0;
            // 
            // logFilePage
            // 
            this.logFilePage.Name = "logFilePage";
            this.logFilePage.Size = new System.Drawing.Size(0, 0);
            this.logFilePage.TabIndex = 0;
            this.logFilePage.Text = "Page Title";
            // 
            // InstallerWizard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(574, 415);
            this.Controls.Add(this.copyrightLabel);
            this.Controls.Add(this.installerWizardControl);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InstallerWizard";
            this.termsConditionPage.ResumeLayout(false);
            this.termsConditionPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.installerWizardControl)).EndInit();
            this.welcomePage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.wAgentLogoPictureBox)).EndInit();
            this.configPage.ResumeLayout(false);
            this.configPage.PerformLayout();
            this.installationFolderPage.ResumeLayout(false);
            this.installationFolderPage.PerformLayout();
            this.installationPathPanel.ResumeLayout(false);
            this.installationPathPanel.PerformLayout();
            this.installationPage.ResumeLayout(false);
            this.installationPage.PerformLayout();
            this.installationAsServiceConfirmationPage.ResumeLayout(false);
            this.confirmInstallationPanel.ResumeLayout(false);
            this.confirmInstallationPanel.PerformLayout();
            this.installationInProgressPage.ResumeLayout(false);
            this.installationInProgressPage.PerformLayout();
            this.servicePage.ResumeLayout(false);
            this.servicePanel.ResumeLayout(false);
            this.servicePanel.PerformLayout();
            this.serviceStartInProgressPage.ResumeLayout(false);
            this.serviceStartInProgressPage.PerformLayout();
            this.setupCompletePage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.finishPageLogoPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AeroWizard.WizardPage termsConditionPage;
        private System.Windows.Forms.CheckBox acceptConditionsCheckBox;
        private System.Windows.Forms.Label licenseAgreementlabel;
        private System.Windows.Forms.RichTextBox termConditionsTextBox;
        private AeroWizard.WizardControl installerWizardControl;
        private AeroWizard.WizardPage configPage;
        private System.Windows.Forms.TextBox usernameTextBox;
        private System.Windows.Forms.Label usernameLabel;
        private AeroWizard.WizardPage welcomePage;
        private System.Windows.Forms.RichTextBox introTextBox;
        private System.Windows.Forms.PictureBox wAgentLogoPictureBox;
        private System.Windows.Forms.Label configPageLabel;
        private AeroWizard.ThemedLabel copyrightLabel;
        private AeroWizard.WizardPage installationFolderPage;
        private System.Windows.Forms.Label installationPathPageLabel;
        private System.Windows.Forms.Button chooseInstallationPathButton;
        private System.Windows.Forms.TextBox installationPathTextBox;
        private AeroWizard.WizardPage installationPage;
        private System.Windows.Forms.RichTextBox reviewPageTextBox;
        private AeroWizard.WizardPage installationInProgressPage;
        private System.Windows.Forms.ProgressBar installationProgressBar;
        private System.Windows.Forms.Label installationStatusLabel;
        private System.Windows.Forms.Label installationLabel;
        private AeroWizard.WizardPage servicePage;
        private System.Windows.Forms.RadioButton noRadioButton;
        private System.Windows.Forms.RadioButton yesRadioButton;
        private System.Windows.Forms.RichTextBox servicePageTextBox;
        private AeroWizard.WizardPage serviceStartInProgressPage;
        private System.Windows.Forms.ProgressBar serviceStartUpProgressBar;
        private System.Windows.Forms.Label serviceStartUpStatusLabel;
        private System.Windows.Forms.Label serviceStartUpLabel;
        private AeroWizard.WizardPage setupCompletePage;
        private System.Windows.Forms.RichTextBox setupCompletionDetailsRichTextBox;
        private System.Windows.Forms.PictureBox finishPageLogoPictureBox;
        private System.Windows.Forms.OpenFileDialog selectInstallationPathDialog;
        private System.Windows.Forms.Panel installationPathPanel;
        private System.Windows.Forms.TextBox defaultPathTextBox;
        private System.Windows.Forms.RadioButton defaultPathRadioButton;
        private System.Windows.Forms.RadioButton customInstallationPathRadioButton;
        private System.Windows.Forms.Label selectedUsernameLabel;
        private System.Windows.Forms.TextBox showInstallationPathTextBox;
        private System.Windows.Forms.TextBox selectedUsernameTextBox;
        private System.Windows.Forms.Label installationPathLabel;
        private System.Windows.Forms.Panel servicePanel;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button usernameHelpButton;
        private System.Windows.Forms.ToolTip orgIdToolTip;
        private System.Windows.Forms.Label timeEstimateLabel;
        private System.Windows.Forms.RichTextBox serviceDetailsTextBox;
        private System.Windows.Forms.Button serviceDetailsButton;
        private System.Windows.Forms.Label invalidPathLabel;
        private System.Windows.Forms.Label logfilePageLabel;
        private System.Windows.Forms.TextBox logFilePathTextBox;
        private System.Windows.Forms.Button logFileBrowseButton;
        private AeroWizard.WizardPage logFilePage;
        private AeroWizard.WizardPage installationAsServiceConfirmationPage;
        private System.Windows.Forms.RichTextBox confirmInstallationLabel;
        private System.Windows.Forms.Panel confirmInstallationPanel;
        private System.Windows.Forms.RadioButton installationNoRadioButton;
        private System.Windows.Forms.RadioButton installationYesRadioButton;
        private System.Windows.Forms.RichTextBox insufficientPermissionsTextBox;
        private System.Windows.Forms.RichTextBox reinstallationTextBox;
    }
}