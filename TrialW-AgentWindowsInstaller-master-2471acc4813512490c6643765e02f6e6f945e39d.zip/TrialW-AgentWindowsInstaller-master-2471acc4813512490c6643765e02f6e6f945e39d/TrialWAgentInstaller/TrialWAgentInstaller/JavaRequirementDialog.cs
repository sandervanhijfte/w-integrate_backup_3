﻿/*
 * 	Author: Maira Tul Islam
 * 	Usage: This class is to handle the controls on JavaRequirementDialog page
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

using System;
using System.Windows.Forms;

namespace TrialWAgentInstaller
{
    public partial class JavaRequirementDialog : Form
    {
        /*
         * Default Constructor
         */
        public JavaRequirementDialog()
        {
            InitializeComponent();
        }

        /*
         * Handler to control button click
         */
        private void btn_Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
