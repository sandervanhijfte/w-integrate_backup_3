﻿/*
 * 	Author: Maira Tul Islam
 * 	Usage: This is the class that provides help methods to perform steps of installation for w-agent
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

/*.NET Packages*/
using System;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;
using System.Windows.Forms;

namespace TrialWAgentInstaller
{
    class WAgentServiceHandler
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private string TMP_SERVICE_INSTALLER = "tmp_w-agent_service_installer.bat";
        private string NSSM_PATH_PARAMETER = "NSSM_PATH";
        private string SERVICE_NAME_PARAMETER = "SERVICE_NAME";
        private string LOGSTASH_BIN_PARAMETER = "LOGSTASH_BIN";
        private string LOGFILE_PATH_PARAMETER = "LOGFILE_PATH";
        private string WAGENT_LOG_FILE_LOCATION = "\\w-agent_home\\w-agent\\logs";
        private string WAGENT_LOGSTASH_BIN = "\\w-agent_home\\w-agent\\bin";
        private string NSSM_LOCATION = "\\w-agent_home\\w-agent\\nssm.exe";
        private string NSSM_LOCATION_IN_ASSEMBLIES = "\\assemblies\\nssm.exe";
        private string WAGENT_SERVICE_INSTALLER_FILE = "w-agent_service_installer.bat";

        private string theCurrentDirectory;
        private string theServiceName;

        /***************************************************************
							        METHODS
	    ****************************************************************/
        /*
         * @Usage Default Constructor
         * 
         */
        public WAgentServiceHandler(string aCurrentDirectory, string aServiceName)
        {
            this.theCurrentDirectory = aCurrentDirectory;
            this.theServiceName = aServiceName;
        }

        /*
         * @Usage Remove temp file for myService installer
         * 
         */
        public void removeServiceInstallerTmpFile()
        {
            File.Delete(theCurrentDirectory + "\\" + TMP_SERVICE_INSTALLER);
        }

        /*
         * @Usage To start the myService
         *
         * @param anInstallationPath the installation path selected by user
         */
        public void startService(string anInstallationPath)
        {
            string myCommand = "\"" + anInstallationPath + NSSM_LOCATION + "\"" + " start " + theServiceName;
            runCommand(myCommand);
        }

        /*
         * @Usage To check if a myService exists
         *
         */
        public bool serviceExists()
        {
            ServiceController[] myServices = ServiceController.GetServices();
            
            foreach (ServiceController myService in myServices)
            {
                if (myService.ServiceName == theServiceName)
                    return true;
            }
            return false;
        }

        /*
         * @Usage To delete the service
         *
         */
        public void deleteService(bool anAdminUser)
        {
            if (serviceExists() && anAdminUser)
            {
                stopService(theServiceName);
                removeService(theServiceName);
            }
        }

        /*
         * @Usage To stop the service
         *
         * @param aServiceName a service name
         */
        public void stopService(string aServiceName)
        {
            string myStopCommand = "\"" + theCurrentDirectory + NSSM_LOCATION_IN_ASSEMBLIES + "\"" + " stop " + aServiceName;
            runCommand(myStopCommand);
        }

        /*
         * @Usage To remove the service
         *
         * @param aServiceName a service name
         */
        public void removeService(string aServiceName)
        {
            string myRemoveCommand = "\"" + theCurrentDirectory + NSSM_LOCATION_IN_ASSEMBLIES + "\"" + " remove " + aServiceName + " confirm";
            runCommand(myRemoveCommand);
        }

        /*
         * @Usage To run a command 
         *
         * @param aCommand a command
         */
        public void runCommand(String aCommand)
        {
            var myProcessInfo = new ProcessStartInfo("cmd.exe", "/c " + aCommand);
            myProcessInfo.CreateNoWindow = true;
            myProcessInfo.UseShellExecute = false;
            myProcessInfo.RedirectStandardError = true;
            myProcessInfo.RedirectStandardOutput = true;

            var myProcess = Process.Start(myProcessInfo);

            myProcess.OutputDataReceived += (object sender, DataReceivedEventArgs e) =>
                Console.WriteLine("output>>" + e.Data);
            
            myProcess.BeginOutputReadLine();

            myProcess.ErrorDataReceived += (object sender, DataReceivedEventArgs e) =>
                Console.WriteLine("error>>" + e.Data);
            myProcess.BeginErrorReadLine();

            myProcess.WaitForExit();

            Console.WriteLine("ExitCode: {0}", myProcess.ExitCode);
            myProcess.Close();
        }

        /*
         * @Usage To replace variables in service installer
         *
         * @param anInstallationPath the installation path selected by user
         */
        public void replaceVariablesInServiceInstaller(string anInstallationPath)
        {
            string myServiceInstallerFilePath = getServiceInstallerFilePath();

            //Service file
            string myServiceInstallerText = File.ReadAllText(myServiceInstallerFilePath);
            myServiceInstallerText = myServiceInstallerText.Replace(NSSM_PATH_PARAMETER, anInstallationPath + NSSM_LOCATION);
            myServiceInstallerText = myServiceInstallerText.Replace(LOGSTASH_BIN_PARAMETER, anInstallationPath + WAGENT_LOGSTASH_BIN);
            myServiceInstallerText = myServiceInstallerText.Replace(SERVICE_NAME_PARAMETER, theServiceName);
            myServiceInstallerText = myServiceInstallerText.Replace(LOGFILE_PATH_PARAMETER, anInstallationPath + WAGENT_LOG_FILE_LOCATION);
            myServiceInstallerText = myServiceInstallerText.Replace("/", "\\");
            myServiceInstallerText = myServiceInstallerText.Replace("DIR_FLAG", "/d");

            File.WriteAllText(myServiceInstallerFilePath, myServiceInstallerText);
        }

        /*
         * @Usage To get the service installer file path
         * 
         */
        private string getServiceInstallerFilePath()
        {
            string mySourceFile = System.IO.Path.Combine(theCurrentDirectory, WAGENT_SERVICE_INSTALLER_FILE);
            string myDestFile = System.IO.Path.Combine(theCurrentDirectory, TMP_SERVICE_INSTALLER);

            System.IO.File.Copy(mySourceFile, myDestFile, true);

            return theCurrentDirectory + "\\" + TMP_SERVICE_INSTALLER;
        }
    }
}
