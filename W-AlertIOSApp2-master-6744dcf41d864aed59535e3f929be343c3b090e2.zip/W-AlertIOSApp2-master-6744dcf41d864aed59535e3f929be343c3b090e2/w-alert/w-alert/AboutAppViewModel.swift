//
//  AboutAppViewModel.swift
//  w-alert
//
//  Created by Mehak Zia on 5/4/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

import UIKit

class AboutAppViewModel: NSObject {

    func getVersionNumber() -> String {
    
    return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
    
    }
}
