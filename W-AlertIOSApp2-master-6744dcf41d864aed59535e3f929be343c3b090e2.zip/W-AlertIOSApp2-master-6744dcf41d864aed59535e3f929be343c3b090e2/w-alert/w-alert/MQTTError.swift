//
//  MQTTError.swift
//  w-alert
//
//  Created by Mehak Zia on 4/17/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

import Foundation

/// Enum : MQTTError
/// Description : Errors for MQTT Manager
///
enum MQTTError : Error {
    case ReadCertificateFileFail
    case Certificate_File_Incorrect_Password
    case DeleteSubscriptionRecordFail
    case ReadSubscriptionRecordFail
    case UnableToReadSubscriptionDAO
}
