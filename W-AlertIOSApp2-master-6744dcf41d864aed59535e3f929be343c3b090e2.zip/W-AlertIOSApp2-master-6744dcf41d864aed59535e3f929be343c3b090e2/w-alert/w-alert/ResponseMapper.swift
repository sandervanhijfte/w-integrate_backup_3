//
//  ResponseMapper.swift
//  w-alert
//
//  Created by Arqam Amin on 22/03/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

import Foundation
import SwiftyJSON

class ResponseMapper {
    
    func mapGetUserResponseToUser(userResponse: JSON, password: String) -> User {
        
        let myUserResponse = userResponse["GetUserResponse"]
        return User(id: 1,
                    userId: myUserResponse["User"]["UserId"].stringValue,
                    userName: myUserResponse["User"]["UserName"].stringValue,
                    password: password,
                    status: myUserResponse["User"]["UserStatus"].stringValue,
                    firstName: myUserResponse["User"]["PersonalDetail"]["FirstName"].stringValue,
                    lastName: myUserResponse["User"]["PersonalDetail"]["LastName"].stringValue,
                    mobileNo: "",
                    email: myUserResponse["User"]["ContactDetail"][1]["ChannelCode"].stringValue,
                    roleId: myUserResponse["User"]["UserId"].stringValue,
                    organizationId: myUserResponse["Client"]["OrganizationId"].stringValue,
                    organizationName: myUserResponse["Client"]["OrganizationName"].stringValue,
                    organzationDomain: myUserResponse["Client"]["OrganizationDomain"].stringValue,
                    isLoggedIn: true)
    }
    
    func mapGetEventSubscriptionResponseToSubscription(subscriptionResponse: JSON) -> [Subscription]? {
        let eventSubscription = subscriptionResponse["GetEventSubscriptionResponse"]["EventSubscription"]
        let subscriptionDetail = eventSubscription["SubscriptionDetail"]
        
        var subscriptions = [Subscription]()
        switch subscriptionDetail.type {
        case .array:
            if let topics = subscriptionDetail.array {
                for topic in topics {
                    
                    let status = Subscription(id: 1,
                                              subscriptionId: eventSubscription["SubscriptionId"].stringValue,
                                              subscriptionName: eventSubscription["SubscriptionName"].stringValue,
                                              subscriptionKey: eventSubscription["EventEncryptionKey"].stringValue,
                                              topicName: topic["TopicName"].stringValue,
                                              brokerURL: topic["BrokerUrl"].stringValue,
                                              brokerUserName: topic["UserName"].stringValue,
                                              brokerPassword: topic["Password"].stringValue)
                    
                    subscriptions.append(status)
                }
            }
        case .dictionary:
            
            let status = Subscription(id: 1,
                                      subscriptionId: eventSubscription["SubscriptionId"].stringValue,
                                      subscriptionName: eventSubscription["SubscriptionName"].stringValue,
                                      subscriptionKey: eventSubscription["EventEncryptionKey"].stringValue,
                                      topicName: subscriptionDetail["TopicName"].stringValue,
                                      brokerURL: subscriptionDetail["BrokerUrl"].stringValue,
                                      brokerUserName: subscriptionDetail["UserName"].stringValue,
                                      brokerPassword: subscriptionDetail["Password"].stringValue)
            
            subscriptions.append(status)
            
        default:
            return nil
        }
        return subscriptions
    }
}
