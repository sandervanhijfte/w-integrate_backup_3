//
//  CreatePasswordController.swift
//  w-alert
//
//  Created by Mehak Zia on 27/09/2017.
//  Copyright © 2017 WeIntegrate. All rights reserved.
//  Initial implementation :mehak zia cheema
//

//  imports

import UIKit


class ChangePasswordController: UIViewController {

    /// Variables and Objects
    @IBOutlet weak var oldPassword: CustomTextField!
    @IBOutlet weak var newPassword: CustomTextField!
    @IBOutlet weak var confirmPassword: CustomTextField!
    @IBOutlet weak var submitButton: UIButton!

    let activityIndicator: ActivityIndicator! = ActivityIndicator()
    var originalFrame = CGRect(x: 0.0, y: 0.0, width: 0.0, height: 0.0)

    var changePasswordViewModel = ChangePasswordViewModel()

    /// ChangePasswordController UIViewController Methods

    /// Method : viewDidLoad
    /// Description : This method is overrided to load the ui
    ///
    override func viewDidLoad() {

        super.viewDidLoad()
        initializeAlertDetailViewModel()
        initializeView()
    }

    func initializeAlertDetailViewModel() {

        changePasswordViewModel.oldPasswordTextField = oldPassword
        changePasswordViewModel.newPasswordTextField = newPassword
        changePasswordViewModel.confirmPassword = confirmPassword
    }

    /// Method : submitButtonPressed
    /// Description : This method will be invoke when submit button is pressed.
    ///
    @IBAction func submitButtonPressed(_ sender: Any) {

        self.showActivityIndicator()

        guard oldPassword.text != "", newPassword.text != "", confirmPassword.text != "" else {
            self.alertDialog(message: Constants.FILL_REQUIRED_FIELDS, title: "Error")
            activityIndicator.hideActivityIndicator()
            return
        }
        guard validateOldPassword(), validateNewPassword(), validateConfirmPassword() else {
            self.alertDialog(message: Constants.VALID_DATA_MESSAGE, title: "Error")
            activityIndicator.hideActivityIndicator()
            return
        }

        changePasswordViewModel.changePassword(oldPassword: oldPassword.text!, newPassword: newPassword.text!) { (isChanged) in

            if !isChanged {
                self.alertDialog(message: Constants.UNABLE_TO_CHANGE_PASSWORD_MESSAGE, title: "Error")
                self.activityIndicator.hideActivityIndicator()
                Logger.log.info("Fail to update password")
                return
            }
            
            Logger.log.info("Update password successfully.")

            self.alertDialogWithFunction(message: Constants.CHANGE_PASSWORD_MESSAGE, title: "Success")
            self.activityIndicator.hideActivityIndicator()
        }
    }

    /// Method : cancelButtonPressed
    /// Description : This method will be invoke when cancel button is pressed. It will navigate to alertList
    ///
    @IBAction func cancelButtonPressed(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }

    /// Method : tapGestureRecognizer
    /// Description : This method will be invoke on tap. it will hide keyboard and set the view back to its original position.
    ///
    @IBAction func tapGestureRecognizer(_ sender: Any) {
        view.endEditing(true)
        originalFrame.origin.y = 64
        self.view.frame = originalFrame
    }

    /// Method : oldPasswordMessage
    /// Description : Show the required format of oldPasswordMessage.
    ///
    @IBAction func oldPasswordMessage(_ sender: Any) {
        self.alertDialog(message: Constants.OLD_PASSWORD_MESSAGE, title: "")
    }

    /// Method : newPasswordMessage
    /// Description : Show the required format of newPasswordMessage.
    ///
    @IBAction func newPasswordMessage(_ sender: Any) {
        self.alertDialog(message: Constants.NEW_PASSWORD_MESSAGE, title: "")
    }

    /// Method : confirmPasswordMessage
    /// Description : Show the required format of confirmPasswordMessage.
    ///
    @IBAction func confirmPasswordMessage(_ sender: Any) {
        self.alertDialog(message: Constants.CONFIRM_PASSWORD_MESSAGE, title: "")
    }

    /// Method : oldPasswordTextChange
    /// Description : this method is use to validate password when text change.
    ///
    @IBAction func oldPasswordTextChange(_ sender: Any) {

        submitButton.isEnabled = validateOldPassword() && validateNewPassword() && validateConfirmPassword()
    }

    /// Method : newPasswordTextChange
    /// Description : this method is use to validate password when text change.
    ///
    @IBAction func newPasswordTextChange(_ sender: Any) {
        submitButton.isEnabled = validateOldPassword() && validateNewPassword() && validateConfirmPassword()
    }

    /// Method : confirmPasswordTextChange
    /// Description : this method is use to validate password when text change.
    ///
    @IBAction func confirmPasswordTextChange(_ sender: Any) {
        submitButton.isEnabled = validateOldPassword() && validateNewPassword() && validateConfirmPassword()
    }

    /// Method : initializeView
    /// Description : This method will set the ui
    ///
    func initializeView() {

        originalFrame = self.view.frame
        oldPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
        newPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
        confirmPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
        self.oldPassword.delegate = self
        self.newPassword.delegate = self
        self.confirmPassword.delegate = self
        oldPassword.tag = 0
        newPassword.tag = 1
        confirmPassword.tag = 2
        submitButton.isEnabled = false
    }

    /// Method : showActivityIndicator
    /// Description : This method will be used to show acyivity indecator
    /// Input : none
    ///
    func showActivityIndicator() {

        let center = view.center
        let loadingView = activityIndicator.setLoadingView(center: center)
        view.addSubview(loadingView)
        activityIndicator.spinner.startAnimating()

    }

    /// Method : alertDialog
    /// Description : This method will be used to display the Alert dialog
    ///  Input : The input value is message string
    ///
    func alertDialog(message: String, title: String) {

        let errorAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)

        errorAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        self.present(errorAlert, animated: true, completion: nil)
    }

    /// Method : alertDialogWithFunction
    /// Description : This method will be used to display the Alert dialog
    ///  Input : The input value is message string and title
    ///
    func alertDialogWithFunction(message: String, title: String) {

        let errorAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)

        errorAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
            self.navigationController?.popViewController(animated: true)
        }))
        self.present(errorAlert, animated: true, completion: nil)
    }

    /// Method : validateOldPassword
    /// Description : This method will be used to validate Old Password
    ///
    func validateOldPassword() -> Bool {

        if oldPassword.text != "" {
            if (Validator().validatePasswordLength(password: oldPassword.text!)) {
                oldPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
                return true
            } else {
                oldPassword.awakeForError()
                return false
            }
        } else {
            oldPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
            return false
        }
    }

    /// Method : validateNewPassword
    /// Description : This method will be used to validate new Password
    ///
    func validateNewPassword() -> Bool {

        if newPassword.text != "" {
            guard Validator().validatePasswordLength(password: newPassword.text!), Validator().validateNewPassword(oldPassword: oldPassword.text!, newPassword: newPassword.text!) else {
                newPassword.awakeForError()
                return false
            }
            newPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
            return true
        } else {
            newPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
            return false
        }
    }

    /// Method : validateConfirmPassword
    /// Description : This method will be used to validate confirm Password
    ///
    func validateConfirmPassword() -> Bool {

        if confirmPassword.text != "" {
            if (Validator().validateConfirmPassword(newPassword: newPassword.text!, confirmPassword: confirmPassword.text!)) {
                confirmPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
                print("validate true")
                return true
            } else {
                confirmPassword.awakeForError()
                print("validate false")
                return false
            }
        } else {
            confirmPassword.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
            return false
        }
    }
}

// extension to UITextFieldDelegate
extension ChangePasswordController: UITextFieldDelegate {

    // UITextFieldDelegate Methods

    /// Method : textFieldShouldBeginEditing
    /// Description : This method is overrided to handle the text field input
    ///
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        print("text return")
        if textField.tag == 0 {
            oldPassword.resignFirstResponder()
            newPassword.becomeFirstResponder()
            return false
        } else if textField.tag == 1 {
            newPassword.resignFirstResponder()
            confirmPassword.becomeFirstResponder()
            validateNewPassword()
            return false
        } else if textField.tag == 2 {
            confirmPassword.resignFirstResponder()
            view.endEditing(true)
            originalFrame.origin.y = 64
            self.view.frame = originalFrame
            return false
        }
        return true
    }

    /// Method : textFieldDidEndEditing
    /// Description : This method is overrided to handle the text field input
    ///
    @nonobjc func textFieldDidEndEditing(_ textField: CustomTextField) {

        print("didend")
        //var result = false
        if textField.tag == 0 {
            print("tag 0 match")
            validateOldPassword()
        } else if textField.tag == 1 {
            print("tag 1 match")
            validateNewPassword()
            validateConfirmPassword()
        } else if textField.tag == 2 {
            print("tag 2 match")
            validateConfirmPassword()
        }
        print("didend end")
    }
}
