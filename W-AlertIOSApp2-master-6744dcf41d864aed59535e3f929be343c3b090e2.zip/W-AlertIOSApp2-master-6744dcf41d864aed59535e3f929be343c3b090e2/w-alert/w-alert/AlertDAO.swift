//
//  IAlertDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

protocol AlertDAO {
    
    func insertAlert(alert: AlertDetail) throws -> Int64
    func getAllAlerts() throws -> [Alert]
    func getAlerts(from: Int, limit: Int) throws -> [Alert]
    func getAlert(id: Int64) throws -> AlertDetail
    func deleteAlert(alertId: Int64) throws
    func deleteMultipleAlerts(alertIds: [Int64]) throws
    func deleteAllAlerts() throws
    func deleteAlertTable() throws
    func getTotalNumberOfAlerts() throws -> Int
    func updateAlertStatusToRead(alertId: Int64) throws
    func searchAlert(searchValue: String) throws -> [Alert]
    func searchAlert(searchValue: String , from: Int, limit: Int) throws -> [Alert]
    func getTotalNumberOfSearchAlerts(searchValue: String) throws -> Int
    func getTotalNumberOfUnreadAlerts() throws -> Int
    func recycleAlerts(numberOfAlertsToDelete: Int) throws
}

