//
//  AlertListViewModel.swift
//  w-alert
//
//  Created by Mehak Zia on 2/28/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports

import UIKit

class AlertListViewModel {

    // Variables and Object
    let daoFactory: DAOFactory = SqliteDAOFactory()
    var deviceManagement = DeviceManagement.deviceManagement
    var dictionaryDAOFactory: DAOFactory = DictionaryDAOFactory()
    var deviceTokenDAO: DeviceTokenDAO!
    var subscription: Subscription?
    let alertDecryption = AlertDecryption()
    var alertDAO: AlertDAO!
    var userDao: UserDAO!
    var user: User!
    var selectAll = false
    var numberOfAlerts = 0
    var alertList: [Alert] = [Alert]()
    var alertDetail: AlertDetail!
    var alertOffset = 0
    var alertLimit = Constants.AlertListConfig.NEW_ALERT_LOAD_LIMIT

    /// AlertListViewModel Methods

    init() {
        do {
        alertDAO = try daoFactory.getAlertDAO()
        subscription = try daoFactory.getSubscriptionDAO().getSubscription()
        userDao = try self.daoFactory.getUserDAO()
        deviceTokenDAO = try dictionaryDAOFactory.getDeviceTokenDAO()
        user = try self.userDao.getUserProfile()
        deleteOlderAlerts()
        } catch AlertError.UnableToCreateAlertDAO {
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadAlertDAO)
        } catch SubscriptionError.UnableToCreateSubscriptionDAO {

            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadSubscriptionDAO)
            print(Messages.ERROR_MESSAGES.UnableToReadSubscriptionDAO)
        } catch UserError.UnableToCreateUserDAO {

            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadUserDAO)
            print(Messages.ERROR_MESSAGES.UnableToReadUserDAO)
        } catch UserError.ReadUserRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.ReadUserRecordFail)
            print (Messages.ERROR_MESSAGES.ReadUserRecordFail)
        } catch {

            Logger.log.error("\(Messages.UnexpectedError) \(error)")
            print (error)
        }
    }

    /// Method : deleteSubscription
    /// Description : This method is used to delete Subscription
    ///
    func deleteSubscription() {

        do {

            _ = try daoFactory.getSubscriptionDAO().deleteSubscription()
            Logger.log.info(Messages.INFO_MESSAGES.deleteSubscription)
        } catch SubscriptionError.DeleteSubscriptionRecordFail{

            Logger.log.error("\(Messages.ERROR_MESSAGES.DeleteSubscriptionRecordFail)")
        } catch {

            Logger.log.error("\(Messages.ERROR_MESSAGES.DeleteSubscriptionRecordFail)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            print("\(error)")
        }
    }

    /// Method : getAlert
    /// Description : This method is used to get alerts
    ///
    func getAlert() -> [Alert] {

        do {

            alertList = try alertDAO.getAlerts(from: alertOffset, limit: alertLimit)
            Logger.log.info(Messages.INFO_MESSAGES.ReadAlertFromDB)
        } catch AlertError.ReadAlertsFail {

            Logger.log.error("\(Messages.ERROR_MESSAGES.ReadAlertsFail)")
        } catch {

            Logger.log.error("\(Messages.ERROR_MESSAGES.ReadAlertsFail) \(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
        return decryptAlerts(alertList)
    }

    /// Method : decryptAlert
    /// Description : This method is used to decrypt alert
    /// Output: decrypted alertMessage
    ///
    func decryptAlert(alertMessage: String) -> String {
        Logger.log.info(Messages.INFO_MESSAGES.DecryptAlert)
        return alertDecryption.decryptAlertMessage(alertMessage: alertMessage, encryptionKey: (subscription?.subscriptionKey)!)!
    }

    /// Method : getAlertDetail
    /// Description : This method is used to get alert Detail
    /// Input: alert id
    /// Output: Detail of alert
    ///
    func getAlertDetail(id: Int64) -> AlertDetail {

        do {
            alertDetail = try alertDAO.getAlert(id: id)
            Logger.log.info(Messages.INFO_MESSAGES.ReadAlert)
        } catch AlertError.ReadAlertsWithRangeFail {

            Logger.log.error("\(Messages.ERROR_MESSAGES.ReadAlertsWithRangeFail)")
        } catch {
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
        return alertDetail
    }

    /// Method : getAlertFromSearch
    /// Description : This method is used to get alert from search results
    /// Input: searchText
    /// Output: List of alerts
    ///
    func getAlertFromSearch(searchText: String) -> [Alert] {

        do {
            alertList = try self.alertDAO.searchAlert(searchValue: searchText, from: alertOffset, limit: alertLimit)
            Logger.log.info(Messages.INFO_MESSAGES.ReadAlertFromDB)
        } catch AlertError.SearchAlertWithFilterFail {

            Logger.log.error("\(Messages.ERROR_MESSAGES.SearchAlertWithFilterFail)");

        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
        return decryptAlerts(alertList)
    }

    /// Method : getAlertCount
    /// Description : This method is used to get alert count
    /// Output: total alerts
    ///
    func getAlertCount() -> Int {

        do {
            numberOfAlerts = try alertDAO.getTotalNumberOfAlerts()
        } catch AlertError.CountAlertRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.CountAlertRecordFail);
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
        return numberOfAlerts
    }

    /// Method : getSearchAlertCount
    /// Description : This method is used to get alert count of searched alerts
    /// Output: total searched result
    ///
    func getSearchAlertCount(searchText: String) -> Int {

        do {
            numberOfAlerts = try alertDAO.getTotalNumberOfSearchAlerts(searchValue: searchText)
        } catch AlertError.CountAlertRecordWithFilterFail {
            Logger.log.error(Messages.ERROR_MESSAGES.CountAlertRecordWithFilterFail)
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
        return numberOfAlerts
    }

    /// Method : getAlertOffSet
    /// Description : This method is used to get alert offset
    /// Output: Offset
    ///
    func getAlertOffSet(numberOfDeleteAlerts: Int) -> Int {

        if numberOfDeleteAlerts > self.alertOffset {
            self.alertOffset = 0
        } else {
            self.alertOffset -= numberOfDeleteAlerts
        }
        return alertOffset
    }

    /// Method : getBackgroundColor
    /// Description : This method is used to get background color of alerts
    /// Output: color
    ///
    func getBackgroundColor(type: Bool) -> UIColor {

        if !type {

            return UIColor.init(red: 217.0/255.0, green: 217.0/255.0, blue: 217.0/255.0, alpha: 1)
        }
        return UIColor.white
    }

    /// Method : setReadAlert
    /// Description : This method is used to set readAlert property
    /// Input: alert id
    ///
    func setReadAlert(id: Int64, indexPath: IndexPath) {

        do {
            try alertDAO.updateAlertStatusToRead(alertId: id)
            //alertListViewModel.alertList[indexPath.row].unread = true
            self.alertList[indexPath.row].unread = false
            Logger.log.info(Messages.INFO_MESSAGES.ReadAlertState)
        } catch AlertError.UpdateAlertReadStatusChangeFail {

            Logger.log.error(Messages.ERROR_MESSAGES.UpdateAlertReadStatusChangeFail)
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
    }

    /// Method : signOutAndDisconnect
    /// Description : This method will unregister device, and signOut
    ///
    func signOutAndDisconnect() {

        removeDevice()
    }

    /// Method : signOut
    /// Description : This method will deleteUserPassword, and signOut
    ///
    func signOut() {

        do {

            try self.changeLoggedInState(loggedIn: false)
            try self.deleteUserPassword()
            Logger.log.info(Messages.LoggedOut)
        } catch UserError.UpdateUserLoogedInStateFail {

            Logger.log.error(Messages.ERROR_MESSAGES.UpdateUserLoogedInStateFail)
        } catch UserError.DeleteUserPasswordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.DeleteUserPasswordFail);
            //self.printErrorMessage(errorMessage: "unable to delete database object.")
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
    }

    /// Method : deleteAlertItem
    /// Description : This method is used to delete alert from database
    /// Input: alert id
    ///
    func deleteAlertItem(id: Int64) throws {

        do {
            try self.alertDAO.deleteAlert(alertId: id)
            Logger.log.info(Messages.INFO_MESSAGES.DeleteAlert)
        } catch AlertError.DeleteAlertFail {

            Logger.log.error(Messages.ERROR_MESSAGES.DeleteAlertFail);
            throw AlertError.DeleteAlertFail
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            throw error
        }
    }

    /// Method : deleteMultipleAlert
    /// Description : This method is used to delete alert from database
    /// Input: alert ids
    ///
    func deleteMultipleAlert(alertIds: [Int64]) {

        do {
            try self.alertDAO.deleteMultipleAlerts(alertIds: alertIds)
            Logger.log.info(Messages.INFO_MESSAGES.DeleteAlert)
        } catch AlertError.DeleteMultipleAlertRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.DeleteMultipleAlertRecordFail);
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
    }

    /// Method : deleteOlderAlerts
    /// Description : This method is used to delete older alerts from database
    ///
    func deleteOlderAlerts() {

        do {
            numberOfAlerts = try self.getAlertCount()
            guard numberOfAlerts >= 500 else {
                return
            }
            let numberOfAlertsToDelete = numberOfAlerts - 500
            try alertDAO.recycleAlerts(numberOfAlertsToDelete: numberOfAlertsToDelete)
            numberOfAlerts = try self.getAlertCount()
            Logger.log.info(Messages.INFO_MESSAGES.DeleteAlert)
        } catch AlertError.CountAlertRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.CountAlertRecordFail)
        } catch AlertError.DeleteOlderAlertRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.DeleteOlderAlertRecordFail);
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
    }

    /// Method : refreshAlerts
    /// Description : This method is used to get new alerts from database
    ///
    func refreshAlerts() -> [Alert] {
        var newAlerts = [Alert]()
        do {

            numberOfAlerts = try alertDAO.getTotalNumberOfAlerts()
            let off = alertList.count
            newAlerts = try alertDAO.getAlerts(from: off, limit: alertLimit)

        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
        return decryptAlerts(newAlerts)
    }

    private func decryptAlerts(_ alerts: [Alert]) -> [Alert] {
        for alert in alerts {
            
            alert.alertMessage = decryptAlert(alertMessage: alert.alertMessage)
        }

        return alerts
    }

    /// Method : deleteUserPassword
    /// Description : This method is used to delete user password from database
    ///
    func deleteUserPassword() throws {

        do {
            try self.userDao.deleteUserPassword(id: user.id!)
            Logger.log.info(Messages.INFO_MESSAGES.deletePassword)

        } catch {

            throw error
            //printErrorMessage(errorMessage: "unknown error occure. Because of \(error)")
        }
    }

    /// Method : changeLoggedInState
    /// Description : This method is used to change login property
    /// Input: logged in state
    ///
    func changeLoggedInState(loggedIn: Bool) throws {
        do {

            try self.userDao.updateLoggedInState(id: user.id!, isLoggedIn: loggedIn)
            Logger.log.info(Messages.INFO_MESSAGES.LoggedInStateChange)
        } catch {

            throw error
        }
    }

    /// Method : deleteUserProfile
    /// Description : This method is used to delete user profile from database
    ///
    func deleteUserProfile() throws {
        do {
            try self.userDao.deleteUserProfile(id: user.id!)
            Logger.log.info(Messages.INFO_MESSAGES.deleteProfile)
        } catch {

            throw error
        }
    }

    /// Method : deleteAlertTable
    /// Description : This method is used to delete user profile from database
    ///
    func deleteAlertTable() throws {
        do {
            try self.alertDAO.deleteAlertTable()
            Logger.log.info(Messages.INFO_MESSAGES.DeleteAlertTable)
        } catch {

            throw error
            //printErrorMessage(errorMessage: "unknown error occure. Because of \(error)")
        }
    }

    /// Method : removeDevice
    /// Description : This method is used to remove device
    ///
    func removeDevice() {
        deviceManagement.unRegisterDeviceToken { response in
            if response["response"] == true {
                print("successfully unRegister device")
                do{
                    try self.deleteUserProfile()
                } catch {
                    Logger.log.info("Fail to delete user profile. Because of: \(error)")
                }
                
                do{
                    try self.deleteAlertTable()
                }catch {
                    Logger.log.info("Fail to delete alertTable. Because of: \(error)")
                }

                disconnectMQTTConnection()
                do{
                    try self.deviceTokenDAO.deleteToken()
                }catch{
                    Logger.log.info("Fail to delete device token. Because of: \(error)")
                }
                
                AlertListController.listController?.performSegue(withIdentifier: "goto_login", sender: self)

            } else {
                print(Constants.DEVICE_MANAGEMENT_ERROR_message)

                let signOutFail = UIAlertController(title: Constants.SIGNOUT_AND_DISCONNECT_FAIL_TITLE, message: Constants.SIGNOUT_AND_DISCONNECT_FAIL_MESSAGE, preferredStyle: .alert)
                signOutFail.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                AlertListController.listController?.present(signOutFail, animated: false, completion: nil)
            }
        }
    }

    func getLogFilePath() -> String {

        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let filePath = "\(documentsPath)/w-alertLogs.log"
        print(filePath)
        print("File path loaded.")

        return filePath

    }
}
