//
//  SeverityColor.swift
//  w-alert
//
//  Created by Arqam Amin on 10/28/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation
import UIKit

class SeverityColor {
    
    /// Method : getRGBColor
    /// Description : get RGB according to severity
    /// Input : String
    ///
    static func getRGBColor(fromType: String) -> UIColor {
        switch (fromType) {
        case "low", "Low", "LOW" :
            return UIColor(red:0.27, green:0.49, blue:0.09, alpha:1.0)
        case "high", "High", "HIGH":
            return UIColor(red:1.00, green:0.00, blue:0.01, alpha:1.0)
        default:
            return UIColor(red:1.00, green:0.49, blue:0.01, alpha:1.0)
        }
    }
}

