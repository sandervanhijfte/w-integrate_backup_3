//
//  UpdatePasswordViewModel.swift
//  w-alert
//
//  Created by Mehak Zia on 6/25/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports

import UIKit

class UpdatePasswordViewModel: UIView {
    
    /// Method : updatePassword
    /// Description : update user using Identity and access management api.
    /// Input       : The input param is username, confirmationCode, newPassword
    /// Output      : String flag with status of updatePassword
    ///
    func updatePassword(userName:String, confirmationCode: String, newPassword: String, completionHandler: @escaping (Bool) -> ()) {
    do {
        IdentityandAccessManagement.updatePassword(userName: userName, confirmationCode: confirmationCode, newPassword: newPassword) { (updatePasswordResponse) in
            
            //print(updatePasswordResponse)
    
    if updatePasswordResponse.stringValue == "true" {
    
    Logger.log.debug(Messages.INFO_MESSAGES.PasswordChanged)
    completionHandler(true)
    } else {
    Logger.log.debug(Messages.INFO_MESSAGES.IncorrectCradentials)
    completionHandler(false)
    }
    }
    
    } catch UserError.ReadUserRecordFail {
    
    Logger.log.error(Messages.ERROR_MESSAGES.ReadUserRecordFail)
    completionHandler(false)
    } catch {
    
    Logger.log.error("\(Messages.UnexpectedError)\(error)");
    Logger.log.error(Thread.callStackSymbols);
    completionHandler(false)
    }
    }

}
