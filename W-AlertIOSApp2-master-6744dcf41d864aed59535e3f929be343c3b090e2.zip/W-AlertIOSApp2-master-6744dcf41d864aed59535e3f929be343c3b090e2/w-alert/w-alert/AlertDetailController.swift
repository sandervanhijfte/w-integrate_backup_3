//
//  DetailAlertController.swift
//  w-alert
//
//  Created by Mehak Zia on 28/09/2017.
//  Copyright © 2017 WeIntegrate. All rights reserved.
//  Initial implementation :mehak zia cheema
//

//  imports

import UIKit

class AlertDetailController: UIViewController {

    // Variables and Objects
    @IBOutlet weak var detailAlertView: UIView!
    @IBOutlet weak var detailMessage: UITextView!
    @IBOutlet weak var alertLabel: UILabel!
    @IBOutlet weak var type: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var severty: UILabel!

    var alertDetail: AlertDetail!
    var indexPath: IndexPath?
    weak var delegate: AlertListController!

    let alertDetailViewModel = AlertDetailViewModel()

    override func viewDidLoad() {

        super.viewDidLoad()
        initializeAlertDetailViewModel()
        initializeView()
        presentAlertDetail()

    }

    private func initializeView() {
        detailAlertView.layer.borderColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255).cgColor
        detailAlertView.layer.borderWidth = 1.0
        detailAlertView.layer.masksToBounds = false

        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .trash, target: self, action: #selector(deleteButtonPressed))

        detailMessage.isScrollEnabled = true
    }

    /// Method : getAllertDetail
    /// Description : This method will be used to get alert detail
    /// Input : none
    ///
    private func presentAlertDetail() {

        do {
        try alertDetailViewModel.presentAlertDetailMessage()
        } catch {
            let selectDeleteAlertDialog = UIAlertController(title: "Error", message: Constants.UNABLE_TO_GET_ALERT_DETAIL, preferredStyle: UIAlertControllerStyle.alert)
            selectDeleteAlertDialog.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(selectDeleteAlertDialog, animated: false, completion: nil)
        }
    }

    /// Method : deleteButtonPressed
    /// Description : This method will be used to delete alert
    /// Input : none
    ///
    private func initializeAlertDetailViewModel() {

        alertDetailViewModel.indexPath = indexPath
        alertDetailViewModel.delegate = delegate
        alertDetailViewModel.detailMessage = detailMessage
        alertDetailViewModel.alertLabel = alertLabel
        alertDetailViewModel.type = type
        alertDetailViewModel.time = time
        alertDetailViewModel.date = date
        alertDetailViewModel.severty = severty
    }

    /// Method : deleteButtonPressed
    /// Description : This method will be used to delete alert
    /// Input : none
    ///
    @IBAction func deleteButtonPressed(_ sender: Any) {
        let deleteAlertDialog = UIAlertController(title: "Alert Delete", message: "Are you sure you want to delete?", preferredStyle: UIAlertControllerStyle.alert)
        deleteAlertDialog.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))

        deleteAlertDialog.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) in

            self.alertDetailViewModel.deleteAlert()
            self.navigationController?.popViewController(animated: true)
        }))

        self.present(deleteAlertDialog, animated: false, completion: nil)
    }
}
