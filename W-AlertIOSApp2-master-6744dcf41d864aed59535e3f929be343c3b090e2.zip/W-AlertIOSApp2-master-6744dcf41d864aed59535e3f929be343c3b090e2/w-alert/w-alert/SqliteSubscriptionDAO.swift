//
//  SqliteSubscriptionDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 26/02/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

// imports
import Foundation
import SQLite

class SqliteSubscriptionDAO : SubscriptionDAO {
    
    // Variables and Objects
    private let subscriptionTable = Table("C_ALERT")
    private let C_ID = Expression<Int64>("C_ID")
    private let C_SUBSCRIPTION_ID = Expression<String>("C_SUBSCRIPTION_ID")
    private let C_SUBSCRIPTION_NAME = Expression<String>("C_SUBSCRIPTION_NAME")
    private let C_SUBSCRIPTION_KEY = Expression<String>("C_SUBSCRIPTION_KEY")
    private let C_TOPIC_NAME = Expression<String>("C_TOPIC_NAME")
    private let C_BROKER_URL = Expression<String>("C_BROKER_URL")
    private let C_BROKER_USER_NAME = Expression<String>("C_BROKER_USER_NAME")
    private let C_BROKER_PASSWORD = Expression<String>("C_BROKER_PASSWORD")
    private let dataBase: Connection?
    
    // Methods
    
    /// Method : init
    /// Description : This is constructer method and is use to construct object and create connection between database
    /// Input : void
    ///
    init(connection: Connection?) throws {
        dataBase = connection
        try createTable()
    }
    
    /// Method : createTable
    /// Description : This method will be use to create userDataBase
    /// Input : void
    ///
    func createTable() throws {
        
        do {
            try dataBase?.run(subscriptionTable.create(ifNotExists: true) { table in
                table.column(C_ID, primaryKey: true)
                table.column(C_SUBSCRIPTION_ID)
                table.column(C_SUBSCRIPTION_NAME)
                table.column(C_SUBSCRIPTION_KEY)
                table.column(C_TOPIC_NAME)
                table.column(C_BROKER_URL)
                table.column(C_BROKER_USER_NAME)
                table.column(C_BROKER_PASSWORD)
            })
        } catch {
            throw SubscriptionError.CreateSubscriptionTableFail
        }
    }
    
    /// Method : insert
    /// Description : This method is use to insert subscription to database
    /// Input : void
    ///
    func insert(subscription: Subscription) throws -> Int64 {
        do{
            let insert = self.subscriptionTable.insert(C_SUBSCRIPTION_ID <- subscription.subscriptionId, C_SUBSCRIPTION_NAME <- subscription.subscriptionName, C_SUBSCRIPTION_KEY <- subscription.subscriptionKey, C_TOPIC_NAME <- subscription.topicName, C_BROKER_URL <- subscription.brokerURL, C_BROKER_USER_NAME <- subscription.brokerUserName, C_BROKER_PASSWORD <- subscription.brokerPassword)
            return try dataBase!.run(insert)
        } catch {
            
            throw SubscriptionError.InsertSubscriptionRecordFail
        }
    }
    
    /// Method : getSubscription
    /// Description : This method is use to get subscription from database
    /// Input : void
    ///
    func getSubscription() throws -> Subscription? {
        
        do{
            let subscription = try self.dataBase!.prepare(self.subscriptionTable.order(C_ID.desc))
            for sub in subscription{
                return Subscription(id: sub[C_ID], subscriptionId: sub[C_SUBSCRIPTION_ID], subscriptionName: sub[C_SUBSCRIPTION_NAME], subscriptionKey: sub[C_SUBSCRIPTION_KEY], topicName: sub[C_TOPIC_NAME], brokerURL: sub[C_BROKER_URL], brokerUserName: sub[C_BROKER_USER_NAME], brokerPassword: sub[C_BROKER_PASSWORD])
            }
            return nil
        }
        catch{
            throw SubscriptionError.ReadSubscriptionRecordFail
        }
    }
    
    /// Method : deleteSubscription
    /// Description : This method is use to delete subscription from database
    /// Input : void
    ///
    func deleteSubscription() throws -> Bool {
        do {
            try dataBase!.run(self.subscriptionTable.delete())
            return true
        } catch {
            throw SubscriptionError.DeleteSubscriptionRecordFail
        }
        
    }
    
    
    
}
