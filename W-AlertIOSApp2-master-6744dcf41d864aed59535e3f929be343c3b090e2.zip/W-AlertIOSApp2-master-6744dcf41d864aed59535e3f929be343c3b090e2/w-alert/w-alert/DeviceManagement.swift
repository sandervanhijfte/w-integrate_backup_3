//
//  DeviceManagement.swift
//  w-alert
//
//  Created by Arqam Amin on 25/01/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation
import SwiftyJSON
import Alamofire

class DeviceManagement {
    
    // Variables and Objects
    static let deviceManagement = DeviceManagement()
    let daoFactorry : DAOFactory = SqliteDAOFactory()
    var userDAO: UserDAO!
    var dictionaryDAOFactory: DAOFactory = DictionaryDAOFactory()
    var deviceTokenDAO: DeviceTokenDAO!
    
    // Methods
    
    /// Method : init
    /// Description : This is constructer method and is use to construct object.
    ///
    private init(){
        
        do {
            self.userDAO = try self.daoFactorry.getUserDAO()
            deviceTokenDAO = try! dictionaryDAOFactory.getDeviceTokenDAO()
        } catch {
            
        }
    }
    
    /// Method: registerDeviceToken
    /// Description: This method will register device
    ///
    func registerDeviceToken(_ completion: @escaping (_ dataResponse: DataResponse<Any>) -> Void ) {
        
        guard canRegistrDeviceToken() else {return}
        
        let deviceToken: String! = deviceTokenDAO.getDeviceToken()
        var username: String?
        
        do{
            username  = try self.userDAO.getUserProfile().userName
        } catch {
            return
        }
        
        guard deviceToken != nil, username != nil else { return }
        
        let parameters: Parameters = ["DeviceIdentifier": deviceToken, "OperatingSystemType": "ios", "UserName": username!,"OperatingSystemVersion": "10.3", "EnvironmentType" : "PILOT"]
        let headers = [
            "Content-type": "application/json",
            "Accept": "application/json",
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN
        ]
        
        print(Constants.ENVIRONMENT.DEVICE_TOKEN_REGISTRATION_URL)
        
        Alamofire.request(Constants.ENVIRONMENT.DEVICE_TOKEN_REGISTRATION_URL , method: .post, parameters: parameters as [String: Any], encoding: JSONEncoding.default, headers: headers).responseJSON{ registerDeviceResponse in
            self.deviceTokenDAO.updateOldToken()
            completion(registerDeviceResponse)
        }
    }
    
    //TODO: change unregister api to latest 
    /// Method: unRegisterDeviceToken
    /// Description: This method will unRegister Device Tokens
    /// numberOfAlertsToDelete : number of alerts to delete
    ///
    func unRegisterDeviceToken(_ completion: @escaping (JSON) -> Void ) {

        if  deviceTokenDAO.getDeviceToken() == nil {
            let response = JSON(["response" : true])
            completion(response)
            return
        }
        
        guard let deviceToken = deviceTokenDAO.getDeviceToken() else { return }
        let headers: HTTPHeaders = [
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER,
            "Content-Type": Constants.Content_Type]

        let parameters: Parameters = ["UnregisterDeviceRequest": [
                                                                    "DeviceIdentifiers" : [
                                                                                            "DeviceIdentifier" : deviceToken
                                                                                            ]
                                                                ]
                                        ]

        Alamofire.request(Constants.ENVIRONMENT.UN_REGISTER_DEVICE_URL,
                          method: .post,
                          parameters: parameters as? [String: Any],
                          encoding: JSONEncoding.default,
                          headers: headers).responseJSON{ unRegisterDeviceResponse in

            print(unRegisterDeviceResponse)
                            switch(unRegisterDeviceResponse.result) {
                            case .success:

                                let response = JSON(["response" : true])
                                completion(response)
                            case .failure(let error):
                                if error._code == NSURLErrorTimedOut {
                                    let json = JSON(["error": false])
                                     completion(json)
                                } else {
                                    let json = JSON(["error": false])
                                     completion(json)
                                 }
                            }
        }
    }
    
    /// Method: canRegistrDeviceToken
    /// Description: This method will verify token
    /// numberOfAlertsToDelete : number of alerts to delete
    ///
    private func canRegistrDeviceToken() -> Bool {
        
        guard deviceTokenDAO.getDeviceToken() != nil && deviceTokenDAO.isTokenChanged() else { return false }
        return true
    }
}
