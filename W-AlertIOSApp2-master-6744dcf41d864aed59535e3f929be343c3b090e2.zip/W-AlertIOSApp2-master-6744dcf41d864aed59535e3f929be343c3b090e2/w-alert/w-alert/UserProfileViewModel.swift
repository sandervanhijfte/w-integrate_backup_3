//
//  UserProfileViewModel.swift
//  w-alert
//
//  Created by Mehak Zia on 2/27/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports

import UIKit

class UserProfileViewModel: NSObject {
    
    // Variables and Objects
    let daoFactory : DAOFactory = SqliteDAOFactory()
    var userDAO : UserDAO!
    var userName: String?
    var firstName: String?
    var lastName: String?
    var email: String?
    var user: User?
    
    /// Method : getUser
    /// Description : get user using client management api and view user profile
    ///
    func getUserDao() throws{
        do {
            self.userDAO = try self.daoFactory.getUserDAO()
        } catch {
            
            throw error
        }
    }
    
    /// Method : getUserProfile
    /// Description : This method is use to get user profile
    ///
    func getUserProfile() throws{
        
        do {
            try getUserDao()
            self.user = try self.userDAO.getUserProfile()
        } catch {
            
            throw error
        }
    }
    
    /// Method : getUser
    /// Description : get user using client management api and view user profile
    ///
    func getUser(completionHandler: @escaping (Bool) -> ()) {
        
        do {
            try getUserProfile()
            ClientManagement.getUser(userName: (self.user?.userName)!) { (getUserResponse) in
                print(getUserResponse)
                guard getUserResponse["GetUserResponse"]["Result"]["ResponseCode"].stringValue == Constants.CLIENT_MANAGEMENT_SUCCESS_CODE else {
                    Logger.log.info(Messages.UnexpectedError)
                    completionHandler(false)
                    return
                }
                self.userName = getUserResponse["GetUserResponse"]["User"]["UserName"].stringValue
                self.firstName = getUserResponse["GetUserResponse"]["User"]["PersonalDetail"]["FirstName"].stringValue
                self.lastName = getUserResponse["GetUserResponse"]["User"]["PersonalDetail"]["LastName"].stringValue
                self.email = getUserResponse["GetUserResponse"]["User"]["ContactDetail"][1]["ChannelCode"].stringValue
                
                Logger.log.info(Messages.INFO_MESSAGES.UserProfileReceive)
                completionHandler(true)
            }
        } catch UserError.UnableToCreateUserDAO {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadUserDAO)
            completionHandler(false)
        } catch UserError.ReadUserRecordFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.ReadUserRecordFail);
            completionHandler(false)
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            completionHandler(false)
        }
    }
    
    /// Method : updateUser
    /// Description : get user using client management api
    /// Input : first name, last name, email
    ///
    func updateUser(firstName: String, lastName: String, email: String, completionHandler: @escaping (Bool) -> ()) {
        do
        {
            try ClientManagement.updateUser(userId: (self.user?.userId)!, firstName: firstName, lastName: lastName,email: email, organizationId: (self.user?.organizationId)!, organizationDomain: (self.user?.organizationDomain)!, userName: ((self.user?.userName)!.components(separatedBy: "@")[0])) { (updateUserResponse) in
                guard updateUserResponse.stringValue == "true" else {
                    Logger.log.info(Messages.INFO_MESSAGES.UserProfileNotUpdated)
                    completionHandler(false)
                    return
                    
                }
                self.firstName = firstName
                self.lastName = lastName
                self.email = email
                Logger.log.info(Messages.INFO_MESSAGES.UserProfileUpdated);
                completionHandler(true)
            }
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            completionHandler(false)
        }
    }
}
