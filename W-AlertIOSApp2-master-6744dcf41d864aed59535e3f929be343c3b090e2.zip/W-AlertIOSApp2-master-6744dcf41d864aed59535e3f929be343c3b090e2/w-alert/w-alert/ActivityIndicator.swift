//
//  ActivityIndicator.swift
//  w-alert
//
//  Created by Mehak Zia on 2/27/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports
import UIKit

class ActivityIndicator: NSObject {
    
    // Variables and Objects
    var spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    private var loadingView = UIView()
    
    // Activity indicator methods
    
    /// Method : showActivityIndicator
    /// Description : This method will be used to display the progress spinner
    /// Input : none
    ///
    func setLoadingView(center: CGPoint) -> UIView {
        
        self.loadingView.frame = CGRect(x: 0.0, y: 0.0, width: 50.0, height: 50.0)
        self.loadingView.center = center
        self.loadingView.backgroundColor = UIColor(red: 0.26, green: 0.26, blue: 0.26, alpha: 0.7)
        self.loadingView.alpha = 0.7
        self.loadingView.clipsToBounds = true
        self.loadingView.layer.cornerRadius = 10
        
        self.spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
        self.spinner.frame = CGRect(x: 0.0, y: 0.0, width: 80.0, height: 80.0)
        self.spinner.center = CGPoint(x:self.loadingView.bounds.size.width / 2, y:self.loadingView.bounds.size.height / 2)
        
        self.loadingView.addSubview(self.spinner)
        return loadingView
    }
    
    /// Method : hideActivityIndicator
    /// Description : This method will be used to hide the progress spinner
    /// Input : none
    ///
    func hideActivityIndicator() {
        
        DispatchQueue.main.async() {
            self.spinner.stopAnimating()
            self.loadingView.removeFromSuperview()
        }
    }
    
}
