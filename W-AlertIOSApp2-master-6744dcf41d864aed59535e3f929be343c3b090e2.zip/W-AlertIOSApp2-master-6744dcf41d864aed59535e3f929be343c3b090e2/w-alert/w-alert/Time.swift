//
//  Time.swift
//  w-alert
//
//  Created by Arqam Amin on 10/28/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

class Time {
    // Variables and Objects
    static let DATE_TIME_FORMAT = "yyyy-MM-dd HH-mm-ss.SSS"
    static let calendar = Calendar.current

    
    // Methods
    
    /// Method : getRelativeDateTime
    /// Description : This method will be use to get date or relative time of the alert
    /// Input : String
    ///
    static func getRelativeDateTime(_ dateTime: String) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = DATE_TIME_FORMAT
        //let aDate = dateFormatter.string(from: dateTime)
        let alertDate = dateFormatter.date(from: dateTime)
        
        let alertYear = getYear(alertDate!)
        let alertMonth = getMonth(alertDate!)
        let alertDay = getDate(alertDate!)

        
        let date = Date()
        let currentYear = calendar.component(.year, from: date)
        let currentMonth = calendar.component(.month, from: date)
        let currentDay = calendar.component(.day, from: date)
        
        if (currentDay == Int(alertDay) && currentMonth == Int(alertMonth) && currentYear == alertYear) {
            
            let alertHour = getHour(alertDate!)
            let alertMin = getMinute(alertDate!)
            let alertSec = getSecond(alertDate!)
            
            let currentHour = calendar.component(.hour, from: date)
            let currentMin = calendar.component(.minute, from: date)
            let currentSec = calendar.component(.second, from: date)
            
            
            if (currentHour > Int(alertHour)!) {
                
                return "\(currentHour - Int(alertHour)!) hr ago"
            } else if (currentMin > Int(alertMin)!) {
                return "\(currentMin - Int(alertMin)!) min ago"
            } else {
                return "\(currentSec - Int(alertSec)!) sec ago"
            }
        } else if (currentYear == alertYear) {
            
            return "\(alertMonth)/\(alertDay)"
        }
        
        return "\(alertYear)/\(alertMonth)/\(alertDay)"
    }
    
    static func getYear(_ alertDate: Date) -> Int{
        return calendar.component(.year, from: alertDate)
    }
    
    static func getMonth(_ alertDate: Date) -> String{
        var alertMonth = String(calendar.component(.month, from: alertDate))
        if Int(alertMonth)! < 10 {
            let month = "0\(alertMonth)"
            alertMonth = month
        }
     return alertMonth
    }
    
    static func getDate(_ alertDate: Date) -> String{
        var alertDay = String(calendar.component(.day, from: alertDate))
        if Int(alertDay)! < 10 {
            let day = "0\(alertDay)"
            alertDay = day
        }
        return alertDay
    }
    
    static func getHour(_ alertDate: Date) -> String{
      var alertHour = String(calendar.component(.hour, from: alertDate))
        if Int(alertHour)! < 10 {
            let hour = "0\(alertHour)"
            alertHour = hour
        }
        return alertHour
    }
    
    static func getMinute(_ alertDate: Date) -> String{
        var alertMin = String(calendar.component (.minute, from: alertDate))
        if Int(alertMin)! < 10 {
            let min = "0\(alertMin)"
            alertMin = min
        }
        return alertMin
    }
    
    static func getSecond(_ alertDate: Date) -> String{
        var alertSec = String(calendar.component(.second, from: alertDate))
        if Int(alertSec)! < 10 {
            let sec = "0\(alertSec)"
            alertSec = sec
        }
        return alertSec
    }
    
    /// Method : getTime
    /// Description : This method will be use to get time from date and time
    /// Input : String
    ///
    static func getTime(_ dateTime: String) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = DATE_TIME_FORMAT
        let alertDate = dateFormatter.date(from: dateTime)
        let alertHour = getHour(alertDate!)
        let alertMin = getMinute(alertDate!)
        let alertSec = getSecond(alertDate!)
        return "\(alertHour):\(alertMin):\(alertSec)"
    }
    
    /// Method : getDate
    /// Description : This method will be use to get date from date and time
    /// Input : String
    ///
    static func getDate(_ dateTime: String) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = DATE_TIME_FORMAT
        let alertDate = dateFormatter.date(from: dateTime)
        let alertYear = getYear(alertDate!)
        let alertMonth = getMonth(alertDate!)
        let alertDay = getDate(alertDate!)
        return "\(alertYear)-\(alertMonth)-\(alertDay)"
    }
}

