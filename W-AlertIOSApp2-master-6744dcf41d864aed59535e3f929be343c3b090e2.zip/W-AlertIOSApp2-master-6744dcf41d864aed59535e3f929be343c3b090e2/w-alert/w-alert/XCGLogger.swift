//
//  XCGLogger.swift
//  w-alert
//
//  Created by Mehak Zia on 4/13/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

import Foundation
import XCGLogger

let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]

struct Logger {
    
    static let log: XCGLogger = {
        
        // Create a logger object with no destinations
        let log = XCGLogger(identifier: "WAlertLogger", includeDefaultDestinations: false)
        
        // Create a destination for the system console log (via NSLog)
        let systemDestination = AppleSystemLogDestination(identifier: "WAlertLogger.appleSystemLogDestination")
        
        // Optionally set some configuration options
        systemDestination.outputLevel = .debug
        systemDestination.showLogIdentifier = false
        systemDestination.showFunctionName = true
        systemDestination.showThreadName = true
        systemDestination.showLevel = true
        systemDestination.showFileName = true
        systemDestination.showLineNumber = true
        
        // Add the destination to the logger
        log.add(destination: systemDestination)
        
        // Create a file log destination
        
        let autoRotatingFileDestination = AutoRotatingFileDestination(writeToFile: "\(documentsPath)/w-alertLogs.log", identifier: "WAlertLogger.fileDestination", shouldAppend: true)
        
        autoRotatingFileDestination.outputLevel = .debug
        autoRotatingFileDestination.showLogIdentifier = false
        autoRotatingFileDestination.showFunctionName = true
        autoRotatingFileDestination.showThreadName = true
        autoRotatingFileDestination.showLevel = true
        autoRotatingFileDestination.showFileName = true
        autoRotatingFileDestination.showLineNumber = true
        autoRotatingFileDestination.showDate = true
        autoRotatingFileDestination.targetMaxLogFiles = 10 // probably good for this demo and production, (default is 10, max is 255)
        // Process this destination in the background
        autoRotatingFileDestination.logQueue = XCGLogger.logQueue
        
        // Add colour (using the ANSI format) to our file log, you can see the colour when `cat`ing or `tail`ing the file in Terminal on macOS
        let ansiColorLogFormatter: ANSIColorLogFormatter = ANSIColorLogFormatter()
        ansiColorLogFormatter.colorize(level: .verbose, with: .colorIndex(number: 244), options: [.faint])
        ansiColorLogFormatter.colorize(level: .debug, with: .black)
        ansiColorLogFormatter.colorize(level: .info, with: .blue, options: [.underline])
        ansiColorLogFormatter.colorize(level: .warning, with: .red, options: [.faint])
        ansiColorLogFormatter.colorize(level: .error, with: .red, options: [.bold])
        ansiColorLogFormatter.colorize(level: .severe, with: .white, on: .red)
        autoRotatingFileDestination.formatters = [ansiColorLogFormatter]
        
        // Add the destination to the logger
        log.add(destination: autoRotatingFileDestination)
        
        // Add basic app info, version info etc, to the start of the logs
        log.logAppDetails()
        
        return log
    }()

}
