//
//  SubscriptionDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 26/02/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

protocol SubscriptionDAO {
    
    func insert(subscription: Subscription) throws -> Int64
    func getSubscription() throws -> Subscription?
    func deleteSubscription() throws -> Bool
}
