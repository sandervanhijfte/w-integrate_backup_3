//
//  Name: CustomButton.swift
//  version: 1.0.0
//  Created by: Waqas Ali Razzaq on 9/18/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//imports
import UIKit

class CustomButton: UIButton {
    
    // Methods
    
    /// Method : layoutSubviews
    /// Description : This method will be used to customize the buttons in rectangle shape
    /// Input : none
    ///
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.borderColor = UIColor(white:231 / 256,alpha: 1).cgColor
        self.layer.borderWidth=1
    }
    
    
}
