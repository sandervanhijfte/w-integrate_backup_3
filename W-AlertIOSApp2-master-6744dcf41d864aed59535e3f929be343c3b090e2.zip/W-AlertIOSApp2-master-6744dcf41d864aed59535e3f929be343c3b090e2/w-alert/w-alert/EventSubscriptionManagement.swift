//
//  Name: EventSubscriptionManagement.swift
//  version: 1.0.0
//  Created by: Waqas Ali Razzaq on 10/05/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports

import Foundation
import Alamofire
import SwiftyJSON


class EventSubscriptionManagement {
    
    // Varibles and Objects
    private var subscriptions = [Subscription]()
    
    // Methods
    
    /// Method : getSubscriptionDetail
    /// Description : This method will be used to get the getSubscriptionDetail
    /// Input : UserName, completionHandler
    ///
    class func getSubscriptionDetail(userName: String, organizationId: String, userId: String, completionHandler: @escaping (JSON) -> ()) {
        
        let headers: HTTPHeaders = [
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER
        ]
        let parameters: Parameters = [
            "GetEventSubscriptionRequest": [
                "Header": [
                    "CMMHeader": [
                        "CorrelationId": UUID().uuidString
                    ]
                ],
                "ClientContext": [
                    "OrganizationId": organizationId
                ],
                "UserId": userId
            ]
        ]
        let allowedCharacterSet = CharacterSet(charactersIn: "@").inverted
        let escapedString = userId.addingPercentEncoding(withAllowedCharacters: allowedCharacterSet)
        Alamofire.request(Constants.ENVIRONMENT.GET_SUBSCRIPTION_URL + escapedString!, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
            .responseJSON { getSubscriptionResponse in
                
                print(getSubscriptionResponse)
                switch (getSubscriptionResponse.result) {
                case .success:
                    let json = JSON(getSubscriptionResponse.result.value!)
                    
                    completionHandler(json)
                case .failure(let error):
                    
                    if error._code == NSURLErrorTimedOut {
                        //completionHandler("time out")
                    } else {
                        print("error\(error)")
                    }
                    completionHandler(JSON(getSubscriptionResponse.result.value!))
                }
        }
    }
    
    /// Method : saveSubscriptionDetail
    /// Description : This method will be used to save the SubscriptionDetail in storage
    /// Input : subscription JSON
    ///
    class func saveSubscriptionDetail(subscription: JSON) -> Bool {
        print("subscription\(subscription)")
        let daoFactory: DAOFactory = SqliteDAOFactory()
        
        let responseMapper = ResponseMapper()
        
        guard let subscriptions = responseMapper.mapGetEventSubscriptionResponseToSubscription(subscriptionResponse: subscription) else {
            return false
        }
        
        do {
            let subscriptionDAO = try daoFactory.getSubscriptionDAO()
            
            for subscription in subscriptions {
                _ = try subscriptionDAO.insert(subscription: subscription)
                createMQTTConnection()
            }
        } catch SubscriptionError.UnableToCreateSubscriptionDAO {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadSubscriptionDAO)
        } catch SubscriptionError.InsertSubscriptionRecordFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.InsertSubscriptionRecordFail)
        } catch {
            
            print(error)
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            return false
        }
        return true
    }
}
