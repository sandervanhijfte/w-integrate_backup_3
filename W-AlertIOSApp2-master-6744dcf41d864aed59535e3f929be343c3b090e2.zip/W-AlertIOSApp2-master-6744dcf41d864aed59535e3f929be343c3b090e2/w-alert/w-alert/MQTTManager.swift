//
//  Name: MQTTManager.swift
//  version: 1.0.0
//  Created by: Waqas Ali Razzaq on 10/16/17.
//   Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation
import CocoaMQTT
import UserNotifications
import SwiftyJSON
import XCGLogger

class MQTTManager: NSObject, CocoaMQTTDelegate {

    // Variables and Objects
    // static let sharedInstance = MQTTManager()
    private static var sharedInstance: MQTTManager!
    
    class func getSharedInstance () -> MQTTManager {
        if(MQTTManager.sharedInstance == nil) {
            MQTTManager.sharedInstance = MQTTManager()
        }
        return MQTTManager.sharedInstance
    }
    
    var host: String!
    var port = 0
    var subscriptionDAO: SubscriptionDAO?
    var subscription: Subscription!
    var delegate: MQTTManagerDelegate?
    let daoFactory: DAOFactory = SqliteDAOFactory()
    var alertDAO: AlertDAO!
    var userDAO: UserDAO!

    //TODO: fix hardcode values with response ip
    var mqtt: CocoaMQTT!
    var connected = false {
        didSet {
            delegate?.mqttManagerConnectionChanged(mqttManager: self)
        }
    }

    // Methods

    /// Method : init
    /// Description : This is constructer method and is use to construct object.
    /// Input : id, userId, userNa
    ///
    override init() {

        super.init()
        do {

            alertDAO = try self.daoFactory.getAlertDAO()
            subscriptionDAO = try self.daoFactory.getSubscriptionDAO()
            userDAO = try self.daoFactory.getUserDAO()

            
            mqtt = CocoaMQTT(clientID: UIDevice.current.identifierForVendor!.uuidString, host: setHost(), port: UInt16(setPort()))
        } catch AlertError.UnableToCreateAlertDAO {

            Logger.log.error("Unable to ")
        } catch SubscriptionError.UnableToCreateSubscriptionDAO {

            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadSubscriptionDAO)
        } catch UserError.UnableToCreateUserDAO {

            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadUserDAO)
        } catch SubscriptionError.ReadSubscriptionRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.ReadSubscriptionRecordFail)
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            print(error)
        }
        print("Init MQTT manager")
        mqtt?.keepAlive = 10
        mqtt?.cleanSession = false
        mqtt?.autoReconnect = true
        mqtt?.delegate = self
        if Constants.ENVIRONMENT == Constants.ENVIRONMENT_PILOT {
            do {
                try sslSetting()
            } catch MQTTError.ReadCertificateFileFail {

                Logger.log.error(Messages.ERROR_MESSAGES.ReadCertificateFileFail)
            } catch MQTTError.Certificate_File_Incorrect_Password {

                Logger.log.error(Messages.ERROR_MESSAGES.Certificate_File_Incorrect_Password)
            } catch {

                Logger.log.error("\(Messages.UnexpectedError)\(error)");
                Logger.log.error(Thread.callStackSymbols);
            }
        }
        
        do {
            try connect()
        } catch UserError.ReadUserRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.ReadUserRecordFail)
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
    }
    
    /// Method: sslSetting
    /// Description: Settings ssl connection
    /// - Parameters:
    /// - Returns:
    func sslSetting() throws {

        mqtt.enableSSL = true
        var clientCertArray:CFArray?
        do {

            clientCertArray = try getClientCertFromP12File(certificateFileName: Constants.ENVIRONMENT.CERTIFICATE_FILE_NAME, certificateFilePassword: Constants.ENVIRONMENT.CERTIFICATE_FILE_PASSWORD)
        } catch {

            clientCertArray = nil
            throw error
        }
        var sslSettings: [String: NSObject] = [:]
        sslSettings[kCFStreamSSLCertificates as String] = clientCertArray
        mqtt.sslSettings = sslSettings

    }
    
    /// Method: getClientCertFromP12File
    /// Description: This method will be used to get get Client Certificate From P12 File
    /// - Parameters:
    /// - certificateFileName: Name of certificate file
    /// - certificateFilePassword: Password for certificate file
    /// - Returs:
    /// - certificateArray: Client Certificate
    func getClientCertFromP12File(certificateFileName: String, certificateFilePassword: String) throws -> CFArray? {
        
        // get p12 file path
        
        let resourcePath = Bundle.main.path(forResource: certificateFileName, ofType: "p12")
        
        guard let filePath = resourcePath, let p12Data = NSData(contentsOfFile: filePath) else {
            //Logger.log.error("\(Messages.ERROR_MESSAGES.ReadCertificateFileFail): \(certificateFileName).p12")
            //return nil
            throw MQTTError.ReadCertificateFileFail
        }
        
        // create key dictionary for reading p12 file
        let key = kSecImportExportPassphrase as String
        let options : NSDictionary = [key: certificateFilePassword]
        
        var items : CFArray?
        let securityError = SecPKCS12Import(p12Data, options, &items)
        
        guard securityError == errSecSuccess else {
            if securityError == errSecAuthFailed {
                print("\(Constants.ENVIRONMENT.CERTIFICATE_FILE_PASSWORD_ERROR_MESSAGE)")
                throw MQTTError.Certificate_File_Incorrect_Password
            } else {
                throw MQTTError.ReadCertificateFileFail
                //print("\(Constants.ENVIRONMENT.CERTIFICATE_FILE_ERROR_MESSAGE): \(certificateFileName).p12")
            }
            //return nil
        }
        
        guard let theItemsArray = items, CFArrayGetCount(theItemsArray) > 0 else {
            return nil
        }
        
        let dictionary = (theItemsArray as NSArray).object(at: 0)
        guard let identity = (dictionary as AnyObject).value(forKey: kSecImportItemIdentity as String) else {
            return nil
        }
        let certificateArray = [identity] as CFArray
        
        return certificateArray
    }
    
    /// Method : connect
    /// Description : This method will be used to make the connection with messaging server
    /// Input : NONE
    ///
    func connect() throws {
        do {
            self.subscription = try subscriptionDAO?.getSubscription()
            print(self.subscription.subscriptionName)
            print(self.subscription.topicName)
            let user = try userDAO.getUserProfile()
            guard (try subscriptionDAO?.getSubscription()) != nil else {
                return
            }
            mqtt.clientID = UIDevice.current.identifierForVendor!.uuidString + user.userName
            print(mqtt.connState)
            if mqtt.connState != .connected && mqtt.connState != .connecting {
                mqtt.connect();
                Logger.log.info(Messages.INFO_MESSAGES.Connecting)
                print("MQTT connection state \(mqtt.connState)")
            }
        } catch UserError.ReadUserRecordFail {
            
            print("Unable to get User detail")
            throw UserError.ReadUserRecordFail
        } catch {

            print (error)
            print("Error occurs while connecting mqtt")
            throw error
        }
    }

    /// Method : disconnect
    /// Description : This method will be used to remove the connection with messaging server
    /// Input : NONE
    ///

    func disconnect() throws {
        guard mqtt.connState != .disconnected else {
            Logger.log.info(Messages.INFO_MESSAGES.Disconnected)
            return
        }
        mqtt.clientID = ""
        mqtt.disconnect()
        Logger.log.info(Messages.INFO_MESSAGES.Disconnecting)
        mqtt.subscriptions.removeAll()
        self.subscription = nil
        do {
            guard (try self.daoFactory.getSubscriptionDAO().deleteSubscription()) == true else{
                throw SubscriptionError.DeleteSubscriptionRecordFail
            }
            print(try subscriptionDAO?.getSubscription())
        } catch {
            throw error
        }
    }

    /// Method : setHost
    /// Description : This method will be used to set the messaging server host
    /// Input :  NONE
    /// Output : Host name or IP
    ///
    func setHost() -> String {
        let subscription = try! subscriptionDAO?.getSubscription()
        print(subscription?.topicName as Any)
        let url = subscription!.brokerURL.components(separatedBy: "//")[1]
        host = (url.components(separatedBy: ":")[0])
        return host
    }

    /// Method : setPort
    /// Description : This method will be used to set the messaging server port
    /// Input :  NONE
    /// Output : port
    ///
    func setPort() -> Int {
        if Constants.ENVIRONMENT == Constants.ENVIRONMENT_DEV {
            return Constants.ENVIRONMENT.PORT
        }
        else {
        let subscription = try! subscriptionDAO?.getSubscription()
        print(subscription?.topicName)
        let url = subscription!.brokerURL.components(separatedBy: "//")[1]
        port = Int((url.components(separatedBy: ":")[1]))!
        return port
        }
    }

    /// Method : getAlertFromJson
    /// Description : This method will be used to extract the Alert DTO from JSON
    /// Input :  MQTT Message payload
    /// Output : AlertDTO
    ///
    func getAlertFromJson(alert: JSON) throws -> AlertDetail {

        let alertRecord = alert["Alert"]
        print(alertRecord)
        let timeStamp = alertRecord["TimeStamp"].stringValue
        let severity = alertRecord["Severity"].stringValue
        let alertId = alertRecord["AlertId"].stringValue
        let alertType = alertRecord["AlertType"].stringValue
        let alertTitle = alertRecord["AlertTitle"].stringValue
        let alertMessage = alertRecord["AlertMessage"].string
        let hostName = alertRecord["HostName"].stringValue
        let componentName = alertRecord["ComponentName"].stringValue
        let environmentName = alertRecord["EnvironmentName"].stringValue
        var dateTime : String
        if (timeStamp.isEmpty == false) {
             dateTime = getTimestampInLocalTimeZone(timestamp : timeStamp)
        }
        else {
            dateTime = timeStamp
        }
        if (timeStamp.isEmpty || severity.isEmpty || alertId.isEmpty || alertType.isEmpty || alertTitle.isEmpty || (alertMessage ?? "").isEmpty || hostName.isEmpty || componentName.isEmpty || environmentName.isEmpty) {
            throw MQTTManagerError.NullException
        }
        return AlertDetail(id: 1, alertId: alertId, timeStamp: dateTime, severity: severity, alertType: alertType, alertTitle: alertTitle, alertMessage: alertMessage!, hostName: hostName, componentName: componentName, unread: true, environmentName: environmentName)
    }
    
    func getTimestampInLocalTimeZone(timestamp : String) -> String {
        if (timestamp.count > 23) {
            let time = timestamp.prefix(23)
            let dateTimeString = String(time)
            let timeZone = timestamp.suffix(6)
            let timeZoneOffset = String(timeZone)
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
            
            let dateTime = dateFormatter.date(from: dateTimeString)
            let hoursInOffset = timeZoneOffset[timeZoneOffset.index(timeZoneOffset.startIndex, offsetBy: 1)..<timeZoneOffset.index(timeZoneOffset.startIndex, offsetBy: 3)]
            let hours = Int(hoursInOffset)
            let date = timeZoneOffset.hasPrefix("-") ? dateTime!.addingTimeInterval(TimeInterval(3600*hours!)) : dateTime!.addingTimeInterval(TimeInterval(-3600*hours!))
            let UTCDateString = dateFormatter.string(from: date)
            dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
            let UTCDate = dateFormatter.date(from: UTCDateString)
            dateFormatter.timeZone = TimeZone.current
            
            return dateFormatter.string(from: UTCDate!)
        }
        return timestamp;
    }

}
/// Method : createMQTTConnection
/// Description : Create connection with mqtt.
///
func createMQTTConnection() {

    let mqttManager = MQTTManager.getSharedInstance()
    if mqttManager.mqtt.connState != .connected {
        do {
            try mqttManager.connect()
            Logger.log.info(Messages.INFO_MESSAGES.Connecting)
            print("\nMQTT Connecttion is successfilly establish.\n")
        } catch UserError.ReadUserRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.ReadUserRecordFail)
        } catch SubscriptionError.ReadSubscriptionRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.ReadSubscriptionRecordFail)
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)")
            Logger.log.error(Thread.callStackSymbols)
        }
    }
}


/// Method : disconnectMQTTConnection
/// Description : Disconnect connection with mqtt.
///
func disconnectMQTTConnection() {

    let mqttManager = MQTTManager.getSharedInstance()
    if mqttManager.mqtt.connState == .connected || mqttManager.mqtt.connState == .connecting {
        do {

            try mqttManager.disconnect()
        } catch SubscriptionError.DeleteSubscriptionRecordFail {

            Logger.log.error(Messages.ERROR_MESSAGES.DeleteSubscriptionRecordFail)
        } catch {

            Logger.log.error("\(Messages.UnexpectedError)\(error)")
            Logger.log.error(Thread.callStackSymbols)
        }
    }
}

// CocoaMQTTDelegate Methods
extension MQTTManager {

    /// Method : didConnectAck
    /// Description : This method will be call when connection is acknowledges
    /// Input :  void
    /// Output : void
    ///
    func mqtt(_ mqtt: CocoaMQTT, didConnectAck ack: CocoaMQTTConnAck) {

        //guard subscription != nil else {return }
        if (mqtt.connState == .connected) {

            print(subscription?.topicName as Any)
            subscribeToTopic(topic: (subscription!.topicName))
        }
    }

    /// Method : didReceiveMessage
    /// Description : This method will be call when message is received
    /// Input :  message, id
    /// Output : void
    ///
    @objc(mqtt: didReceiveMessage:id:) func mqtt(_ mqtt: CocoaMQTT, didReceiveMessage message: CocoaMQTTMessage, id: UInt16) {
        let myalert = JSON(data: message.string!.data(using: .utf8)!)

        if (myalert.count != 0) {

            do {

                let alert = try getAlertFromJson(alert: myalert)
                try addAlert(alert)
            } catch AlertError.InserAlertError {

                Logger.log.error(Messages.ERROR_MESSAGES.InserAlertError);
            } catch MQTTManagerError.NullException{

                Logger.log.error(Messages.ERROR_MESSAGES.JSONParsingError);
            } catch {

                Logger.log.error("\(Messages.UnexpectedError)\(error)")
                Logger.log.error(Thread.callStackSymbols)
            }
        } else {

            Logger.log.error(Messages.ERROR_MESSAGES.InvalidAlert)
            print("Invalid alert")
        }
    }

    /// Method : addAlert
    /// Description : This method will add alert in alertList
    /// Input :  alert detail
    /// Output : void
    ///
    private func addAlert(_ alert: AlertDetail) throws {

        let result: Int64
        do {
            try result = alertDAO.insertAlert(alert: alert)
            NotificationRequest.soundNotificationRequest()
            AlertListController.listController?.refreshTableView()
            if (result > 0) {
                print("Alert saved successfully")
                Logger.log.info(Messages.INFO_MESSAGES.AlertSaved)
            }
        } catch {
            print("\(error)")
            throw error
        }
    }

    func mqtt(_ mqtt: CocoaMQTT, didPublishAck id: UInt16) {
    }

    /// Method : didSubscribeTopic
    /// Description : This method will subscribe to topic
    /// Input :  topic
    /// Output : void
    ///
    func mqtt(_ mqtt: CocoaMQTT, didSubscribeTopic topic: String) {
        print("Subscribed to topic: ", topic)
        guard topic != "" else{
            Logger.log.info(Messages.ERROR_MESSAGES.UnableToSubscribe)
            return
        }
        Logger.log.info(Messages.INFO_MESSAGES.Subscribed)
    }
    
    /// Method : didUnsubscribeTopic
    /// Description : This method will unsubscribe to topic
    /// Input :  topic
    /// Output : void
    ///
    func mqtt(_ mqtt: CocoaMQTT, didUnsubscribeTopic topic: String) {

        Logger.log.info(Messages.INFO_MESSAGES.Unsubscribed)
    }
    
    /// Method : mqttDidPing
    /// Description : This method will ping.
    /// Input :  void
    /// Output : void
    ///
    func mqttDidPing(_ mqtt: CocoaMQTT) {
        print("Ping!")
    }
    
    /// Method : mqttDidReceivePong
    /// Description : This method will pong
    /// Input :  void
    /// Output : void
    ///
    func mqttDidReceivePong(_ mqtt: CocoaMQTT) {
        print("Pong!")
        
    }
    
    /// Method : mqttDidDisconnect
    /// Description : disconnected from mqtt
    /// Input :  void
    /// Output : void
    ///
    func mqttDidDisconnect(_ mqtt: CocoaMQTT, withError error: Error?) {
        
        guard error != nil else {

            Logger.log.info(Messages.INFO_MESSAGES.Disconnected)
            return
        }
        Logger.log.error("\(Messages.ERROR_MESSAGES.Disconnected)\(String(describing: error))")
        /*mqtt.subscriptions.removeAll()
        self.subscription = nil*/
    }
    
    /// Method : didConnect
    /// Description : This method connect mqtt
    /// Input :  host, port
    /// Output : void
    ///
    func mqtt(_ mqtt: CocoaMQTT, didConnect host: String, port: Int) {

        Logger.log.info(Messages.INFO_MESSAGES.Connected)
        print("Connected to MQTT server.")
        connected = true
    }
    
    @objc(mqtt:didPublishMessage:id:) func mqtt(_ mqtt: CocoaMQTT, didPublishMessage message: CocoaMQTTMessage, id: UInt16) {
        
    }
    
    
    func mqtt(_ mqtt: CocoaMQTT, didReceive trust: SecTrust, completionHandler: @escaping (Bool) -> Void){
        // TODO: Add certificate validation
        completionHandler(true)
    }
    
    /// Method : subscribeToTopic
    /// Description : This method will subscribeToTopic
    /// Input :  topic
    /// Output : void
    ///
    func subscribeToTopic(topic:String) {
        if mqtt.connState == .connected {
            mqtt.subscribe(topic, qos: CocoaMQTTQOS.qos2)
            Logger.log.info(Messages.INFO_MESSAGES.Connected)
        } else {
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToSubscribe)
        }
        
    }
    
    /// Method : unSubscribeToTopic
    /// Description : This method will unSubscribeToTopic
    /// Input :  topic
    /// Output : void
    ///
    func unSubscribeToTopic(topic :String) {
        if mqtt.connState == .connected {
            Logger.log.info(Messages.INFO_MESSAGES.Connected)
            let unsubscribe = mqtt.unsubscribe(topic)
            Logger.log.info(unsubscribe)
            mqtt.subscriptions.removeAll()
        } else {
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToUnsubscribe)
        }
    }
    
    /// Method : publishToTopic
    /// Description : This method will publish to topic
    /// Input :  void
    /// Output : void
    ///
    func publishToTopic(topic:String, payload:String) {
        
    }
    
    enum MQTTManagerError: Error {
        
        case NullException
    }
}

protocol MQTTManagerDelegate {
    /// Method : mqttManagerConnectionChanged
    /// Description : This method will change connection
    /// Input :  void
    /// Output : void
    ///
    func mqttManagerConnectionChanged(mqttManager:MQTTManager)
}
