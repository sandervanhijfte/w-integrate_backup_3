//
//  VerifyUserController.swift
//  w-alert
//
//  Created by Mehak Zia on 6/13/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports

import UIKit

class VerifyUserController: UIViewController {
    
    // Variables and Objects
    @IBOutlet weak var userNameText: CustomTextField!
    @IBOutlet weak var submitButton: UIButton!
    let verifyUserNameViewModel = VerifyUserViewModel()
    static var listController: VerifyUserController?
    var userName = ""
    
    // VerifyUserController UIViewController Methods
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.userNameText.delegate = self
        userNameText.tag = 0
        submitButton.isEnabled = false
    }
    
    /// Method : UserNAmeTextChanged
    /// Description : this method is use to validate userName when text change.
    ///
    @IBAction func UserNamesTextChanged(_ sender: Any) {
        VerifyUserController.listController = self
        
        if (Validator().validateUserName(userNameText: userNameText)) {
            submitButton.isEnabled = true
            userNameText.awakeFromNib()
        } else {
            submitButton.isEnabled = false
        }
    }
    
    /// Method : UnserNameDoneEditing
    /// Description : This method is use to validate userName when editing is complete.
    ///
    @IBAction func UserNameDoneEditing(_ sender: Any) {
        print("edit1")
        if (Validator().validateUserName(userNameText: userNameText)) {
            submitButton.isEnabled = true
            userNameText.awakeFromNib()
        } else {
            submitButton.isEnabled = false
        }
        
    }
    
    /// Method : UserNameTextChange
    /// Description : this method is use to validate userName when text change.
    ///
    @IBAction func UserNameTextChange(_ sender: Any) {
        print("textChange")
        if (Validator().validateUserName(userNameText: userNameText)) {
            submitButton.isEnabled = true
            userNameText.awakeFromNib()
        } else {
            submitButton.isEnabled = false
        }
    }
    
    /// Method : verifyUserName
    /// Description : This method is use to verify userName
    ///
    @IBAction func verifyUserName(_ sender: Any) {
        self.userName = userNameText.text!
        verifyUserNameViewModel.verifyUserName(userName: userNameText.text!) {
            (verifyUserNameResponse) in
            guard verifyUserNameResponse == true else {
                Logger.log.info(Messages.ERROR_MESSAGES.UnableToVerifyUser)
                self.alertDialog(message: Constants.UNABLE_TO_VERIFY_USER_MESSAGE, title: "Error")
                return
            }
            Logger.log.info(Messages.INFO_MESSAGES.UserVerified)
            let viewController = self.storyboard?.instantiateViewController(withIdentifier: "UpdatePasswordControllerId") as! UpdatePasswordController
            viewController.delegate = self
            self.navigationController?.pushViewController(viewController, animated: false)
        }
    }
    
    /// Method : alertDialog
    /// Description : This method will be used to display the alert
    /// Input : message, title
    ///
    func alertDialog(message: String, title: String) {
        
        let errorAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        errorAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
            
        }))
        self.present(errorAlert, animated: true, completion: nil)
    }
    
    /// Method : cancelButtonPressed
    /// Description : This method will take the user to login screen
    ///
    @IBAction func cancelButtonPressed(_ sender: Any) {
        
        self.performSegue(withIdentifier: "Goto_Login_Screen", sender: self)
    }
    
    /// Method : validateUserName
    /// Description : This method will validate userName
    ///
    func validateUserName() {
        if (Validator().validateUserName(userNameText: userNameText)) {
            submitButton.isEnabled = true
            userNameText.awakeFromNib()
        } else {
            submitButton.isEnabled = false
        }
    }
}

// extension to UITextFieldDelegate
extension VerifyUserController: UITextFieldDelegate {
    
    // UITextFieldDelegate Methods
    
    /// Method : textFieldShouldBeginEditing
    /// Description : This method is overrided to handle the text field input
    ///
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        userNameText.resignFirstResponder()
        return true
    }
    
    /// Method : textFieldDidEndEditing
    /// Description : This method is overrided to handle the text field input
    ///
    @nonobjc func textFieldDidEndEditing(_ textField: CustomTextField) {
        if textField.tag == 0 {
            print("tag 0 match")
            validateUserName()
        }
    }
}


