//
//  Name: CustomTextField.swift
//  version: 1.0.0
//  Created by: Waqas Ali Razzaq on 9/18/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import UIKit

class CustomTextField: UITextField {
    
    //Variables and Objects
    var bottomBorder = UIView()
    
    /// Method : awakeFromNib
    /// Description : This method will be overridden to customize the text field. It will add bottom border and change the colour to white
    /// Input : none
    ///
    override func awakeFromNib() {
        
        // Setup Bottom-Border
        
        self.translatesAutoresizingMaskIntoConstraints = false
        
        bottomBorder = UIView.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        bottomBorder.backgroundColor = UIColor(white:231 / 256,alpha: 1)// Set Border-Color
        bottomBorder.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(bottomBorder)
        
        bottomBorder.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
        bottomBorder.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        bottomBorder.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        bottomBorder.heightAnchor.constraint(equalToConstant: 1).isActive = true // Set Border-Strength
    }
    
    //// Method : awakeForError
    /// Description : This method will be used to customize the text field. It will add bottom border and change the colour to red
    /// Input : none
    ///
    
    func awakeForError() {
        
        // Setup Bottom-Border
        
        self.translatesAutoresizingMaskIntoConstraints = false
        
        bottomBorder = UIView.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        bottomBorder.backgroundColor = UIColor(white:231 / 256,alpha: 1)// Set Border-Color
        bottomBorder.translatesAutoresizingMaskIntoConstraints = false
        bottomBorder.backgroundColor = UIColor.red
        
        addSubview(bottomBorder)
        
        bottomBorder.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
        bottomBorder.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        bottomBorder.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        bottomBorder.heightAnchor.constraint(equalToConstant: 1).isActive = true // Set Border-Strength
    }
}
