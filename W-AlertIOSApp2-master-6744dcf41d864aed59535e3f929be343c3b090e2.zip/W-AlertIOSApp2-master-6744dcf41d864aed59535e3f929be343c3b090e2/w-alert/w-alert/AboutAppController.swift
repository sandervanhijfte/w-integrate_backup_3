//
//  AboutWAlertController.swift
//  w-alert
//
//  Created by WeIntegratemac01 on 28/09/2017.
//  Copyright © 2017 WeIntegrate. All rights reserved.
//  Initial implementation :mehak zia cheema
//

//  imports
import UIKit

class AboutAppController: UIViewController {
    
    @IBOutlet weak var appVersion: UILabel!
    let aboutAppViewModel = AboutAppViewModel()
    weak var delegate: AlertListController!
    
    override func viewDidLoad() {
        appVersion.text = "v-\(aboutAppViewModel.getVersionNumber())"
        //alertDetailViewModel.delegate = delegate
    }
}
