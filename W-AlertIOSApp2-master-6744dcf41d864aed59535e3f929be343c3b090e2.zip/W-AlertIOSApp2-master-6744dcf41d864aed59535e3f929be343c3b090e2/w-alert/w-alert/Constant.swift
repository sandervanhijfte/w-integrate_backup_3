//
//  Constant.swift
//  Created by: Waqas Ali Razzaq on 9/15/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//
//  Update Change password message : Mehak Zia on 9/28/18
//


//  imports
import Foundation

struct Constants {
    
    struct AlertListConfig{
        static let NEW_ALERT_LOAD_LIMIT = 20
    }
    
    static let ENVIRONMENT = ENVIRONMENT_PILOT.self
    
    struct ENVIRONMENT_DEV {
        
        static let ENVOIRNMENT = "http://213.187.243.177:8281"          //dev.w-alert.com
 
        static let HOST = "213.187.243.177"
        
        static let PORT = 1883
 
        static let CERTIFICATE_FILE_NAME         = "ssl-bundle-pilot"
        
        static let CERTIFICATE_FILE_PASSWORD     = "l1f09bscs0051"
        
        static let CERTIFICATE_FILE_ERROR_MESSAGE = "Failed to open the certificate file"
        
        static let CERTIFICATE_FILE_PASSWORD_ERROR_MESSAGE = "ERROR: SecPKCS12Import returned errSecAuthFailed. Incorrect password?"
        
        static let ACCESS_TOKEN = "Bearer 4d2f3def-4cf0-3c80-8291-98afc246a725"
        
        static let AUTHENTICATE_USER_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/authenticate"
        
        static let REGISTER_DEVICE_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/registerdevice"

        static let UN_REGISTER_DEVICE_URL = "\(ENVOIRNMENT)/wealert/device/1.0/devicemanagement_01/devices/unregister"
        
        static let UNSUBSCRIBE_USER_URL = "\(ENVOIRNMENT)/wealert/device/1.0/devicemanagement_01/users/"
        
        static let GET_USER_URL = "\(ENVOIRNMENT)/wealert/client/1.0/clientmanagement_01/users"
        
        static let GET_SUBSCRIPTION_URL = "\(ENVOIRNMENT)/wealert/subscription/1.0/eventsubscriptionmanagement_01/eventsubscriptions/"
        
        static let UPDATE_USER_URL = "\(ENVOIRNMENT)/wealert/client/1.0/clientmanagement_01/users"
        
        static let CHANGE_PASSWORD_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/changepassword"
        
        static let DEVICE_TOKEN_REGISTRATION_URL = "\(ENVOIRNMENT)/wealert/device/1.0/devicemanagement_01/devices"
        
        static let VERIFY_USERNAME_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/verifyusername"
        
        static let UPDATE_PASSWORD_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/updatepassword"
    }
    

    struct ENVIRONMENT_PILOT {
        
        static let ENVOIRNMENT = "https://pilot.w-alert.com"
        
        static let HOST = "185.3.211.68"
        
        static let PORT = 1885
        
        static let CERTIFICATE_FILE_NAME         = "ssl-bundle-pilot"
        
        static let CERTIFICATE_FILE_PASSWORD     = "l1f09bscs0051"
        
        static let CERTIFICATE_FILE_ERROR_MESSAGE = "Failed to open the certificate file"
        
        static let CERTIFICATE_FILE_PASSWORD_ERROR_MESSAGE = "ERROR: SecPKCS12Import returned errSecAuthFailed. Incorrect password?"
        
        static let ACCESS_TOKEN = "Bearer 24f7f52a-758a-30ac-9d24-1343ab3ba2bc"
        
        static let AUTHENTICATE_USER_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/authenticate"
        
        static let REGISTER_DEVICE_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/registerdevice"
        
        static let UN_REGISTER_DEVICE_URL = "\(ENVOIRNMENT)/wealert/device/1.0/devicemanagement_01/devices/unregister"
        
        static let UNSUBSCRIBE_USER_URL = "\(ENVOIRNMENT)/wealert/device/1.0/devicemanagement_01/users/"
        
        static let GET_USER_URL = "\(ENVOIRNMENT)/wealert/client/1.0/clientmanagement_01/users"
        
        static let GET_SUBSCRIPTION_URL = "\(ENVOIRNMENT)/wealert/subscription/1.0/eventsubscriptionmanagement_01/eventsubscriptions/"
        
        static let UPDATE_USER_URL = "\(ENVOIRNMENT)/wealert/client/1.0/clientmanagement_01/users"
        
        static let CHANGE_PASSWORD_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/changepassword"
        
        static let DEVICE_TOKEN_REGISTRATION_URL = "\(ENVOIRNMENT)/wealert/device/1.0/devicemanagement_01/devices"
        
        static let VERIFY_USERNAME_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/verifyusername"
        
        static let UPDATE_PASSWORD_URL = "\(ENVOIRNMENT)/wealert/iam/1.0/identityandaccessmanagement_01/users/updatepassword"
        
    }
    
    //static let TIME_OUT: Double = 30 //seconds
    
    static let ACCEPT_HEADER                 =  "application/json"
    
    static let Content_Type                  =  "application/json"

    // Response code
    
    static let DEVICE_MANAGEMENT_SUCCESS_CODE = "DM-N-0000"
    
    static let DEVICE_MANAGEMENT_ERROR_CODE   = "DM-W-0001"
    
    static let EVENT_SUBSCRIPTION_SUCCESS_CODE = "ESM-N-0000"
    
    static let CLIENT_MANAGEMENT_SUCCESS_CODE = "CM-N-0000"
    
    static let CLIENT_MANAGEMNET_ERROR_CODE   = "CM-W-0001"
    
    static let CLIENT_MANAGEMENT_ERRORR_CODE   = "CM-E-9999"
    
    static let IDENTITY_AND_ACCESS_MANAGEMENT_SUCCESS_CODE = "IAM-N-0000"
    
    static let IDENTITY_AND_ACCESS_MANAGEMENT_ERROR_CODE = "IAM-E-9999"

    //  Messages

    static let DEVICE_MANAGEMENT_ERROR_message  = "Device not found. Unable to unregister iOS device, contact your administrator."

    static let SEARCH_RECORD_ERROR            = "Unable to search records with keywords." 
    
    static let LOAD_MORE_ERROR                = "Unable to load more Alerts."
    
    static let CREATE_DATABASE_ERROR          = "Unable to create database object."
    
    static let SEARCH_HELP_DIALOG_TITLE       = "Search Criteria"
    
    static let SEARCH_HELP_DIALOG_MESSAGE     = "Search is working on:\nTitle, Severity, Alert type, Component name, Date/time.\n\n*Search on message detail is coming soon."
    
    static let SELECT_DELETE_ALERT_MESSAGE    = "No alerts selected. Please select an alert first."
    
    static let DELETE_ALERT_MESSAGE           = "Are you sure you want to delete?"
    
    static let READ_ALERT_ERROR               = "error occur while get all records."
    
    static let READ_ALERT_COUNT_ERROR         = "error occur while get records count."
    
    static let UN_EXPECTED_ERROR              = "unknown error occur."
    
    static let REFRESH_CONTROL_MESSAGE        = ""
    
    static let PROFILE_UPDATED_MESSAGE        = "Profile updated successfully."
    
    static let USER_LOGIN_STATE               = "Unable to check if user is already signed in."
    
    static let DATABASE_ERROR                 = "Unable to open database"
    
    static let INSERT_SUBSCRIPTION_ERROR      = "Insert subscription failed"
    
    static let GET_SUBSCRIPTION_ERROR         = "Select subscription failed"
    
    static let OPERATING_SYSTEM_TYPE          = "ios"

    static let REGISTER_DEVICE_MESSAGE       =  "Your device has been registered."

    static let REGISTER_DEVICE_ERROR_MESSAGE =  "Unable to login because the user is not assigned to any group."

    static let REGISTER_DEVICE_NOTIFICATION_ERROR_MESSAGE =  "Unable to register the iOS device."

    static let Subscription_MESSAGE          =  "Successfully receive user subscription"
    
    static let Subscription_ERROR_MESSAGE    =  "Unable to get user subscription"

    static let USER_NAME_PLACEHOLDER         =  "Please enter the username"

    static let PASSWORD_PLACEHOLDER          =  "Please enter the password"

    static let LOGIN_ERROR_MESSAGE           =  "Username or Password is incorrect. Please try again."

    static let UNEXPECTED_ERROR_MESSAGE      =  "Unexpected error has occurred. Please try again."

    static let SERVICE_UNAVAILABLE_MESSAGE   =  "Unable to connect to backend Service. Please try again"
    
    static let FALSE_TOKEN_MESSAGE           =  "Please enter correct token"

    static let CONTACT_ADMINISTRATOR_MESSAGE =  " or contact your administrator."

    static let USER_NOT_FOUND_MESSAGE        =  "Unable to get user details."

    static let USER_UPDATE_SUCCESSFULLY_MESSAGE = "Profile updated successfully."

    static let VALID_DATA_MESSAGE            = "Please enter valid Data."

    static let FILL_REQUIRED_FIELDS          = "Please enter required fields."

    static let SIGN_OUT_TITLE                = "Are you sure you want to sign out?"

    static let SIGN_OUT_MESSAGE              = "Please note that you will continue to receive alerts. If you do not wish to receive alerts, press the disconnect device button."

    static let DISCONNECT_AND_SIGN_OUT_MESSAGE = "All alerts stored in the database will be deleted. You will not receive any new alerts. Any alerts generated during the disconnection period will be lost."

    static let FIRST_NAME_MESSAGE            = "It must only consist of alphabets. Only hyphens are allowed, no other special characters are allowed."

    static let lAST_NAME_MESSAGE             = "It must consist of alphabets. Only hyphens and space are allowed, no other special characters are allowed."

    static let EMAIL_MESSAGE                 = "1. It can be alpha numeric data. 2. Only full stops, hyphens, underscores & one \"@\" must be allowed, no other special characters are allowed."

    static let OK                            = "OK"

    static let CANCEL                        = "Cancel"

    static let DISCONNECT_AND_SIGN_OUT       = "Disconnect & Sign Out"

    static let SIGN_OUT                      = "Sign Out"

    static let CHANGE_PASSWORD_MESSAGE       =  "Password changed successfully."

    static let UNABLE_TO_CHANGE_PASSWORD_MESSAGE =  "Unable to change password. Please try again or contact your administrator."
    static let UNABLE_TO_VERIFY_USER_MESSAGE =  "Unable to verify user. Please try again or contact your administrator."

    static let BACKEND_SERVICE_NOT_RESPONDING_MESSAGE =  "Backend service is not responding at the moment. Please try again or contact your system administrator."

    static let OLD_PASSWORD_MESSAGE          = "Password must contain at least 8 characters including upper-case, lower-case, special characters and numbers."

    static let NEW_PASSWORD_MESSAGE          = "1. Passwords may contain letters (A-Z, a-z), numbers (0-9) and punctuation marks ( !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~). 2. The new password cannot be the same as the old password."

    static let CONFIRM_PASSWORD_MESSAGE      = "Must be the same as the new password."
    
    static let CONFIRMATION_CODE_MESSAGE     = "1. The confirmation code must contain 36 letters. 2. The confirmation code may contain letters (a-z), numbers (0-9) and hypens (-). 3. It must follow (XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX) pattern."
    
    static let NOTIFICATION_ENABLE_DIALOG_MESSAGE = "To receive real-time notifications please enable notifications\nGo to Settings > W-Alert > Notifications > Allow Notification > true"
    
    static let NOTIFICATION_ENABLE_DIALOG_TITLE = "Notification Alert"

    static let SIGNOUT_AND_DISCONNECT_FAIL_TITLE = ""

    static let SIGNOUT_AND_DISCONNECT_FAIL_MESSAGE = "Unable to disconnect with the server, please try again."
    
    static let SUPPORT_EMAIL_ADDRESS = "support.w-alert@w-integrate.nl"
    
    static let LOG_FILE_EMAIL_SUBJECT = "W-Alert iOS App Report"
    
    static let LOG_FILE_EMAIL_MESSAGE = "Please find the attached log file."
    
    static let UNABLE_TO_GET_ALERT_DETAIL = "Unable to retrieve alert details. Please try again or contact your administrator."
    
    static let UNABLE_TO_Delete_ALERT = "Unable to delete alerts. Please try again."
    
    static let DISCARD_CHANGES_DIALOG_MESSAGE = "Are you sure you want to discard changes?"
    
    static let SAVE_PROFILE_CONFIRMATION_DIALOG_MESSAGE = "Are you sure you want to save changes?"
    
    static let YES = "Yes"
    
    static let NO = "No"
    
    static let RELOAD_VISIBLE_ALERTS_TIME_INTERVAL = 5
}
