//
//  Name: Validator.swift
//  version: 1.0.0
//  Created by: Waqas Ali Razzaq on 9/19/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//
//  Update LastName Regex : Mehak Zia on 9/28/18
//  Updated username validation regex : Maira Tul Islam - 10/12/2018
//

//  imports
import Foundation
import UIKit

class Validator {
    
    // Validator methods
    
    /// Method : validateUserName
    /// Description : This method will be used to validate the user name
    /// Input : The input params are username
    ///
    public func validateUserName(userNameText: CustomTextField) -> Bool{
        
        var valid:Bool = true
        if (userNameText.text?.isEmpty)! {
            
            userNameText.attributedPlaceholder = NSAttributedString(string: Constants.USER_NAME_PLACEHOLDER, attributes: [NSForegroundColorAttributeName: UIColor.red])
            valid = false
            userNameText.awakeForError()
            userNameText.shake()
        } else {
            valid = validateEmail(email: userNameText.text!)
            if (!valid) {
                
                userNameText.awakeForError()
                userNameText.shake()
            }
        }
        return valid
    }
    
    /// Method : validatePassword
    /// Description : This method will be used to validate the password
    /// Input : The input params are password
    ///
    public func validatePassword(passwordText: CustomTextField) -> Bool{
        
        if ((passwordText.text?.isEmpty)! || (passwordText.text!.characters.count)<3) {
            
            passwordText.attributedPlaceholder = NSAttributedString(string: Constants.PASSWORD_PLACEHOLDER, attributes: [NSForegroundColorAttributeName: UIColor.red])
            passwordText.awakeForError()
            passwordText.shake()
            return false
        }
        return true
    }
    
    /// Method : validatePasswordLength
    /// Description : This method will be used to validate the length of password
    /// Input : The input params are password
    ///
    func validatePasswordLength(password: String) -> Bool {
        
        return password.characters.count >= 8
    }
    
    /// Method : validateOldPassword
    /// Description : This method will be used to validate the old password
    /// Input : The input value is password string
    ///
    func validateOldPassword(password:String) -> Bool {
        return password.characters.count >= 8
    }
    
    /// Method : validateNewPassword
    /// Description : This method will be used to validate the new Password
    /// Input : The input value is password string
    ///
    func validateNewPassword(oldPassword: String, newPassword: String) -> Bool {
        if(newPasswordValidate(password: newPassword)) {
            return oldPassword != newPassword
        }
        return false
    }
    
    /// Method : validateNewPassword
    /// Description : This method will be used to validate the new Password
    /// Input : The input value is password string
    ///
    func newPasswordValidate(password:String) -> Bool {
        
        print ("validating regex")
        //let passwordRegEx = "^\\p{Graph}*$"
        let passwordRegEx = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#%^&*+=():;<>?/{}|\\[\\]]).{8,}$"
        //let passwordRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*():;<>?/+={}[]|]).{8,}$"
        let passwordString = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
        let result = passwordString.evaluate(with: password)
        return result
    }
    
    /// Method : validateConfirmPassword
    /// Description : This method will be used to validate the new Password
    /// Input : The input value is password string
    ///
    func validateConfirmPassword(newPassword:String, confirmPassword: String) -> Bool {
        
        return newPassword == confirmPassword
    }
    
    /// Method : validateEmail
    /// Description : This method will be used to validate the email
    /// Input : The input value is message string
    ///
    func validateEmail(email:String) -> Bool {
        
        let emailRegEx = "^[a-z0-9]{5,50}@(?=[a-z0-9-_]{2,43})([a-z0-9]+([_-][a-z0-9]+)*)\\.(?=[a-z\\.]{2,6}$)(([a-z][a-z])[a-z]*([\\.][a-z][a-z]+)*)$"
        let emailString = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailString.evaluate(with: email)
        return result
    }
    
    /// Method : validateFirstName
    /// Description : This method will be used to validate the firstName
    /// Input : The input value is message string
    ///
    func validateFirstName(firstName: String) -> Bool {
        let firstNameRegEx = "[a-zA-Z-]*"
        let firstNameString = NSPredicate(format:"SELF MATCHES %@", firstNameRegEx)
        let result = firstNameString.evaluate(with: firstName)
        return result
    }
    
    /// Method : validateLastName
    /// Description : This method will be used to validate the LastName
    /// Input : The input value is message string
    ///
    func validateLastName(lastName: String) -> Bool {
        
        guard lastName.count < 20 else {
            
            return false
        }
        let lastNameRegEx = "^([a-zA-Z-]+( [a-zA-Z-]+)*)$"
        let lastNameString = NSPredicate(format:"SELF MATCHES %@", lastNameRegEx)
        let result = lastNameString.evaluate(with: lastName)
        return result
    }
    
    /// Method : validateEmail
    /// Description : This method will be used to validate the email
    /// Input : The input value is message string
    ///
    func validatePasswordString(password:String) -> Bool {
        
        let passwordRegEx = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$"
        let passwordString = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
        let result = passwordString.evaluate(with: password)
        return result
    }
    
    /// Method : validateConfirmationCode
    /// Description : This method will be used to validate the confirmation code.
    /// Input : The input value is message string
    ///
    func validateConfirmationCode(code:String) -> Bool {
        let codeRegEx = "^[a-z0-9]{8}[-][a-z0-9]{4}[-][a-z0-9]{4}[-][a-z0-9]{4}[-][a-z0-9]{12}$"
        let codeString = NSPredicate(format:"SELF MATCHES %@", codeRegEx)
        let result = codeString.evaluate(with: code)
        return result
    }
}
