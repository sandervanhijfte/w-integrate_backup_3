//
//  ChangePasswordViewModel.swift
//  w-alert
//
//  Created by Mehak Zia on 2/27/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports

import UIKit

class ChangePasswordViewModel {
    
    // Variables and Objects
    let daoFactorry: DAOFactory = SqliteDAOFactory()
    var newPassword = ""
    var oldPassword = ""
    var userDAO: UserDAO!
    var user: User!
    
    weak var oldPasswordTextField: CustomTextField!
    weak var newPasswordTextField: CustomTextField!
    weak var confirmPassword: CustomTextField!
    
    
    init() {
        do {
            
            self.userDAO = try self.daoFactorry.getUserDAO()
        } catch UserError.UnableToCreateUserDAO {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadUserDAO)
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
        
    }
    
    /// Method : changeUserPassword
    /// Description : This function is use to change user password from database
    ///
    func changeUserPassword(userId: Int64) {
        
        do {
            
            try self.userDAO.insertUserPassword(id: userId, userPassword: newPassword)
            Logger.log.info(Messages.INFO_MESSAGES.InsertUserPassword)
        } catch UserError.UpdateUserPasswordFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UpdateUserPasswordFail)
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
    }
    
    /// Method : changePassword
    /// Description : This function is use to change user password using identity and access management
    /// Input: oldPassword, newPassword
    ///
    func changePassword(oldPassword: String, newPassword: String, completionHandler: @escaping (Bool) -> ()) {
        
        do {
            user = try userDAO.getUserProfile()
            
            let userName = user.userName
            let userId = user.id
            IdentityandAccessManagement.changePassword(userName: userName, oldPassword: oldPassword, newPassword: newPassword, completionHandler: { (changePasswordResponse) in
                
                if changePasswordResponse.stringValue == "true" {
                    
                    self.changeUserPassword(userId: userId!)
                    Logger.log.info(Messages.INFO_MESSAGES.PasswordChanged)
                    completionHandler(true)
                } else {
                    Logger.log.info(Messages.INFO_MESSAGES.IncorrectCradentials)
                    completionHandler(false)
                }
            })
            
        } catch UserError.ReadUserRecordFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.ReadUserRecordFail)
            completionHandler(false)
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            completionHandler(false)
        }
    }
    
    /// Method : validateOldPassword
    /// Description : This function is use to validate user old password
    /// Input: oldPassword, newPassword
    ///
    func validateOldPassword(oldPassword: String) -> Bool {
        
        return oldPassword == "" || Validator().validatePasswordLength(password: oldPassword)
    }
}
