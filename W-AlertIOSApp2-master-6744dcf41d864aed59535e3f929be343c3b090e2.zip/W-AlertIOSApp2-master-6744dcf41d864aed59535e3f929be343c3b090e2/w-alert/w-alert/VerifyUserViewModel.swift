//
//  VerifyUserViewModel.swift
//  w-alert
//
//  Created by Mehak Zia on 6/23/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports

import UIKit

class VerifyUserViewModel {
    
    /// Method : verifyUserName
    /// Description : verify user using Identity and access management api.
    /// Input       : The input param is username
    /// Output      : String flag with status of verifyUserName
    ///
    func verifyUserName(userName: String, completionHandler: @escaping (Bool) -> ()) {
        
        
        IdentityandAccessManagement.verifyUserName(userName: userName) { (verifyUserNameResponse) in
            //print(verifyUserNameResponse)
            //print(verifyUserNameResponse["VerifyUsernameResponse"]["Result"]["ResponseCode"].stringValue)
            guard verifyUserNameResponse.boolValue == true else {
                Logger.log.error(Messages.ERROR_MESSAGES.UnableToVerifyUser)
                completionHandler(false)
                return
            }
            
            Logger.log.debug(Messages.INFO_MESSAGES.UserVerified)
            completionHandler(true)
        }
    }
    
}
