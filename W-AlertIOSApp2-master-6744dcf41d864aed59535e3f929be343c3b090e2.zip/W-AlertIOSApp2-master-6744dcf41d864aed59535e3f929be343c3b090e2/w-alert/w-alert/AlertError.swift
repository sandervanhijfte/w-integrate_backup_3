//
//  AlertError.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

enum WeAlertError : Error{
    
}

/// Enum : AlertError
/// Description : Errors for alert
///
enum AlertError : Error {
    case UnableToCreateConnection
    case CreateAlertTableFail
    case InserAlertError
    case ReadAlertsFail
    case DeleteAlertFail
    case DeleteMultipleAlertRecordFail
    case DeleteOlderAlertRecordFail
    case CountAlertRecordFail
    case ReadAlertsWithRangeFail
    case SearchAlertWithFilterFail
    case SearchAlertWithFilterRangeFail
    case CountAlertRecordWithFilterFail
    case UpdateAlertReadStatusChangeFail
    case CountUnreadAlertRecordFail
    case UnableToCreateAlertDAO
}

/// Enum : UserError
/// Description : Errors for user
///
enum UserError : Error {
    case CreateUserTableFail
    case InsertUserRecordFail
    case CountNumberOfUserRecordFail
    case DeleteUserRecordFail
    case UpdateUserPasswordFail
    case DeleteUserPasswordFail
    case ReadUserRecordFail
    case DeleteAllUserProfile
    case DeleteUserTableFail
    case UpdateUserLoogedInStateFail
    case UnableToCreateUserDAO
}
