//
//  AlertListTableViewCell.swift
//  w-alert
//
//  Created by WeIntegratemac01 on 20/09/2017.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import UIKit

class AlertListTableViewCell: UITableViewCell {
    
    // Variables and Objects
    @IBOutlet weak var AgentName: UILabel!
    @IBOutlet weak var ErrorMessage: UILabel!
    @IBOutlet weak var AlertTime: UILabel!
    @IBOutlet weak var servityColor: UILabel!
    
    //Methods
    
    /// Method : awakeFromNib
    /// Description : This method will be used to
    /// Input : none
    ///
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
