//
//  Contact.swift
//  SQLiteApp
//
//  Created by deivitaka on 3/28/16.
//
//

//  imports
import Foundation

class User {
    
    // Variables and Objects
    let id: Int64?
    var userId: String
    var userName: String
    var password: String
    var status: String
    var firstName: String
    var lastName: String
    var mobileNo: String
    var email: String
    var roleId: String
    var organizationId: String
    var organizationName: String
    var organizationDomain:String
    var isLoggedIn:Bool
    
    // Methods
    
    /// Method : init
    /// Description : This is constructer method and is use to construct object.
    /// Input : id
    ///
    init(id: Int64) {
        
        self.id = id
        userId = ""
        userName = ""
        password = ""
        status = ""
        firstName = ""
        lastName = ""
        mobileNo = ""
        email = ""
        roleId = ""
        organizationId = ""
        organizationName = ""
        organizationDomain = ""
        isLoggedIn = false
    }
    
    /// Method : init
    /// Description : This is constructer method and is use to construct object.
    /// Input : id, userId, userNa
    ///
    init(id: Int64, userId: String, userName: String, password: String, status: String,firstName: String, lastName: String, mobileNo: String, email: String, roleId: String, organizationId: String, organizationName: String, organzationDomain: String, isLoggedIn: Bool) {
        
        self.id = id
        self.userId = userId
        self.userName = userName
        self.password = password
        self.status = status
        self.firstName = firstName
        self.lastName = lastName
        self.mobileNo = mobileNo
        self.email = email
        self.roleId = roleId
        self.organizationId = organizationId
        self.organizationName = organizationName
        self.organizationDomain = organzationDomain
        self.isLoggedIn = isLoggedIn
    }
}

