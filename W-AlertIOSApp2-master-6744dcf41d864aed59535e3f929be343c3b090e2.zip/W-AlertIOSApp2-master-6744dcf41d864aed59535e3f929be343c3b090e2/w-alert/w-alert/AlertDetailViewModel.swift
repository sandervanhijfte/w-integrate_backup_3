//
//  alertDetailViewModel.swift
//  w-alert
//
//  Created by Mehak Zia on 2/26/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports

import UIKit
import  XCGLogger

class AlertDetailViewModel {

    let daoFactory: DAOFactory = SqliteDAOFactory()
    var alertDAO: AlertDAO!
    weak var delegate: AlertListController!
    var indexPath: IndexPath?
    var alertDetail: AlertDetail!
    var subscription: Subscription?
    let alertDecryption = AlertDecryption()

    weak var detailMessage: UITextView!
    weak var alertLabel: UILabel!
    weak var type: UILabel!
    weak var time: UILabel!
    weak var date: UILabel!
    weak var severty: UILabel!


    init() {
        do {
        alertDAO = try self.daoFactory.getAlertDAO()
        subscription = try daoFactory.getSubscriptionDAO().getSubscription()
        } catch AlertError.UnableToCreateAlertDAO {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadAlertDAO)
        } catch SubscriptionError.UnableToCreateSubscriptionDAO {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadSubscriptionDAO)
        } catch {
            
        }
    }

    /// Method : getAlertDetail
    /// Description : This function is use to get alert detail
    ///
    func presentAlertDetailMessage() throws{
        do {
            alertDetail = try alertDAO.getAlert(id: delegate.alertListViewModel.alertList[(indexPath?.row)!].id!)
            Logger.log.info(Messages.INFO_MESSAGES.ReadAlert)
            
            let alertMessage: String = ": " + getDecryptedAlertDetailMessage()
            let alertType = alertDetail.alertType
            let italicType = NSMutableAttributedString(string: "\n" + alertType.uppercased(), attributes: [NSFontAttributeName: UIFont.italicSystemFont(ofSize: 16.0)])
            let attributedMessage = NSMutableAttributedString(string: alertMessage, attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 16.0)])
            italicType.append(attributedMessage)
            detailMessage.attributedText = italicType
            alertLabel.text = alertDetail.componentName
            type.text = "From: \(alertDetail.environmentName)"
            time.text = Time.getTime(alertDetail.timeStamp)
            date.text = Time.getDate(alertDetail.timeStamp)
            severty.backgroundColor = SeverityColor.getRGBColor(fromType: alertDetail.severity)
            
        } catch AlertError.ReadAlertsFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.ReadAlertsFail)
            throw AlertError.ReadAlertsFail
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            throw error
        }
    }

    /// Method : getDetailMessage
    /// Description : This function is use to get alert detail
    ///
    func getDecryptedAlertDetailMessage() -> String {
        let message = alertDetail?.alertMessage

        return "\(decryptAlert(alertMessage: message!))\n\n\nID: \(alertDetail!.alertId))"
    }

    /// Method : deleteAlert
    /// Description : This function is use to delete Alert
    ///
    func deleteAlert() {

        self.delegate.deleteAlertItem(indexPath: self.indexPath!)
        self.delegate.self.updateNumberOfAlertsInfo()
    }

    /// Method : decryptAlert
    /// Description : This function is use to decrypt alert message
    /// Input: alertMessage
    ///
    func decryptAlert(alertMessage: String) -> String {
        return alertDecryption.decryptAlertMessage(alertMessage: alertMessage, encryptionKey: (subscription?.subscriptionKey)!)!
    }
}
