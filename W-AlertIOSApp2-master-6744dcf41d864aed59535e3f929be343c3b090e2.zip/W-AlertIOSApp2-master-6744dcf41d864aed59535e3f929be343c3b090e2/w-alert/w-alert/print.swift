//
//  print.swift
//  w-alert
//
//  Created by Arqam Amin on 22/03/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

import Foundation

func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    #if DEBUG
        var idx = items.startIndex
        let endIdx = items.endIndex
        repeat {
            Swift.print(items[idx], separator: separator, terminator : idx == (endIdx - 1) ? terminator : separator )
            idx += 1
        }
            while idx < endIdx
    #endif
}
