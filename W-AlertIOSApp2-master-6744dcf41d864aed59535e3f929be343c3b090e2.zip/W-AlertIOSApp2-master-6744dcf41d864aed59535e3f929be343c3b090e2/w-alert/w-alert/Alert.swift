//
//  Alert.swift
//  w-alert
//
//  Created by Arqam Amin on 10/6/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

class Alert {
    /// Variables and Objects
    let id: Int64?
    var timeStamp: String
    var severity: String
    var alertType: String
    var alertMessage: String
    var componentName: String
    var unread: Bool
    
    // Methods
    
    /// Method : init
    /// Description : This is constructer method and is use to construct object.
    /// Input : id
    ///
    init(id: Int64) {
        
        self.id = id
        timeStamp = ""
        severity = ""
        alertType = ""
        alertMessage = ""
        componentName = ""
        unread = true
        
    }
    
    /// Method : init
    /// Description : This is constructer method and is use to construct object.
    /// Input : id, timeStamp, severity, alertMessage, componentName
    ///
    init(id: Int64, timeStamp: String, severity: String, alertType: String, alertMessage: String, componentName: String, unread: Bool) {
        
        self.id = id
        self.timeStamp = timeStamp
        self.severity = severity
        self.alertType = alertType
        self.alertMessage = alertMessage
        self.componentName = componentName
        self.unread = unread
    }
}
