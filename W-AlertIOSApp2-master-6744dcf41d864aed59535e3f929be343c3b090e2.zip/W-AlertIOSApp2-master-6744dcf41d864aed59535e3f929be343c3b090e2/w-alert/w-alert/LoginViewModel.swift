//
//  LoginViewModel.swift
//  w-alert
//
//  Created by Mehak Zia on 2/27/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports
import UIKit
import SwiftyJSON
import XCGLogger

class LoginViewModel {

    // UI Bindings

    var loginButtonBinder: ((Bool) -> ())!

    private var isLoginButtonEnable = true {
        didSet {
            loginButtonBinder(isLoginButtonEnable)
        }
    }

    var ActivityIndicator: ((Bool) -> ())!

    var showLoginActivityIndicator = false {
        didSet {
            ActivityIndicator(showLoginActivityIndicator)
        }
    }

    var alertDialogShow: ((String,String) -> ())!

    // Variables and Objects
    let daoFactory : DAOFactory = SqliteDAOFactory()
    var deviceManagement = DeviceManagement.deviceManagement
    var userDAO: UserDAO!
    var userPassword: String?
    var firstName: String?
    var lastName: String?
    var email: String?
    //private var user = [User]()

    init() {
        do {
            
            self.userDAO = try self.daoFactory.getUserDAO()
        } catch UserError.UnableToCreateUserDAO {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UnableToReadUserDAO);
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
    }

    
    /// Method : userExist
    /// Description : This method is use to check if user axist?.
    /// Input : userName
    ///
    func userExist(userName: String) -> Bool {

        do{
            let user = try self.userDAO.getUserProfile()
            if user.userName == userName {
                Logger.log.info(Messages.INFO_MESSAGES.UserAlreadyExist)
                return true
            }
        } catch UserError.ReadUserRecordFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.ReadUserRecordFail);
            Logger.log.info(Messages.INFO_MESSAGES.UserDoesNotExist);
            return true
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            return true
        }
        Logger.log.warning(Messages.WARNING_MESSAGES.UserAlreadyExist)
        alertDialogShow("", "Please sign in with the user you used previously, use Sign Out and Disconnect to switch user.");
        return false
    }
    
    /// Method : insertUserRecord
    /// Description : insert user record to database
    /// Input : password, userDetail
    ///
    func insertUserRecord(userResponse: JSON, password: String) -> Void {

        let responseMapper = ResponseMapper()
        let user = responseMapper.mapGetUserResponseToUser(userResponse: userResponse, password: password)
        
        do {
            if (try self.userDAO.getUserCount()<1) {
                try self.userDAO.insert(user: user)
                self.updateDeviceRegistrationIfNeeded()
            } else {
                try self.userDAO.insertUserPassword(id: user.id!, userPassword: password)
                try self.userDAO.updateLoggedInState(id: user.id!, isLoggedIn: true)
            }
        } catch UserError.CountNumberOfUserRecordFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.CountNumberOfUserRecordFail);
        } catch UserError.InsertUserRecordFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.InsertUserRecordFail);
        } catch UserError.UpdateUserPasswordFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UpdateUserPasswordFail);
        } catch UserError.UpdateUserLoogedInStateFail {
            
            Logger.log.error(Messages.ERROR_MESSAGES.UpdateUserLoogedInStateFail);
        } catch {
            
            Logger.log.error("\(Messages.UnexpectedError)\(error)");
            Logger.log.error(Thread.callStackSymbols);
            alertDialogShow("!Error", "\(error)")
        }
    }
    
    /// Method : login
    /// Description : varify user credentials and loggedIn
    /// Input : userNAme, password
    ///
    func login(userName: String, password: String, subscriptionKey: String, completionHandler: @escaping (String) -> ()) {

        showLoginActivityIndicator = true

        IdentityandAccessManagement.authenticate(userName: userName, password: password, subscriptionKey: subscriptionKey) { (authenticateResponse) in
            
            if(authenticateResponse == ResponseConstants.authenticated) {
                Logger.log.info (Messages.INFO_MESSAGES.Authenticated)
                do {

                    try ClientManagement.getUser(userName: userName) { (getUserResponse) in

                        let userResponse =  getUserResponse[ResponseConstants.GetUserResponse]
                        if userResponse[ResponseConstants.Result][ResponseConstants.ResponseCode].stringValue == Constants.CLIENT_MANAGEMENT_SUCCESS_CODE {
                            
                            Logger.log.info (Messages.INFO_MESSAGES.UserProfileReceive)

                            let userId = userResponse[ResponseConstants.User][ResponseConstants.UserId].stringValue
                            let organizationId = userResponse[ResponseConstants.Client][ResponseConstants.OrganizationId].stringValue
                            self.registerDevice(organizationId: organizationId, userId: userId, userName: userName.components(separatedBy: "@")[0], clientContextUser: "admin@\(userName.components(separatedBy: "@")[1])") {(registerDeviceMessage) in
                                if registerDeviceMessage == Constants.REGISTER_DEVICE_MESSAGE {
                                    self.insertUserRecord(userResponse: getUserResponse, password: password)
                                    Logger.log.info(Messages.INFO_MESSAGES.SuccessfullyLoggedIn)
                                }
                                Logger.log.info(registerDeviceMessage)
                                completionHandler(registerDeviceMessage)
                            }
                        } else if userResponse[ResponseConstants.Result][ResponseConstants.ResponseCode].stringValue == Constants.CLIENT_MANAGEMNET_ERROR_CODE {
                            
                            Logger.log.info(Constants.USER_NOT_FOUND_MESSAGE)
                            completionHandler(Constants.USER_NOT_FOUND_MESSAGE)
                        } else {
                            Logger.log.info(Constants.UNEXPECTED_ERROR_MESSAGE)
                            completionHandler(Constants.UNEXPECTED_ERROR_MESSAGE)
                        }
                    }
                } catch {
                    
                    Logger.log.error("\(Messages.UnexpectedError)\(error)");
                    Logger.log.error(Thread.callStackSymbols);
                    completionHandler(Constants.UNEXPECTED_ERROR_MESSAGE)
                }
            } else if (authenticateResponse == ResponseConstants.unathenticated) {
                
                Logger.log.info(Constants.LOGIN_ERROR_MESSAGE)
                completionHandler(Constants.LOGIN_ERROR_MESSAGE)
            } else if (authenticateResponse == ResponseConstants.timeOut) {
                
                Logger.log.info(Constants.SERVICE_UNAVAILABLE_MESSAGE)
                completionHandler(Constants.SERVICE_UNAVAILABLE_MESSAGE)
            } else if (authenticateResponse == ResponseConstants.FalseToken) {
                
                Logger.log.info(Constants.FALSE_TOKEN_MESSAGE)
                completionHandler(Constants.FALSE_TOKEN_MESSAGE)
            } else {
                
                Logger.log.error(Messages.BackendConnectivity);
                Logger.log.error(Thread.callStackSymbols);
                completionHandler(Constants.UNEXPECTED_ERROR_MESSAGE)
            }
        }
        showLoginActivityIndicator = true
    }
    
    /// Method : updateDeviceRegistrationIfNeeded
    /// Description : update device registration
    ///
    func updateDeviceRegistrationIfNeeded() {
        
        deviceManagement.registerDeviceToken{ registerDeviceTokenResponse in
            if registerDeviceTokenResponse.response?.statusCode == 200 {
                
                Logger.log.info (Constants.REGISTER_DEVICE_MESSAGE)
                
            } else {
                
                Logger.log.error("\(Constants.REGISTER_DEVICE_NOTIFICATION_ERROR_MESSAGE) \(String(describing: registerDeviceTokenResponse.error))")
            }
        }
    }
    
    /// Method : registerDevice
    /// Description : register device
    /// Input : userNAme, organizationId, clientId, clientContextUser
    ///
    func registerDevice(organizationId: String, userId: String, userName: String, clientContextUser: String, completionHandler: @escaping (String) -> ()) {
        
        IdentityandAccessManagement.registerDevice(userName: userName, clientContextUser: clientContextUser) { (registerDeviceResponse) in
            
            if(registerDeviceResponse == "registered") {
                EventSubscriptionManagement.getSubscriptionDetail(userName: userName, organizationId: organizationId, userId: userId) { (getSubscriptionResponse) in
                    print(getSubscriptionResponse)
                    if getSubscriptionResponse["GetEventSubscriptionResponse"]["Result"]["ResponseCode"].stringValue == Constants.EVENT_SUBSCRIPTION_SUCCESS_CODE {
                        
                        _ = EventSubscriptionManagement.saveSubscriptionDetail(subscription: getSubscriptionResponse)
                        createMQTTConnection()
                        
                        Logger.log.info(Constants.Subscription_MESSAGE)
                        completionHandler(Constants.REGISTER_DEVICE_MESSAGE)
                    } else {
                        
                        print(getSubscriptionResponse["GetEventSubscriptionResponse"]["Result"]["ResponseMessage"].stringValue)
                        Logger.log.info(Constants.Subscription_ERROR_MESSAGE)
                        completionHandler(Constants.Subscription_ERROR_MESSAGE)
                    }
                    
                }
            } else if (registerDeviceResponse == "unauthorized") {
                
                Logger.log.info(Constants.REGISTER_DEVICE_ERROR_MESSAGE)
                completionHandler(Constants.REGISTER_DEVICE_ERROR_MESSAGE)
            } else if (registerDeviceResponse == "timeOut") {
                
                Logger.log.info(Constants.SERVICE_UNAVAILABLE_MESSAGE)
                completionHandler(Constants.SERVICE_UNAVAILABLE_MESSAGE)
            } else {
                
                Logger.log.error(Messages.BackendConnectivity);
                Logger.log.error(Thread.callStackSymbols);
                completionHandler(Constants.UNEXPECTED_ERROR_MESSAGE)
            }
        }
    }
}
