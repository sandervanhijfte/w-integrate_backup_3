//
//  AlertListController.swift
//  Login
//
//  Created by Waqas Ali Razzaq on 8/24/17.
//  Copyright © 2017 Waqas Ali Razzaq. All rights reserved.
//  Initial implementation :mehak zia cheema
//

//  imports
import UIKit
import MessageUI


class AlertListController: UIViewController {
    
    // Variables and Objects
    @IBOutlet weak var menuBarButton: UIBarButtonItem!
    @IBOutlet var tapGesture: UITapGestureRecognizer!
    @IBOutlet weak var colorLabel: UILabel!
    @IBOutlet weak var severity: UILabel!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var alertCount: UILabel!
    @IBOutlet weak var alertSelectCount: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var alerListView: UIView!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var help: UIButton!
    @IBOutlet weak var deleteView: UIView!
    @IBOutlet weak var alertTable: UITableView!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var noAlertTestView: UITextField!

    var alertListViewModel = AlertListViewModel()
    
    var set = NSMutableSet()
    var alertOffset = 0                                  // use to track range and limit of record
    var alertLimit = Constants.AlertListConfig.NEW_ALERT_LOAD_LIMIT
    var selectView = false
    var isNewDataLoading = false
    var searchActive: Bool = false
    var selectAll: Bool = false
    private var severtyColor: UIColor!
    private let refreshControl = UIRefreshControl()
    var numberOfAlerts: Int = Int()
    private var visibleCellStartIndex: Int?
    private var visibleCellEndIndex: Int?
    static var listController: AlertListController?
    var timer = Timer()
    
    // AlertListController UIViewController Methods
    
    /// Method : viewDidLoad
    /// Description : This method is overrided to load the ui
    ///
    override func viewDidLoad() {
        
        super.viewDidLoad()
        AlertListController.listController = self

        updateAlerts()
        initializeSearchBar()
        initializeRefreshController()
        initializeView()
        createMQTTConnection ()
        scheduledTimerToReloadVisibleAlerts()
    }
    
    override func viewDidDisappear(_: Bool) {
        super.viewDidDisappear(false)
        hideMenu()
    }
    
    /// Method : scheduledTimerToReloadVisibleAlerts
    /// Description : This method will set a timer for a specific interval to reload visible alerts in the alert table
    ///
    func scheduledTimerToReloadVisibleAlerts(){
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(Constants.RELOAD_VISIBLE_ALERTS_TIME_INTERVAL), target: self, selector: #selector(self.loadVisibleAlerts), userInfo: nil, repeats: true)
    }
    
    /// Method : loadVisibleAlerts
    /// Description : This method will load the visible rows of the alert table
    ///
    @objc func loadVisibleAlerts(){
        if numberOfAlerts != 0 {
            let visibleRowsPaths = alertTable.indexPathsForVisibleRows;
            UIView.performWithoutAnimation({
                let loc = alertTable.contentOffset
                alertTable.reloadRows(at: visibleRowsPaths! , with: UITableViewRowAnimation.none)
                alertTable.contentOffset = loc
            })
        }
    }

    /// Method : initializeDatabaseConnection
    /// Description : This method will set the mqttConnection and connect wiith database
    ///
    private func updateAlerts() {

            alertListViewModel.alertList = alertListViewModel.getAlert()
            numberOfAlerts = alertListViewModel.getAlertCount()
            updateNumberOfAlertsInfo()
    }

    /// Method : initializeSearchBar
    /// Description : This method will set the searchBar
    ///
    func initializeSearchBar() {

        searchBar.delegate = self
        searchBar.layer.borderWidth = 1
        searchBar.layer.borderColor = UIColor.lightGray.cgColor
        searchBar.layer.cornerRadius = 5
        searchBar.layer.masksToBounds = true
        searchBar.barTintColor = UIColor.white
        searchBar.frame = CGRect(x: searchBar.frame.origin.x, y: searchBar.frame.origin.y, width: searchBar.frame.size.width, height: 37)
    }

    /// Method : initializeRefreshController
    /// Description : This method will set the refreshController
    ///
    func initializeRefreshController() {

        if #available(iOS 10.0, *) {
            alertTable.refreshControl = refreshControl
        } else {
            alertTable.addSubview(refreshControl)
        }
        refreshControl.addTarget(self, action: #selector(refreshAlertData(_:)), for: .valueChanged)
        refreshControl.tintColor = UIColor(red:0.25, green:0.72, blue:0.85, alpha:1.0)
        refreshControl.attributedTitle = NSAttributedString(string: Constants.REFRESH_CONTROL_MESSAGE)
    }

    /// Method : initializeView
    /// Description : This method will set the ui
    ///
    func initializeView() {

        menuView.layer.shadowOpacity = 0.4
        menuView.isHidden = true
        alertTable.delegate = self
        alertTable.tableFooterView = UIView(frame: .zero)
        alertTable.isScrollEnabled = true
        title = "W-Alert"
        noAlertTestView.text = "You have no alerts"
        tapGesture.isEnabled = false
        navigationItem.rightBarButtonItem = menuBarButton
        navigationItem.hidesBackButton = true

        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector((AlertListController.handleLogPressGesture)))
        longPressGesture.numberOfTouchesRequired = 1
        longPressGesture.minimumPressDuration = 1.0
        alertTable.addGestureRecognizer(longPressGesture)
        updateNumberOfAlertsInfo()
    }
    
    /// Method : refreshAlertData
    /// Description : This method will refresh the alertList
    ///
    @objc private func refreshAlertData(_ sender: Any) {
        
        //selectAll = true
       // selectAllButton((Any).self)
        //alertInfoReset()
        refreshTableView()
    }
    
    /// Method : cancelDelete
    /// Description :This method will be used to disable the delete view
    ///
    @IBAction func cancelDelete(_ sender: Any) {
        
        deleteView.isHidden = true
        deleteView.isUserInteractionEnabled = false
        searchView.isHidden = false
        searchView.isUserInteractionEnabled = true
        searchBar.isUserInteractionEnabled = true
        help.isEnabled = true
        set.removeAllObjects()
        setAccessoryType(type: .none, selected: false)
        alertSelectCount.text = "Selected : \(set.count)"
        changeDeleteButtonEnableState()
        selectAll = false
    }
    
    /// Method: deleteButton
    //  Description: This method will be used to delete selected alerts
    ///
    @IBAction func deleteButton(_ sender: Any) {
        guard set.count != 0 else {
            let selectDeleteAlertDialog = UIAlertController(title: "", message: Constants.SELECT_DELETE_ALERT_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
            selectDeleteAlertDialog.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(selectDeleteAlertDialog, animated: false, completion: nil)
            return
        }
        
        let deleteAlertDialog = UIAlertController(title: "", message: Constants.DELETE_ALERT_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
        deleteAlertDialog.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))
        
        deleteAlertDialog.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) in
            self.deleteAlert()
        }))
        self.present(deleteAlertDialog, animated: false, completion: nil)
    }
    
    /// Method : selectAllButton
    /// Description : This method will be used to select all the alerts that are present in ui
    ///
    @IBAction func selectAllButton(_ sender: Any) {
        
        if selectAll == false {
            setAccessoryType(type: .checkmark, selected: true)
            set.addObjects(from: Array(0...(alertListViewModel.alertList.count - 1)))
        } else {
            setAccessoryType(type: .none, selected: false)
            set.removeAllObjects()
        }
        alertSelectCount.text = "Selected : \(set.count)"
        changeDeleteButtonEnableState()
        selectAll = !selectAll
    }
    
    /// Method : changeDeleteButtonState
    /// Description : This method will be use to enable or disable the delete button
    ///
    func changeDeleteButtonEnableState() {
        
        deleteButton.isEnabled = set.count > 0
    }
    
    /// Method: handleLogPressGesture
    /// Description: This method used to enable delete view
    ///
    func handleLogPressGesture(longPressGesture: UILongPressGestureRecognizer) {
        
        searchView.isHidden = true
        searchView.isUserInteractionEnabled = false
        searchBar.isUserInteractionEnabled = false
        help.isEnabled = false
        deleteView.isHidden = false
        deleteView.isUserInteractionEnabled = true
    }
    
    /// Method : handleTapGesture
    /// Description : This method is used to hide the menu
    /// Input : none
    ///
    @IBAction func handleTapGesture(_ sender: Any) {
        
        guard tapGesture.isEnabled == true else {return}
        viewMenu((Any).self)
    }
    
    /// Method : ViewMenu
    /// Description : This method will be used to view the menu
    ///
    @IBAction func viewMenu(_ sender: Any) {
        
        selectView = !selectView
        menuView.isHidden = !menuView.isHidden
        menuView.alpha = 1.0
        if menuView.isHidden == false {
            searchView.isUserInteractionEnabled = false
            alertTable.isUserInteractionEnabled = false
            alertCount.alpha = 0.2
            alertTable.alpha = 0.2
            searchView.alpha = 0.2
            deleteView.alpha = 0.2
            noAlertTestView.alpha = 0.0
            tapGesture.isEnabled = true
        } else {
            searchView.isUserInteractionEnabled = true
            alertTable.isUserInteractionEnabled = true
            alertCount.alpha = 1.0
            alertTable.alpha = 1.0
            searchView.alpha = 1.0
            deleteView.alpha = 1.0
            noAlertTestView.alpha = 1.0
            tapGesture.isEnabled = false
        }
    }
    
    func hideMenu() {
        if(menuView.isHidden == false) {
            selectView = !selectView
            menuView.isHidden = !menuView.isHidden
            menuView.alpha = 1.0
        if menuView.isHidden == true {
            searchView.isUserInteractionEnabled = true
            alertTable.isUserInteractionEnabled = true
            alertCount.alpha = 1.0
            alertTable.alpha = 1.0
            searchView.alpha = 1.0
            deleteView.alpha = 1.0
            noAlertTestView.alpha = 1.0
            tapGesture.isEnabled = false
        }
        }
    }
    
    func showMenu() {
        if(menuView.isHidden == true) {
            selectView = !selectView
            menuView.isHidden = !menuView.isHidden
            menuView.alpha = 1.0
            if menuView.isHidden == false {
                searchView.isUserInteractionEnabled = false
                alertTable.isUserInteractionEnabled = false
                alertCount.alpha = 0.2
                alertTable.alpha = 0.2
                searchView.alpha = 0.2
                deleteView.alpha = 0.2
                noAlertTestView.alpha = 0.0
                tapGesture.isEnabled = true
            }
        }
    }
    
    /// Method : helpButtonPressed
    /// Description : This method will be called when press question mark. It shows search criteria
    ///
    @IBAction func helpButtonPressed(_ sender: Any) {
        let helpButtonDialog = UIAlertController(title: Constants.SEARCH_HELP_DIALOG_TITLE, message: Constants.SEARCH_HELP_DIALOG_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
        
        helpButtonDialog.addAction(UIAlertAction(title: "cancel", style: UIAlertActionStyle.default, handler: nil))
        self.present(helpButtonDialog, animated: false, completion: nil)
    }
    
    /// Method : sendLogFile
    /// Description : This method will be called when press Send App Report.
    ///
    @IBAction func sendFile(_ sender: UIButton) {
        sendLogFile((UIButton).self)
    }
    
    /// Method : sendLogFile
    /// Description : This method will be called when press Send App Report.
    ///
    @IBAction func sendLogFile(_ sender: Any) {
        //Check to see the device can send email.
        
        guard let mailComposeViewController = configureMailController() else {
            return
        }
        
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            showMailError()
        }
    }
    
    /// Method : signOutButtonPressed
    /// Description : This method will be called when press signOut from menu. there are three options to select Cancel, signOut and signOutAndDisconnect
    ///
    @IBAction func signOutButton(_ sender: Any) {
        signOutButtonPressed((Any).self)
    }
    
    /// Method : signOutButtonPressed
    /// Description : This method will be called when press signOut from menu. there are three options to select Cancel, signOut and signOutAndDisconnect
    ///
    @IBAction func signOutButtonPressed(_ sender: Any) {

            let signOutDialog = UIAlertController(title: Constants.SIGN_OUT_TITLE, message: Constants.SIGN_OUT_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
            signOutDialog.addAction(UIAlertAction(title: Constants.CANCEL, style: UIAlertActionStyle.default, handler: { (action) in   }))
            signOutDialog.addAction(UIAlertAction(title: Constants.DISCONNECT_AND_SIGN_OUT, style: UIAlertActionStyle.default, handler: { (action) in
                
                let signOutMessageDialog = UIAlertController(title: "Warning!", message: Constants.DISCONNECT_AND_SIGN_OUT_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
                signOutMessageDialog.addAction(UIAlertAction(title: Constants.OK, style: UIAlertActionStyle.destructive, handler: { (action) in
                    self.alertListViewModel.signOutAndDisconnect()
                }))
                signOutMessageDialog.addAction(UIAlertAction(title: Constants.CANCEL, style: UIAlertActionStyle.default, handler: { (action) in
                   return
                }))
                self.present(signOutMessageDialog, animated: false, completion: nil)
            }))
            signOutDialog.addAction(UIAlertAction(title: Constants.SIGN_OUT, style: UIAlertActionStyle.default, handler: { (action) in
                
                self.alertListViewModel.signOut()
                self.performSegue(withIdentifier: "goto_login", sender: self)
            }))
            let widthConstraint: NSLayoutConstraint = NSLayoutConstraint(item: signOutDialog.view, attribute: NSLayoutAttribute.width, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: NSLayoutAttribute.notAnAttribute , multiplier: 1, constant: 480.0)
            signOutDialog.view.addConstraint(widthConstraint)
            self.present(signOutDialog, animated: false, completion: nil)

    }
    
    /// Method : scrollViewDidScroll
    /// Description : This method will be called when scroll the alertList
    ///
    func scrollViewDidScroll(_ scrollView: UIScrollView) {

        updateNumberOfAlertsInfo()
    }
    
    /// Method : scrollViewDidEndDragging
    /// Description : This method will be called when scroll the alertList is ended
    ///
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        print(selectAll);
        if scrollView.isZoomBouncing {
            print("Bounce")
        }
        if selectAll == true {
            setAccessoryType(type: .none, selected: false)
            set.removeAllObjects()
            print(set.count)
            alertSelectCount.text = "Selected : \(set.count)"
            changeDeleteButtonEnableState()
            selectAll = !selectAll
        }
        
        guard ((scrollView.contentOffset.y + scrollView.frame.size.height + 80) >= scrollView.contentSize.height), !isNewDataLoading, isHasMoreData() else {return}

        isNewDataLoading = true
        loadMoreAlerts()
    }

    /// Method : deleteAlert
    /// Description : This method will dalete the alert from alertList and database
    ///
    func deleteAlert() {
        
        let rmIndexis = self.set.allObjects as! [Int]
        let alertIds:[Int64] = alertListViewModel.alertList.enumerated().filter{  rmIndexis.contains($0.offset) }.map{
            print($0.element.id!); return $0.element.id!
        }
        self.deleteView.isHidden = true
        self.deleteView.isUserInteractionEnabled = false
        self.searchView.isHidden = false
        self.searchView.isUserInteractionEnabled = true
        self.searchBar.isUserInteractionEnabled = true
        self.help.isEnabled = true
        
        self.alertListViewModel.deleteMultipleAlert(alertIds: alertIds)
        let numberOfDeleteAlerts = self.set.count
        self.alertOffset = self.alertListViewModel.getAlertOffSet(numberOfDeleteAlerts: numberOfDeleteAlerts)
        self.numberOfAlerts = alertListViewModel.getAlertCount()
        alertListViewModel.alertList = alertListViewModel.alertList.enumerated().filter{ !rmIndexis.contains($0.offset)}.map{$0.element}
        self.set.removeAllObjects()
        self.setAccessoryType(type: .none, selected: false)
        self.refreshTableView()
        self.alertTable.reloadData()
        self.alertSelectCount.text = "Selected : \(set.count)"
        self.updateNumberOfAlertsInfo()
        
    }
    
    func performAlertDetailSegue(indexPath: IndexPath, cell: AlertListTableViewCell) {
        alertTable.cellForRow(at: indexPath)?.isSelected = false
        let id = alertListViewModel.alertList[indexPath.row].id!
        alertListViewModel.setReadAlert(id: id, indexPath: indexPath)
        cell.backgroundColor = alertListViewModel.getBackgroundColor(type: false)
        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "AlertDetailControllerId") as! AlertDetailController
        viewController.indexPath = indexPath
        viewController.delegate = self
        //self.alertTable.reloadData()
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    /// Method : setAccessoryType
    /// Description : This method will set the accessoryType
    ///
    func setAccessoryType(type: UITableViewCellAccessoryType, selected: Bool){
        
        _ = self.alertTable.visibleCells.enumerated().map{$0.element.isSelected = false;
            $0.element.accessoryType = type;
        }
    }
    
    /// Method : isHasMoreData
    /// Description : This method will be use to check is more alerts are present in databse or not
    ///
    func isHasMoreData() -> Bool {
        
        guard alertOffset < numberOfAlerts else {return false}
        self.alertOffset += self.alertLimit
        alertListViewModel.alertOffset = alertOffset
        return true
    }
    
    /// Method : loadMoreAlerts
    /// Description : This method will be use to load alerts from database for specified range
    ///
    func loadMoreAlerts() {
        
        _ = self.alertTable.visibleCells.enumerated().map{$0.element.isHighlighted = false }
        isNewDataLoading = false

            var newAlerts : [Alert]!
            
            if searchActive == true {
                newAlerts = self.alertListViewModel.getAlertFromSearch(searchText: searchBar.text!)
            } else {
                newAlerts = self.alertListViewModel.refreshAlerts()
            }
            alertListViewModel.alertList += newAlerts
            self.numberOfAlerts = self.alertListViewModel.getAlertCount()
            updateNumberOfAlertsInfo()
            self.alertTable.reloadData()

    }
    
    /// Method : searchAlertWithMatchKeyword
    /// Description : This method will be use to get search/filtered alerts from database and update table view
    /// - Input: keyword: value for which search is conduct
    ///
    func searchAlertWithMatchKeyword(keyword: String) {

            alertInfoReset()
            numberOfAlerts = alertListViewModel.getSearchAlertCount(searchText: keyword)
        if(numberOfAlerts == 0) {
            noAlertTestView.text = "No matching alerts found"
        }
            alertListViewModel.alertList = alertListViewModel.getAlertFromSearch(searchText: keyword)
            searchActive = true
            alertTable.reloadData()
            updateNumberOfAlertsInfo()
    }
    
    /// Method : alertInfoReset
    /// Description : This method will be use to reset the alerts trck info
    ///
    func alertInfoReset() {
        alertListViewModel.alertOffset = 0
        alertOffset = 0
        alertTable.reloadData()
        isNewDataLoading = false
    }
    
    /// Method : updateAlertsInfo
    /// Description : This method will be use to update number of alerts info
    ///
    func updateNumberOfAlertsInfo() {
        let index = alertTable.indexPathsForVisibleRows
        if numberOfAlerts != 0 {
            alertCount.isHidden = false
            noAlertTestView.isHidden = true
            visibleCellStartIndex = index?.first?.last ?? 0
            visibleCellEndIndex = index?.last?.last ?? 0
            alertCount.text = "\((visibleCellStartIndex! + 1)) to \(visibleCellEndIndex! + 1) of \(String(describing: numberOfAlerts)) total alerts";
        } else {
            alertCount.isHidden = true
            noAlertTestView.isHidden = false
        }
    }
    
    /// Method : printErrorMessage
    /// Description : This method will be use to print error message in console
    /// Input: errorMessage: Error Message
    ///
    func printErrorMessage(errorMessage: String) {
        print(errorMessage)
    }
    
    /// Method : notifyAlert
    /// Description : This method will be use to notify the user
    ///
    func notifyAlert(alert: AlertDetail) {
        alertListViewModel.alertList.insert(alert, at: 0)
        numberOfAlerts += 1
        updateNumberOfAlertsInfo()
    }
    
    /// Method : refreshTableView
    /// Description : This method will be use to refresh the table view
    ///
    func refreshTableView() {

        alertInfoReset()
        alertListViewModel.alertList = alertListViewModel.getAlert()
        numberOfAlerts = alertListViewModel.getAlertCount()

        alertTable.reloadData()
        searchActive = false
        refreshControl.endRefreshing()
        updateNumberOfAlertsInfo()
    }
    
    /// Method: deleteAlertItem
    /// Description: This method will be use to delete alert
    ///
    func deleteAlertItem(indexPath: IndexPath) {
        let id = alertListViewModel.alertList[indexPath.row].id!
        do{
            try alertListViewModel.deleteAlertItem(id: id)
            numberOfAlerts = numberOfAlerts - 1
            alertListViewModel.alertList.remove(at: indexPath.row)
            alertTable.deleteRows(at: [indexPath], with: .fade)
            changeDeleteButtonEnableState()
            updateNumberOfAlertsInfo()
        } catch {
            let selectDeleteAlertDialog = UIAlertController(title: "Error", message: Constants.UNABLE_TO_Delete_ALERT, preferredStyle: UIAlertControllerStyle.alert)
            selectDeleteAlertDialog.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(selectDeleteAlertDialog, animated: false, completion: nil)
        }
    }
}

extension AlertListController: MFMailComposeViewControllerDelegate {
    func configureMailController() -> MFMailComposeViewController? {
        
        let mailComposer = MFMailComposeViewController()
        mailComposer.mailComposeDelegate = self
        mailComposer.setToRecipients([Constants.SUPPORT_EMAIL_ADDRESS])
        mailComposer.setSubject(Constants.LOG_FILE_EMAIL_SUBJECT)
        mailComposer.setMessageBody(Constants.LOG_FILE_EMAIL_MESSAGE, isHTML: false)

        let filePath = alertListViewModel.getLogFilePath()
        if let fileData = NSData(contentsOfFile: filePath) {
            print("File data loaded.")
            mailComposer.addAttachmentData(fileData as Data, mimeType: "text/plain", fileName: "w-alertLogs.log")
        } else {
            let sendMailErrorAlert = UIAlertController(title: "", message: "Unable to find W-Alert log file.", preferredStyle: .alert)
            let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
            sendMailErrorAlert.addAction(dismiss)
            return nil
        }
        
        return mailComposer
    }
    
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email.", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        
        //self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
        
    }
}

//extension to UITableViewDataSource
extension AlertListController: UITableViewDataSource {
    // UITableViewDataSource Methods
    /// Method: cellForRowAt
    /// Description: This method will be used to enter the data in cell
    ///
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "AlertTableCell", for: indexPath) as! AlertListTableViewCell

        initializeCellWithValues(cell: cell, alert: alertListViewModel.alertList[indexPath.row])
        
        return cell
    }

    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {

        updateCellColorState(cell: cell, toSelect: set.contains(indexPath.row))
    }
    
    /// Method : initializeCellWithValues
    /// Description : This method will set the alertList cell
    ///
    func initializeCellWithValues(cell: AlertListTableViewCell, alert: Alert) {

        cell.AgentName.text = alert.componentName
        let alertMessage: String = ": " + alert.alertMessage
        let alertType = alert.alertType
        let italicType = NSMutableAttributedString(string: alertType.uppercased(), attributes: [NSFontAttributeName: UIFont.italicSystemFont(ofSize: 16.0)])
        let attributedMessage = NSMutableAttributedString(string: alertMessage, attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 16.0)])
        italicType.append(attributedMessage)
        cell.ErrorMessage.attributedText = italicType
        cell.AlertTime.text = Time.getRelativeDateTime(alert.timeStamp)
        cell.servityColor.backgroundColor = SeverityColor.getRGBColor(fromType: alert.severity)
        //cell.servityColor?.text = alert.severity
        cell.backgroundColor = alertListViewModel.getBackgroundColor(type: alert.unread)
    }

    /// Method: cellForRowAt
    /// Description: This method will be used to get total number of rows
    ///
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return alertListViewModel.alertList.count
    }
}

// extension to UISearchBarDelegate
extension AlertListController: UISearchBarDelegate {
    
    // UISearchBarDelegate Methods
    
    // maybe we need in future
    /// Method: searchBarTextDidEndEditing
    /// Description: This method will be called when user stop editing text in UISearchBar
    ///
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        print("\nend calling")
    }
    
    // maybe we need in future
    /// Method: searchBarTextDidEndEditing
    /// Description: This method will be called when text is change in UISearchBar if user clear the text than hide the keybord
    /// Input: searchText
    ///
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

        if searchBar.text == nil || searchBar.text == "" {

            refreshTableView()
            noAlertTestView.text = "You have no alerts"
            searchBar.perform(#selector(self.resignFirstResponder), with: nil, afterDelay: 0.1)
        }
    }
    
    /// Method: searchBarSearchButtonClicked
    /// Description: This method will be called whenn user clink search button to search/filter alerts
    ///
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        searchAlertWithMatchKeyword(keyword: searchBar.text!)
        searchBar.resignFirstResponder()
    }
    
    // Due to bug in ios this method is not call
    /// Method: searchBarTextDidEndEditing
    /// Description: This method will be called when user click X button of UISearchBar
    ///
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        print("searchBarCancelButtonClicked")
        noAlertTestView.text = "You have no alerts"
    }
}

// extension to UITableViewDelegate
extension AlertListController: UITableViewDelegate {
    
    //UITableViewDelegate Methods
    
    /// Method: didSelectRowAt
    /// Description: This method will be used to perform action when a row is seleted
    ///
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = alertTable.cellForRow(at: indexPath) as! AlertListTableViewCell

        if deleteView.isHidden == true  {
            performAlertDetailSegue(indexPath: indexPath, cell: cell)
        } else {
            tableViewCellSelectOrUnselect(cell: cell, indexPath: indexPath)
        }
    }
    
    /// Method: didDeselectRowAt
    /// Description: This method will be used to perform action when a row is unseleted
    ///
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {

        if deleteView.isHidden == false {
            let cell = alertTable.cellForRow(at: indexPath) as! AlertListTableViewCell
            tableViewCellSelectOrUnselect(cell: cell, indexPath: indexPath)
        }
    }

    private func tableViewCellSelectOrUnselect(cell: AlertListTableViewCell, indexPath: IndexPath) {
        if cell.accessoryType == UITableViewCellAccessoryType.none {
            set.add(indexPath.row)
            updateCellColorState(cell: cell, toSelect: true)
        } else {
            set.remove(indexPath.row)
            updateCellColorState(cell: cell, toSelect: false)
        }

        alertSelectCount.text = "Selected : \(set.count)"
        changeDeleteButtonEnableState()
    }

    /// Method: selectDeSelectRow
    /// Description: This method will be used to selet or unselect the row
    ///
//    private func tableViewCellSelectStateChange(cell: AlertListTableViewCell, indexPath: IndexPath) {
//        if cell.accessoryType == UITableViewCellAccessoryType.none {
//            cell.accessoryType = UITableViewCellAccessoryType.checkmark
//            cell.isSelected = true
//            set.add(indexPath.row)
//        } else {
//            cell.accessoryType = UITableViewCellAccessoryType.none
//            cell.isSelected = false
//            set.remove(indexPath.row)
//        }
//        cell.servityColor.backgroundColor = SeverityColor.getRGBColor(fromType: alertListViewModel.alertList[indexPath.row].severity)
//        alertSelectCount.text = "Selected : \(set.count)"
//        changeDeleteButtonEnableState()
//    }

    func updateCellColorState(cell: UITableViewCell, toSelect: Bool) {
        if toSelect {
            cell.accessoryType = UITableViewCellAccessoryType.checkmark
            //cell.isSelected = true
            cell.isHighlighted = true
            let alertCell = cell as! AlertListTableViewCell
            //alertCell.servityColor.backgroundColor =  SeverityColor.getRGBColor(fromType: (alertCell.servityColor?.text)!)
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.none
            cell.isSelected = false
            cell.isHighlighted = false
        }
    }
    
    /// Method: didEndEditingRowAt
    /// Description: This method will be used to update alert info
    ///
    func tableView(_ tableView: UITableView, didEndEditingRowAt indexPath: IndexPath?) {
        
        updateNumberOfAlertsInfo()
    }
    
    /// Method: commit
    /// Description: This method will be use to delete alert
    ///
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if deleteView.isHidden == true && editingStyle == .delete {
            let deleteAlertDialog = UIAlertController(title: "", message: Constants.DELETE_ALERT_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
            deleteAlertDialog.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default, handler: nil))
            
            deleteAlertDialog.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) in
                self.deleteAlertItem(indexPath: indexPath)
            }))
            self.present(deleteAlertDialog, animated: false, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let deleteButton = UITableViewRowAction(style: .default, title: "Delete") { (action, indexPath) in
            tableView.dataSource?.tableView!(tableView, commit: .delete, forRowAt: indexPath)
            return
        }
        deleteButton.backgroundColor = UIColor.init(red: 129/256, green: 150/256, blue: 179/256, alpha: 1)
        return [deleteButton]
    }
}

 
