//
//  DeviceTokenDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 24/01/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

protocol DeviceTokenDAO {
    
    func insertNew(token: String) throws
    func deleteToken() throws
    func updateOldToken()
    func isTokenChanged() -> Bool
    func getDeviceToken() -> String?
}
