//
//  AppDelegate.swift
//  w-alert
//
//  Created by Waqas Ali on 9/14/17.
//  Copyright © 2017 WeIntegrate B.V. All righ    ts reserved.
//  Initial implementation: Waqas Ali
//  Add push Notification: Arqam Amin
//  Set login state: Mehak zia
//

//  imports
import UIKit
import CoreData
import UserNotifications
import XCGLogger

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    // Variables and Objects
    var window: UIWindow?
    var daoFactory: DAOFactory = SqliteDAOFactory()
    var userDAO: UserDAO!
    var dictionaryDAOFactory: DAOFactory = DictionaryDAOFactory()
    var deviceTokenDAO: DeviceTokenDAO!
    private var user = [User]()
    var listController: UIViewController?
    let deviceManagement = DeviceManagement.deviceManagement
    var storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
    
//    static let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
//    static let cachePath = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0]
    
    
    // AppDelegate Methods
    
    /// Method : didFinishLaunchingWithOptions
    /// Description : Call when app is launched.
    ///
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {

        #if DEBUG
            Logger.log.setup(level: .debug, showLogIdentifier: true, showFunctionName: true, showThreadName: true, showLevel: true, showFileNames: true, showLineNumbers: true)
        #else
            Logger.log.setup(level: .info, showLogIdentifier: true, showFunctionName: true, showThreadName: true, showLevel: true, showFileNames: true, showLineNumbers: true)
        #endif

        registerForPushNotifications()
        UIApplication.shared.applicationIconBadgeNumber = 0
        do {
            if try isUserLogedIn() {
                redirectToAlertScreen()
            }
        } catch {

        }
        return true
    }
    
    /// Method : applicationDidBecomeActive
    /// Description : Call when app became active.
    ///
    func applicationDidBecomeActive(_ application: UIApplication) {
        
        do {
            if try isUserLogedIn() {
                createMQTTConnection()
                redirectToAlertScreen()
            }
        } catch UserError.UnableToCreateUserDAO {
            Logger.log.error("\(Messages.ERROR_MESSAGES.UnableToReadUserDAO). Because of: \(UserError.UnableToCreateUserDAO)")
        } catch UserError.ReadUserRecordFail {
            Logger.log.error("\(Messages.ERROR_MESSAGES.ReadUserRecordFail). Because of: \(UserError.ReadUserRecordFail)")
        } catch {
            Logger.log.error("\(Messages.UnexpectedError). Because of: \(error)");
            Logger.log.error(Thread.callStackSymbols);
        }
    }
    
    /// Method : isUserLogedIn
    /// Description : Check user loggedin state.
    /// Output : loggedInState (true/false)
    ///
    func isUserLogedIn() throws -> Bool {
        
        do {
            userDAO = try daoFactory.getUserDAO()
            let isLoggedIn = try userDAO.getUserProfile().isLoggedIn
            guard isLoggedIn else {
                Logger.log.info("user is not loggedin")
                print("user is not loggedin")
                return false
            }
            Logger.log.info("user is loggedin")
            print("user is loggedin")
            return true
        } catch {
            print("\(Constants.USER_LOGIN_STATE). Because of: \(error)")
            Logger.log.info("\(Constants.USER_LOGIN_STATE). Because of: \(error)")
            throw error
        }
        return false
    }
    
    /// Method : redirectToAlertScreen
    /// Description : Navigate user to alertList screen instead of login screen.
    ///
    func redirectToAlertScreen() {
        
        let myNavigationViewController = storyboard.instantiateViewController(withIdentifier: "myNavigationController") as! UINavigationController
        listController = storyboard.instantiateViewController(withIdentifier: "AlertList")
        
        myNavigationViewController.pushViewController(listController!, animated: false)
        
        self.window?.rootViewController = myNavigationViewController
    }
    
    /// Method : registerForPushNotifications
    /// Description : User allow to register for push Notification.
    ///
    func registerForPushNotifications() {
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
            (granted, error) in
            
            print("Permission granted: \(granted)")
            
            
            if !granted {
                Logger.log.info("Show confirmation dialogbox for enable APNS")
                let alertController = UIAlertController(title: Constants.NOTIFICATION_ENABLE_DIALOG_TITLE, message: Constants.NOTIFICATION_ENABLE_DIALOG_MESSAGE, preferredStyle: .alert)
                
                let settingsAction = UIAlertAction(title: "Settings", style: .default) { (_) -> Void in
                    guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
                        return
                    }
                    
                    if UIApplication.shared.canOpenURL(settingsUrl) {
                        UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                        })
                    }
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
                alertController.addAction(cancelAction)
                alertController.addAction(settingsAction)
                DispatchQueue.main.async {
                    self.window?.rootViewController?.present(alertController, animated: true, completion: nil)
                }
            }
            guard granted else { return }
            Logger.log.info("APNS Notification permission granted")
            self.getNotificationSettings()
        }
    }
    
    /// Method : getNotificationSettings
    /// Description : Check user notification settings.
    ///
    func getNotificationSettings() {
        
        UNUserNotificationCenter.current().getNotificationSettings { (settings) in
            print("Notification settings: \(settings)")
            guard settings.authorizationStatus == .authorized else { return }
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
                Logger.log.info("Register for push notification.")
            }
        }
    }
    
    /// Method : didRegisterForRemoteNotificationsWithDeviceToken
    /// Description : Register device token.
    ///
    func application(_ application: UIApplication,
                     didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let tokenParts = deviceToken.map { data -> String in
            return String(format: "%02.2hhx", data)
        }
        
        let token = tokenParts.joined()
        print("Device Token: \(token)")
        Logger.log.debug("Device Token: \(token)")
        deviceTokenDAO = try! dictionaryDAOFactory.getDeviceTokenDAO()
        try! deviceTokenDAO.insertNew(token: "\(token)")
        deviceManagement.registerDeviceToken{ response in
            if response.response?.statusCode == 200 {
                print ("\(Constants.REGISTER_DEVICE_MESSAGE) successfully.")
                Logger.log.info("\(Constants.REGISTER_DEVICE_MESSAGE) successfully.")
                
            } else {
                print(Constants.REGISTER_DEVICE_NOTIFICATION_ERROR_MESSAGE)
                Logger.log.info(Constants.REGISTER_DEVICE_NOTIFICATION_ERROR_MESSAGE)
            }
        }
    }
    
    /// Method : didFailToRegisterForRemoteNotificationsWithError
    /// Description : Unable to register push notification.
    ///
    func application(_ application: UIApplication,
                     didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Failed to register: \(error)")
        Logger.log.info("Failed to register: \(error)")
    }
}

// extension to user notification center
extension AppDelegate: UNUserNotificationCenterDelegate {
    
    // UNUserNotificationCenterDelegate methods
    
    /// Method : willPresent
    /// Description : notification that will be received.
    ///
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.sound])
    }
}
