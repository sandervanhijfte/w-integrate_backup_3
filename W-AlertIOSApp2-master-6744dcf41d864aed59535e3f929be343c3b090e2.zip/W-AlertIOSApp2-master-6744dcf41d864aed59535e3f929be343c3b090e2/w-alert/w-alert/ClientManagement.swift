//
//  Name: ClientManagement.swift
//  version: 1.0.0
//  Created by: Waqas Ali Razzaq on 9/20/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation
import Alamofire
import SwiftyJSON

class ClientManagement: NSObject {
    
    //Methods
    
    /// Method : updateUser
    /// Description : This method will be used to update the user details
    /// Input : UserId, FirstName, ListName, Email, OrganizationId, completionHandler
    ///
    
    class func updateUser(userId: String, firstName: String, lastName: String, email: String, organizationId: String, organizationDomain: String, userName:String, completionHandler: @escaping (JSON) -> ()) {
        
        let parameters: Parameters = ["UpdateUserRequest": ["Header":["CMMHeader":["CorrelationId": UUID().uuidString]],"ClientContext":["OrganizationId":organizationId,"OrganizationDomain":organizationDomain],"UserId": userId,"User":["UserName":userName,"FirstName":firstName,"LastName":lastName,"ContactDetail":["ChannelCode": email,"ChannelType": "Email"]]]]
        let headers: HTTPHeaders = [
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER,
            "Content-Type": Constants.Content_Type]
        Alamofire.request(Constants.ENVIRONMENT.UPDATE_USER_URL,
                          method: .put,
                          parameters: parameters,
                          encoding: JSONEncoding.default,
                          headers: headers).responseJSON { updateUserResponse in
                            print(updateUserResponse)
                            switch(updateUserResponse.result){
                            case .success:
                                var json = JSON(updateUserResponse.result.value!)
                                print (json)
                                if json["UpdateUserResponse"]["Result"]["ResponseCode"].stringValue == Constants.CLIENT_MANAGEMENT_SUCCESS_CODE {
                                    
                                    completionHandler("true")
                                } else if json["UpdateUserResponse"]["Result"]["ResponseCode"].stringValue == Constants.CLIENT_MANAGEMENT_ERRORR_CODE {
                                    
                                    completionHandler("false")
                                } else {
                                    completionHandler("false")
                                }
                            case .failure(let error):
                                if error._code == NSURLErrorTimedOut {
                                    
                                    completionHandler("false")
                                } else {
                                    
                                    completionHandler("false")
                                }
                            }
        }
    }
    
    /// Method : getUser
    /// Description : This method will be used to get the user details
    /// Input : UserName, completionHandler
    ///
    class func getUser(userName: String ,completionHandler: @escaping (JSON) -> ()) {
        
        let headers: HTTPHeaders = [
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER
        ]
        let parameters = "?UserName=\(userName)&CorrelationId=\(UUID().uuidString)&OrganizationId=1234"
        let allowedCharacterSet = (CharacterSet(charactersIn: "@").inverted)
        let escapedString = parameters.addingPercentEncoding(withAllowedCharacters: allowedCharacterSet)
        Alamofire.request(Constants.ENVIRONMENT.GET_USER_URL+escapedString!,
                          method: .get,
                          encoding: URLEncoding.default,
                          headers: headers).responseJSON {  getUserResponse in
                            
                            print(getUserResponse)
                            switch(getUserResponse.result){
                            case .success:
                                let json = JSON(getUserResponse.result.value!)
                                completionHandler(json)
                            case .failure(let error):
                                if error._code == NSURLErrorTimedOut {
                                    let json = JSON(["error": "timeOut"])
                                    completionHandler(json)
                                } else {
                                    let json = JSON(["error": "unexpectedError"])
                                    completionHandler(json)
                                }
                            }
        }
    }
}
