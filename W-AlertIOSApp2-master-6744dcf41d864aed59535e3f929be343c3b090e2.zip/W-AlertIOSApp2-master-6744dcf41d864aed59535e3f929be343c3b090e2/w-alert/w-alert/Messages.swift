//
//  Messages.swift
//  w-alert
//
//  Created by Mehak Zia on 4/17/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

import Foundation
struct Messages {
    
    // INFO_MESSAGES
    struct INFO_MESSAGES {
        
        //ALERT_MESSAGES
        
        static let AlertSaved = "Alert saved successfully"
        
        static let ReadAlert = "Presenting alert detail Message."
        
        static let DeleteAlert = "Alert successfully deleted."
        
        static let ReadAlertFromDB = "Read alerts from database"
        
        static let DecryptAlert = "Alert successfully decrypted."
        
        static let ReadAlertState = "Read alert state change from unread to read"
        
        //USER_MESSAGES
        static let Authenticated = "User is authenticated."
        
        static let UserProfileReceive = "Successfully receive User profile."
        
        static let PasswordChanged = "Password Successfully Changed."
        
        static let InsertUserPassword = "Password successfully updated in Database."
        
        static let IncorrectCradentials = "UserName or Password is incorrect."
        
        static let UserAlreadyExist = "User already exist with same user name."
        
        static let UserDoesNotExist = "Previous User does not exist."
        
        static let SuccessfullyLoggedIn = "User is Successfully logged in."
        
        static let UserProfileUpdated = "User is successfully Updated."
        
        static let deletePassword = "Password successfully deleted."
        
        static let UserProfileNotUpdated = "Unable to update user profile."
        
        static let deleteProfile = "User profile deleted."
        
        static let LoggedInStateChange = "Successfully change loggedIn state."
        
        static let DeleteAlertTable = "Alert table deleted."
        
        static let UserVerified = "User is Verified"
        
         static let PasswordUpdated = "Password is successfully Updated"
        
        // SUBSCRIPTION_MESSAGES
        
        static let deleteSubscription = "Subscription is successfully deleted."
        
        // MQTT_MESSAGES
        static let Connected = "Connected to MQTT server."
        
        static let Connecting = "Connecting to MQTT server"
        
        static let Disconnected = "Disconnected from MQTT server"
        
        static let Disconnecting = "Disconnecting from MQTT server"
        
        static let Subscribed = "Subscribed to MQTT topic."
        
        static let Unsubscribed = "Unsubscribed to MQTT topic."
    }
    
    // WARNING_MESSAGES
    struct WARNING_MESSAGES {
        
        // USER_MESSAGES
        static let UserAlreadyExist = "User already exist with different user name."
    }
    
    // ERROR_MESSAGES
    struct ERROR_MESSAGES {
        
        // ALERT_MESSAGES
        
        static let CreateAlertTableFail = "Unable to create alert table."
        
        static let InserAlertError = "Unable to insert alert in database."
        
        static let ReadAlertsFail = "Unable to get alerts from database ."
        
        static let DeleteAlertFail = "Unable to Delete Alerts."
        
        static let DeleteMultipleAlertRecordFail = "Unable to Delete Alerts."
        
        static let DeleteOlderAlertRecordFail = "Unable to Delete Alerts."
        
        static let CountAlertRecordFail = "Unable to get alert's count."
        
        static let ReadAlertsWithRangeFail = "Unable to get user detail."
        
        static let SearchAlertWithFilterFail = "Unable to search alerts. Please try again."
        
        static let SearchAlertWithFilterRangeFail = "Unable to get alerts from database."
        
        static let CountAlertRecordWithFilterFail = "Unable to get alert's count."
        
        static let UpdateAlertReadStatusChangeFail = "Unable to update read status of alert."
        
        static let CountUnreadAlertRecordFail = "Unable to get alert's count."
        
        static let UnableToReadAlertDAO = "Unable to get alert Dao."
        
        static let InvalidAlert = "Invalid alert."
        
        // USER_MESSAGES
        static let CreateUserTableFail = "Unable to create user table."
        
        static let InsertUserRecordFail = "Unable to insert user detail."
        
        static let CountNumberOfUserRecordFail = "Unable to get count of users."
        
        static let DeleteUserRecordFail = "Unable to Delete user profile."
        
        static let UpdateUserPasswordFail = "Unable to update user password."
        
        static let DeleteUserPasswordFail = "Unable to delete database object."
        
        static let ReadUserRecordFail = "Unable to get user detail."
        
        static let DeleteAllUserProfile = "Unable to delete userProfile."
        
        static let DeleteUserTableFail = "Unable to delete user table."
        
        static let UpdateUserLoogedInStateFail = "Unable to update user login state."
        
        static let UnableToReadUserDAO = "Unable to get user Dao."
        
        static let UnableToVerifyUser = "Unable to verify user."
        
        static let PasswordNotUpdated = "Unable to updated user Password."
        
        // SUBSCRIPTION_MESSAGES
        static let CreateSubscriptionTableFail = "Unable to create subscription table."
        
        static let InsertSubscriptionRecordFail = "Unable to add user subscription."
        
        static let DeleteSubscriptionRecordFail = "Unable to delete user subscription ."
        
        static let ReadSubscriptionRecordFail = "Unable to get user subscription."
        
        static let UnableToReadSubscriptionDAO = "Unable to get subscription DAO."
        
        // MQTT_MESSAGES
        
        static let ReadCertificateFileFail = "Failed to open the certificate file."
        
        static let Certificate_File_Incorrect_Password = "ERROR: SecPKCS12Import returned errSecAuthFailed. Incorrect password."
        
        static let Unable_To_Connect = "Unable to connect to MQTT server."
        
        static let JSONParsingError = "Error parsing the alert."
        
        static let UnableToSubscribe = "Unable to subscribe to MQTT topic. Not connected."
        
        static let UnableToUnsubscribe = "Unable to unsubscribe to MQTT topic. Not connected."
        
        static let Disconnected = "Disconnected from MQTT server with error: "
        
    }
    
    static let UnableToCreateConnection = "Unable to create database connection."
    
    static let BackendConnectivity = "Unable to connect to the backend service ."
    
    static let UnexpectedError = "Unknown error occure. Because of "
    
    static let LoggedOutAndDisconnect = "Successfully logged out from w-alert. and disconnected from MQTT"
    
    static let LoggedOut = "Successfully logged out from w-alert"
    
    static let UnregisterDevice = "successfully unRegister device"
}
