//
// Created by Arqam Amin on 21/03/2018.
// Copyright (c) 2018 WeIntegrate B.V. All rights reserved.
//

import Foundation

class ResponseConstants {
    
    static let authenticated                = "Authenticated"
    
    static let unAuthenticated              = "Unathenticated"
    
    static let timeOut                      = "TimeOut"
    
    static let FalseToken                   = "FalseToken"
    
    static let UnexpectedError              = "UnexpectedError"
    
    static let GetUserResponse              = "GetUserResponse"
    
    static let Result                       = "Result"
    
    static let ResponseCode                 = "ResponseCode"
    
    static let User                         = "User"
    
    static let UserId                       = "UserId"
    
    static let Client                       = "Client"
    
    static let OrganizationId               = "OrganizationId"
    
    static let unathenticated               = "unathenticated"
}
