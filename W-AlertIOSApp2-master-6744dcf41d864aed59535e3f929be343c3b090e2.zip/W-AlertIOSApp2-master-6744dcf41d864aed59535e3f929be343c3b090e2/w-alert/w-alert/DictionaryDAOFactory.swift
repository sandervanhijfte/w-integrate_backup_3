//
//  DictionaryDAOFactory.swift
//  w-alert
//
//  Created by Arqam Amin on 24/01/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

class DictionaryDAOFactory: DAOFactory {
    
    // Methods
    
    /// Method : getDeviceTokenDAO
    /// Description : This method is use to get device token dao
    /// Input : void
    ///
    override func getDeviceTokenDAO() throws -> DeviceTokenDAO {
        return DictionaryDeviceTokenDAO()
    }
}
