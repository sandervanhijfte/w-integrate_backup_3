//
//  AlertDetail.swift
//  w-alert
//
//  Created by Arqam Amin on 10/28/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

// imports
import Foundation
class AlertDetail : Alert {
    
    /// Variables and Objects
    var alertId: String
    //var alertType: String
    var alertTitle: String
    var hostName: String
    var environmentName: String
    
    // Methods
    
    /// Method : init
    /// Description : This is constructer method and is use to construct object.
    /// Input : void
    ///
    init(id: Int64, alertId: String, timeStamp: String, severity: String, alertType: String, alertTitle: String, alertMessage: String, hostName: String, componentName: String, unread: Bool, environmentName: String) {
        self.alertId = alertId
        //self.alertType = timeStamp
        self.alertTitle = alertTitle
        self.hostName = hostName
        self.environmentName = environmentName
        super.init(id: id, timeStamp: timeStamp, severity: severity, alertType: alertType, alertMessage: alertMessage, componentName: componentName, unread: unread)
    }
    
    /// Method : init
    /// Description : This method override constructer method and is use to construct object.
    /// Input : void
    ///
    override init(id: Int64) {
        self.alertId = ""
        //self.alertType = ""
        self.alertTitle = ""
        self.hostName = ""
        self.environmentName = ""
        super.init(id: id)
    }
    
    /// Method: initilize
    /// Description: This method will use to initialize alertDetail
    /// Input : void
    ///
    private func initilize(alertId: String, alertType: String, alertTitle: String, hostName: String, unread: Bool,  environmentName: String) {
        self.alertId = alertId
        //self.alertType = alertType
        self.alertTitle = alertTitle
        self.hostName = hostName
        self.unread = unread
        self.environmentName = environmentName
    }
    
}

