//
//  DAOFactory.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

class DAOFactory{
    
    /// Method: getAlertDAO
    /// Description: This method will use to get alert dao
    ///
    func getAlertDAO() throws -> AlertDAO? {
        fatalError()
    }
    
    /// Method: getUserDAO
    /// Description: This method will use to get user dao
    ///
    func getUserDAO() throws -> UserDAO? {
        fatalError()
    }
    
    /// Method: getDeviceTokenDAO
    /// Description: This method will use to get device Token dao
    ///
    func getDeviceTokenDAO() throws -> DeviceTokenDAO? {
        fatalError()
    }
    
    /// Method: getSubscriptionDAO
    /// Description: This method will use to get subscription dao
    ///
    func getSubscriptionDAO() throws -> SubscriptionDAO {
        fatalError()
    }
    
    /// Method: getDAOFactory
    /// Description: This method will use to get dao Factory
    ///
    static func getDAOFactory(factoryType: DAOFactoryType) -> DAOFactory {
        switch factoryType {
        case .sqlite:
            return SqliteDAOFactory()
        case .dictionary:
            return DictionaryDAOFactory()
        default:
            return SqliteDAOFactory()
        }
    }
}

enum DAOFactoryType {
    case sqlite
    case dictionary
}
