//
//  SqliteUserDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 10/12/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation
import SQLite

class SqliteUserDAO : UserDAO {
    
    /*
     "CREATE TABLE IF NOT EXISTS T_USER (C_USER_ID text PRIMARY KEY,C_USER_NAME text, C_USER_PASSWORD text, C_USER_STATUS text, C_USER_FIRST_NAME text, C_USER_LAST_NAME text, C_USER_MOBILE_NO text, C_USER_EMAIL text, C_USER_ROLE_ID text, C_ORGANIZATION_ID text, C_ORGANIZATION_NAME text, C_ORGANIZATION_DOMAIN text)";
     
     */
    
    // Variables and Objects
    private let userTable = Table("t_user")
    private let C_ID = Expression<Int64>("C_ID")
    private let C_USER_ID = Expression<String>("C_USER_ID")
    private let C_USER_NAME = Expression<String>("C_USER_NAME")
    private let C_USER_PASSWORD = Expression<String>("C_USER_PASSWORD")
    private let C_USER_STATUS = Expression<String>("C_USER_STATUS")
    private let C_USER_FIRST_NAME = Expression<String>("C_USER_FIRST_NAME")
    private let C_USER_LAST_NAME = Expression<String>("C_USER_LAST_NAME")
    private let C_USER_MOBILE_NO = Expression<String>("C_USER_MOBILE_NO")
    private let C_USER_EMAIL = Expression<String>("C_USER_EMAIL")
    private let C_USER_ROLE_ID = Expression<String>("C_USER_ROLE_ID")
    private let C_ORGANIZATION_ID = Expression<String>("C_ORGANIZATION_ID")
    private let C_ORGANIZATION_NAME = Expression<String>("C_ORGANIZATION_NAME")
    private let C_ORGANIZATION_DOMAIN = Expression<String>("C_ORGANIZATION_DOMAIN")
    private let C_IS_LOGGED_IN = Expression<Bool>("C_IS_LOGGED_IN")
    
    private let dataBase: Connection?
    
    // Methods
    init(connection: Connection?) throws {
        dataBase = connection
        try createTable()
    }
    
    /// Method : createTable
    /// Description : This method will be use to create userDataBase
    /// Input : void
    ///
    func createTable() throws {
        
        do {
            try dataBase?.run(userTable.create(ifNotExists: true) { table in
                table.column(C_ID, primaryKey: true)
                table.column(C_USER_ID)
                table.column(C_USER_NAME)
                table.column(C_USER_PASSWORD)
                table.column(C_USER_STATUS)
                table.column(C_USER_FIRST_NAME)
                table.column(C_USER_LAST_NAME)
                table.column(C_USER_MOBILE_NO)
                table.column(C_USER_EMAIL)
                table.column(C_USER_ROLE_ID)
                table.column(C_ORGANIZATION_ID)
                table.column(C_ORGANIZATION_NAME)
                table.column(C_ORGANIZATION_DOMAIN)
                table.column(C_IS_LOGGED_IN)
            })
        } catch {
            throw UserError.CreateUserTableFail
        }
    }
    
    /// Method : insert
    /// Description : This method will be use to insert user in userDataBase
    /// Input : void
    ///
    func insert(user: User) throws -> Int64 {
        do {
            let query = self.userTable.insert(C_USER_ID <- user.userId, C_USER_NAME <- user.userName, C_USER_PASSWORD <- user.password, C_USER_STATUS <- user.status, C_USER_FIRST_NAME <- user.firstName, C_USER_LAST_NAME <- user.lastName, C_USER_MOBILE_NO <- user.mobileNo, C_USER_EMAIL <- user.email, C_USER_ROLE_ID <- user.roleId, C_ORGANIZATION_ID <- user.organizationId, C_ORGANIZATION_NAME <- user.organizationName, C_ORGANIZATION_DOMAIN <- user.organizationDomain, C_IS_LOGGED_IN <- user.isLoggedIn)
            
            return try dataBase!.run(query)
        } catch {
            throw UserError.InsertUserRecordFail
        }
    }
    
    /// Method : getUserProfile
    /// Description : This method will be use to get user profile from userDataBase
    /// Input : void
    ///
    func getUserProfile() throws -> User {
        
        do {
            let user = try dataBase!.prepare(self.userTable)
            return try getUser(user)
        } catch {
            throw UserError.ReadUserRecordFail
        }
    }
    
    /// Method : getUser
    /// Description : This method will be use to get user from userDataBase
    /// Input : void
    ///
    private func getUser(_ record: AnySequence<Row>) throws -> User {
        
        for user in record{
            return User(id: user[C_ID], userId: user[C_USER_ID], userName: user[C_USER_NAME], password: user[C_USER_PASSWORD], status: user[C_USER_STATUS], firstName: user[C_USER_FIRST_NAME], lastName: user[C_USER_LAST_NAME], mobileNo: user[C_USER_MOBILE_NO], email: user[C_USER_EMAIL], roleId: user[C_USER_ROLE_ID], organizationId: user[C_ORGANIZATION_ID], organizationName: user[C_ORGANIZATION_NAME], organzationDomain: user[C_ORGANIZATION_DOMAIN], isLoggedIn: user[C_IS_LOGGED_IN])
        }
        
        throw UserError.ReadUserRecordFail
    }
    
    /// Method : deleteUserPassword
    /// Description : This method will be use to delet user password from userDataBase
    /// Input : user id
    ///
    func deleteUserPassword(id: Int64) throws {
        
        do{
            try insertUserPassword(id: id, userPassword: "")
        }
        catch {
            throw UserError.DeleteUserPasswordFail
        }
    }
    
    /// Method : insertUserPassword
    /// Description : This method will be use to insert user password to userDataBase
    /// Input : id, userPassword
    ///
    func insertUserPassword(id: Int64, userPassword: String) throws {
        
        do{
            try self.dataBase!.run(self.userTable.filter(C_ID == id).update(C_USER_PASSWORD <- userPassword))
        } catch {
            throw UserError.UpdateUserPasswordFail
        }
    }
    
    /// Method : deleteUserProfile
    /// Description : This method will be use to delete userProfile from userDataBase
    /// Input : id
    ///
    func deleteUserProfile(id: Int64) throws {
        
        do {
            try dataBase!.run(self.userTable.filter(C_ID == id).delete())
        } catch {
            throw  UserError.DeleteUserRecordFail
        }
    }
    
    /// Method : deleteAllUserProfile
    /// Description : This method will be use to delete all user profiles from userDataBase
    /// Input : void
    ///
    func deleteAllUserProfile() throws {
        
        do {
            try dataBase!.run(self.userTable.delete())
        } catch {
            throw UserError.DeleteAllUserProfile
        }
    }
    
    /// Method : getUserCount
    /// Description : This method will be use to get user count from userDataBase
    /// Input : void
    ///
    func getUserCount() throws -> Int {
        
        do{
            return try self.dataBase!.scalar(self.userTable.count)
        } catch {
            throw UserError.CountNumberOfUserRecordFail
        }
    }
    
    /// Method : updateLoggedInState
    /// Description : This method will be use to update userLoggedin state in userDataBase
    /// Input : id, isLoggedIn
    ///
    func updateLoggedInState(id: Int64, isLoggedIn: Bool) throws {
        
        do{
            try self.dataBase!.run(self.userTable.filter(C_ID == id).update(C_IS_LOGGED_IN <- isLoggedIn))
        } catch {
            throw UserError.UpdateUserLoogedInStateFail
        }
    }
}
