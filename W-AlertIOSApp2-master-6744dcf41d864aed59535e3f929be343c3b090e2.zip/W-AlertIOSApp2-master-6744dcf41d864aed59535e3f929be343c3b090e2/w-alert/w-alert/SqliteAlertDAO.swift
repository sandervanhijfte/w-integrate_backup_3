//
//  SqliteAlertDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

// imports
import Foundation
import SQLite

class SqliteAlertDAO: AlertDAO {
    
    /**
     
     "CREATE TABLE IF NOT EXISTS T_ALERT (C_ALERT_ID text PRIMARY KEY, C_TIME_STAMP text, C_SEVERITY text, C_ALERT_TYPE text, C_ALERT_TITLE text, C_ALERT_MESSAGE text, C_HOST_NAME text, C_COMPONENT_NAME text, C_UNREAD numeric, C_ENVIRONMENT_NAME)"
     */
    
    // Variables and Objects
    private let alertTable = Table("T_ALERT")
    private let id = Expression<Int64>("id")
    private let C_ALERT_ID = Expression<String>("C_ALERT_ID")
    private let C_TIME_STAMP = Expression<String>("C_TIME_STAMP")
    private let C_SEVERITY = Expression<String>("C_SEVERITY")
    private let C_ALERT_TYPE = Expression<String>("C_ALERT_TYPE")
    private let C_ALERT_TITLE = Expression<String>("C_ALERT_TITLE")
    private let C_ALERT_MESSAGE = Expression<String>("C_ALERT_MESSAGE")
    private let C_HOST_NAME = Expression<String>("C_HOST_NAME")
    private let C_COMPONENT_NAME = Expression<String>("C_COMPONENT_NAME")
    private let C_UNREAD = Expression<Bool>("C_UNREAD")
    private let C_ENVIRONMENT_NAME = Expression<String>("C_ENVIRONMENT_NAME")
    
    private let dataBase: Connection?
    
    // Methods
    init(connection: Connection) throws {
        dataBase = connection
        do {
            guard (try createTable()) == true else{
                //throw AlertError.CreateAlertTableFail
                return
            }
        } catch {
            throw error
        }
        
    }
    
    /// Method : createTable
    /// Description : This method will be use create Alert table in database
    /// Input : void
    ///
    func createTable() throws -> Bool {
        var isExist = true
        do {
            try dataBase!.run(alertTable.create(ifNotExists: true) { table in
                table.column(id, primaryKey: true)
                table.column(C_ALERT_ID, unique: true)
                table.column(C_TIME_STAMP)
                table.column(C_SEVERITY)
                table.column(C_ALERT_TYPE)
                table.column(C_ALERT_TITLE)
                table.column(C_ALERT_MESSAGE)
                table.column(C_HOST_NAME)
                table.column(C_COMPONENT_NAME)
                table.column(C_UNREAD)
                table.column(C_ENVIRONMENT_NAME)
                isExist = false
            })
        } catch {
            throw AlertError.CreateAlertTableFail
        }
        return isExist
    }
    
    /// Method : insertAlert
    /// Description : This method will be use insert Alert in database
    /// Input : AlertDetail
    ///
    func insertAlert(alert: AlertDetail) throws -> Int64 {
        do {
            let insert = alertTable.insert(C_ALERT_ID <- alert.alertId ,C_TIME_STAMP <- alert.timeStamp, C_SEVERITY <- alert.severity, C_ALERT_TYPE <- alert.alertType, C_ALERT_TITLE <- alert.alertTitle, C_ALERT_MESSAGE <- alert.alertMessage, C_HOST_NAME <- alert.hostName, C_COMPONENT_NAME <- alert.componentName, C_UNREAD <- alert.unread, C_ENVIRONMENT_NAME <- alert.environmentName)
            
            return try dataBase!.run(insert)
        } catch {
            throw AlertError.InserAlertError
        }
    }
    
    /// Method : getAllAlerts
    /// Description : This method will be use creta Alert table in database
    /// Input : void
    ///
    func getAllAlerts() throws -> [Alert] {
        do {
            return try getAlerts(from: -1, limit: -1)
        } catch AlertError.ReadAlertsWithRangeFail{
            throw AlertError.ReadAlertsFail
        }
    }
    
    /// Method : createTable
    /// Description : This method will be use get Alert from database
    /// Input : from, limit
    ///
    func getAlerts(from: Int, limit: Int) throws -> [Alert] {
        do {
            
            let allAlert = try self.dataBase!.prepare(self.alertTable.limit(limit, offset: from).order(C_TIME_STAMP.desc, id.desc))
            return getAlerts(allAlert)
        } catch {
            throw AlertError.ReadAlertsWithRangeFail
        }
    }
    
    /// Method : getAlert
    /// Description : This method will be use to get Alert from database
    /// Input : id
    ///
    func getAlert(id: Int64) throws -> AlertDetail {
        do {
            
            let allAlert = try self.dataBase!.prepare(self.alertTable.filter(self.id == id))
            for alert in allAlert {
                return getAlertDetail(alert)
            }
        } catch {
            throw AlertError.ReadAlertsWithRangeFail
        }
        throw AlertError.ReadAlertsWithRangeFail
    }
    
    /// Method : deleteAlert
    /// Description : This method will be delete Alert from database
    /// Input : id
    ///
    func deleteAlert(alertId: Int64) throws {
        do {
            try dataBase!.run(self.alertTable.filter(id == alertId).delete())
        } catch {
            throw AlertError.DeleteAlertFail
        }
    }
    
    /// Method : deleteMultipleAlerts
    /// Description : This method will be use to delete Alert from database
    /// Input : list of ids
    ///
    func deleteMultipleAlerts(alertIds: [Int64]) throws {
        do {
            try dataBase!.run(self.alertTable.filter(alertIds.contains(id)).delete())
        } catch {
            throw AlertError.DeleteMultipleAlertRecordFail
        }
    }
    
    /// Method : deleteAllAlerts
    /// Description : This method will be use to delete all Alert from database
    /// Input : id
    ///
    func deleteAllAlerts() throws {
        do {
            try dataBase!.run(self.alertTable.delete())
        } catch {
            throw AlertError.DeleteMultipleAlertRecordFail
        }
    }
    
    /// Method : deleteAllUserProfile
    /// Description : This method will be use to delete all user profiles from userDataBase
    /// Input : void
    ///
    func deleteAlertTable() throws {
        
        do {
            try dataBase!.run(self.alertTable.delete())
        } catch {
            throw UserError.DeleteAllUserProfile
        }
    }
    
    /// Method : getTotalNumberOfAlerts
    /// Description : This method will be use to get Alert count from database
    /// Input : id
    ///
    func getTotalNumberOfAlerts() throws -> Int {
        do{
            return try self.dataBase!.scalar(alertTable.count)
        } catch {
            throw AlertError.CountAlertRecordFail
        }
        
    }
    
    /// Method : updateAlertStatusToRead
    /// Description : This method will be use to update alert status from database
    /// Input : id
    ///
    func updateAlertStatusToRead(alertId: Int64) throws {
        do {
            try self.dataBase!.run(self.alertTable.filter(id == alertId).update(C_UNREAD <- false))
        } catch {
            throw AlertError.UpdateAlertReadStatusChangeFail
        }
    }
    
    /// Method : searchAlert
    /// Description : This method will be use to get searched Alert from database
    /// Input : searchValue
    ///
    func searchAlert(searchValue: String) throws -> [Alert] {
        do{
            return try searchAlert(searchValue: searchValue, from: -1, limit: -1)
        } catch {
            throw AlertError.SearchAlertWithFilterFail
        }
    }
    
    /// Method : searchAlert
    /// Description : This method will be use to get searched Alert from database
    /// Input : searchValue, from , limit
    ///
    func searchAlert(searchValue: String, from: Int, limit: Int) throws -> [Alert] {
        
        do{
            let filterAlerts = try self.dataBase!.prepare(getFilterQuery(searchValue).order(C_TIME_STAMP.desc, id.desc).limit(limit, offset: from))
            
            return getAlerts(filterAlerts)
        } catch {
            throw AlertError.SearchAlertWithFilterRangeFail
        }
    }
    
    /// Method : getTotalNumberOfSearchAlerts
    /// Description : This method will be use to get searched Alert count from database
    /// Input : searchValue
    ///
    func getTotalNumberOfSearchAlerts(searchValue: String) throws -> Int {
        
        do{
            return try self.dataBase!.scalar(getFilterQuery(searchValue).count)
        } catch {
            throw AlertError.CountAlertRecordWithFilterFail
        }
    }
    
    /// Method : getTotalNumberOfUnreadAlerts
    /// Description : This method will be use to get unread Alert count from database
    /// Input : searchValue
    ///
    func getTotalNumberOfUnreadAlerts() throws -> Int {
        do{
            return try self.dataBase!.scalar(self.alertTable.filter(C_UNREAD == true).count)
        } catch {
            throw AlertError.CountUnreadAlertRecordFail
        }
    }
    
    /// Method : getFilterQuery
    /// Description : This method will be use to filter Alert from database
    /// Input : searchValue
    ///
    private func getFilterQuery(_ arg : String) -> Table {
        
        let keyword = "%\(arg)%";
        
        return self.alertTable.filter(C_ALERT_TITLE.like(keyword) || C_SEVERITY.like(keyword) || C_ALERT_TYPE.like(keyword) || C_COMPONENT_NAME.like(keyword) || C_TIME_STAMP.like(keyword))
    }
    
    /// Method : getAlerts
    ///Description : This method will be use to convert alerts record from AnySequence object to Alert array onjecct
    ///Input : AnySequence<Row>
    ///
    private func getAlerts(_ record: AnySequence<Row>) -> [Alert] {
        var alerts = [Alert]()
        
        for alert in record {
            let myAlert = getAlert(alert)
            
            alerts.append(myAlert)
        }
        
        return alerts
    }
    
    /// Method : getAlert
    /// Description : This method will be use to convert alert row record to Alert Object
    /// Input : Row
    ///
    private func getAlert(_ alert: Row) -> Alert {
        return Alert(id: alert[id], timeStamp: alert[C_TIME_STAMP], severity: alert[C_SEVERITY], alertType:alert[C_ALERT_TYPE], alertMessage: alert[C_ALERT_MESSAGE], componentName: alert[C_COMPONENT_NAME], unread: alert[C_UNREAD])
    }
    
    /// Method : getAlertDetail
    /// Description : This method will be use to convert alert row record to Alert Object
    /// Input : Row
    ///
    private func getAlertDetail(_ alert: Row) -> AlertDetail {
        return AlertDetail(id: alert[id], alertId:alert[C_ALERT_ID], timeStamp: alert[C_TIME_STAMP], severity: alert[C_SEVERITY], alertType: alert[C_ALERT_TYPE], alertTitle: alert[C_ALERT_TITLE], alertMessage: alert[C_ALERT_MESSAGE], hostName: alert[C_HOST_NAME], componentName: alert[C_COMPONENT_NAME], unread: alert[C_UNREAD], environmentName: alert[C_ENVIRONMENT_NAME])
    }
    
    /// Method: recycleAlerts
    /// Description: This method will delete alerts
    /// numberOfAlertsToDelete : number of alerts to delete
    ///
    func recycleAlerts(numberOfAlertsToDelete: Int) throws {
        do {
            
            let allAlert = try self.dataBase!.prepare(self.alertTable.limit(numberOfAlertsToDelete).order(C_TIME_STAMP.asc))
            let myAlerts = getAlerts(allAlert)
            var alertID: [Int64] = [Int64()]
            for alert in myAlerts {
                
                alertID.append(alert.id!)
            }
            print(alertID)
            try deleteMultipleAlerts(alertIds: alertID)
        } catch {
            
            throw AlertError.DeleteOlderAlertRecordFail
        }
    }
}
