//
//  SqliteDAOFactory.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

class SqliteDAOFactory: DAOFactory {
    
    /// Method: getAlertDAO
    /// Description: This method will use to get alert dao
    ///
    override func getAlertDAO() throws -> AlertDAO {
        do {
            
            return try SqliteAlertDAO(connection: try SQLiteConnection.getConnection())
        } catch {
            
            throw error//AlertError.CreateAlertTableFail
        }
    }
    
    /// Method: getUserDAO
    /// Description: This method will use to get user dao
    ///
    override func getUserDAO() throws -> UserDAO {
        do {
            
            return try SqliteUserDAO(connection: try SQLiteConnection.getConnection())
        } catch {
            
            throw UserError.UnableToCreateUserDAO
        }
    }
    
    /// Method: getSubscriptionDAO
    /// Description: This method will use to get subscription dao
    ///
    override func getSubscriptionDAO() throws -> SubscriptionDAO {
        do {
            return try SqliteSubscriptionDAO(connection: try SQLiteConnection.getConnection())
        } catch {
            throw SubscriptionError.UnableToCreateSubscriptionDAO
        }
    } 
}
