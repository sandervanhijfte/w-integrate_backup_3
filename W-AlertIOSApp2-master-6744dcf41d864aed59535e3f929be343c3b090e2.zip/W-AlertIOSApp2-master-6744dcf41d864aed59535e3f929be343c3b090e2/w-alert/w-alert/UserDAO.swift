//
//  IUserDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation

protocol UserDAO{
    
    func insert(user: User) throws -> Int64
    func getUserProfile() throws -> User
    func deleteUserPassword(id: Int64) throws
    func insertUserPassword(id: Int64, userPassword: String) throws
    func deleteUserProfile(id: Int64) throws
    func deleteAllUserProfile() throws
    func getUserCount() throws -> Int
    func updateLoggedInState(id: Int64, isLoggedIn: Bool) throws
}

