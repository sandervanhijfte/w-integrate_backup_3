//
//  DictionaryDeviceTokenDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 24/01/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

// imports
import Foundation

class DictionaryDeviceTokenDAO : DeviceTokenDAO{
    
    // Variables and Objects
    let preferences: UserDefaults! = UserDefaults.standard
    
    // Methods
    
    /// Method : insertNew
    /// Description : This method is use to insert new token.
    /// Input : token
    ///
    func insertNew(token: String) throws {
        
        preferences.set(token, forKey: TokenType.newToken.rawValue)
        preferences.synchronize()
    }
    
    /// Method : deleteToken
    /// Description : This method is use to delete token.
    /// Input : void
    ///
    func deleteToken() throws {
        
        preferences.removeObject(forKey: TokenType.newToken.rawValue)
        preferences.removeObject(forKey: TokenType.oldToken.rawValue)
    }
    
    /// Method : updateOldToken
    /// Description : This method is use to update old token.
    /// Input : void
    ///
    func updateOldToken() {
        
        let dt = getDeviceToken()
        preferences.set(dt, forKey: TokenType.oldToken.rawValue)
        preferences.synchronize()
    }
    
    /// Method : isTokenChanged
    /// Description : This method is use to check either token is changed.
    /// Input : void
    ///
    func isTokenChanged() -> Bool {
        
        guard let oldToken = preferences.object(forKey: TokenType.oldToken.rawValue) as! String?,
            let newToken = preferences.object(forKey: TokenType.newToken.rawValue) as! String?
            else {
                
                return true
        }
        
        if oldToken == newToken {
            
            return false
        }
        return true
    }
    
    /// Method : getDeviceToken
    /// Description : This method is use to get device token.
    /// Input : token
    ///
    func getDeviceToken() -> String? {
        
        return preferences.string(forKey: TokenType.newToken.rawValue)
    }
    
    enum TokenType : String {
        
        case newToken
        case oldToken
    }
}
