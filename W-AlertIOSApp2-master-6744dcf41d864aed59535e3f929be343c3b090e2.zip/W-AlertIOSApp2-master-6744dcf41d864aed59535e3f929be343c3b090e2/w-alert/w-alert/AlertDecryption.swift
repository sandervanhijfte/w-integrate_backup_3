//
//  AlertDecryption.swift
//  w-alert
//
//  Created by Arqam Amin on 26/02/2018.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation
import CryptoSwift

class AlertDecryption {
    //AlertDecryption methods
    
    /// Method : decryptAlertMessage
    /// Description : This method will be used to decrypt alertMessage
    /// Input : The input value is alert message string and encryption key
    ///
    func decryptAlertMessage(alertMessage: String, encryptionKey: String) -> String? {
        
        var message: String?
        do{
            
            let key = encryptionKey.bytes
            let cipher = try Blowfish(key: key, blockMode: .ECB, padding: .pkcs7)
            let decryptedAlert = try alertMessage.decryptBase64(cipher: cipher)

            if let string = String(bytes: decryptedAlert, encoding: .utf8) {

                message = string
            } else {
                Logger.log.warning("Alert message is not in a valid UTF-8 sequence")
            }
        }catch{
            
            Logger.log.debug("Error occure while decrypting alert message. Because of: \(error)")
        }
        return message
    }
}
