//
//  UpdatePasswordController.swift
//  w-alert
//
//  Created by Mehak Zia on 6/13/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports

import UIKit

class UpdatePasswordController: UIViewController {
    
    // Variables and Objects
    @IBOutlet weak var confirmationCodeText: CustomTextField!
    @IBOutlet weak var newPasswordText: CustomTextField!
    @IBOutlet weak var confirmationPasswordText: CustomTextField!
    @IBOutlet weak var submitButton: UIButton!
    weak var delegate: VerifyUserController!
    let activityIndicator: ActivityIndicator! = ActivityIndicator()
    var originalFrame = CGRect(x: 0.0, y: 0.0, width: 0.0, height: 0.0)
    var updatePasswordViewModel = UpdatePasswordViewModel()
    
    // VerifyUserController UIViewController Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        print(delegate.userNameText.text!)
        
        originalFrame = self.view.frame
        confirmationCodeText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
        newPasswordText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
        confirmationPasswordText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
        self.confirmationCodeText.delegate = self
        self.newPasswordText.delegate = self
        self.confirmationPasswordText.delegate = self
        confirmationCodeText.tag = 0
        newPasswordText.tag = 1
        confirmationPasswordText.tag = 2
        submitButton.isEnabled = false
    }
    
    /// Method : forgetPassword
    /// Description : This method is use to update user password.
    ///
    @IBAction func forgetPassword(_ sender: Any) {
        
        self.showActivityIndicator()
        
        guard confirmationCodeText.text != "", newPasswordText.text != "", confirmationPasswordText.text != "" else {
            self.alertDialog(message: Constants.FILL_REQUIRED_FIELDS, title: "Error")
            activityIndicator.hideActivityIndicator()
            return
        }
        guard validateConfirmationCode(), validateNewPassword(), validateConfirmPassword() else {
            self.alertDialog(message: Constants.VALID_DATA_MESSAGE, title: "Error")
            activityIndicator.hideActivityIndicator()
            return
        }
        updatePasswordViewModel.updatePassword(userName:delegate.userNameText.text!, confirmationCode: confirmationCodeText.text!, newPassword: newPasswordText.text!) { (isUpdated) in
 
            if !isUpdated {
                self.alertDialog(message: Constants.UNABLE_TO_CHANGE_PASSWORD_MESSAGE, title: "Error")
                self.activityIndicator.hideActivityIndicator()
                Logger.log.info("Fail to update password")
                return
            }
 
            Logger.log.info("Update password successfully.")
 
            self.alertDialogWithFunction(message: Constants.CHANGE_PASSWORD_MESSAGE, title: "Success")
            self.activityIndicator.hideActivityIndicator()
        }
    }
    
    /// Method : cancelButtonPressed
    /// Description : This method will take the user to login screen
    ///
    @IBAction func cancelButtonPressed(_ sender: Any) {
        
        navigationController?.popViewController(animated: false)
    }
    
    
    /// Method : confirmationCode
    /// Description : Show the required format of confirmationCode.
    ///
    @IBAction func confirmationCode(_ sender: Any) {
        
        self.alertDialog(message: Constants.CONFIRMATION_CODE_MESSAGE, title: "")
    }
    
    /// Method : newPasswordMessage
    /// Description : Show the required format of newPasswordMessage.
    ///
    @IBAction func newPasswordMessage(_ sender: Any) {
        
        self.alertDialog(message: Constants.NEW_PASSWORD_MESSAGE, title: "")
    }
    
    /// Method : confirmPasswordMessage
    /// Description : Show the required format of confirmPasswordMessage.
    ///
    @IBAction func confirmPasswordMessage(_ sender: Any) {
        
        self.alertDialog(message: Constants.CONFIRM_PASSWORD_MESSAGE, title: "")
    }
    
    /// Method : confirmationCodeTextChange
    /// Description : The text of confirmationCode textBox is changed
    ///
    @IBAction func confirmationCodeTextChange(_ sender: Any) {
        
        submitButton.isEnabled = validateConfirmationCode() && validateNewPassword() && validateConfirmPassword()
    }
    
    /// Method : newPasswordTextChange
    /// Description : The text of newPassword textBox is changed
    ///
    @IBAction func newPasswordTextChange(_ sender: Any) {
        
        submitButton.isEnabled = validateNewPassword() && validateConfirmationCode() && validateConfirmPassword()
    }
    
    /// Method : confirmPasswordTextChange
    /// Description : The text of confirmPassword textBox is changed
    ///
    @IBAction func confirmPasswordTextChange(_ sender: Any) {
        
            guard validateConfirmPassword(), validateConfirmationCode() , validateNewPassword()  else {
                submitButton.isEnabled = false
                return
        }
        submitButton.isEnabled = true
    }
    
    /// Method : tapGestureRecognizer
    /// Description : On tap the keyboard will hide
    ///
    @IBAction func tapGestureRecognizer(_ sender: Any) {
        
        view.endEditing(true)
        originalFrame.origin.y = 64
        self.view.frame = originalFrame
    }
    
    /// Method : showActivityIndicator
    /// Description : This method will be used to show acyivity indecator
    /// Input : none
    ///
    func showActivityIndicator() {
        
        let center = view.center
        let loadingView = activityIndicator.setLoadingView(center: center)
        view.addSubview(loadingView)
        activityIndicator.spinner.startAnimating()
        
    }
    
    /// Method : alertDialog
    /// Description : This method will be used to display the Alert dialog
    ///  Input : The input value is message string
    ///
    func alertDialog(message: String, title: String) {
        
        let errorAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        errorAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        self.present(errorAlert, animated: true, completion: nil)
    }
    
    /// Method : alertDialogWithFunction
    /// Description : This method will be used to display the Alert dialog
    ///  Input : The input value is message string and title
    ///
    func alertDialogWithFunction(message: String, title: String) {
        
        let errorAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        errorAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
           
            self.performSegue(withIdentifier: "Goto_Login_Page", sender: self)
            
        }))
        self.present(errorAlert, animated: true, completion: nil)
    }
    
    /// Method : validateConfirmationCode
    /// Description : This method will be used to validate confirmation code
    ///
    func validateConfirmationCode() -> Bool {
        
        if confirmationCodeText.text != "" {
            if (Validator().validateConfirmationCode(code: confirmationCodeText.text!)) {
                confirmationCodeText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
                return true
            } else {
                confirmationCodeText.awakeForError()
                return false
            }
        } else {
            confirmationCodeText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
            return false
        }
    }
    
    /// Method : validateNewPassword
    /// Description : This method will be used to validate new Password
    ///
    func validateNewPassword() -> Bool {
        validateConfirmPassword()
        if newPasswordText.text != "" {
            guard Validator().validatePasswordLength(password: newPasswordText.text!), Validator().newPasswordValidate(password: newPasswordText.text!) else {
                newPasswordText.awakeForError()
                return false
            }
            newPasswordText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
            return true
        } else {
            newPasswordText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
            return false
        }
        
    }
    
    /// Method : validateConfirmPassword
    /// Description : This method will be used to validate confirm Password
    ///
    func validateConfirmPassword() -> Bool {
        
        if confirmationPasswordText.text != "" {
            if (Validator().validateConfirmPassword(newPassword: newPasswordText.text!, confirmPassword: confirmationPasswordText.text!)) {
                confirmationPasswordText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
                print("validate true")
                return true
            } else {
                confirmationPasswordText.awakeForError()
                print("validate false")
                return false
            }
        } else {
            confirmationPasswordText.bottomBorder.backgroundColor = UIColor(red: 132 / 255, green: 151 / 255, blue: 176 / 255, alpha: 255)
            return false
        }
    }
}

// extension to UITextFieldDelegate
extension UpdatePasswordController: UITextFieldDelegate {
    
    // UITextFieldDelegate Methods
    
    /// Method : textFieldShouldBeginEditing
    /// Description : This method is overrided to handle the text field input
    ///
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        print("text return")
        if textField.tag == 0 {
            confirmationCodeText.resignFirstResponder()
            newPasswordText.becomeFirstResponder()
            return false
        } else if textField.tag == 1 {
            newPasswordText.resignFirstResponder()
            confirmationPasswordText.becomeFirstResponder()
            validateConfirmPassword()
            return false
        } else if textField.tag == 2 {
            confirmationPasswordText.resignFirstResponder()
            view.endEditing(true)
            originalFrame.origin.y = 64
            self.view.frame = originalFrame
            return false
        }
        return true
    }
    
    /// Method : textFieldDidEndEditing
    /// Description : This method is overrided to handle the text field input
    ///
    @nonobjc func textFieldDidEndEditing(_ textField: CustomTextField) {
        
        print("didend")
        //var result = false
        if textField.tag == 0 {
            print("tag 0 match")
            validateConfirmationCode()
        } else if textField.tag == 1 {
            print("tag 1 match")
            validateNewPassword()
            validateConfirmPassword()
        } else if textField.tag == 2 {
            print("tag 2 match")
            validateConfirmPassword()
        }
        print("didend end")
    }
}
