//
//  subscriptionError.swift
//  w-alert
//
//  Created by Mehak Zia on 4/16/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

import Foundation

/// Enum : SubscriptionError
/// Description : Errors for Subscription
///
enum SubscriptionError : Error {
    case CreateSubscriptionTableFail
    case InsertSubscriptionRecordFail
    case DeleteSubscriptionRecordFail
    case ReadSubscriptionRecordFail
    case UnableToCreateSubscriptionDAO
}
