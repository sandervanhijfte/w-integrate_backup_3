//
//  Name: IdentityandAccessManagement.swift
//  version: 1.0.0
//  Created by: Waqas Ali Razzaq on 9/20/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

//  imports

import Foundation
import Alamofire
import SwiftyJSON

class IdentityandAccessManagement: NSObject {

    // Methods

    /// Method      : authenticate
    /// Description : This method will be used to call the IdentityandAccessManagement API authenticate operation
    /// Input       : The input params are username and password
    /// Output      : String flag with status of authentication
    ///
    class func authenticate(userName: String, password: String, subscriptionKey: String, completionHandler: @escaping (_ result: String) -> ()) {
        let headers: HTTPHeaders = [
            "Authorization": subscriptionKey,
            "Accept": Constants.ACCEPT_HEADER]
        let parameters: Parameters = [
            "AuthenticateRequest": [
                "Header": [
                    "CMMHeader": [
                        "CorrelationId": UUID().uuidString
                    ]
                ],
                "ClientContext": [
                    "UserName": userName
                ],
                "UserName": userName.components(separatedBy: "@")[0],
                "UserPassword": password
            ]
        ]
        let IAMCookes = HTTPCookieStorage.shared
        if let cookes = IAMCookes.cookies(for: URL(string:Constants.ENVIRONMENT.AUTHENTICATE_USER_URL)!){
            for cooke in cookes {
                IAMCookes.deleteCookie(cooke)
            }
        }
        Alamofire.request(Constants.ENVIRONMENT.AUTHENTICATE_USER_URL, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
            .validate()
            .responseJSON { authenticateResponse in

                //print("authenticate \(authenticateResponse)");

                switch (authenticateResponse.result) {
                case .success:
                    var json = JSON(authenticateResponse.result.value!)
                    let responseCode = json["AuthenticateResponse"]["Result"]["ResponseCode"].stringValue
                    if responseCode == Constants.IDENTITY_AND_ACCESS_MANAGEMENT_SUCCESS_CODE {

                        completionHandler(ResponseConstants.authenticated)
                    } else if responseCode == Constants.IDENTITY_AND_ACCESS_MANAGEMENT_ERROR_CODE {

                        completionHandler(ResponseConstants.unathenticated)
                    } else {
                        completionHandler(ResponseConstants.unathenticated)
                    }
                    /*if json["AuthenticateResponse"]["AuthenticationStatus"].stringValue == "true" {
                     completionHandler("authenticated")
                     return
                     }
                     completionHandler("unathenticated")*/

                case .failure(let error):
                    if authenticateResponse.response?.statusCode == 401 {
                        completionHandler(ResponseConstants.FalseToken)
                    }
                    if error._code == NSURLErrorTimedOut {
                        completionHandler(ResponseConstants.timeOut)
                        return
                    }
                    completionHandler("UnexpectedError")
                }
        }
    }

    /// Method      : registerDevice
    /// Description : This method will be used to call the IdentityandAccessManagement API registerDevice operation
    /// Input       : The input params are username and client context
    /// Output      : String flag with status of registration
    ///
    class func registerDevice(userName: String, clientContextUser: String, completionHandler: @escaping (_ result: String) -> ()) {

        let headers: HTTPHeaders = [
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER
        ]
        let parameters: Parameters = [
            "RegisterDeviceRequest": [
                "Header": [
                    "CMMHeader": [
                        "CorrelationId": UUID().uuidString
                    ]
                ],
                "ClientContext": [
                    "UserName": clientContextUser
                ],
                "UserName": userName
            ]
        ]

        Alamofire.request(Constants.ENVIRONMENT.REGISTER_DEVICE_URL, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
            .responseJSON { registerDeviceResponse in

                //print(registerDeviceResponse)
                switch (registerDeviceResponse.result) {
                case .success:
                    var json = JSON(registerDeviceResponse.result.value!)
                    if json["RegisterDeviceResponse"]["RegistrationStatus"].stringValue == "true" {
                        completionHandler("registered")
                        return
                    }
                    completionHandler("unauthorized")

                case .failure(let error):
                    if error._code == NSURLErrorTimedOut {
                        completionHandler("timeOut")

                        return
                    }
                    completionHandler("unexpectedError")
                }
        }
    }

    /// Method      : changePassword
    /// Description : This method will be used to call the IdentityandAccessManagement API registerDevice operation
    /// Input       : The input params are username and oldPassword,newPassword
    /// Output      : String flag with status of changePassword
    ///
    class func changePassword(userName: String, oldPassword: String, newPassword: String, completionHandler: @escaping (JSON) -> ()) {
        let headers: HTTPHeaders = [
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER,
            "Content-Type": Constants.Content_Type]

        let parameters: Parameters = [
            "ChangePasswordRequest": [
                "Header": [
                    "CMMHeader": [
                        "CorrelationId": UUID().uuidString
                    ]
                ],
                "ClientContext": [
                    "UserName": userName
                ],
                "UserName": userName.components(separatedBy: "@")[0],
                "UserOldPassword": oldPassword,
                "UserPassword": newPassword
            ]
        ]

        Alamofire.request(Constants.ENVIRONMENT.CHANGE_PASSWORD_URL, method: .put, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
            .responseJSON { changePasswordResponse in
                //print(changePasswordResponse)
                switch (changePasswordResponse.result) {
                case .success:
                    var json = JSON(changePasswordResponse.result.value!)
                    //print(json)
                    if json["ChangePasswordResponse"]["Result"]["ResponseCode"].stringValue == Constants.IDENTITY_AND_ACCESS_MANAGEMENT_SUCCESS_CODE {
                        completionHandler("true")
                        return
                    }
                    completionHandler("false")

                case .failure(let error):
                    if error._code == NSURLErrorTimedOut {
                        completionHandler("false")
                        return
                    }
                    completionHandler(false)
                }
        }
    }
    
    /// Method      : verifyUserName
    /// Description : This method will be used to call the IdentityandAccessManagement API verifyUsername operation
    /// Input       : The input param is username
    /// Output      : String flag with status of verifyUsername
    ///
    class func verifyUserName(userName: String, completionHandler: @escaping (JSON) -> ()) {
        let headers: HTTPHeaders = [
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER,
            "Content-Type": Constants.Content_Type]
        
        let parameters: Parameters = [
            "VerifyUsernameRequest": [
                "Header": [
                    "CMMHeader": [
                        "CorrelationId": UUID().uuidString
                    ]
                ],
                "ClientContext": [
                    "UserName": userName
                ],
                "UserName": userName
            ]
        ]
        Alamofire.request(Constants.ENVIRONMENT.VERIFY_USERNAME_URL, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
            .responseJSON { verifyUsernameResponse in
                //print(verifyUsernameResponse)
                switch (verifyUsernameResponse.result) {
                case .success:
                    var json = JSON(verifyUsernameResponse.result.value!)
                    //print(json)
                    if json["VerifyUsernameResponse"]["Result"]["ResponseCode"].stringValue == Constants.IDENTITY_AND_ACCESS_MANAGEMENT_SUCCESS_CODE {
                        completionHandler("true")
                        return
                    }
                    completionHandler("false")
                    
                case .failure(let error):
                    if error._code == NSURLErrorTimedOut {
                        completionHandler("false")
                        return
                    }
                    completionHandler(false)
                }
        }
    }
    
    /// Method      : updatePassword
    /// Description : This method will be used to call the IdentityandAccessManagement API updatePassword operation
    /// Input       : The input param is username, confirmationCode, newPassword
    /// Output      : String flag with status of updatePassword
    ///
    class func updatePassword(userName: String, confirmationCode: String, newPassword: String, completionHandler: @escaping (JSON) -> ()) {
        let headers: HTTPHeaders = [
            "Authorization": Constants.ENVIRONMENT.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER,
            "Content-Type": Constants.Content_Type]
        
        let parameters: Parameters = [
            "UpdatePasswordRequest": [
                "Header": [
                    "CMMHeader": [
                        "CorrelationId": UUID().uuidString
                    ]
                ],
                "ClientContext": [
                    "UserName": userName
                ],
                "ConfirmationCode": confirmationCode,
                "UserPassword": newPassword
            ]
        ]
        Alamofire.request(Constants.ENVIRONMENT.UPDATE_PASSWORD_URL, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
            .responseJSON { updatePasswordResponse in
                //print(updatePasswordResponse)
                switch (updatePasswordResponse.result) {
                case .success:
                    var json = JSON(updatePasswordResponse.result.value!)
                    //print(json)
                    if json["UpdatePasswordResponse"]["Result"]["ResponseCode"].stringValue == Constants.IDENTITY_AND_ACCESS_MANAGEMENT_SUCCESS_CODE {
                        completionHandler("true")
                        return
                    }
                    completionHandler("false")
                    
                case .failure(let error):
                    if error._code == NSURLErrorTimedOut {
                        completionHandler("false")
                        return
                    }
                    completionHandler(false)
                }
        }
    }
}
