//
//  Name: LoginController.swift
//  version: 1.0.0
//  Created by: Waqas Ali Razzaq on 9/13/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//  Initial implementation: Waqas Ali
//

//  imports
import UIKit
import Alamofire
import SwiftyJSON
import UserNotifications

class LoginController: UIViewController {
    
    /// Variables and Object

    @IBOutlet var loginButton: CustomButton!
    @IBOutlet var passwordText: CustomTextField!
    @IBOutlet var userNameText: CustomTextField!
    @IBOutlet var subscriptionKeyText: CustomTextField!

    var activeTextField: UITextField!
    
    var loginViewModel: LoginViewModel! = LoginViewModel()

    private var spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    private var loadingView: UIView = UIView()

    var userPassword: String = ""
    var originalFrame = CGRect(x: 0.0, y: 0.0, width: 0.0, height: 0.0)

    /// Method : viewDidLoad
    /// Description : This method is overrided to load the ui
    ///
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        loginViewModel.loginButtonBinder = {
            self.loginButton.isEnabled = $0
        }
        initializeView()
        
        let center: NotificationCenter = NotificationCenter.default
        center.addObserver(self, selector: #selector(keybordDidShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        center.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    /// Method : loginPressed
    /// Description : This method will be invoked on Sign in button pressed
    ///  Input : The input param is touch event
    
    @IBAction func loginPressed(_ sender: Any) {
        
        let userName: String = userNameText.text!
        let password: String = passwordText.text!
        if (Validator().validatePassword(passwordText: passwordText) && (Validator().validateUserName(userNameText: userNameText))) {

            if (loginViewModel.userExist(userName: userName)) {
                login(userName: userName, password: password, subscriptionKey: getSubscriptionKey())
            } else { }
        }
    }
    
    /// Method : tapGestureRecognizer
    /// Description : This method will use recognize tapGesture.
    ///
    func getSubscriptionKey() -> String {
        if subscriptionKeyText.isHidden == true {
            return Constants.ENVIRONMENT.ACCESS_TOKEN
        }

        return "Bearer " + subscriptionKeyText.text!
    }
    
    /// Method : tapGestureRecognizer
    /// Description : This method will use recognize tapGesture.
    ///
    @IBAction func tapGestureRecognizer(_ sender: Any) {
        
        view.endEditing(true)
        self.view.frame = originalFrame
    }
    
    /// Method : userNameTextChange
    /// Description : This method will use when userName text is changed.
    ///
    @IBAction func userNameTextChange(_ sender: Any) {
        
    }
    
    /// Method : passwordTextChange
    /// Description :  This method will use when userName text is changed.
    ///
    @IBAction func passwordTextChange(_ sender: Any) {
        
    }
    
    /// Method : subscriptionTextChange
    /// Description : This method will be used recognize tapGesture.
    ///
    @IBAction func subscriptionTextChange(_ sender: Any) {
        
    }
    
    /// Method : initializeView
    /// Description : This method will set the ui
    ///
    func initializeView() {
        
        userNameText.tag = 0
        passwordText.tag = 1
        subscriptionKeyText.tag = 2
        loginButton.isEnabled = false
        self.userNameText.delegate = self
        self.passwordText.delegate = self
        self.subscriptionKeyText.delegate = self
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        originalFrame = self.view.frame
        spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
        self.loadingView = UIView()

        loginViewModel.ActivityIndicator = {
            if $0 {
                self.loadingView.frame = CGRect(x: 0.0, y: 0.0, width: 50.0, height: 50.0)
                self.loadingView.center = self.view.center
                self.loadingView.backgroundColor = UIColor(red: 0.26, green: 0.26, blue: 0.26, alpha: 0.7)
                self.loadingView.alpha = 0.7
                self.loadingView.clipsToBounds = true
                self.loadingView.layer.cornerRadius = 10
                self.spinner.frame = CGRect(x: 0.0, y: 0.0, width: 80.0, height: 80.0)
                self.spinner.center = CGPoint(x:self.loadingView.bounds.size.width / 2, y:self.loadingView.bounds.size.height / 2)
                self.loadingView.addSubview(self.spinner)
                self.view.addSubview(self.loadingView)
                self.spinner.startAnimating()
            } else {

                self.spinner.stopAnimating()
                self.spinner.removeFromSuperview()
                self.loadingView.removeFromSuperview()
            }
        }

        loginViewModel.alertDialogShow = {(title, description) in
            let alertController = UIAlertController(title: title, message: description, preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {
                (result : UIAlertAction) -> Void in
            }
            alertController.addAction(okAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    /// Method : login
    /// Description : This method will be used to authenticate the user
    /// Input : The input params are username and password
    ///
    func login(userName: String, password: String, subscriptionKey: String) -> Void {
        loginViewModel.login(userName: userName, password: password, subscriptionKey: subscriptionKey) {
            (message) in
            if (message == Constants.REGISTER_DEVICE_MESSAGE) {
                let alertController = UIAlertController(title: "Success", message: Constants.REGISTER_DEVICE_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
                let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {
                    (result : UIAlertAction) -> Void in
                    self.performSegue(withIdentifier: "goto_list", sender: self)
                }
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
                Logger.log.info("User has been successfully logged in and user profile is successfully updated.")
            } else {
                self.alertDialog(message: message,title: "Error")
                Logger.log.info("User has not been successfully logged in.")
            }
            self.loginViewModel.showLoginActivityIndicator = false
        }
    }
    
    /// Method : alertDialog
    /// Description : This method will be used to display the Alert dialog
    ///  Input : The input value is message string
    ///
    
    func alertDialog(message: String, title: String) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {
            (result : UIAlertAction) -> Void in
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
}

// extension to UITextFieldDelegate
extension LoginController: UITextFieldDelegate {
    
    // UITextFieldDelegate Methods
    
    /// Method : textFieldShouldReturn
    /// Description : This method is overrided to handle the text field input
    ///
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        if (textField.tag == 0) {
            userNameText.resignFirstResponder()
            passwordText.becomeFirstResponder()
            return false
        }
        else if(textField.tag == 1) {
            passwordText.resignFirstResponder()
            if(!(subscriptionKeyText.isHidden)) {
                subscriptionKeyText.becomeFirstResponder()
            }
            view.endEditing(true)
            return false
        } else if(textField.tag == 2) {
            subscriptionKeyText.resignFirstResponder()
            view.endEditing(true)
            return false
        }
        return true
    }
    
    func keybordDidShow(notification: Notification)  {
        let info: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        let keyboardY = self.view.frame.size.height - keyboardSize.height
        let editingTextFieldY: CGFloat! = self.activeTextField?.frame.origin.y
        if self.view.frame.origin.y >= 0 {
            if editingTextFieldY>keyboardY - 60 {
                UIView.animate(withDuration: 0.25, delay: 0.0, options: UIViewAnimationOptions.curveEaseIn, animations: {
                    self.view.frame = CGRect(x:0, y: self.view.frame.origin.y - (editingTextFieldY! - (keyboardY-60)), width: self.view.bounds.width, height: self.view.bounds.height)
                }, completion: nil)
            }
        }
    }
    
    func keyboardWillHide(notification: Notification)  {
        UIView.animate(withDuration: 0.25, delay: 0.0, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.view.frame = CGRect(x:0, y:0, width:self.view.bounds.width, height: self.view.bounds.height)
        }, completion: nil)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextField = textField
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    /// Method : textFieldDidEndEditing
    /// Description : This method is overrided to handle the text field input validation
    /// Input : name of text field
    ///
    
    //TODO: improve the if/else
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if (textField.tag == 0 && userNameText.text!.contains("@w-alertdemo")) {
            
            self.subscriptionKeyText.isHidden = true
            if (Validator().validateUserName(userNameText: userNameText)) {
                loginButton.isEnabled = true
                userNameText.awakeFromNib()
            } else {
                loginButton.isEnabled = false
            }
        }
        else if (textField.tag == 0 && !userNameText.text!.contains("@w-alertdemo")) {
            
            self.subscriptionKeyText.isHidden = false
            if (Validator().validateUserName(userNameText: userNameText)) {
                loginButton.isEnabled = true
                userNameText.awakeFromNib()
            }
            else {
                loginButton.isEnabled = false
            }
        }
        if (textField.tag == 1 && userNameText.text!.contains("@w-alertdemo")) {
            
            self.subscriptionKeyText.isHidden = true
            if (Validator().validatePassword(passwordText: passwordText)) {
                loginButton.isEnabled = true
                passwordText.awakeFromNib()
            }
            else {
                
                loginButton.isEnabled = false
            }
        }
            
        else if (textField.tag == 1 && !userNameText.text!.contains("@w-alertdemo")) {
            
            self.subscriptionKeyText.isHidden = false
            if (Validator().validatePassword(passwordText: passwordText)) {
                loginButton.isEnabled = true
                passwordText.awakeFromNib()
            }
            else {
                
                loginButton.isEnabled = false
            }
        }
    }
}
