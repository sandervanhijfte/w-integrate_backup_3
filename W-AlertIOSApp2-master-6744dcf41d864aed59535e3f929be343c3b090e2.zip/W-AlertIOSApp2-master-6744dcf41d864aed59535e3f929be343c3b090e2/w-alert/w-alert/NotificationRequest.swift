//
//  NotificationRequest.swift
//  w-alert
//
//  Created by Arqam Amin on 1/25/18.
//  Copyright © 2018 WeIntegrate B.V. All rights reserved.
//

//  imports
import Foundation
import UserNotifications
import XCGLogger

class NotificationRequest {
    
    // Variables and Objects
    static let center = UNUserNotificationCenter.current()
    static let content = UNMutableNotificationContent()
    static let identifier = "UYLLocalNotification"
    
    //notification request Methods
    
    /// Method : soundNotificationRequest
    /// Description : This method will be used to notify user with sound
    /// Input : The input value is alert message string and encryption key
    ///
    class func soundNotificationRequest() {
        
        content.sound = UNNotificationSound.default()
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval:  0.1, repeats: false)
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        center.add(request, withCompletionHandler: { (error) in
            if let error = error {
                
                Logger.log.error("Sound Notification failed with error: \(error)")
            }
        })
    }
}
