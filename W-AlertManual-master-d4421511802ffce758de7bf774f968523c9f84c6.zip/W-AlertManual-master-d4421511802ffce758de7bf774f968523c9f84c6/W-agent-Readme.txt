#*****************************************************
# Copyright (c) WeIntegrate bv 2016. All Rights Reserved.
# This configuration is copyright of WeIntegrate bv. The information
# contained herein is proprietary and confidential to WeIntegrate bv.
# This proprietary and confidential information, either in whole or in
# part, shall not be used for any purpose unless permitted by the terms
# of a valid license agreement.
#*****************************************************

Prerequisites
=============

Before installing, please ensure the following prerequisites:

a. JAVA_HOME must be set in the environment

b. JDK version > 1.7

Please  make sure that necessary permission are alloted to the user running the installation script.


Installation Steps
==================
 
1. Place the zip file W-Agent.zip where you would like to test the W-Agent.

2. Unzip W-Agent.zip and go the the W-Agent_Demo folder

4. In the folder, you should find W-Agentinstaller-86-64.sh. Open a terminal and enter following command to get access to installation folder.
	
	cd {W-Agent_Demo}
	
5. Type in the terminal following command:

	./W-AgentInstaller-x86-64.sh

6. The installer asks for the username, fill in the complete username (example@w-alertdemo.com) sent in the email.

7. The installer asks for the installation directory, type the path or follow the default path "<USER_HOME>/W-Agent_Default/" by keeping it blank and pressing ENTER.

8. The installer asks for the password of your machine to install, type in the linux password.

9. The installer asks whether you want the W-Agent to start. Respond with "Y" 

10. The installer will start W-Agent and exit afterwards.
						
11. Now login to the mobile app with credentials sent in the email to receive and view the alerts.

12. In order to receive alerts, execute the script file <Test-w-agent.sh> given at <USER_HOME>/W-Agent_Default/scripts/Test-w-agent.sh Or <SPECIFIED_PATH>/scripts/Test-w-agent.sh using below command in linux terminal.

     ./Test-w-agent.sh

13. Press "y" to send an alert or "n" to stop the script.

14. Check your mobile app to see the alert.


How to Start and Stop W-Agent Service
=====================================

For services, please make sure the user executing commands has necessary system priviledges.

1. For starting the W-Agent service, please enter following in the linux terminal.
	service w-agent start

2. For stopping the W-Agent service, please enter following in the linux terminal.
	service w-agent stop

3. To check the status of W-Agent service, please enter following in the linux terminal.
	service w-agent status