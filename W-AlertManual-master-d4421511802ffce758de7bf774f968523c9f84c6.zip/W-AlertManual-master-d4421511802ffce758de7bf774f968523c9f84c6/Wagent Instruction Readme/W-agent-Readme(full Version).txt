#*****************************************************
# Copyright (c) WeIntegrate bv 2016. All Rights Reserved.
# This configuration is copyright of WeIntegrate bv. The information
# contained herein is proprietary and confidential to WeIntegrate bv.
# This proprietary and confidential information, either in whole or in
# part, shall not be used for any purpose unless permitted by the terms
# of a valid license agreement.
#*****************************************************

Prerequisites
=============

Before installing, please ensure the following prerequisites:

a. JAVA_HOME must be set in the environment
b. JDK version > 1.7

Using Web Console:
1. Client Administrator is created and Users are created and assigned to a Group.
2. For Organization ID and Application Group ID, please refer to section 7 of web console.

Please  make sure that necessary permission are alloted to the user doing the installations.

Installation Steps
==================
 
1. Place the zip file W-Agent.zip where you would like to test the W-Agent.

2. Unzip W-Agent{ProductName}.zip.

3. Go the the W-Agent{ProductName} folder

4. There you should find W-Agentinstaller-86-64.sh. Open a terminal and enter following command to get access to installation folder.

	cd {W-Agent{ProductName}}

5. Type in the terminal following command:

	./W-AgentInstaller-x86-64.sh

6. The installer asks for the organization ID, fill in the complete organization ID. Please refer to Section 7 of web console manual. 

7. The installer asks for the Application group ID, fill in the complete Application group ID. Please refer to Section 7 of web console manual.

8. The installer asks for the Environment Name, fill in the complete environment name of the server. e.g. Dev, Test, Acceptance, Production etc.

9. The installer asks for the Log File Path, fill in the complete log file path of respective server e.g. /home/apache-activemq-5.9.0-bin/apache-activemq-5.9.0/data/activemq.log

10. The installer asks for the installation directory, type the path or follow the default path "<USER_HOME>/W-Agent_Default/" by keeping it blank and then pressing ENTER.

11. The installer asks for the password of your machine to install, type in the linux password.

12. The installer asks whether you want the W-Agent to start. If you want to start, please respond with Y. 

13. The installer should be able to run the W-Agent.

14. To test whether the W-Agent instance is running. Go to the W-Agent installation directory e.g. <USER_SPECIFIED_PATH>/w-agent/logs/.

15. Depending on the system constraints and internet speed, it can take a while before W-Agent starts. Check for logs in file <w-agent.log> for any issue, if there are no issues following success message will be displayed in the log file. 
					
							[logstash.pipeline        ] Pipeline main started
							[INFO ][logstash.agent           ] Successfully started Logstash API endpoint 
							

16. Please go to the directory where the W-Agent is installed, for path please consult point 9. Please enter the path of your log file in w-agentshipper.conf file.

17. Now login to the mobile app with credentials sent in the email or provided by the administrator to view the alerts.

18.Check your mobile app to see the alerts of the logs.


How to Start and Stop W-Agent Service
=====================================

For services, please make sure the user executing commands has necessary system priviledges.

1. For starting the W-Agent service, please enter following in the linux terminal.
	service w-agent start
2. For stopping the W-Agent service, please enter following in the linux terminal.
	service w-agent stop
3. To check the status of W-Agent service, please enter following in the linux terminal.
	service w-agent status
	