#*****************************************************
# Copyright (c) WeIntegrate bv 2016. All Rights Reserved.
# This configuration is copyright of WeIntegrate bv. The information
# contained herein is proprietary and confidential to WeIntegrate bv.
# This proprietary and confidential information, either in whole or in
# part, shall not be used for any purpose unless permitted by the terms
# of a valid license agreement.
#*****************************************************
Prerequisites
=============
Before installing, please ensure the following prerequisites:
a. JAVA_HOME must be set in the environment
b. JDK version > 1.7
Please  make sure that necessary permission are alloted to the user doing the installations.
Installation Steps
==================
 
1. Place the zip file W-Agent.zip where you would like to test the W-Agent.
2. Unzip W-Agent.zip.
3. Go the the W-Agent_Demo folder
4.There you should find W-Agentinstaller-86-64.sh. Open a terminal and enter following command to get access to installation folder.
	
	cd {W-Agent_Demo}
	
5. Type in the terminal following command:
	./W-AgentInstaller-x86-64.sh
6. The installer asks for the username, fill in the complete username (example@w-alertdemo.com) sent in the email.
7. The installer asks for the installation directory, type the path or follow the default path "<USER_HOME>/W-Agent_Default/" by keeping it blank and pressing ENTER.
8. The installer asks for the password of your machine to install, type in the linux password.
9. The installer asks whether you want the W-Agent to start. Respond with "Y" 
10. The installer will exit.
11. To test whether the W-Agent instance is running. Go to the W-Agent installation directory e.g. default path <USER_HOME>/W-Agent_Default/w-agent/logs/ Or <USER_SPECIFIED_PATH>/w-agent/logs/. 
12. Depending on the system constraints and internet speed, it can take a while before W-Agent starts. Check for logs in file <w-agent.log> for any issue, if there are no issues following success message will be displayed in the log file. 
					
							[logstash.pipeline        ] Pipeline main started
							[INFO ][logstash.agent           ] Successfully started Logstash API endpoint 
						
13. Now login to the mobile app with credentials sent in the email to receive and view the alerts.
14. In order to receive alerts, open the sample log file <sample.log> given at <USER_HOME>/W-Agent_Default/samples/sample.log Or <SPECIFIED_PATH>/samples/sample.log using "vi", "nano" using below commands. You can also use any other text editor as well.
15. "nano <USER_HOME>/W-Agent_Default/samples/sample.log" Or "nano <USER_SPECIFIED_PATH>/samples/sample.log"
16. Copy the log entry from <W-Agent_Demo>/samples/sample.log and paste it at the end of file that is opened using above step. After pasting the entry press Ctrl+X from keyboard then type the "Y" to confirm the changes and press Enter button from keyboard.
17. Check your mobile app to see the alert.

Troubleshooting
==================
1. If you use gedit or any linux UI editor, you might receive repeating alerts.
How to Start and Stop W-Agent Service
=====================================
For services, please make sure the user executing commands has necessary system priviledges.
1. For starting the W-Agent service, please enter following in the linux terminal.
	service w-agent start
2. For stopping the W-Agent service, please enter following in the linux terminal.
	service w-agent stop
3. To check the status of W-Agent service, please enter following in the linux terminal.
	service w-agent status