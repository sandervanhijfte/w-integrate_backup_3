package nl.weintegrate.util.mediators;

/*
 * Author: Yasir Janjua
 * Date: 30/05/2018
 * 
 * Purpose: Generates Authentication Token based on HmacSHA256 as Algorithm and 
 * 			BaseString as Salt
 */

/*Java Imports*/
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

/*Java Crypto Libraries Imports*/
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/*WSO2 Libraries Imports*/
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.synapse.MessageContext;
import org.apache.synapse.SynapseException;
import org.apache.synapse.mediators.AbstractMediator;

public class StringHasher extends AbstractMediator {

	private static final Log log = LogFactory.getLog(StringHasher.class);
	private String HASH_SALT = "";
	private String HASHING_ALGORITHM = "HmacSHA256";
	private String STRING_TO_BE_HASHED = "";
	private String AUTHENTICATION_TOKEN = "AUTHENTICATION_TOKEN";
	private String HASH_TIMESTAMP = "HASH_TIMESTAMP";
	private String CLIENT_NUMBER = "CLIENT_NUMBER";
	
	/**
	 * define default message mediation
	 */
	public boolean mediate(MessageContext context) {

		String apiKey = "f60e0c16-a0e8-4181-9843-cd31faefa453";
		String apiClientNumber = "7460";

		Date currentDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
		String date = formatter.format(currentDate);

		String baseString = String.format("%1$s|%2$s|%3$s", date.substring(0, 10), date.substring(11, 23),
				apiClientNumber);

		setHashSalt(apiKey);
		setStringToBeHashed(baseString);

		// By enabling debug logs for this class mediator we can check whether
		// the values have been passed properly
		if (log.isDebugEnabled()) {

			log.debug("Value need to be hashed : " + STRING_TO_BE_HASHED);
			log.debug("Hash Salt  : " + HASH_SALT);
		}

		try {

			String hash = computeHash(HASH_SALT, STRING_TO_BE_HASHED, HASHING_ALGORITHM);
			String token = String.format("%s:%s", apiClientNumber, hash);

			// By enabling debug logs for this class mediator we can check
			// whether
			// the values have been passed properly
			if (log.isDebugEnabled()) {

				log.debug("Hashed Value : " + hash);
				log.debug("Authentication Token : " + token);
			} else {

				log.info("Client Number : " + apiClientNumber);
				log.info("Date : " + date);
				log.info("Authentication Token : " + token);
			}

			// Set HASHED_VALUE
			context.setProperty(AUTHENTICATION_TOKEN, token);
			// Set HASH_TIMESTAMP
			context.setProperty(HASH_TIMESTAMP, date);
			// Set CLIENT_NUMBER
			context.setProperty(CLIENT_NUMBER, apiClientNumber);

		} catch (NoSuchAlgorithmException e) {
			
			throw new SynapseException("Error occurred while getting algorithm.", e);
		} catch (InvalidKeyException e) {

			throw new SynapseException("Error occurred while creating key.", e);
		} catch (UnsupportedEncodingException e) {

			throw new SynapseException("Error occurred while encoding.", e);
		}

		return true;
	}
	
	/**
	 * 
	 * @param key - Salt for hashing 
	 * @param data - String to be hashed
	 * @param algorithm - Hashing Algorithm
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws UnsupportedEncodingException
	 * @throws InvalidKeyException
	 */
	public String computeHash(String key, String data, String algorithm)
			throws NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeyException {
		Mac hmac = Mac.getInstance(algorithm);
		SecretKeySpec secretKey = new SecretKeySpec(key.getBytes("UTF-8"), algorithm);
		hmac.init(secretKey);

		String hash = Base64.getEncoder().encodeToString(hmac.doFinal(data.getBytes("UTF-8")));

		return hash;
	}
	
	/**
	 * Set Salt
	 * @param salt
	 */
	public void setHashSalt(String salt) {
		this.HASH_SALT = salt;
	}
	
	/**
	 * Set StringToBeHashed
	 * @param data
	 */
	public void setStringToBeHashed(String data) {
		this.STRING_TO_BE_HASHED = data;
	}
	
}
