﻿using System;
using System.Drawing;

namespace WAgentService
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wAgentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sendFeedbackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ApplicationStatusValueLabel = new System.Windows.Forms.Label();
            this.ApplicationStatusKeyLabel = new System.Windows.Forms.Label();
            this.ServiceNotFoundLabel = new System.Windows.Forms.Label();
            this.WAgentApplicationDetailsBox = new System.Windows.Forms.RichTextBox();
            this.WAgentApplicationTestButton = new System.Windows.Forms.Button();
            this.WAgentApplicationDetailsButton = new System.Windows.Forms.Button();
            this.WAgentApplicationRestartButton = new System.Windows.Forms.Button();
            this.WAgentApplicationStopButton = new System.Windows.Forms.Button();
            this.WAgentApplicationStartButton = new System.Windows.Forms.Button();
            this.WAgentLogo = new System.Windows.Forms.PictureBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.PermissionsLabel = new System.Windows.Forms.Label();
            this.RestartButton = new System.Windows.Forms.Button();
            this.ApplicationNotFoundLabel = new System.Windows.Forms.Label();
            this.WAgentTestButton = new System.Windows.Forms.Button();
            this.ServiceTabDetailsButton = new System.Windows.Forms.Button();
            this.DetailsBoxServiceTab = new System.Windows.Forms.RichTextBox();
            this.ServiceNameKey = new System.Windows.Forms.Label();
            this.WAgentRestartButton = new System.Windows.Forms.Button();
            this.WAgentLogoServiceTab = new System.Windows.Forms.PictureBox();
            this.WAgentStopButton = new System.Windows.Forms.Button();
            this.WAgentStartButton = new System.Windows.Forms.Button();
            this.ServiceNameLabel = new System.Windows.Forms.Label();
            this.ServiceStatusKey = new System.Windows.Forms.Label();
            this.ServiceStatus = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.menuStrip1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WAgentLogo)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WAgentLogoServiceTab)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(834, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewHelpToolStripMenuItem,
            this.wAgentToolStripMenuItem,
            this.sendFeedbackToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.aboutToolStripMenuItem.Text = "Help";
            // 
            // viewHelpToolStripMenuItem
            // 
            this.viewHelpToolStripMenuItem.Name = "viewHelpToolStripMenuItem";
            this.viewHelpToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.viewHelpToolStripMenuItem.Text = "View Help";
            this.viewHelpToolStripMenuItem.Click += new System.EventHandler(this.viewHelpToolStripMenuItem_Click);
            // 
            // wAgentToolStripMenuItem
            // 
            this.wAgentToolStripMenuItem.Name = "wAgentToolStripMenuItem";
            this.wAgentToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.wAgentToolStripMenuItem.Text = "About";
            this.wAgentToolStripMenuItem.Click += new System.EventHandler(this.wAgentToolStripMenuItem_Click);
            // 
            // sendFeedbackToolStripMenuItem
            // 
            this.sendFeedbackToolStripMenuItem.Name = "sendFeedbackToolStripMenuItem";
            this.sendFeedbackToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.sendFeedbackToolStripMenuItem.Text = "Send Feedback";
            this.sendFeedbackToolStripMenuItem.Click += new System.EventHandler(this.sendFeedbackToolStripMenuItem_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ApplicationStatusValueLabel);
            this.tabPage2.Controls.Add(this.ApplicationStatusKeyLabel);
            this.tabPage2.Controls.Add(this.ServiceNotFoundLabel);
            this.tabPage2.Controls.Add(this.WAgentApplicationDetailsBox);
            this.tabPage2.Controls.Add(this.WAgentApplicationTestButton);
            this.tabPage2.Controls.Add(this.WAgentApplicationDetailsButton);
            this.tabPage2.Controls.Add(this.WAgentApplicationRestartButton);
            this.tabPage2.Controls.Add(this.WAgentApplicationStopButton);
            this.tabPage2.Controls.Add(this.WAgentApplicationStartButton);
            this.tabPage2.Controls.Add(this.WAgentLogo);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(826, 522);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Application";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // ApplicationStatusValueLabel
            // 
            this.ApplicationStatusValueLabel.AutoSize = true;
            this.ApplicationStatusValueLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ApplicationStatusValueLabel.Location = new System.Drawing.Point(154, 29);
            this.ApplicationStatusValueLabel.Name = "ApplicationStatusValueLabel";
            this.ApplicationStatusValueLabel.Size = new System.Drawing.Size(58, 16);
            this.ApplicationStatusValueLabel.TabIndex = 21;
            this.ApplicationStatusValueLabel.Text = "Stopped";
            // 
            // ApplicationStatusKeyLabel
            // 
            this.ApplicationStatusKeyLabel.AutoSize = true;
            this.ApplicationStatusKeyLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ApplicationStatusKeyLabel.Location = new System.Drawing.Point(18, 29);
            this.ApplicationStatusKeyLabel.Name = "ApplicationStatusKeyLabel";
            this.ApplicationStatusKeyLabel.Size = new System.Drawing.Size(129, 16);
            this.ApplicationStatusKeyLabel.TabIndex = 20;
            this.ApplicationStatusKeyLabel.Text = "Application Status :";
            // 
            // ServiceNotFoundLabel
            // 
            this.ServiceNotFoundLabel.AutoSize = true;
            this.ServiceNotFoundLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceNotFoundLabel.Location = new System.Drawing.Point(11, 27);
            this.ServiceNotFoundLabel.Name = "ServiceNotFoundLabel";
            this.ServiceNotFoundLabel.Size = new System.Drawing.Size(0, 16);
            this.ServiceNotFoundLabel.TabIndex = 19;
            // 
            // WAgentApplicationDetailsBox
            // 
            this.WAgentApplicationDetailsBox.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WAgentApplicationDetailsBox.Location = new System.Drawing.Point(12, 311);
            this.WAgentApplicationDetailsBox.Name = "WAgentApplicationDetailsBox";
            this.WAgentApplicationDetailsBox.Size = new System.Drawing.Size(384, 195);
            this.WAgentApplicationDetailsBox.TabIndex = 18;
            this.WAgentApplicationDetailsBox.Text = "";
            this.WAgentApplicationDetailsBox.WordWrap = false;
            this.WAgentApplicationDetailsBox.TextChanged += new System.EventHandler(this.WAgentApplicationDetailsBox_TextChanged);
            // 
            // WAgentApplicationTestButton
            // 
            this.WAgentApplicationTestButton.Location = new System.Drawing.Point(288, 69);
            this.WAgentApplicationTestButton.Name = "WAgentApplicationTestButton";
            this.WAgentApplicationTestButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentApplicationTestButton.TabIndex = 17;
            this.WAgentApplicationTestButton.Text = "Send Alert\r\n(For Testing Only)";
            this.WAgentApplicationTestButton.UseVisualStyleBackColor = true;
            this.WAgentApplicationTestButton.Click += new System.EventHandler(this.WAgentApplicationTestButton_Click);
            // 
            // WAgentApplicationDetailsButton
            // 
            this.WAgentApplicationDetailsButton.Location = new System.Drawing.Point(12, 285);
            this.WAgentApplicationDetailsButton.Name = "WAgentApplicationDetailsButton";
            this.WAgentApplicationDetailsButton.Size = new System.Drawing.Size(61, 20);
            this.WAgentApplicationDetailsButton.TabIndex = 16;
            this.WAgentApplicationDetailsButton.Text = "Details>>";
            this.WAgentApplicationDetailsButton.UseVisualStyleBackColor = true;
            this.WAgentApplicationDetailsButton.Click += new System.EventHandler(this.WAgentApplicationDetailsButton_Click);
            // 
            // WAgentApplicationRestartButton
            // 
            this.WAgentApplicationRestartButton.Location = new System.Drawing.Point(288, 222);
            this.WAgentApplicationRestartButton.Name = "WAgentApplicationRestartButton";
            this.WAgentApplicationRestartButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentApplicationRestartButton.TabIndex = 15;
            this.WAgentApplicationRestartButton.Text = "Restart W-Agent";
            this.WAgentApplicationRestartButton.UseVisualStyleBackColor = true;
            // 
            // WAgentApplicationStopButton
            // 
            this.WAgentApplicationStopButton.Location = new System.Drawing.Point(288, 172);
            this.WAgentApplicationStopButton.Name = "WAgentApplicationStopButton";
            this.WAgentApplicationStopButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentApplicationStopButton.TabIndex = 14;
            this.WAgentApplicationStopButton.Text = "Stop W-Agent";
            this.WAgentApplicationStopButton.UseVisualStyleBackColor = true;
            this.WAgentApplicationStopButton.Click += new System.EventHandler(this.WAgentApplicationStopButton_Click);
            // 
            // WAgentApplicationStartButton
            // 
            this.WAgentApplicationStartButton.Location = new System.Drawing.Point(288, 119);
            this.WAgentApplicationStartButton.Name = "WAgentApplicationStartButton";
            this.WAgentApplicationStartButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentApplicationStartButton.TabIndex = 13;
            this.WAgentApplicationStartButton.Text = "Start W-Agent";
            this.WAgentApplicationStartButton.UseVisualStyleBackColor = true;
            this.WAgentApplicationStartButton.Click += new System.EventHandler(this.WAgentApplicationStartButton_Click);
            // 
            // WAgentLogo
            // 
            this.WAgentLogo.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.WAgentLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WAgentLogo.BackgroundImage")));
            this.WAgentLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.WAgentLogo.InitialImage = ((System.Drawing.Image)(resources.GetObject("WAgentLogo.InitialImage")));
            this.WAgentLogo.Location = new System.Drawing.Point(11, 69);
            this.WAgentLogo.Name = "WAgentLogo";
            this.WAgentLogo.Size = new System.Drawing.Size(213, 198);
            this.WAgentLogo.TabIndex = 10;
            this.WAgentLogo.TabStop = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.PermissionsLabel);
            this.tabPage1.Controls.Add(this.RestartButton);
            this.tabPage1.Controls.Add(this.ApplicationNotFoundLabel);
            this.tabPage1.Controls.Add(this.WAgentTestButton);
            this.tabPage1.Controls.Add(this.ServiceTabDetailsButton);
            this.tabPage1.Controls.Add(this.DetailsBoxServiceTab);
            this.tabPage1.Controls.Add(this.ServiceNameKey);
            this.tabPage1.Controls.Add(this.WAgentRestartButton);
            this.tabPage1.Controls.Add(this.WAgentLogoServiceTab);
            this.tabPage1.Controls.Add(this.WAgentStopButton);
            this.tabPage1.Controls.Add(this.WAgentStartButton);
            this.tabPage1.Controls.Add(this.ServiceNameLabel);
            this.tabPage1.Controls.Add(this.ServiceStatusKey);
            this.tabPage1.Controls.Add(this.ServiceStatus);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(826, 522);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Service";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // PermissionsLabel
            // 
            this.PermissionsLabel.AutoSize = true;
            this.PermissionsLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PermissionsLabel.ForeColor = System.Drawing.Color.Red;
            this.PermissionsLabel.Location = new System.Drawing.Point(90, 287);
            this.PermissionsLabel.Name = "PermissionsLabel";
            this.PermissionsLabel.Size = new System.Drawing.Size(192, 14);
            this.PermissionsLabel.TabIndex = 15;
            this.PermissionsLabel.Text = "Administrator Permission Required.";
            this.PermissionsLabel.Visible = false;
            // 
            // RestartButton
            // 
            this.RestartButton.Image = ((System.Drawing.Image)(resources.GetObject("RestartButton.Image")));
            this.RestartButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RestartButton.Location = new System.Drawing.Point(311, 282);
            this.RestartButton.Name = "RestartButton";
            this.RestartButton.Size = new System.Drawing.Size(65, 23);
            this.RestartButton.TabIndex = 14;
            this.RestartButton.Text = "Restart";
            this.RestartButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.RestartButton.UseVisualStyleBackColor = true;
            this.RestartButton.Visible = false;
            this.RestartButton.Click += new System.EventHandler(this.RestartButton_Click);
            // 
            // ApplicationNotFoundLabel
            // 
            this.ApplicationNotFoundLabel.AutoSize = true;
            this.ApplicationNotFoundLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ApplicationNotFoundLabel.Location = new System.Drawing.Point(11, 27);
            this.ApplicationNotFoundLabel.Name = "ApplicationNotFoundLabel";
            this.ApplicationNotFoundLabel.Size = new System.Drawing.Size(0, 16);
            this.ApplicationNotFoundLabel.TabIndex = 13;
            // 
            // WAgentTestButton
            // 
            this.WAgentTestButton.Location = new System.Drawing.Point(287, 69);
            this.WAgentTestButton.Name = "WAgentTestButton";
            this.WAgentTestButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentTestButton.TabIndex = 12;
            this.WAgentTestButton.Text = "Send Alert\r\n(For Testing Only)";
            this.WAgentTestButton.UseVisualStyleBackColor = true;
            this.WAgentTestButton.Click += new System.EventHandler(this.WAgentTestButton_Click);
            // 
            // ServiceTabDetailsButton
            // 
            this.ServiceTabDetailsButton.Location = new System.Drawing.Point(11, 285);
            this.ServiceTabDetailsButton.Name = "ServiceTabDetailsButton";
            this.ServiceTabDetailsButton.Size = new System.Drawing.Size(61, 20);
            this.ServiceTabDetailsButton.TabIndex = 10;
            this.ServiceTabDetailsButton.Text = "Details>>";
            this.ServiceTabDetailsButton.UseVisualStyleBackColor = true;
            this.ServiceTabDetailsButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // DetailsBoxServiceTab
            // 
            this.DetailsBoxServiceTab.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DetailsBoxServiceTab.Location = new System.Drawing.Point(11, 311);
            this.DetailsBoxServiceTab.Name = "DetailsBoxServiceTab";
            this.DetailsBoxServiceTab.Size = new System.Drawing.Size(384, 195);
            this.DetailsBoxServiceTab.TabIndex = 9;
            this.DetailsBoxServiceTab.Text = "";
            this.DetailsBoxServiceTab.WordWrap = false;
            this.DetailsBoxServiceTab.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // ServiceNameKey
            // 
            this.ServiceNameKey.AutoSize = true;
            this.ServiceNameKey.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceNameKey.Location = new System.Drawing.Point(6, 18);
            this.ServiceNameKey.Name = "ServiceNameKey";
            this.ServiceNameKey.Size = new System.Drawing.Size(99, 16);
            this.ServiceNameKey.TabIndex = 7;
            this.ServiceNameKey.Text = "Service Name :";
            // 
            // WAgentRestartButton
            // 
            this.WAgentRestartButton.Location = new System.Drawing.Point(287, 222);
            this.WAgentRestartButton.Name = "WAgentRestartButton";
            this.WAgentRestartButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentRestartButton.TabIndex = 2;
            this.WAgentRestartButton.Text = "Restart W-Agent";
            this.WAgentRestartButton.UseVisualStyleBackColor = true;
            this.WAgentRestartButton.Click += new System.EventHandler(this.WAgentRestartButton_Click);
            // 
            // WAgentLogoServiceTab
            // 
            this.WAgentLogoServiceTab.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.WAgentLogoServiceTab.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WAgentLogoServiceTab.BackgroundImage")));
            this.WAgentLogoServiceTab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.WAgentLogoServiceTab.InitialImage = ((System.Drawing.Image)(resources.GetObject("WAgentLogoServiceTab.InitialImage")));
            this.WAgentLogoServiceTab.Location = new System.Drawing.Point(11, 69);
            this.WAgentLogoServiceTab.Name = "WAgentLogoServiceTab";
            this.WAgentLogoServiceTab.Size = new System.Drawing.Size(213, 198);
            this.WAgentLogoServiceTab.TabIndex = 6;
            this.WAgentLogoServiceTab.TabStop = false;
            // 
            // WAgentStopButton
            // 
            this.WAgentStopButton.Location = new System.Drawing.Point(287, 172);
            this.WAgentStopButton.Name = "WAgentStopButton";
            this.WAgentStopButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentStopButton.TabIndex = 1;
            this.WAgentStopButton.Text = "Stop W-Agent";
            this.WAgentStopButton.UseVisualStyleBackColor = true;
            this.WAgentStopButton.Click += new System.EventHandler(this.WAgentStopButton_Click);
            // 
            // WAgentStartButton
            // 
            this.WAgentStartButton.Location = new System.Drawing.Point(287, 119);
            this.WAgentStartButton.Name = "WAgentStartButton";
            this.WAgentStartButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentStartButton.TabIndex = 0;
            this.WAgentStartButton.Text = "Start W-Agent";
            this.WAgentStartButton.UseVisualStyleBackColor = true;
            this.WAgentStartButton.Click += new System.EventHandler(this.WAgentStartButton_Click);
            // 
            // ServiceNameLabel
            // 
            this.ServiceNameLabel.AutoSize = true;
            this.ServiceNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceNameLabel.Location = new System.Drawing.Point(109, 18);
            this.ServiceNameLabel.Name = "ServiceNameLabel";
            this.ServiceNameLabel.Size = new System.Drawing.Size(94, 16);
            this.ServiceNameLabel.TabIndex = 8;
            this.ServiceNameLabel.Text = "Service Name";
            // 
            // ServiceStatusKey
            // 
            this.ServiceStatusKey.AutoSize = true;
            this.ServiceStatusKey.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceStatusKey.Location = new System.Drawing.Point(6, 43);
            this.ServiceStatusKey.Name = "ServiceStatusKey";
            this.ServiceStatusKey.Size = new System.Drawing.Size(105, 16);
            this.ServiceStatusKey.TabIndex = 3;
            this.ServiceStatusKey.Text = "Service Status : ";
            // 
            // ServiceStatus
            // 
            this.ServiceStatus.AutoSize = true;
            this.ServiceStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceStatus.Location = new System.Drawing.Point(108, 43);
            this.ServiceStatus.Name = "ServiceStatus";
            this.ServiceStatus.Size = new System.Drawing.Size(64, 16);
            this.ServiceStatus.TabIndex = 4;
            this.ServiceStatus.Text = "Checking";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(834, 548);
            this.tabControl1.TabIndex = 9;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(834, 571);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "W-Agent";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WAgentLogo)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WAgentLogoServiceTab)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wAgentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sendFeedbackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button WAgentApplicationTestButton;
        private System.Windows.Forms.Button WAgentApplicationDetailsButton;
        private System.Windows.Forms.Button WAgentApplicationStopButton;
        private System.Windows.Forms.Button WAgentApplicationStartButton;
        private System.Windows.Forms.PictureBox WAgentLogo;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button WAgentTestButton;
        private System.Windows.Forms.Button ServiceTabDetailsButton;
        private System.Windows.Forms.RichTextBox DetailsBoxServiceTab;
        private System.Windows.Forms.Label ServiceNameKey;
        private System.Windows.Forms.Button WAgentRestartButton;
        private System.Windows.Forms.PictureBox WAgentLogoServiceTab;
        private System.Windows.Forms.Button WAgentStopButton;
        private System.Windows.Forms.Button WAgentStartButton;
        private System.Windows.Forms.Label ServiceNameLabel;
        private System.Windows.Forms.Label ServiceStatusKey;
        private System.Windows.Forms.Label ServiceStatus;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.RichTextBox WAgentApplicationDetailsBox;
        private System.Windows.Forms.Label ServiceNotFoundLabel;
        private System.Windows.Forms.Label ApplicationNotFoundLabel;
        private System.Windows.Forms.Button WAgentApplicationRestartButton;
        private System.Windows.Forms.Label ApplicationStatusValueLabel;
        private System.Windows.Forms.Label ApplicationStatusKeyLabel;
        private System.Windows.Forms.Button RestartButton;
        private System.Windows.Forms.Label PermissionsLabel;
    }
}

