﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: to read log file constantly
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

/* .Net Packages*/
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WAgentService
{
    class LogReaderByLastModified
    {
        /***************************************************************
							        Variables
	    ****************************************************************/
        private MainForm theForm;
        private int theOldCount;
        private string thePath;

        /***************************************************************
							        METHODS
	    ****************************************************************/

        /**
         * @Usage overridden constructor
         */
        public LogReaderByLastModified(MainForm aForm)
        {
            thePath = "";
            theOldCount = 0;
            theForm = aForm;
            setPath();
            setOldCount();
            
        }

        /**
         * @Usage set path to w-agent log file
         */
        public void setPath()
        {
            thePath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\w-agent\\logs";
        }

        /**
         * @Usage count the number of lines already in log file before w-agent starts
         */
        public void setOldCount()
        {
            try
            {
                System.IO.FileStream fs = new System.IO.FileStream(thePath + "\\logstash-plain.log", System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite);
                System.IO.StreamReader sr = new System.IO.StreamReader(fs);
                //int count = 0;
                while (!sr.EndOfStream)
                {
                    sr.ReadLine();
                    theOldCount++;
                }
                fs.Close();
                sr.Close();

            }
            catch(Exception e)
            {
                theOldCount = 0;
            }

        }

        /**
         * @Usage constantly read the log file after 5 seconds
         */
        public void readLog()
        {
            while (true) {
                Thread.Sleep(5000);
                if (theForm.IsDisposed) {
                    break;
                }
                updateDetailsBox();
                
            }
        }

        /**
         * @Usage read log file
         */
        public void updateDetailsBox() {
            try
            {

                System.IO.FileStream fs = new System.IO.FileStream(thePath + "\\logstash-plain.log", System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.ReadWrite);
                System.IO.StreamReader sr = new System.IO.StreamReader(fs);
                int count = 0;
                string line;
                while (!sr.EndOfStream)
                {
                    line = sr.ReadLine();
                    if (count >= theOldCount)
                    {
                        updateDetailsBox(line);
                    }

                    count++;
                }
                theOldCount = count;
                fs.Close();
                sr.Close();

            }
            catch(Exception e)
            {
                
            }

        }

        /**
         * @Usage update details box according to log
         */
        private void updateDetailsBox(string line)
        {
            theForm.Invoke(new Action(() => theForm.detailsBoxText += line + "\n"));
            if (Regex.IsMatch(line, "ERROR") && Regex.IsMatch(line, "logstash.outputs.http"))
            {
                theForm.Invoke(new Action(() => theForm.detailsBoxText += "Error ! Test Alert not sent." + "\n"));
            }
            
            else if (Regex.IsMatch(line, "Terminating")) {
                theForm.Invoke(new Action(() => theForm.detailsBoxText += "W-Agent Service is Stopped." + "\n"));
                theForm.Invoke(new Action(() => theForm.WAgentTestButtonProperty.Enabled = false));
            }
            else if (Regex.IsMatch(line, "Successfully\\sstarted"))
            {
                theForm.Invoke(new Action(() => theForm.detailsBoxText += "W-Agent Service is Started Successfully." + "\n"));
                theForm.Invoke(new Action(() => theForm.WAgentTestButtonProperty.Enabled = true));
            }
            
        }

    }
}
