﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: This class is the main class that handles everything.
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */


/*.NET Packages*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WAgentService
{
    public partial class AboutForm : Form
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        public string Label1Text
        {
            get
            {
                return this.label1.Text;
            }
            set
            {
                this.label1.Text = value;
            }
        }
        public string Label2Text
        {
            get
            {
                return this.label2.Text;
            }
            set
            {
                this.label2.Text = value;
            }
        }
        public string Label3Text
        {
            get
            {
                return this.label3.Text;
            }
            set
            {
                this.label3.Text = value;
            }
        }
        /***************************************************************
								METHODS
	    ****************************************************************/
        public AboutForm()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
