﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: This class is the main class that handles everything.
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */


/*.NET Packages*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceProcess;
using System.IO;
using System.Collections;
using System.Threading;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Management;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace WAgentService
{
    public partial class MainForm : Form
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private string thePathToNSSM;
        private string theServiceName;
        private ServiceController theServiceController;
        LogReaderByLastModified theLogReaderByLastModified;
        public MainApplicationHelper theMainApplicationHelper;
        Process theCmd = new Process();
        Thread theWAgentApplicationStartThread;
        public int theProcessID;

        private bool isApplicationStarted = false;
        public bool isTestLog = false;
        public bool isError = false;
        public bool isFullSizeWindow;
        public bool isStart;
        private bool isElevated;

        public string detailsBoxText
        {
            get
            {
                return this.DetailsBoxServiceTab.Text;
            }
            set
            {
                this.DetailsBoxServiceTab.Text = value;
            }
        }
        public string WAgentApplicationDetailsBoxText
        {
            get
            {
                return this.WAgentApplicationDetailsBox.Text;
            }
            set
            {
                this.WAgentApplicationDetailsBox.Text = value;
            }
        }
        
        public Button WAgentTestButtonProperty
        {
            get { return WAgentTestButton; }
            set { WAgentTestButton = value; }
        }

        /***************************************************************
							        METHODS
	    ****************************************************************/

        /**
         * @Usage default constructor 
         */
        public MainForm()
        {

            isFullSizeWindow = false;
            isStart = true;
            InitializeComponent();
            this.Size = new Size(430,420);
            DetailsBoxServiceTab.Visible = false;
            ServiceNameLabel.Text = theMainApplicationHelper.getServiceName();
            theServiceController = new ServiceController(theMainApplicationHelper.getServiceName());
            setupWindow();
            DetailsBoxServiceTab.ReadOnly = true;
            theLogReaderByLastModified = new LogReaderByLastModified(this);
            Thread tid1 = new Thread(new ThreadStart(theLogReaderByLastModified.readLog));
            tid1.Start();
        }

        /**
         * @Usage overridden constructor to decide to run app in service mode or app mode
         */
        public MainForm(String aType)
        {
            /*if service isn't installed*/
            if (aType == "Application")
            {

                isFullSizeWindow = false;
                isStart = true;
                InitializeComponent();

                theMainApplicationHelper = new MainApplicationHelper();
                theMainApplicationHelper.setPathTONSSM(this);

                this.Size = new Size(430, 420);
                WAgentApplicationDetailsBox.Visible = false;
                DetailsBoxServiceTab.Visible = false;
                setupWindow();
                this.tabPage1.Enabled = false;
                this.tabControl1.SelectedTab = this.tabPage2;
                this.ServiceNameLabel.Visible = false;
                WAgentApplicationDetailsBox.ReadOnly = true;
                this.ServiceStatus.Visible = false;
                this.ServiceStatusKey.Visible = false;
                this.ServiceNameKey.Visible = false;
                this.ApplicationNotFoundLabel.Text = "Service Not Found Please goto Application Tab";
                this.WAgentApplicationStopButton.Enabled = false;
                this.WAgentApplicationRestartButton.Visible = false;
                this.WAgentApplicationTestButton.Enabled = false;

            }
            else if (aType == "Service") {

                /*if service is installed*/
                isFullSizeWindow = false;
                isStart = true;
                InitializeComponent();

                theMainApplicationHelper = new MainApplicationHelper();
                theMainApplicationHelper.setPathTONSSM(this);

                this.Size = new Size(430, 420);
                DetailsBoxServiceTab.Visible = false;
                WAgentApplicationDetailsBox.Visible = false;
                ServiceNameLabel.Text = theMainApplicationHelper.getServiceName();
                theServiceController = new ServiceController(theMainApplicationHelper.getServiceName());
                setupWindow();
                DetailsBoxServiceTab.ReadOnly = true;
                theLogReaderByLastModified = new LogReaderByLastModified(this);
                Thread tid1 = new Thread(new ThreadStart(theLogReaderByLastModified.readLog));
                tid1.Start();
                this.ApplicationStatusKeyLabel.Visible = false;
                this.ApplicationStatusValueLabel.Visible = false;
                this.tabPage2.Enabled = false;
                this.tabControl1.SelectedTab = this.tabPage1;
                this.ServiceNotFoundLabel.Text = "Application Not Found Please goto Service Tab";

                checkAdminRights();

                if (!isElevated)
                {
                    this.WAgentTestButton.Enabled = false;
                    this.WAgentStopButton.Enabled = false;
                    this.WAgentStartButton.Enabled = false;
                    this.WAgentRestartButton.Enabled = false;
                    this.ServiceTabDetailsButton.Enabled = false;
                    RestartButton.Visible = true;
                    this.PermissionsLabel.Visible = true;
                }

            }
            
        }

        /**
	    * @Usage heck admin rights when program starts
	    */
        private void checkAdminRights()
        {
            try
            {
                WindowsIdentity identity = WindowsIdentity.GetCurrent();
                WindowsPrincipal principal = new WindowsPrincipal(identity);
                isElevated = principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch (Exception e)
            {

            }


        }
        /**
	    * @Usage Setup window at start
	    */
        public void setupWindow() {

            string myStatus = checkStatus();
            ServiceStatus.Text = myStatus;

            /*To enable and disable buttons according to the service status*/
            if (myStatus.Equals("Running"))
            {
                WAgentStartButton.Enabled = false;
                WAgentStopButton.Enabled = true;
                WAgentRestartButton.Enabled = true;
                if (isStart)
                {
                    WAgentTestButton.Enabled = true;
                }
                
            }
            else if (myStatus.Equals("ServiceNotFound")) {
                WAgentStartButton.Enabled = false;
                WAgentStopButton.Enabled = false;
                WAgentRestartButton.Enabled = false;
                WAgentTestButton.Enabled = false;
                ServiceStatus.Text = "Service Not Found Click Refresh to Check Again";
            }
            else
            {
                WAgentStartButton.Enabled = true;
                WAgentStopButton.Enabled = false;
                WAgentRestartButton.Enabled = false;
                WAgentTestButton.Enabled = false;
            }
            isStart = false;

        }
        
        
        /**
	    * @Usage to get current directory in which exe exists
	    */
        private string getPathFromCurrentDirectory ()
        {
            string myCurrentDirectory = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            return myCurrentDirectory;
        }

        

        /**
	    * @Usage what happens when user click start button
	    */
        private void WAgentStartButton_Click(object sender, EventArgs e)
        {            
            manageWAgentService("start");
        }

        /**
       * @Usage to run command to start w-agent service
       */
        private void manageWAgentService(string aAction)
        {

            /*run command*/
            theMainApplicationHelper.manageWAgentService(aAction);

            /*change gui according to the action*/
            if (aAction.Equals("start"))
            {
                ServiceStatus.Text = "Sarting Service";
                DetailsBoxServiceTab.Text += "Starting W-Agent Service.\n";
                this.Refresh();
                theServiceController.WaitForStatus(ServiceControllerStatus.Running);
                setupWindow();
                DetailsBoxServiceTab.Text += "W-Agent Service is started. It may take upto 1 minute to setup W-Agent.\n";
            }
            else if (aAction.Equals("stop"))
            {
                DetailsBoxServiceTab.Text += "Stopping W-Agent Service.\n";
                ServiceStatus.Text = "Stopping Service";
                this.Refresh();
                theServiceController.WaitForStatus(ServiceControllerStatus.Stopped);
                setupWindow();
            }
            else
            {
                ServiceStatus.Text = "Restarting Service";
                DetailsBoxServiceTab.Text += "Restarting W-Agent.\n";
                this.Refresh();
                theServiceController.WaitForStatus(ServiceControllerStatus.Running);
                setupWindow();
                Thread tid1 = new Thread(new ThreadStart(updateDetailsBoxWithRestart));
                tid1.Start();
            }

        }
        
        /**
	    * @Usage show restarting details in detailsbox 
	    */
        private void updateDetailsBoxWithRestart() {
            Thread.Sleep(5000);
            this.Invoke(new Action(() => this.detailsBoxText += "Starting W-Agent.\n"));
            this.Invoke(new Action(() => this.detailsBoxText += "W-Agent Service is started. It may take upto 1 minute to setup W-Agent.\n"));

        }

        /**
	    * @Usage what happens when user click stop button
	    */
        private void WAgentStopButton_Click(object sender, EventArgs e)
        {
            WAgentTestButton.Enabled = false;
            manageWAgentService("stop");
        }

        /**
	    * @Usage what happens when user click restart button
	    */
        private void WAgentRestartButton_Click(object sender, EventArgs e)
        {
            
            manageWAgentService("restart");
        }
        
        /**
	    * @Usage to check service status
	    */
        private string checkStatus()
        {
            return theMainApplicationHelper.checkStatus(theMainApplicationHelper.getServiceName());
        }
        
        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void sendFeedbackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.w-alert.com/#contact");
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void wAgentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var myForm = new AboutForm();
            myForm.StartPosition = FormStartPosition.CenterParent;
            myForm.ShowDialog(this);
            
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setupWindow();
            this.Refresh();
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void viewHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://w-alert.com/#features");
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void serviceDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            var myForm = new AboutForm();
            myForm.StartPosition = FormStartPosition.CenterParent;
            myForm.Label1Text = "Service Name : ";
            myForm.Label2Text = theMainApplicationHelper.getServiceName();
            myForm.Label3Text = "";
            myForm.Text = "Service Name";
            myForm.ShowDialog(this);
        }

        /**
        * @Usage if details button in service tab is clicked
        */
        private void button1_Click(object sender, EventArgs e)
        {
            /*resize window and show/hide details box*/
            if (isFullSizeWindow) {
                this.Size = new Size(430, 420);
                isFullSizeWindow = false;
                DetailsBoxServiceTab.Visible = false;
            }
            else
            {
                this.Size = new Size(430, 610);
                isFullSizeWindow = true;
                DetailsBoxServiceTab.Visible = true;
            }
            
        }

        /**
        * @Usage send sample alert on test button click in servie tab
        */
        private void WAgentTestButton_Click(object sender, EventArgs e)
        {
            DetailsBoxServiceTab.Text += "Sending test alert !!!\n";
            isTestLog = true;
            sendDemoLog();

            /*Seperate thread to see if alert is sent successfully*/
            Thread sendSampleLog = new Thread(() => alertSentStatus(this));
            sendSampleLog.IsBackground = true;
            sendSampleLog.Start();

        }

        /**
        * @Usage send sample alert by adding alert to sample file
        */
        public void sendDemoLog() {
            try
            {
                /*make a sample log and copy it to sample file*/
                string myDemoLog = "TID: [-1234] [] [2018-09-19 11:17:16,371] ERROR {org.apache.synapse.mediators.builtin.LogMediator} - Test-PC,SequenceName = CustomerAPI_01_ValidateSearchCustomerCDMResponse_01, Message = Error occurred while validating SearchCUstomer CDM response.";
                string dt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                myDemoLog = myDemoLog.Replace("2018-09-19 11:17:16", dt);
                getPathFromCurrentDirectory();
                File.AppendAllText(getPathFromCurrentDirectory() + "\\samples\\sample.log", myDemoLog + Environment.NewLine);
            }
            catch(Exception e)
            {
                /*catch error in case sample.log file does not exist.*/
                var form = new ErrorForm();
                form.StartPosition = FormStartPosition.CenterParent;
                form.LabelText = "Can't find sample.log file in sample.";
                form.ShowDialog(this);
                DetailsBoxServiceTab.Text += "Alert not Sent! No sample file in sample folder.\n";
                WAgentApplicationDetailsBox.Text += "Alert not Sent! No sample file in sample folder.\n";
                isError = true;
            }

            
        }
        /**
        * @Usage to decide what happens when form 1 loads
        */
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /**
        * @Usage on change listener of details box in service tab
        */
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            DetailsBoxServiceTab.SelectionStart = DetailsBoxServiceTab.Text.Length;
            DetailsBoxServiceTab.ScrollToCaret();
            if (isTestLog)
            {
                isError = true;
            }
        }

        /**
        * @Usage show and hide details box on details button click in application tab
        */
        private void WAgentApplicationDetailsButton_Click(object sender, EventArgs e)
        {
            if (isFullSizeWindow)
            {
                this.Size = new Size(430, 420);
                isFullSizeWindow = false;
                WAgentApplicationDetailsBox.Visible = false;
            }
            else
            {
                this.Size = new Size(430, 610);
                isFullSizeWindow = true;
                WAgentApplicationDetailsBox.Visible = true;
            }
        }

        /**
        * @Usage on change listener of details box in application tab
        */
        private void WAgentApplicationDetailsBox_TextChanged(object sender, EventArgs e)
        {
            WAgentApplicationDetailsBox.SelectionStart = WAgentApplicationDetailsBox.Text.Length;
            WAgentApplicationDetailsBox.ScrollToCaret();

            
            if (isTestLog)
            {
                isError = true;
            }

        }

        /**
        * @Usage on select listner of tabs in w-agent application
        */
        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            Size size = new Size(430, 420);
            if (this.Size != size) {
                this.Size = size;
                DetailsBoxServiceTab.Visible = false;
                WAgentApplicationDetailsBox.Visible = false;
                isFullSizeWindow = false;
            }
            
        }

        /**
        * @Usage overrride EndTask method to end a running task
        */
        [DllImport("user32.dll")]
        public static extern bool EndTask(IntPtr hWnd, bool fShutDown, bool fForce);

        /**
        * @Usage start application on start button click in application tab
        */
        private void startWAgentApplication(MainForm aForm)
        {

            string path = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\w-agent\\bin";
            string myCommand = "logstash.bat -f w-alert_shipper.conf";

            /*configure cmd to run application in command line*/
            theCmd.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            theCmd.StartInfo.WorkingDirectory = path;
            theCmd.StartInfo.FileName = "cmd.exe";
            theCmd.StartInfo.RedirectStandardInput = true;
            theCmd.StartInfo.RedirectStandardOutput = true;
            theCmd.StartInfo.CreateNoWindow = true;
            theCmd.StartInfo.UseShellExecute = false;
            theCmd.Start();

            aForm.Invoke(new Action(() => aForm.theProcessID = theCmd.Id));

            theCmd.StandardInput.WriteLine(myCommand);
            theCmd.StandardInput.Flush();
            theCmd.StandardInput.Close();
            int lineCount = 0;

            /*read cmd until app is closed*/
            while (!theCmd.StandardOutput.EndOfStream)
            {
                lineCount++;
                string line = theCmd.StandardOutput.ReadLine();
                if (lineCount > 4)
                {
                    addDetailsInDetailsBox(aForm, line);
                }
                
                //Console.WriteLine(line);
            }
           
        }

        /**
        * @Usage add details in application tab detail box according to the logs in commandline
        */
        private void addDetailsInDetailsBox(MainForm aForm,string aLine) {

            /*add every log to details box*/
            aForm.Invoke(new Action(() => aForm.WAgentApplicationDetailsBox.Text += aLine + "\n"));
            
            /*decide what to add in details box according to the logs*/
            if (Regex.IsMatch(aLine, "ERROR") && Regex.IsMatch(aLine, "logstash.outputs.http"))
            {
                aForm.Invoke(new Action(() => aForm.WAgentApplicationDetailsBox.Text += "Error ! Test Alert not sent." + "\n"));
            }
            else if (Regex.IsMatch(aLine, "Terminating"))
            {
                aForm.Invoke(new Action(() => aForm.WAgentApplicationDetailsBox.Text += "W-Agent Application is Stopped." + "\n"));
            }
            else if (Regex.IsMatch(aLine, "Successfully\\sstarted"))
            {
                aForm.Invoke(new Action(() => aForm.WAgentApplicationDetailsBox.Text += "W-Agent Application is Started Successfully." + "\n"));
                aForm.Invoke(new Action(() => aForm.WAgentApplicationTestButton.Enabled = true));
                aForm.Invoke(new Action(() => aForm.WAgentApplicationStopButton.Enabled = true));
                aForm.Invoke(new Action(() => aForm.ApplicationStatusValueLabel.Text = "Running"));
                
            }
            else if (Regex.IsMatch(aLine, "(SystemExit)"))
            {
                aForm.Invoke(new Action(() => aForm.WAgentApplicationDetailsBox.Text += "W-Agent Application is already running.Please Restart application." + "\n"));
            }
            
        }

        /**
        * @Usage on click listener of start button in application tab
        */
        private void WAgentApplicationStartButton_Click(object sender, EventArgs e)
        {

            this.WAgentApplicationStartButton.Enabled = false ;
            this.ApplicationStatusValueLabel.Text = "Starting Application.";
            WAgentApplicationDetailsBox.Text += "Starting W-Agent Application." + "\n";
            isApplicationStarted = true;

            /*new thread to start application in background*/
            theWAgentApplicationStartThread = new Thread(() => startWAgentApplication(this));
            theWAgentApplicationStartThread.IsBackground = true;
            theWAgentApplicationStartThread.Start();

            WAgentApplicationDetailsBox.Text += "W-Agent Application is started. It may take upto 1 minute to setup W-Agent.\n";
            this.WAgentApplicationStopButton.Enabled = true;

        }

        /**
        * @Usage to close threads and application if form is closed
        */
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (isApplicationStarted) {
                    KillAllProcessesSpawnedBy((uint)theProcessID);
                }
                
            }
            catch (Exception ex)
            {

            }

            try
            {
                theWAgentApplicationStartThread.Abort();
            }
            catch (Exception ex)
            {

            }

        }

        /**
        * @Usage to kill all the child process of a given process
        */
        private static void KillAllProcessesSpawnedBy(UInt32 parentProcessId)
        {
           
            /* NOTE: Process Ids are reused!*/
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                "SELECT * " +
                "FROM Win32_Process " +
                "WHERE ParentProcessId=" + parentProcessId);
            ManagementObjectCollection collection = searcher.Get();
            if (collection.Count > 0)
            {
                foreach (var item in collection)
                {
                    UInt32 childProcessId = (UInt32)item["ProcessId"];
                    if ((int)childProcessId != Process.GetCurrentProcess().Id)
                    {
                        KillAllProcessesSpawnedBy(childProcessId);
                        Process childProcess = Process.GetProcessById((int)childProcessId);
                        childProcess.Kill();
                    }
                }
            }
        }

        /**
        * @Usage stop w-agent application on stop button click in application tab
        */
        private void WAgentApplicationStopButton_Click(object sender, EventArgs e)
        {

            this.WAgentApplicationStopButton.Enabled = false;
            this.WAgentApplicationTestButton.Enabled = false;

            /*kill all child processes of application*/
            try
            {
                KillAllProcessesSpawnedBy((uint)theProcessID);
            }
            catch(Exception ex)
            {

            }
            /*stop the thread running the application*/
            try
            {
                theWAgentApplicationStartThread.Abort();
            }
            catch(Exception ex)
            {

            }
            
            ApplicationStatusValueLabel.Text = "Stopped";
            WAgentApplicationDetailsBox.Text += "W-Agent Application has been stopped.\n";
            this.WAgentApplicationStartButton.Enabled = true;
            
        }

        /**
        * @Usage send sample log on test button click in application tab
        */
        private void WAgentApplicationTestButton_Click(object sender, EventArgs e)
        {
            WAgentApplicationDetailsBox.Text += "Sending test alert !!!\n";
            isTestLog = true;
            sendDemoLog();

            /*seperate thread to check if alert is sent successfully.*/
            Thread sendSampleLog = new Thread(() => alertSentStatus(this));
            sendSampleLog.IsBackground = true;
            sendSampleLog.Start();
 
        }

        /**
        * @Usage add sent alert in details box if alert is sent successfully.
        */
        public void alertSentStatus(MainForm aForm)
        {
            Thread.Sleep(5000);
            bool isNotSent = false;
            aForm.Invoke(new Action(() => isNotSent = aForm.isError));

            if (!isNotSent)
            {
                aForm.Invoke(new Action(() => aForm.WAgentApplicationDetailsBox.Text += "Test alert sent successfully from sample log file.\n"));
                aForm.Invoke(new Action(() => aForm.DetailsBoxServiceTab.Text += "Test alert sent successfully from sample log file.\n"));
            }
            aForm.Invoke(new Action(() => aForm.isTestLog = false));
            aForm.Invoke(new Action(() => aForm.isError = false));

        }

        /**
        * @Usage event happens after form is closed
        */
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
           // Application.Exit();
        }

        /**
        * @Usage method to bring the already running window to front if user starts in again.
        */
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == NativeMethods.WM_SHOWME)
            {
                ShowMe();
            }
            base.WndProc(ref m);
        }

        /**
        * @Usage helper method for WndProc method
        */
        private void ShowMe()
        {
            if (WindowState == FormWindowState.Minimized)
            {
                WindowState = FormWindowState.Normal;
            }
            bool top = TopMost;
            TopMost = true;
            TopMost = top;
        }

        private void RestartButton_Click(object sender, EventArgs e)
        {
            ProcessStartInfo info = new ProcessStartInfo(getPathFromCurrentDirectory() + "\\WAgentService.exe");
            info.UseShellExecute = true;
            info.Verb = "runas";
            Process.Start(info);
            this.Close();
        }
    }
    
}
