  /*
  * Author: Maham Imtiaz Hassan
  * Usage: Constant values used througout the application
  * Known Issues:
  *
  *
  * Version History:
  *
  * v01.001 : 14-12-2016 :  Initial Implementation : Maham I. Hassan
  * v01.002 : 15-12-16 : Added config variable to call APIs
  * v01.003 : 15-04-17 : Added API Manager variables and token. : Maheen Nasir
  * v01.004 : 30-04-2018 : Added Reset Password variables :Ghilman Anjum
  * v01.005 : 25-05-2018 : Added variables for forget password : Ghilman Anjum
  *
  */

/****************Error Codes from the backend APIs****************/
WeAlertApp.constant("RESPONSE_CODE", {
  "CM_SUCCESS" : "CM-N-0000",
  "CM_USERNAME_ERROR" : "CM-E-1100",
  "CM_INVALID_INPUT" : "CM-E-2001",
  "CM_NO_RECORD_WARNING" : "CM-W-0001",
  "IAM_SUCCESS" : "IAM-N-0000",
  "IAM_UNAUTHORIZED": "IAM-E-9999",
  "IAM_INVALID_INPUT" : "IAM-E-2001",
  "GENERAL_WARNING" : "W-0001",
  "CM_DOMAINNAME_ERROR" : "CM-E-1000",
  "CM_GROUP_NAME" : "CM-E-3001",
  "IAM_NO_RECORDS_WARNING": "IAM-W-0001"
});
/****************User messages that will be displayed****************/
WeAlertApp.constant("USER_MESSAGE", {
  "CREATE_USER_SUCCESS" : "User created successfully.",
  "CREATE_USER_WARNING" : "Username or Email already exisits. Please try another one.",
  "GET_USER_WARNING" : "User does not exist.",
  "DELETE_USER_SUCCESS" : "User deleted successfully.",
  "DELETE_USER_WARNING" : "",
  "UPDATE_USER_SUCCESS" : "User updated successfully.",
  "CREATE_APPLICATION_SUCCESS" : "Application created successfully.",
  "UPDATE_APPLICATION_SUCCESS" : "Application updated successfully.", 
  "DELETE_APPLICATION_SUCCESS" : "Application deleted successfully.",
  "CREATE_GROUP_SUCCESS" : "Group created successfully.",
  "UPDATE_GROUP_SUCCESS" : "Group updated successfully.",
  "DELETE_GROUP_SUCCESS" : "Group deleted successfully.",
  "SERVICE_NOT_AVAILABLE" : "Service is not available. Please try again later.",
  "UNAUTHORIZED" : "You are not authorized.",
  "CREATE_CLIENT_SUCCESS" : "Client created successfully.",
  "INVALID_REQUEST": "Invalid Request.",
  "INTERNAL_SERVER_ERROR": "An internal server error has occurred.",
  "DOMAINNAME_ERROR": "Domain name is not available. Please try again.",
  "GROUP_NAME_ERROR" : "Group name is not available. Please try again.",
  "CHANGE_PASSWORD_ERROR" : "Invalid credentials. Please try again.",
  "CHANGE_PASSWORD_SUCCESS" : "Your Password is changed successfully.",
  "RESET_PASSWORD_SUCCESS": "Password is reset successfully",
  "RESET_PASSWORD_WARNING": "Record does not exist.",
  "VERIFY_USERNAME_WARNING" : "Username does not exist",
  "UPDATE_PASSWORD_SUCCESS" : "Password is updated successfully",
  "CONFIRMATION_CODE_WARNING" : "Confiramtion code is incorrect"
});
/****************Configurations for API calls****************/
WeAlertApp.constant("REQUEST_HEADER", {
  headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization':'Bearer c505e8f7-ecb3-346f-8216-f906965edc17',   
        'Access-Control-Allow-Origin': '*'
    }
});
/****************API URLs****************/
var API_MANAGER_IAM_DOMAIN = 'http://wso2esb:8283';
var API_MANAGER_CLIENT_DOMAIN ='http://wso2esb:8283';
var IM_USERS = '/identityandaccessmanagement_01/users';
var CM_USERS = '/clientmanagement_01/users';
var CM_CLIENTS ='/clientmanagement_01/clients'
var CM_APPLICATION_GROUP = '/clientmanagement_01/applicationgroups'; 
var RECAPTCHA = 'http://wso2esb:8283';


WeAlertApp.constant("API_URL", { 
     //AUTHENTICATION
    'AUTHENTICATE' :  API_MANAGER_IAM_DOMAIN+IM_USERS+'/authenticate',
    //CHANGE PASSWORD
    'CHANGE_PASSWORD' : API_MANAGER_IAM_DOMAIN+IM_USERS+'/changepassword',
     //RESET PASSWORD
    'RESET_PASSWORD': API_MANAGER_IAM_DOMAIN + IM_USERS + '/resetpassword',
    //VERIFY USERNAME
    'VERIFY_USERNAME': API_MANAGER_IAM_DOMAIN + IM_USERS + '/verifyusername',
    //VERIFY USERNAME
    'UPDATE_PASSWORD': API_MANAGER_IAM_DOMAIN + IM_USERS + '/updatepassword',
    //CRUL CLIENTS
    'CREATE_CLIENT' : API_MANAGER_CLIENT_DOMAIN+CM_CLIENTS,
    'GET_CLIENT_LIST' : API_MANAGER_CLIENT_DOMAIN+CM_CLIENTS+'/list',
    'GET_CLIENT' : API_MANAGER_CLIENT_DOMAIN+CM_CLIENTS+'?OrganizationId=',
    'UPDATE_CLIENT' : API_MANAGER_CLIENT_DOMAIN+CM_CLIENTS,
    //CRUDL MANAGERS
    'CREATE_MANAGER' : API_MANAGER_CLIENT_DOMAIN+CM_USERS,
    'GET_MANAGER_LIST' : API_MANAGER_CLIENT_DOMAIN+CM_USERS+'/list',
    'GET_MANAGER' : API_MANAGER_CLIENT_DOMAIN+CM_USERS+'?UserName=',
    'DELETE_MANAGER' : API_MANAGER_CLIENT_DOMAIN+CM_USERS+'/',
    'UPDATE_MANAGER' : API_MANAGER_CLIENT_DOMAIN+CM_USERS,
    //CRUDL USERS
    'CREATE_USER' : API_MANAGER_CLIENT_DOMAIN+CM_USERS,
    'GET_USER' : API_MANAGER_CLIENT_DOMAIN+CM_USERS+'?UserName=',
    'DELETE_USER' : API_MANAGER_CLIENT_DOMAIN+CM_USERS+'/',
    'GET_USER_LIST' : API_MANAGER_CLIENT_DOMAIN+CM_USERS+'/list',
    'UPDATE_USER' : API_MANAGER_CLIENT_DOMAIN+CM_USERS,
    //CRUDL APPLICATION GROUPS
    'GET_GROUP' : API_MANAGER_CLIENT_DOMAIN+CM_APPLICATION_GROUP+'?ApplicationGroupId=',
    'CM_GROUP' : API_MANAGER_CLIENT_DOMAIN+CM_APPLICATION_GROUP,
    'GET_GROUP_LIST' : API_MANAGER_CLIENT_DOMAIN+CM_APPLICATION_GROUP+'/list',
    'UPDATE_GROUP_WITH_USERS' : API_MANAGER_CLIENT_DOMAIN+CM_APPLICATION_GROUP+'/assign',
    'UPDATE_GROUP' : API_MANAGER_CLIENT_DOMAIN+CM_APPLICATION_GROUP,
    'REMOVE_USER_IN_GROUP' : API_MANAGER_CLIENT_DOMAIN+CM_APPLICATION_GROUP+'/delete',
    'DELETE_GROUP' : API_MANAGER_CLIENT_DOMAIN +CM_APPLICATION_GROUP+'/',
    // GOOGLE RECAPTCHA
    'RECAPTCHA' : RECAPTCHA + '/recaptcha_01/verify/',
});