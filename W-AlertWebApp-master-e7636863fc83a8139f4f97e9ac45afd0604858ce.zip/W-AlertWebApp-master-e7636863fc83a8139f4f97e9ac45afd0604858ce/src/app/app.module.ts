import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { AlertItemComponent } from './components/alert-item/alert-item.component';
import { AlertListComponent } from './components/alert-list/alert-list.component';
import { AlertMasterDetailComponent } from './components/alert-master-detail/alert-master-detail.component';
import { AlertDetailComponent } from './components/alert-detail/alert-detail.component';
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AlertItemComponent,
    AlertListComponent,
    AlertMasterDetailComponent,
    AlertDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
