

export class Alert {
  id: string;
  title: string;
  time: string;
  severity: string;
}
