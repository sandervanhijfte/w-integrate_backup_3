import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertMasterDetailComponent } from './alert-master-detail.component';

describe('AlertMasterDetailComponent', () => {
  let component: AlertMasterDetailComponent;
  let fixture: ComponentFixture<AlertMasterDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlertMasterDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertMasterDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
