import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alert-master-detail',
  templateUrl: './alert-master-detail.component.html',
  styleUrls: ['./alert-master-detail.component.scss']
})
export class AlertMasterDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
