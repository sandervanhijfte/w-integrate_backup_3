import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alert-detail',
  templateUrl: './alert-detail.component.html',
  styleUrls: ['./alert-detail.component.scss']
})
export class AlertDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
