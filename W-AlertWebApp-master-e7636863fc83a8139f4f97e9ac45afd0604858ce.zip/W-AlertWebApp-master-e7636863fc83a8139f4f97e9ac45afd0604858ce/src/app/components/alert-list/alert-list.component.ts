import {Component, OnInit} from '@angular/core';
import {Alert} from '../../models/Alert';
import {log} from 'util';

@Component({
  selector: 'app-alert-list',
  templateUrl: './alert-list.component.html',
  styleUrls: ['./alert-list.component.css']
})
export class AlertListComponent implements OnInit {

  a: Alert[] = [{
    id: '1',
    title: 'WSO2',
    severity: 'severity',
    time: 'time'
  }, {
    id: '2',
    title: 'ActiveMQ',
    severity: 'severity',
    time: 'time'
  }, {
    id: '3',
    title: 'Demo Alert',
    severity: 'severity',
    time: 'time'
  },
    {
      id: '3',
      title: 'Demo Alert',
      severity: 'severity',
      time: 'time'
    },{
      id: '3',
      title: 'Demo Alert',
      severity: 'severity',
      time: 'time'
    },{
      id: '3',
      title: 'Demo Alert',
      severity: 'severity',
      time: 'time'
    },{
      id: '3',
      title: 'Demo Alert',
      severity: 'severity',
      time: 'time'
    }];


  constructor() {
  }

  ngOnInit() {
  }

  onSelect(l: Alert) {
console.log(l.title);

  }
}
