﻿namespace WAgentService
{
    partial class WAgentMainApplicationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WAgentMainApplicationForm));
            this.WAgentStartButton = new System.Windows.Forms.Button();
            this.WAgentStopButton = new System.Windows.Forms.Button();
            this.WAgentRestartButton = new System.Windows.Forms.Button();
            this.serviceStatusKeyLabel = new System.Windows.Forms.Label();
            this.serviceStatus = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wAgentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sendFeedbackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wAgentLogo = new System.Windows.Forms.PictureBox();
            this.serviceNameKeyLabel = new System.Windows.Forms.Label();
            this.serviceNameLabel = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // WAgentStartButton
            // 
            this.WAgentStartButton.Location = new System.Drawing.Point(266, 118);
            this.WAgentStartButton.Name = "WAgentStartButton";
            this.WAgentStartButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentStartButton.TabIndex = 0;
            this.WAgentStartButton.Text = "Start W-Agent";
            this.WAgentStartButton.UseVisualStyleBackColor = true;
            this.WAgentStartButton.Click += new System.EventHandler(this.WAgentStartButton_Click);
            // 
            // WAgentStopButton
            // 
            this.WAgentStopButton.Location = new System.Drawing.Point(266, 200);
            this.WAgentStopButton.Name = "WAgentStopButton";
            this.WAgentStopButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentStopButton.TabIndex = 1;
            this.WAgentStopButton.Text = "Stop W-Agent";
            this.WAgentStopButton.UseVisualStyleBackColor = true;
            this.WAgentStopButton.Click += new System.EventHandler(this.WAgentStopButton_Click);
            // 
            // WAgentRestartButton
            // 
            this.WAgentRestartButton.Location = new System.Drawing.Point(266, 274);
            this.WAgentRestartButton.Name = "WAgentRestartButton";
            this.WAgentRestartButton.Size = new System.Drawing.Size(106, 42);
            this.WAgentRestartButton.TabIndex = 2;
            this.WAgentRestartButton.Text = "Restart W-Agent";
            this.WAgentRestartButton.UseVisualStyleBackColor = true;
            this.WAgentRestartButton.Click += new System.EventHandler(this.WAgentRestartButton_Click);
            // 
            // serviceStatusKeyLabel
            // 
            this.serviceStatusKeyLabel.AutoSize = true;
            this.serviceStatusKeyLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceStatusKeyLabel.Location = new System.Drawing.Point(12, 68);
            this.serviceStatusKeyLabel.Name = "serviceStatusKeyLabel";
            this.serviceStatusKeyLabel.Size = new System.Drawing.Size(105, 16);
            this.serviceStatusKeyLabel.TabIndex = 3;
            this.serviceStatusKeyLabel.Text = "Service Status : ";
            // 
            // serviceStatus
            // 
            this.serviceStatus.AutoSize = true;
            this.serviceStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceStatus.Location = new System.Drawing.Point(110, 68);
            this.serviceStatus.Name = "serviceStatus";
            this.serviceStatus.Size = new System.Drawing.Size(64, 16);
            this.serviceStatus.TabIndex = 4;
            this.serviceStatus.Text = "Checking";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(434, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "WAgentMenuStrip";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewHelpToolStripMenuItem,
            this.wAgentToolStripMenuItem,
            this.sendFeedbackToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.aboutToolStripMenuItem.Text = "Help";
            // 
            // viewHelpToolStripMenuItem
            // 
            this.viewHelpToolStripMenuItem.Name = "viewHelpToolStripMenuItem";
            this.viewHelpToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.viewHelpToolStripMenuItem.Text = "View Help";
            this.viewHelpToolStripMenuItem.Click += new System.EventHandler(this.viewHelpToolStripMenuItem_Click);
            // 
            // wAgentToolStripMenuItem
            // 
            this.wAgentToolStripMenuItem.Name = "wAgentToolStripMenuItem";
            this.wAgentToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.wAgentToolStripMenuItem.Text = "About";
            this.wAgentToolStripMenuItem.Click += new System.EventHandler(this.wAgentToolStripMenuItem_Click);
            // 
            // sendFeedbackToolStripMenuItem
            // 
            this.sendFeedbackToolStripMenuItem.Name = "sendFeedbackToolStripMenuItem";
            this.sendFeedbackToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.sendFeedbackToolStripMenuItem.Text = "Send Feedback";
            this.sendFeedbackToolStripMenuItem.Click += new System.EventHandler(this.sendFeedbackToolStripMenuItem_Click);
            // 
            // wAgentLogo
            // 
            this.wAgentLogo.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.wAgentLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("wAgentLogo.BackgroundImage")));
            this.wAgentLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.wAgentLogo.InitialImage = ((System.Drawing.Image)(resources.GetObject("wAgentLogo.InitialImage")));
            this.wAgentLogo.Location = new System.Drawing.Point(12, 118);
            this.wAgentLogo.Name = "wAgentLogo";
            this.wAgentLogo.Size = new System.Drawing.Size(213, 198);
            this.wAgentLogo.TabIndex = 6;
            this.wAgentLogo.TabStop = false;
            // 
            // serviceNameKeyLabel
            // 
            this.serviceNameKeyLabel.AutoSize = true;
            this.serviceNameKeyLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceNameKeyLabel.Location = new System.Drawing.Point(12, 43);
            this.serviceNameKeyLabel.Name = "serviceNameKeyLabel";
            this.serviceNameKeyLabel.Size = new System.Drawing.Size(99, 16);
            this.serviceNameKeyLabel.TabIndex = 7;
            this.serviceNameKeyLabel.Text = "Service Name :";
            // 
            // serviceNameLabel
            // 
            this.serviceNameLabel.AutoSize = true;
            this.serviceNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceNameLabel.Location = new System.Drawing.Point(111, 43);
            this.serviceNameLabel.Name = "serviceNameLabel";
            this.serviceNameLabel.Size = new System.Drawing.Size(94, 16);
            this.serviceNameLabel.TabIndex = 8;
            this.serviceNameLabel.Text = "Service Name";
            // 
            // WAgentMainApplicationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(434, 381);
            this.Controls.Add(this.serviceNameLabel);
            this.Controls.Add(this.serviceNameKeyLabel);
            this.Controls.Add(this.wAgentLogo);
            this.Controls.Add(this.serviceStatus);
            this.Controls.Add(this.serviceStatusKeyLabel);
            this.Controls.Add(this.WAgentRestartButton);
            this.Controls.Add(this.WAgentStopButton);
            this.Controls.Add(this.WAgentStartButton);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "WAgentMainApplicationForm";
            this.Text = "W-Agent";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wAgentLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button WAgentStartButton;
        private System.Windows.Forms.Button WAgentStopButton;
        private System.Windows.Forms.Button WAgentRestartButton;
        private System.Windows.Forms.Label serviceStatusKeyLabel;
        private System.Windows.Forms.Label serviceStatus;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wAgentToolStripMenuItem;
        private System.Windows.Forms.PictureBox wAgentLogo;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sendFeedbackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.Label serviceNameKeyLabel;
        private System.Windows.Forms.Label serviceNameLabel;
    }
}

