﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: This class contains helper methods for main form
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WAgentService
{
    class MainApplicationHelper
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private ServiceController theServiceController;
        private string thePathToNSSM;
        private string theServiceName;


        /***************************************************************
							        METHODS
	    ****************************************************************/
        /**
	    * @Usage to read from configurations.properties file
	    */
        public IDictionary ReadDictionaryFile(string fileName, WAgentMainApplicationForm aForm)
        {

            /*dictionary object to store values read from properties file*/
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            try
            {

                foreach (string line in File.ReadAllLines(fileName))
                {
                    if ((!string.IsNullOrEmpty(line)) &&
                        (!line.StartsWith(";")) &&
                        (!line.StartsWith("#")) &&
                        (!line.StartsWith("'")) &&
                        (line.Contains('=')))
                    {
                        int index = line.IndexOf('=');
                        string key = line.Substring(0, index).Trim();
                        string value = line.Substring(index + 1).Trim();

                        if ((value.StartsWith("\"") && value.EndsWith("\"")) ||
                            (value.StartsWith("'") && value.EndsWith("'")))
                        {
                            value = value.Substring(1, value.Length - 2);
                        }
                        dictionary.Add(key, value);
                    }
                }
            }
            catch (Exception e)
            {

                var myForm = new ErrorForm();
                myForm.StartPosition = FormStartPosition.CenterParent;
                myForm.ShowDialog(aForm);
                aForm.Close();
                throw e;
            }
            return dictionary;
        }

        /**
	    * @Usage to start, stop or restart service according to the action
	    */
        public void manageWAgentService(string aAction)
        {
            string myCommand = "";
            if (aAction.Equals("start"))
            {
                myCommand = getPathTONSSM() + " start " + getServiceName();
            }
            else if (aAction.Equals("stop"))
            {
                myCommand = getPathTONSSM() + " stop " + getServiceName();
            }
            else
            {
                myCommand = getPathTONSSM() + " restart " + getServiceName();
            }

            /*run command on cmd*/
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = myCommand;
            process.StartInfo = startInfo;
            process.Start();
        }

        /**
       * @Usage to check service status
       */
        public string checkStatus(string aServiceName)
        {

            /*Check if service is installed*/
            ServiceController ctl = ServiceController.GetServices().FirstOrDefault(s => s.ServiceName == aServiceName);
            if (ctl == null)
            {
                return "ServiceNotFound";

            }
            else
            {

                /*Check the status of the service*/
                theServiceController = new ServiceController(aServiceName);
                switch (theServiceController.Status)
                {
                    case ServiceControllerStatus.Running:
                        return "Running";
                    case ServiceControllerStatus.Stopped:
                        return "Stopped";
                    case ServiceControllerStatus.Paused:
                        return "Paused";
                    case ServiceControllerStatus.StopPending:
                        return "Stopping";
                    case ServiceControllerStatus.StartPending:
                        return "Starting";
                    default:
                        return "Status Changing";
                }
            }

        }

        /**
	    * @Usage to set Path to nssm
	    */
        public void setPathTONSSM(WAgentMainApplicationForm aForm)
        {

            thePathToNSSM = "/C \"" + getPathFromCurrentDirectory() + "\\w-agent\\nssm\"";

            /*to check if nssm exists in the given directory*/
            if (!File.Exists(getPathFromCurrentDirectory() + "\\w-agent\\nssm.exe"))
            {
                var form = new ErrorForm();
                form.StartPosition = FormStartPosition.CenterParent;
                form.LabelText = "Wrong Directory! Can't find nssm";
                form.ShowDialog(aForm);
                aForm.Close();
                throw new Exception();
            }

        }

        /**
	    * @Usage to get Path to nssm
	    */
        public string getPathTONSSM()
        {
            return thePathToNSSM;
        }

        /**
	    * @Usage to get current directory in which exe exists
	    */
        private string getPathFromCurrentDirectory()
        {
            string myCurrentDirectory = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            return myCurrentDirectory;
        }

        /**
	    * @Usage to get service name
	    */
        public string getServiceName()
        {
            return theServiceName;
        }

        /**
	    * @Usage to get service name from configurations.properties file
	    */
        public void setServiceNameFromFile(WAgentMainApplicationForm aForm)
        {

            IDictionary myDictionary = ReadDictionaryFile("configurations.properties", aForm);

            /*read service name from properties file*/
            try
            {
                theServiceName = myDictionary["ServiceName"].ToString();
            }
            catch (Exception e)
            {

                /*Show error dialog box in case of error*/
                var myForm = new ErrorForm();
                myForm.StartPosition = FormStartPosition.CenterParent;
                myForm.LabelText = "Configuration file is wrong";
                myForm.ShowDialog(aForm);
                aForm.Close();
                throw e;
            }
        }
    }
}
