﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: This class is the main class that handles everything.
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */


/*.NET Packages*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceProcess;
using System.IO;
using System.Collections;

namespace WAgentService
{
    public partial class WAgentMainApplicationForm : Form
    {
        /***************************************************************
								VARIABLES
	    ****************************************************************/
        private ServiceController theServiceController;
        private MainApplicationHelper theMainApplicationHelper;

        /***************************************************************
							        METHODS
	    ****************************************************************/

        /**
         * @Usage default constructor 
         */
        public WAgentMainApplicationForm()
        {
            
            InitializeComponent();
            theMainApplicationHelper = new MainApplicationHelper();
            theMainApplicationHelper.setPathTONSSM(this);
            theMainApplicationHelper.setServiceNameFromFile(this);
            serviceNameLabel.Text = theMainApplicationHelper.getServiceName();
            theServiceController = new ServiceController(theMainApplicationHelper.getServiceName());
            setupWindow();
        }

        /**
	    * @Usage Setup window at start
	    */
        public void setupWindow() {

            string myStatus = checkStatus();
            serviceStatus.Text = myStatus;

            /*To enable and disable buttons according to the service status*/
            if (myStatus.Equals("Running"))
            {
                WAgentStartButton.Enabled = false;
                WAgentStopButton.Enabled = true;
                WAgentRestartButton.Enabled = true;
            }
            else if (myStatus.Equals("ServiceNotFound")) {
                WAgentStartButton.Enabled = false;
                WAgentStopButton.Enabled = false;
                WAgentRestartButton.Enabled = false;
                serviceStatus.Text = "Service Not Found Click Refresh to Check Again";
            }
            else
            {
                WAgentStartButton.Enabled = true;
                WAgentStopButton.Enabled = false;
                WAgentRestartButton.Enabled = false;
            }
            
        }
        
        /**
	    * @Usage what happens when user click start button
	    */
        private void WAgentStartButton_Click(object sender, EventArgs e)
        {
            manageWAgentService("start");
        }

        /**
	    * @Usage to run command to start w-agent service
	    */
        private void manageWAgentService(string aAction)
        {
            
            /*run command*/
            theMainApplicationHelper.manageWAgentService(aAction);
            
            /*change gui according to the action*/
            if (aAction.Equals("start"))
            {
                serviceStatus.Text = "Sarting Service";
                this.Refresh();
                theServiceController.WaitForStatus(ServiceControllerStatus.Running);
                setupWindow();
            }
            else if (aAction.Equals("stop"))
            {
                serviceStatus.Text = "Stopping Service";
                this.Refresh();
                theServiceController.WaitForStatus(ServiceControllerStatus.Stopped);
                setupWindow();
            }
            else
            {
                serviceStatus.Text = "Restarting Service";
                this.Refresh();
                theServiceController.WaitForStatus(ServiceControllerStatus.Running);
                setupWindow();
            }
            
        }
        

        /**
	    * @Usage what happens when user click stop button
	    */
        private void WAgentStopButton_Click(object sender, EventArgs e)
        {
            manageWAgentService("stop");
        }

        /**
	    * @Usage what happens when user click restart button
	    */
        private void WAgentRestartButton_Click(object sender, EventArgs e)
        {
            manageWAgentService("restart");
        }
        
        /**
	    * @Usage to check service status
	    */
        private string checkStatus() {

            return theMainApplicationHelper.checkStatus(theMainApplicationHelper.getServiceName());
  
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void sendFeedbackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.w-alert.com/#contact");
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void wAgentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var myForm = new AboutForm();
            myForm.StartPosition = FormStartPosition.CenterParent;
            myForm.ShowDialog(this);
            
            
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setupWindow();
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void viewHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://w-alert.com/#features");
        }

        /**
	    * @Usage what happens when user click toolstrip
	    */
        private void serviceDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            var myForm = new AboutForm();
            myForm.StartPosition = FormStartPosition.CenterParent;
            myForm.Label1Text = "Service Name : ";
            myForm.Label2Text = theMainApplicationHelper.getServiceName();
            myForm.Label3Text = "";
            myForm.Text = "Service Name";
            myForm.ShowDialog(this);
        }

        /**
	    * @Usage to check if w-agent is already running
	    */
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == NativeMethods.WM_SHOWME)
            {
                ShowMe();
            }
            base.WndProc(ref m);
        }

        /**
	    * @Usage to start already running w-agent window
	    */
        private void ShowMe()
        {
            if (WindowState == FormWindowState.Minimized)
            {
                WindowState = FormWindowState.Normal;
            }
            // get our current "TopMost" value (ours will always be false though)
            bool top = TopMost;
            // make our form jump to the top of everything
            TopMost = true;
            // set it back to whatever it was
            TopMost = top;
        }
    }
}
