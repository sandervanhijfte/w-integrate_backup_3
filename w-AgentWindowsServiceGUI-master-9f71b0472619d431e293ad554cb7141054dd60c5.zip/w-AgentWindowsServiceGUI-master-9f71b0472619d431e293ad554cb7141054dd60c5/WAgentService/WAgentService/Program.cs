﻿/*
 * 	Author: Fahad Ashiq
 * 	Usage: Entry point to the application and initializes everything
 * 	Known Issues: None
 *  
 *  Version History : 
 *  
 *  1.0 (Initial implementation)
 *  
 */

/* .Net Packages*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WAgentService
{
    static class Program
    {
        /**
        * @Usage remove characters from a path to use it as an vairiable name
        */
        static string getCurrentPath()
        {
            string appPath = Application.ExecutablePath;
            appPath = Regex.Replace(appPath, @"[^a-zA-Z]+", "");
            return appPath;
        }
        static Mutex mutex = new Mutex(true, getCurrentPath());

        /**
        * @Usage Main Method
        */
        [STAThread]
        static void Main()
        {
            /*to see if program is already running*/
            if (!(mutex.WaitOne(TimeSpan.Zero, true)))
            {
                NativeMethods.PostMessage(
                (IntPtr)NativeMethods.HWND_BROADCAST,
                NativeMethods.WM_SHOWME,
                IntPtr.Zero,
                IntPtr.Zero);
                return;
            }

            /*in case program is not already running*/
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try {
                Application.Run(new WAgentMainApplicationForm());
            }
            catch(Exception e)
            {

            }

        }       
    }

    /**
    * @Usage helper class to ckeck if program is already running
    */
    internal class NativeMethods
    {
        public const int HWND_BROADCAST = 0xffff;
        public static readonly int WM_SHOWME = RegisterWindowMessage("WM_SHOWME");
        [DllImport("user32")]
        public static extern bool PostMessage(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam);
        [DllImport("user32")]
        public static extern int RegisterWindowMessage(string message);
    }
}
