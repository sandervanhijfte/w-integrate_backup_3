package nl.weintegrate.wealert.app.utils;

/*
 *	@Author: Maham Hassan
 *	
 *	@Usage:  This class contains all the constants used for the app. 
 *	
 *	@KnownIssues: 
 *
 *
 *	@VersionHistory: 
 *
 *					01.001 (Initial Implementation)
 */

public class Constant 
{

	public static final int CONNECTION_TIMEOUT = 30000;
    public static final int ALERT_LIST_PAGE_SIZE = 20;
	public static final String ALERT_TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String WE_ALERT_LOG = "weAlertLog.txt";
	public static final int KEEP_ALIVE_INTERVAL =120;
	public static final int HTTP_STATUS_CODE = 200;
	public static final String EVENT_SUBSCRIPTION_RESPONSE = "GetEventSubscriptionResponse";
	public static final String EVENT_SUBSCRIPTION = "EventSubscription";
	public static final String EVENT_SUBSCRIPTION_DETAIL = "SubscriptionDetail";
	public static final String BROKER_URL = "BrokerUrl";
	public static final String USER_NAME = "UserName";
	public static final String PASSWORD = "Password";
	public static final String TOPIC_NAME = "TopicName";
	public static final String SINGLE_SUBSCRIPTION = "SingleTopic";
	public static final String MULTIPLE_SUBSCRIPTION = "MultipleTopic";
	public static final String EVENT_SUBSCRIPTION_API = "https://pilot.w-alert.com/wealert/subscription/1.0/eventsubscriptionmanagement_01/eventsubscriptions/";
	public static final String AUTHENTICATE_USER_URL = "https://pilot.w-alert.com/wealert/iam/1.0/identityandaccessmanagement_01/users/authenticate";
	public static final String UPDATE_USER_URL = "https://pilot.w-alert.com/wealert/client/1.0/clientmanagement_01/users";
	public static final String GET_USER_URL = "https://pilot.w-alert.com/wealert/client/1.0/clientmanagement_01/users";
	public static final String REGISTER_DEVICE_URL = "https://pilot.w-alert.com/wealert/iam/1.0/identityandaccessmanagement_01/users/registerdevice";
    public static final String CHANGE_PASSWORD_URL = "https://pilot.w-alert.com/wealert/iam/1.0/identityandaccessmanagement_01/users/changepassword";
	public static final long CLEANUP_INTERVAL = 30* 60 * 1000; // 30 minutes
	public static final int ALERT_LIMIT = 500; // 10 seconds
	public static boolean IS_FROM_SIGNOUT = false;
}