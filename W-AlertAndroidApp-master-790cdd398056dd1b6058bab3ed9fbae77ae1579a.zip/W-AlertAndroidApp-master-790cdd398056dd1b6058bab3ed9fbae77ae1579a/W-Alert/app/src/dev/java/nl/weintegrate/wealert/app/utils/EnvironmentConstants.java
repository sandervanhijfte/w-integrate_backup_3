package nl.weintegrate.wealert.app.utils;

public class EnvironmentConstants {
    public static String SUBSCRIPTION_TOKEN  =  "4d2f3def-4cf0-3c80-8291-98afc246a725";
    public static String MQTT_TCP_PORT = "1883";
}
