/*
 *	@Author: Waqas Ali Razzaq
 *
 *  @Usage:
 *			1. Connection and subscription to MQTT Server
 *		    2. Receive new alerts
 *  		3. Close connection
 *
 *	@Known Issues:
 *	        1. Put callback methods in separate class for mqtt
 *          2. Self signed certificates.
 *          3. Changed MQTTException to Exception to catch security exceptions
 *	@VersionHistory:
 *			01.001 (Initial Implementation)
 *		    01.002 Generate notification on new alert function added
 *		    01.003 check duplicate alert function added
 *          01.004 Added MQTT over SSL functionality
 *
 */
package nl.weintegrate.wealert.app.messaging;

/* Android Imports */

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.support.v4.content.LocalBroadcastManager;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.android.service.ParcelableMqttMessage;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.ui.LoginActivity;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.EnvironmentConstants;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/* Eclipse Paho Imports */
/* WeIntegrate Imports */

/* Class Declarations start*/
public class AlertMqttSubscriber {

    /***************************************************************
                                 VARIABLES
     ****************************************************************/

    private static final String CLASS_NAME = "AlertMqttSubscriber";
    private Context theContext;
    private MqttAndroidClient theMQTTClient;
    private static Uri theNotificationType;
    private static long theTimeOfLastAlert = 0;
    private Ringtone theRingtone;
    private final static String GROUP_KEY_ALERTS = "group_key_alert";
    private boolean theIsNewSeries = true;
    private long theCurrentTimeInSeconds = 0;
    private AlertProcessor myAlertProcessor;
    private Queue<MqttMessage> theMQTTAlertMessageArray = new LinkedList<>();
    private MQTTAlertSaveThread theMQTTAlertSaveThread;


    public AlertMqttSubscriber(Context aContext) {
        this.theContext = aContext;
        try {
            myAlertProcessor = new AlertProcessor(theContext);
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,exception);
        }
    }

    /***************************************************************
                        PUBLIC - METHOD
     ****************************************************************/
    /*
    * Usage:
    *       close the messaging server connection on sigout/disconnect
    * Params:
    *       none
    * */
    public void closeConnection() {
        if (theMQTTClient != null) {
            theMQTTClient.unregisterResources();
            theMQTTClient.close();
        }
        if (theMQTTAlertSaveThread != null) {
            theMQTTAlertSaveThread.stopThreadWhenComplete();
        }
    }

    /*
    * Usage:
    *       Create connection with server to receive new alerts.
    * Params:
    *       aContext: the current context of application
    *       aDeviceId: the unique device number
    *       aBrokerUrl: messaging server Url
    *       aUserName: the messaging server username
    *      aPassword: the password for messaging server username
    * */

    public void makeConnection(final Context aContext, String aDeviceId, String aBrokerUrl, String aUserName, String aPassword) throws WeAlertException {


        try {
            MqttConnectOptions myOptions = new MqttConnectOptions();
            myOptions.setCleanSession(false);
            myOptions.setAutomaticReconnect(true);
            myOptions.setKeepAliveInterval(Constant.KEEP_ALIVE_INTERVAL);

            String myBrockerUrl = aBrokerUrl.replaceAll("ssl", "tcp").substring(0, aBrokerUrl.lastIndexOf(":")+1) + EnvironmentConstants.MQTT_TCP_PORT;

            theMQTTClient = new MqttAndroidClient(this.theContext, myBrockerUrl, aDeviceId, MqttAndroidClient.Ack.MANUAL_ACK);
            IMqttToken token = theMQTTClient.connect(myOptions);

            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    try {
                        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                        myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Connection status is: "+String.valueOf(theMQTTClient.isConnected()));
                        ArrayList<String> myTopicName = getTopicName(aContext);
                        for (int topicName=0;topicName<myTopicName.size();topicName++) {
                            theMQTTClient.subscribe(myTopicName.get(topicName), 1);
                        }
                    } catch (MqttException exception) {
                        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                        myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,exception);
                    }
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                    myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME, ((Exception) exception));
                }
            });
            theMQTTClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                    myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME, ((Exception) cause));
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {

                    theCurrentTimeInSeconds = System.currentTimeMillis();

                    if ((theCurrentTimeInSeconds - theTimeOfLastAlert) > 2000 && theIsNewSeries) {
                        theNotificationType = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                        theRingtone = RingtoneManager.getRingtone(theContext, theNotificationType);
                        theRingtone.play();
                        theTimeOfLastAlert = theCurrentTimeInSeconds;
                        theIsNewSeries = false;
                        ProcessReceivedAlert(message);
                        LocalBroadcastManager.getInstance(AlertMqttSubscriber.this.theContext).sendBroadcast(new Intent("alert_added"));
                    } else {

                        theMQTTAlertMessageArray.add(message);
                        if (theMQTTAlertSaveThread == null || theMQTTAlertSaveThread.getState() == Thread.State.TERMINATED) {
                            theMQTTAlertSaveThread = new MQTTAlertSaveThread();
                            theMQTTAlertSaveThread.start();
                        }

                        if (theMQTTAlertSaveThread.getState() == Thread.State.WAITING) {
                            synchronized (theMQTTAlertSaveThread) {
                                theMQTTAlertSaveThread.notifyAll();
                            }
                        }
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {

                }
            });
        } catch (Exception exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,exception);
            throw myWeAlertException;
        }
    }



    private void ProcessReceivedAlert(MqttMessage message) throws WeAlertException {
        try {
            JSONObject myAlertJsonObject = new JSONObject(message.toString());
            if (!message.isDuplicate() && !isDuplicateMessage(myAlertJsonObject.getJSONObject("Alert").get("AlertId").toString())) {

                generateNotification(AlertMqttSubscriber.this.theContext, myAlertJsonObject);

                myAlertProcessor.processAlert(myAlertJsonObject, theContext);
                theMQTTClient.acknowledgeMessage(((ParcelableMqttMessage)message).getMessageId());
            }
        } catch (Exception exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, exception);
            throw myWeAlertException;
        }
    }

    /***************************************************************
                        PRIVATE - METHOD
     ****************************************************************/
    /*
    * Usage:
    *       Retrieve topic names from storage.
    * Params:
    *       aContext: the current context of application
    * */

    private ArrayList<String> getTopicName(Context aContext) {
        ArrayList<SubscriptionDTO> mySubscription;
        ArrayList<String> myTopicList = new ArrayList<>();
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
            mySubscription = mySubscriptionDao.getSubscriptionList();
            for (int i = 0; i < mySubscription.size(); i++) {
                if (mySubscription.get(i).getTopicName() != null) {
                    myTopicList.add(mySubscription.get(i).getTopicName());
                }
            }
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, myWeAlertException.getMessage());
        }
        return myTopicList;
    }
    /*
    * Usage:
    *       Generate a android pop up notification on new alert.
    * Params:
    *       aContext: the current context of application
    *       aJsonObject: incoming Json message payload
    * */

    private void generateNotification(Context aContext, JSONObject aJsonObject) throws JSONException {
        DAOFactory mySQLLiteDaoFactory;
        NotificationCompat.Builder mBuilder = null;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            IAlertDAO myAlertDao = mySQLLiteDaoFactory.getAlertDAO();
            Bitmap largeIcon = BitmapFactory.decodeResource(aContext.getResources(), R.drawable.logo_walert);
            mBuilder = new NotificationCompat.Builder(aContext).setLargeIcon(largeIcon).setSmallIcon(R.drawable.logo_walert).setNumber(myAlertDao.getUnreadMessageCount() + 1)
                    .setContentTitle(aJsonObject.getJSONObject("Alert").get("AlertTitle").toString())
                    .setContentText("Severity: " + aJsonObject.getJSONObject("Alert").get("Severity").toString() + ", Type: " + aJsonObject.getJSONObject("Alert").get("AlertType").toString())
                    .setGroup(GROUP_KEY_ALERTS).setGroupSummary(true);
            mBuilder.setAutoCancel(true);
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, myWeAlertException.getMessage());
        }
        Intent resultIntent = new Intent(aContext, LoginActivity.class);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(aContext);
        stackBuilder.addParentStack(LoginActivity.class);
        stackBuilder.addNextIntent(resultIntent);
        PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
        mBuilder.setContentIntent(resultPendingIntent);
        NotificationManager mNotificationManager = (NotificationManager) aContext.getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(1, mBuilder.build());
    }
    /*
    * Usage:
    *       check if newly received message is duplicate.
    * params:
    *       aAlertId: alertId of incoming message
    * */

    private boolean isDuplicateMessage(String aAlertId) {
        DAOFactory mySQLLiteDaoFactory;

        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(theContext);
            IAlertDAO myAlertDao = mySQLLiteDaoFactory.getAlertDAO();
            if(myAlertDao.checkIfAlertExists(aAlertId))
                return true;
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, myWeAlertException.getMessage());
        }
        return false;
    }

    private class MQTTAlertSaveThread extends Thread {

        private boolean myIsThreadShouldStop = false;

        public MQTTAlertSaveThread() {
            super("MQTTAlertSaveThread");
            setPriority(Thread.NORM_PRIORITY);
        }

        public void stopThreadWhenComplete() {
            myIsThreadShouldStop = true;
        }

        @Override
        public void run() {

            try {
                while (true) {

                    while (!theMQTTAlertMessageArray.isEmpty()) {
                        ProcessReceivedAlert(theMQTTAlertMessageArray.poll());
                    }
                    theIsNewSeries = true;
                    LocalBroadcastManager.getInstance(AlertMqttSubscriber.this.theContext).sendBroadcast(new Intent("multiple_alerts_added"));
                    synchronized (theMQTTAlertSaveThread) {
                        if (myIsThreadShouldStop) {
                            break;
                        }
                        theMQTTAlertSaveThread.wait();
                    }
                }
            } catch (Exception exception) {
                WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, exception);
            }
        }
    }
}// End Of Class
