package nl.weintegrate.wealert.app.utils;

public class WeAlertURLs {
    public static final String EVENT_SUBSCRIPTION_API = "http://213.187.243.177:8281/wealert/subscription/1.0/eventsubscriptionmanagement_01/eventsubscriptions/";
    public static final String AUTHENTICATE_USER_URL = "http://213.187.243.177:8281/wealert/iam/1.0/identityandaccessmanagement_01/users/authenticate";
    public static final String UPDATE_USER_URL = "http://213.187.243.177:8281/wealert/client/1.0/clientmanagement_01/users";
    public static final String GET_USER_URL = "http://213.187.243.177:8281/wealert/client/1.0/clientmanagement_01/users";
    public static final String REGISTER_DEVICE_URL = "http://213.187.243.177:8281/wealert/iam/1.0/identityandaccessmanagement_01/users/registerdevice";
    public static final String CHANGE_PASSWORD_URL = "http://213.187.243.177:8281/wealert/iam/1.0/identityandaccessmanagement_01/users/changepassword";
    public static final String VERIFY_USERNAME_URL = "http://213.187.243.177:8281/wealert/iam/1.0/identityandaccessmanagement_01/users/verifyusername";
    public static final String UPDATE_PASSWORD_URL = "http://213.187.243.177:8281/wealert/iam/1.0/identityandaccessmanagement_01/users/updatepassword";

}
