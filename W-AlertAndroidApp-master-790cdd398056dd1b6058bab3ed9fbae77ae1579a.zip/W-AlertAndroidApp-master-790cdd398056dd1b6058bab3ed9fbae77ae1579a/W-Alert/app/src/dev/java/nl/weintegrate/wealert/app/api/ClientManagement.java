package nl.weintegrate.wealert.app.api;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. To make the the client management api requests
 *		    2. Make Https API calls
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *          01.002 (Https method)
 *          01.003 Updated "UpdateUser" and "UpdateClient" requests - Ghilman Anjum
 *
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.UUID;

import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import nl.weintegrate.wealert.app.utils.WeAlertSSLContext;

public class ClientManagement {
    private final String CLASS_NAME = "ClientManagement";

    /*
   *
   * to make the update user json request payload
   *
    */
    private String makeUpdateUserJSONRequestPayload(String aUserId, String aUserName,String aFirstName, String aLastName, String anEmail, String anOrganizationId, String anOrganizationDomain) {
        String myUpdateUserRequest = "{\n" +
                "  \"UpdateUserRequest\": {\n" +
                "    \"Header\": {\n" +
                "      \"CMMHeader\": { \"CorrelationId\": \""+UUID.randomUUID().toString() +"\" }\n" +
                "    },\n" +
                "    \"ClientContext\": { \"OrganizationId\": \""+anOrganizationId+"\" , \n" +
                "                         \"OrganizationDomain\" : \""+anOrganizationDomain+"\"},\n" +
                "    \"UserId\": \""+aUserId+"\",\n" +
                "    \"User\": {\n" +
                "      \"UserName\" : \""+aUserName+"\",\n"+
                "      \"FirstName\": \""+aFirstName+"\",\n" +
                "      \"LastName\": \""+aLastName+"\",\n" +
                "      \"ContactDetail\": {\n" +
                "        \"ChannelCode\": \""+anEmail+"\",\n" +
                "        \"ChannelType\": \"Email\"\n" +
                "      }\n" +
                "    }\n" +
                "  }\n" +
                "}";
        return myUpdateUserRequest;
    }
     /*
    *
    *  to send api call for update user profile and get response
    *
     */
    public boolean sendUpdateUserRequest(String aPath, String aUserId, String aUserName,String aFirstName, String aLastName, String anEmail, String anOrganizationId, String anOrganizationDomain, Context aContext) throws WeAlertException {
        boolean myUserUpdated = false;
        HttpURLConnection myConnection = null;
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(aContext);
        String myToken = preferences.getString("Token", "");
        try {
            //get JSON payload
            String myUpdateUserPayload = makeUpdateUserJSONRequestPayload(aUserId, aUserName,aFirstName,aLastName,anEmail,anOrganizationId, anOrganizationDomain);
            System.out.println(myUpdateUserPayload);
            WeAlertSSLContext mySSLContext= new WeAlertSSLContext();
            // Initialisation of connection to the API
            URL myUrl = new URL(aPath);
            myConnection = (HttpURLConnection) myUrl.openConnection();
           // myConnection.setDefaultSSLSocketFactory(mySSLContext.setWeAlertSSLContext(aContext).getSocketFactory());
            //Setting Connection request parameters
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("PUT");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Content-Length", Integer.toString(myUpdateUserPayload.getBytes().length));
            myConnection.setRequestProperty("Authorization", "Bearer " + myToken);
            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            // Writing the request to the stream writer
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myUpdateUserPayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            // Check if the API returns HTTP code 200 OK
            if (myConnection.getResponseCode() == 200) {

                // Read the response payload returned from the API
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();

                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());
                // Get the authentication status from the response
                String myResponseCode = myResponseJsonObject.getJSONObject("UpdateUserResponse").getJSONObject("Result").getString("ResponseCode");
                if (myResponseCode.equals("CM-N-0000")) {
                    myUserUpdated = true;
                } else if (myResponseCode.equals("CM-E-1100")) {
                    myUserUpdated = false;
                } else {
                    myUserUpdated = false;
                }
            }
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Unable to update profile. Please try again or contact your administrator.");
            throw myWeAlertException;
        } finally {
            // clean up initialised resources
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return myUserUpdated;

    }
    /*
    *
    * to make JSON request for getUser operation
    *
     */
    private String makeGetUserRequestQuery(String aUsername) throws WeAlertException {
        String myCharset = "UTF-8";
        String myUserName = aUsername;
        String myCorrelationId = UUID.randomUUID().toString();
        String myOrganizationId = "12345";
        String myGetUserQuery = null;
        try {
            myGetUserQuery = String.format("UserName=%s&CorrelationId=%s&OrganizationId=%s",
                    URLEncoder.encode(myUserName, myCharset),
                    URLEncoder.encode(myCorrelationId, myCharset),
                    URLEncoder.encode(myOrganizationId, myCharset));
        } catch (UnsupportedEncodingException e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making the query for getUser operation");
            throw myWeAlertException;
        }
        return myGetUserQuery;
    }
    public JSONObject sendGetUserRequest(String aPath, String aUsername, Context aContext) throws WeAlertException
    {
        String myUsername = aUsername;
        JSONObject myResponseJsonObject = new JSONObject();
        HttpURLConnection myConnection = null;

        try {
            // Initialisation of connection to the API
            String myQuery = makeGetUserRequestQuery(aUsername);
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(aContext);
            String myToken = preferences.getString("Token", "");
            WeAlertSSLContext mySSLContext= new WeAlertSSLContext();
            // Initialisation of connection to the API
            URL myUrl = new URL(aPath+"?"+myQuery);
            myConnection = (HttpURLConnection) myUrl.openConnection();
            //myConnection.setDefaultSSLSocketFactory(mySSLContext.setWeAlertSSLContext(aContext).getSocketFactory());
            //Setting Connection request parameters
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("GET");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Authorization", "Bearer "+myToken);
            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            int myResponseCode = myConnection.getResponseCode();
            // Check if the API returns HTTP code 200 OK
            if (myConnection.getResponseCode() == 200) {
                // Read the response payload returned from the API
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
                myResponseJsonObject = new JSONObject(myResponse.toString());
            }
        }

        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making getUser call");
            throw myWeAlertException;
        } finally {
            // clean up initialised resources
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return myResponseJsonObject;
    }
}
