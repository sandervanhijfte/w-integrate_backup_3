/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. Convert Alert Json message to Alert DTO
 *	@Known Issues:
 *
 *
 *	@VersionHistory:
 *			01.001 (Initial Implementation)
 *		    01.002 setAlertDTO function added to make it reusable
 *
 */

package nl.weintegrate.wealert.app.messaging;

/* Android Imports */

import android.content.Context;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.TimeZone;

import nl.weintegrate.wealert.app.dto.AlertDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/* WeIntegrate Imports */

/* Class Declarations start*/
public class AlertProcessor implements IAlertProcessor {

    /***************************************************************
     VARIABLES
     ****************************************************************/

    private static final String CLASS_NAME = "AlertProcessor";
    private DAOFactory mySQLLiteDaoFactory;
    private IAlertDAO myAlertDao;

    /***************************************************************
     PUBLIC - METHOD
     ****************************************************************/

    public AlertProcessor(Context aContext) throws WeAlertException {
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            myAlertDao = mySQLLiteDaoFactory.getAlertDAO();
        } catch (Exception exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, exception);
            throw myWeAlertException;
        }
    }

    @Override
    public void processAlert(JSONObject aJsonObject, Context aContext) throws WeAlertException {
        try {

            myAlertDao.insertAlert(setAlertDTO(aJsonObject));
        } catch (JSONException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, exception);
            throw myWeAlertException;
        } catch (ParseException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, exception);
            throw myWeAlertException;
        }
    }

    /***************************************************************
     PRIVATE - METHOD
     ****************************************************************/
    /*
    * Usage:
    *       Setting Alert DTO from received Json message
    *
    * Params:
    *       aJsonObject: Json message payload
    * */
    private AlertDTO setAlertDTO(JSONObject aJsonObject) throws JSONException, ParseException {
        AlertDTO myAlertDTO = new AlertDTO();

        Date myTimeStamp = convertDate(aJsonObject.getJSONObject("Alert").get("TimeStamp").toString());
        myAlertDTO.setTheAlertId(aJsonObject.getJSONObject("Alert").get("AlertId").toString());
        myAlertDTO.setTheTimestamp(myTimeStamp);
        myAlertDTO.setTheSeverity(aJsonObject.getJSONObject("Alert").get("Severity").toString());
        myAlertDTO.setTheAlertType(aJsonObject.getJSONObject("Alert").get("AlertType").toString());
        myAlertDTO.setTheAlertTitle(aJsonObject.getJSONObject("Alert").get("AlertTitle").toString());
        myAlertDTO.setTheAlertMessage(aJsonObject.getJSONObject("Alert").get("AlertMessage").toString());
        myAlertDTO.setTheHost(aJsonObject.getJSONObject("Alert").get("HostName").toString());
        myAlertDTO.setTheEnvironmentName(aJsonObject.getJSONObject("Alert").get("EnvironmentName").toString());
        myAlertDTO.setTheComponentName(aJsonObject.getJSONObject("Alert").get("ComponentName").toString());

        return myAlertDTO;
    }

    private Date convertDate(String timestamp) throws ParseException {

        SimpleDateFormat myDateFormatter = new SimpleDateFormat(Constant.ALERT_TIMESTAMP_FORMAT);
        if(timestamp.length() > 23) {
            Date dateTime = myDateFormatter.parse(timestamp.substring(0, timestamp.length() - 6));
            String timeZoneOffset = timestamp.substring(timestamp.length() - 6);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateTime);
            int offset = Character.getNumericValue(timeZoneOffset.charAt(1)) + Character.getNumericValue(timeZoneOffset.charAt(2));
            if (timeZoneOffset.startsWith("-")) {
                calendar.add(Calendar.HOUR_OF_DAY, offset);
            } else {
                calendar.add(Calendar.HOUR_OF_DAY, -offset);
            }
            String utcDateTimeString = myDateFormatter.format(calendar.getTime());
            myDateFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date utcDateTime = myDateFormatter.parse(utcDateTimeString);
            myDateFormatter.setTimeZone(TimeZone.getDefault());
            Date localDateTime = myDateFormatter.parse(myDateFormatter.format(utcDateTime));

            return localDateTime;
        }

        Date myTimestamp = myDateFormatter.parse(timestamp);

        return myTimestamp;
    }
} // End Of Class
