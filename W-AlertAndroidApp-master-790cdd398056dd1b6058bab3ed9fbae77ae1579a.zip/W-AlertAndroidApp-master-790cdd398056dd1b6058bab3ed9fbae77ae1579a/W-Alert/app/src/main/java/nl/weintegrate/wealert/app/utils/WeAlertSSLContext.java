package nl.weintegrate.wealert.app.utils;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import nl.weintegrate.wealert.app.R;

/*
 *	@Author: Waqas Ali
 *
 *	@Usage:  This is a Generic class for SSL Context
 *
 *	@KnownIssues:
 *
 *	@VersionHistory:
 *
 *					01.001 (Initial Implementation)
 */
public class WeAlertSSLContext {

    /*
    * This method will set the SSL properties and certificate for HTTPS and SSL connections
    *
    * */
    public SSLContext setWeAlertSSLContext (Context context){
        TrustManagerFactory myTrustManagerFactory=null;
        SSLContext mySSLContext=null;
        Certificate myCertificate;
        try {
            CertificateFactory myCertificateFactory = CertificateFactory.getInstance("X.509");
            InputStream myCertificateAuthorityInput = new BufferedInputStream(context.getResources().openRawResource(R.raw.sslbundle));

            myCertificate = myCertificateFactory.generateCertificate(myCertificateAuthorityInput);
            String keyStoreType = KeyStore.getDefaultType();
            KeyStore myKeyStore = KeyStore.getInstance(keyStoreType);
            myKeyStore.load(null, null);
            myKeyStore.setCertificateEntry("ca", myCertificate);
            String myTrustManagerFactoryAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
            myTrustManagerFactory = TrustManagerFactory.getInstance(myTrustManagerFactoryAlgorithm);
            myTrustManagerFactory.init(myKeyStore);
            mySSLContext = SSLContext.getInstance("TLS");
            mySSLContext.init(null, myTrustManagerFactory.getTrustManagers(), null);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return mySSLContext;

    }
}
