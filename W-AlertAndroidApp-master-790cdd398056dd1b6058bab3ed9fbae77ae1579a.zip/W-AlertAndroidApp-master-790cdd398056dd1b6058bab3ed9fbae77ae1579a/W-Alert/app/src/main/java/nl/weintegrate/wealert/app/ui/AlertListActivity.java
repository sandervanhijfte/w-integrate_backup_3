package nl.weintegrate.wealert.app.ui;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Code behind the alert list activity which displays all alerts.
 *
 *	@Known Issues:
 *          1. ://TODO  improve look and feel
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002	Added custom layout for list items
 *		    01.003  Added multiple deletion functions
 *          01.004  Added swipe refresh and refresh button for alert list
 *          01.005  Incorporated paging in alert list
 *          01.006  Added Clear application data functionality on SignOut and Disconnect Button. - Omer Khalid (01-03-2018)
 *
 */

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttService;

import java.util.ArrayList;
import java.io.File;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.dto.AlertDTO;
import nl.weintegrate.wealert.app.messaging.AlertService;
import nl.weintegrate.wealert.app.messaging.AlertSubscriptionSetting;
import nl.weintegrate.wealert.app.persistence.AlertRecycleService;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

public class AlertListActivity extends AppCompatActivity {
    /***************************************************************
     VARIABLES
     ****************************************************************/
    private static final String CLASS_NAME = "AlertListActivity";
    private ListView theAlertListView;
    private SearchView theAlertSearchView;
    private TextView theEmptyTextView;
    private TextView theAlertCountTextView;
    private ArrayList<AlertDTO> theAlertListArray;
    private SwipeRefreshLayout theAlertListSwipeRefreshLayout;
    private AlertListAdapter theAlertListAdapter;
    private boolean theAlertCheckboxVisibility = false;
    private ImageButton theRefreshImageButton;
    private boolean theAllCheckboxSelection = false;
    private boolean theListLoading = false;
    private boolean theListSearching = false;
    private String theSearchValue;
    private TextView theSelectedAlertCount;
    private Button theCancelButton;
    private ImageButton theHelpButton;
    private PopupWindow popupWindow;
    private IntentFilter theIntentFilter;
    private NotificationManager theNotificationManager;
    private DAOFactory theSqliteDaoFactory;
    private IAlertDAO theSqliteAlertDao;
    private ProgressDialog theDeleteAlertProgressDialog;
    private AlertDialog theDeleteConfirmationDialog;



    /***************************************************************
     PROTECTED - METHODS
     ****************************************************************/

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert_list);


        /*to dismiss keboard when clicked outside search box*/
        RelativeLayout  myProfileLayout= (RelativeLayout) findViewById(R.id.content_alert_list);
        myProfileLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent ev) {
                theAlertSearchView.clearFocus();
                hideKeyboard(view);
                return false;
            }
        });


        //Menu menu = findViewById(R.id.sta);




        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        theNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        //initializing swipe refresh
        theAlertListSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh_layout);
        setAlertListSwipeRefreshLayout();
        //set alert count
        theAlertCountTextView = (TextView) findViewById(R.id.textView_alertCount);
        //initializing alert list view
        theAlertListView = (ListView) findViewById(R.id.listView_alerts);

        try {
            theSqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            theSqliteDaoFactory.setContext(this);
            theSqliteAlertDao = theSqliteDaoFactory.getAlertDAO();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to delete alerts. Please try again.", Toast.LENGTH_LONG).show();
        }

        theAlertListArray = getAlertListArrayForFirstPage();
        setAlertListView(theAlertListArray, "You have no alerts");

        /*to dismiss keyboard when touched at logs list*/
        theAlertListView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent ev) {
                theAlertSearchView.clearFocus();
                hideKeyboard(view);
                return false;
            }
        });

        theAlertListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            int myLastFirstVisibleItem = 0;

            public void onScrollStateChanged(AbsListView view, int scrollState) {


            }

            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {

                int myLastVisibleItem = firstVisibleItem + visibleItemCount;
                updateAlertCounterView(firstVisibleItem, visibleItemCount, myLastVisibleItem);

                if (firstVisibleItem + visibleItemCount == totalItemCount && totalItemCount != 0 && totalItemCount >= Constant.ALERT_LIST_PAGE_SIZE && myLastFirstVisibleItem < firstVisibleItem) {
                    if (theListLoading == false) {
                        theListLoading = true;
                        addMoreItemsInList();
                    }
                }
                myLastFirstVisibleItem = firstVisibleItem;
            }
        });

        //initializing alert search view
        theAlertSearchView = (SearchView) findViewById(R.id.searchView_alerts);
        searchAlerts();

        //setting drawer layout
        final DrawerLayout myDrawerMenuLayout = (DrawerLayout) findViewById(R.id.drawer_layout_alert_list);
        ActionBarDrawerToggle myMenuToggleButton = new ActionBarDrawerToggle(
                this, myDrawerMenuLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        myDrawerMenuLayout.addDrawerListener(myMenuToggleButton);

        myMenuToggleButton.syncState();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                /*to dismiss keyboard when touched on bar*/
                theAlertSearchView.clearFocus();
                hideKeyboard(v);

                if (myDrawerMenuLayout.isDrawerOpen(Gravity.RIGHT)) {
                    myDrawerMenuLayout.closeDrawer(Gravity.RIGHT);
                } else {
                    myDrawerMenuLayout.openDrawer(Gravity.RIGHT);
                }

            }
        });


        startService("nl.weintegrate.wealert.app.messaging.AlertService", AlertService.class);
        startService("nl.weintegrate.wealert.app.persistence.AlertRecycleService", AlertRecycleService.class);

        //selected alerts count to display in delete view
        theSelectedAlertCount = (TextView) findViewById(R.id.textView_selectedAlertCount);

        theCancelButton = (Button) findViewById(R.id.button_cancel);
        theHelpButton = (ImageButton) findViewById(R.id.button_help);

        updateAlertCounterView(theAlertListView.getFirstVisiblePosition(), theAlertListView.getChildCount() +1 , theAlertListView.getLastVisiblePosition() + 1);

        theIntentFilter = new IntentFilter();
        theIntentFilter.addAction("multiple_alerts_added");
        theIntentFilter.addAction("alert_added");
    }

    private void updateAlertCounterView(int firstVisibleItem, int visibleItemCount, int myLastVisibleItem) {
        if (visibleItemCount > 0){
            theAlertCountTextView.setText(firstVisibleItem + 1 + " to " + myLastVisibleItem + " of " + getTotalNumberOfAlerts() + " total alerts");
            if (firstVisibleItem == 0) {
                theNotificationManager.cancelAll();
            }
        } else {
            theAlertCountTextView.setText("");
        }
    }

    /*
*
*  to get back the result from alert detail activity
*
 */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                String result = data.getStringExtra("theAlertId");
                theAlertListAdapter.updateAlertStatus(result);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        //setting broadcast receiver for alerts
        LocalBroadcastManager.getInstance(this).registerReceiver(theNewAlertReceiver, theIntentFilter);
        refreshAlertList();
    }

    @Override
    protected void onPause() {
        //unregister broadcast receiver
        LocalBroadcastManager.getInstance(this).unregisterReceiver(theNewAlertReceiver);
        super.onPause();
    }

    /***************************************************************
     PUBLIC - METHODS
     ****************************************************************/
    @Override
    public void onBackPressed() {
        DrawerLayout myDrawerMenuLayout = (DrawerLayout) findViewById(R.id.drawer_layout_alert_list);
        if (myDrawerMenuLayout.isDrawerOpen(GravityCompat.END)) {
            myDrawerMenuLayout.closeDrawer(GravityCompat.END);
        } else if (theAlertCheckboxVisibility == true) {
            theAlertCheckboxVisibility = false;
            theCancelButton.setVisibility(View.GONE);
            findViewById(R.id.button_deleteSelected).setVisibility(View.GONE);
            findViewById(R.id.button_selectAll).setVisibility(View.GONE);
            findViewById(R.id.layout_multiple_view).setVisibility(View.GONE);
            theSelectedAlertCount.setVisibility(View.GONE);
            theAllCheckboxSelection = false;
            findViewById(R.id.searchView_alerts).setVisibility(View.VISIBLE);
            refreshAlertList();
        } else {
            super.onBackPressed();
            finish();
        }
    }

    public void refreshAlertList() {
        theAlertListArray = getAlertListArrayForFirstPage();
        setAlertListView(theAlertListArray, "You have no alerts");
    }

    public void onSelectAllButtonClick(View view) {
        if (theAllCheckboxSelection == false) {
            theAllCheckboxSelection = true;
            theAlertListAdapter.selectAllLoadedAlerts(true);
        } else {
            theAllCheckboxSelection = false;
            theAlertListAdapter.selectAllLoadedAlerts(false);
        }

    }

    /*
     *
     * on click ? button beside search bar, onHelpButton() function called
     *
     */

    public void onHelpButton(View view) {

        if(!theAlertCheckboxVisibility) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(AlertListActivity.this);
            LayoutInflater inflater = AlertListActivity.this.getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.layout_help_popup_dialog, null);
            dialogBuilder.setView(dialogView);
            // dialogBuilder.setTitle("Search Criteria");
            Button cancelButton = (Button) dialogView.findViewById(R.id.dismisspopup);
            final AlertDialog alertDialog = dialogBuilder.create();
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alertDialog.dismiss();
                }
            });

            alertDialog.show();
            Resources r = getResources();
            int width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 350, r.getDisplayMetrics());
            int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 235, r.getDisplayMetrics());
            alertDialog.getWindow().setLayout(width, height);
        }
    }


    /*
    *
    *  to go back to the list view with selection disabled
    *
     */
    public void onCancelButton(View view) {
        theAlertCheckboxVisibility = false;
        theCancelButton.setVisibility(View.GONE);
        findViewById(R.id.button_deleteSelected).setVisibility(View.GONE);
        findViewById(R.id.button_selectAll).setVisibility(View.GONE);
        findViewById(R.id.layout_multiple_view).setVisibility(View.GONE);
        theSelectedAlertCount.setVisibility(View.GONE);
        theAllCheckboxSelection = false;
        findViewById(R.id.searchView_alerts).setVisibility(View.VISIBLE);
        refreshAlertList();
    }
    /*
    *
    *  on click handler for delete selected button
    *
     */

    public void OnDeleteSelectedClick(View view) {

        ArrayList<String> mySelectedAlertList = theAlertListAdapter.getTheSelectedItemsList();
        if (mySelectedAlertList.size() >= 1) {

            LayoutInflater myLayoutInflater = this.getLayoutInflater();
            View myDeleteDialogView = myLayoutInflater.inflate(R.layout.layout_delete_dialog, null);
            theDeleteConfirmationDialog = new AlertDialog.Builder(this, R.style.Mytheme).create();
            theDeleteConfirmationDialog.setView(myDeleteDialogView);
            theDeleteConfirmationDialog.setCancelable(true);
            Button myPositiveButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_yes);
            Button myNegativeButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_cancel_delete);

            myPositiveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ArrayList<String> mySelectedAlertList = theAlertListAdapter.getTheSelectedItemsList();
                    theDeleteAlertProgressDialog = new ProgressDialog(AlertListActivity.this, R.style.Mytheme);
                    theDeleteAlertProgressDialog.setMessage("Deleting alerts are in progress. Please wait.");
                    theDeleteAlertProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    theDeleteAlertProgressDialog.setIndeterminate(true);
                    theDeleteAlertProgressDialog.setCancelable(false);
                    theDeleteAlertProgressDialog.show();
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
                    new AlertDeleteThread(mySelectedAlertList).execute();
                 }
            });
            myNegativeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    theDeleteConfirmationDialog.dismiss();
                }
            });

            theDeleteConfirmationDialog.setMessage("Are you sure you want to delete?");
            theDeleteConfirmationDialog.show();
        } else {
            Toast.makeText(this, "No alerts selected. Please select an alert first", Toast.LENGTH_SHORT).show();
        }


    }

    public void OnViewProfileMenuClick(MenuItem item) {
        Intent myIntentToStartUserProfile = new Intent(AlertListActivity.this, UserProfileActivity.class);
        startActivity(myIntentToStartUserProfile);
    }

    /*
    *
    *  on click handler for change password in the drawer menu
    *
     */
    public void OnChangePasswordMenuClick(MenuItem item) {
        Intent myIntentToStartChangePassword = new Intent(AlertListActivity.this, ChangePasswordActivity.class);
        startActivity(myIntentToStartChangePassword);
    }


    /*
    *
    *  on click handler for about us in the drawer menu
    *
     */
    public void OnAboutUsMenuClick(MenuItem item) {
        Intent myIntentToStartAboutUsActivity = new Intent(AlertListActivity.this, AboutUsActivity.class);
        startActivity(myIntentToStartAboutUsActivity);
    }

    /*
    *
    *  on click handler for about us in the drawer menu
    *
     */
    public void OnSendLogFile(MenuItem aItem) {

        File myFilelocation = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/download", Constant.WE_ALERT_LOG);
        if (!myFilelocation.exists()) {
            AlertDialog.Builder myLogFileNotExistDialogBoxBuilder = new AlertDialog.Builder(AlertListActivity.this, R.style.Mytheme);
            myLogFileNotExistDialogBoxBuilder.setPositiveButton("Ok", null);
            AlertDialog myLogFileNotExistDialogBoxBox = myLogFileNotExistDialogBoxBuilder.create();
            myLogFileNotExistDialogBoxBox.setTitle("Logs not exist");
            myLogFileNotExistDialogBoxBox.setMessage("Unable to find W-Alert log file.");
            myLogFileNotExistDialogBoxBox.show();
            myLogFileNotExistDialogBoxBox.getButton(AlertDialog.BUTTON_POSITIVE)
                    .setBackgroundColor(getResources().getColor(R.color.colorPrimary));


        }else {
            try {
                Uri myPath = Uri.fromFile(myFilelocation);
                Intent myEmailIntent = new Intent(Intent.ACTION_SEND);
                myEmailIntent.setType("vnd.android.cursor.dir/email");
                String myToList[] = {"support.w-alert@w-integrate.nl"};
                myEmailIntent.putExtra(Intent.EXTRA_EMAIL, myToList);
                myEmailIntent.putExtra(Intent.EXTRA_STREAM, myPath);
                myEmailIntent.putExtra(Intent.EXTRA_SUBJECT, "W-Alert Android App Report");

                /*to send app report in android pie and oreo*/
                StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                StrictMode.setVmPolicy(builder.build());

                startActivity(Intent.createChooser(myEmailIntent, "Please find the attached log File."));
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    /*
    *
    *  on click handler for sign out in the drawer menu
    *
     */
    public void OnSignOutMenuClick(MenuItem item) {
        final AlertDialog mySignOutConfirmationDialog = new AlertDialog.Builder(AlertListActivity.this, R.style.Mytheme).create();
        LayoutInflater myLayoutInflater = this.getLayoutInflater();

        View mySignOutDialogView = myLayoutInflater.inflate(R.layout.layout_sign_out_dialog, null);
        mySignOutConfirmationDialog.setView(mySignOutDialogView);
        mySignOutConfirmationDialog.setCancelable(true);
        Button mySignOutButton = (Button) mySignOutDialogView.findViewById(R.id.dialog_btn_sign_out);
        Button myDisconnectAndSignOutButton = (Button) mySignOutDialogView.findViewById(R.id.dialog_btn_disconnect);
        Button myCancelButton = (Button) mySignOutDialogView.findViewById(R.id.dialog_btn_cancel);
        myDisconnectAndSignOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder myDisconnectAndSignOutDialog = new AlertDialog.Builder(AlertListActivity.this, R.style.Mytheme);
                myDisconnectAndSignOutDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {

                            Constant.IS_FROM_SIGNOUT = true;
                            Intent myIntentToStartLoginActivity = new Intent(AlertListActivity.this, LoginActivity.class);
                            myIntentToStartLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            myIntentToStartLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            //delete user profile
                            deleteUserProfileFromDatabase();
                            stopAlertService();
                            //clear app data and cache.
                            clearApplicationData();
                            //navigate to the login activity
                            startActivity(myIntentToStartLoginActivity);
                            finish();
                        } catch (WeAlertException e) {
                            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                            Toast.makeText(AlertListActivity.this, "Unable to disconnect with the server, please try again.", Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                            Toast.makeText(AlertListActivity.this, "Unable to disconnect with the server, please try again.", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                AlertDialog myDisconnectDialog = myDisconnectAndSignOutDialog.create();
                myDisconnectDialog.setMessage("WARNING: \nAll alerts stored in the database will be deleted. You will not receive any new alerts. Any alerts generated during the disconnection period will be lost.");
                myDisconnectDialog.show();
                myDisconnectDialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                myDisconnectDialog.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);

            }
        });
        myCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DrawerLayout myDrawerMenuLayout = (DrawerLayout) findViewById(R.id.drawer_layout_alert_list);
                mySignOutConfirmationDialog.dismiss();
                myDrawerMenuLayout.closeDrawer(GravityCompat.END);
            }
        });

        mySignOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent myIntentToStartLoginActivity = new Intent(AlertListActivity.this, LoginActivity.class);
                    myIntentToStartLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    myIntentToStartLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    //delete user password
                    deleteUserPasswordFromDatabase();
                    //navigate to the login activity
                    startActivity(myIntentToStartLoginActivity);
                    finish();
                    mySignOutConfirmationDialog.dismiss();
                } catch (WeAlertException e) {
                    WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                    myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                    Toast.makeText(AlertListActivity.this, "Unable to sign out, please try again.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                    myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                    Toast.makeText(AlertListActivity.this, "Unable to disconnect with the server, please try again.", Toast.LENGTH_LONG).show();
                }
            }
        });


        mySignOutConfirmationDialog.setTitle("Are you sure you want to sign out?");

        mySignOutConfirmationDialog.setMessage("Please note that you will continue to receive alerts. If you do not wish to receive alerts, press the disconnect device button.");
        mySignOutConfirmationDialog.show();
    }


    /***************************************************************
     PRIVATE - METHODS
     ****************************************************************/

    private BroadcastReceiver theNewAlertReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() != null && intent.getAction().equals("alert_added")) {

                // to auto refresh alert list
                // theAlertListArray.add(0, getNewAlertFromDatabase());
                theAlertListAdapter.addNewAlerts(getNewAlertFromDatabase());
                updateAlertCounterView(theAlertListView.getFirstVisiblePosition(), theAlertListView.getChildCount() +1 , theAlertListView.getLastVisiblePosition() + 1);
            }else if(intent.getAction() != null && intent.getAction().equals("multiple_alerts_added")){
                refreshAlertList();
            }
        }
    };


    private void addMoreItemsInList() {
        int myLastAlertRowId = getLastAlertRowId(theAlertListArray.get(theAlertListArray.size() - 1).getTheAlertId());
        if (myLastAlertRowId > 1) {
            ArrayList<AlertDTO> myAlertArrayList = new ArrayList<AlertDTO>();
            if (theListSearching == false) {
                myAlertArrayList = getAlertListArrayForCurrentPage(myLastAlertRowId);

            } else {
                if (!theSearchValue.equals("")) {
                    myAlertArrayList = getAlertListSearchResultForCurrentPage(theSearchValue, myLastAlertRowId);
                }
            }
            if (myAlertArrayList.size() > 0) {
                theAlertListAdapter.addMoreItems(myAlertArrayList);
            } else {
                Toast.makeText(this, "There are no more alerts", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "There are no more alerts", Toast.LENGTH_SHORT).show();
        }
        theListLoading = false;
    }

      /*
      * Usage:
      *       start the alert service in background
      * Params:
      *       aQualifiedName: service name with complete package
      *       aService: service class name
      * */

    private boolean startService(String aQualifiedName, Class aService) {
        if (isServiceRunning(aQualifiedName)) {
            Log.i(CLASS_NAME, "Alert Service is already running.");
        } else {
            Intent myIntentToStartService = new Intent(AlertListActivity.this, aService);
            if (startService(myIntentToStartService) != null) {
                Log.i(CLASS_NAME, aService + " started successfully");
                return true;
            } else {
                Log.e(CLASS_NAME, "Unable to start " + aService);
            }
        }
        return false;
    }

    /*
    * Usage:
    *       function to check Alert Service status
    * Params:
    *       aServiceName: service name with complete package
    * */

    private boolean isServiceRunning(String aServiceName) {
        ActivityManager myManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : myManager.getRunningServices(Integer.MAX_VALUE)) {
            if (aServiceName.equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    /*
     *
     * to set swipe refresh layout
     *
     */
    private void setAlertListSwipeRefreshLayout() {
        theAlertListSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh_layout);

        /*to hide keyboard on touch to logs list*/
        theAlertListSwipeRefreshLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent ev) {
                theAlertSearchView.clearFocus();
                hideKeyboard(view);
                return false;
            }
        });
        theAlertListSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                theAlertListArray = getAlertListArrayForFirstPage();
                setAlertListView(theAlertListArray, "You have no alerts");
            }

        });

    }

    /*
    *
    * to populate the list view
    *
    */
    private void setAlertListView(ArrayList<AlertDTO> myAlertDTOArray, String myEmptyListMessage) {
        //setting empty view for list
        theEmptyTextView = (TextView) findViewById(R.id.textView_emptyList);
        theEmptyTextView.setText(myEmptyListMessage);
        theAlertListView.setEmptyView(theEmptyTextView);
        //setting custom adapter for list view
        theAlertListAdapter = new AlertListAdapter(this, myAlertDTOArray, theAlertCheckboxVisibility);
        theAlertListView.setAdapter(theAlertListAdapter);

        if (theAlertListSwipeRefreshLayout.isRefreshing()) {
            theAlertListSwipeRefreshLayout.setRefreshing(false);
        }
        //on click of any item in the list view
        theAlertListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                TextView myAlertIdTextView = (TextView) view.findViewById(R.id.textView_alertId);
                if (theAlertCheckboxVisibility == false) {
                    Intent myIntentToStartAlertDetail = new Intent(AlertListActivity.this, AlertDetailActivity.class);
                    myIntentToStartAlertDetail.putExtra("theAlertId", myAlertIdTextView.getText().toString());
                    startActivityForResult(myIntentToStartAlertDetail, 1);
                }

            }
        });
        //on click when user taps on list item for a second
        theAlertListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                theAlertCheckboxVisibility = true;
                theCancelButton.setText("Cancel");
                theCancelButton.setVisibility(View.VISIBLE);
                findViewById(R.id.button_deleteSelected).setVisibility(View.VISIBLE);
                findViewById(R.id.button_selectAll).setVisibility(View.VISIBLE);
                findViewById(R.id.layout_multiple_view).setVisibility(View.VISIBLE);
                theSelectedAlertCount.setVisibility(View.VISIBLE);
                findViewById(R.id.searchView_alerts).setVisibility(View.GONE);
                refreshAlertList();
                return false;
            }
        });

    }

    /*
   *
   * to search alerts using search view
   *
   */
    private void searchAlerts() {
        /*
        theAlertSearchView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    //hideKeyboard(v);
                }
            }
        });
        */
        theAlertSearchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                theListSearching = true;
                theAlertSearchView.setIconified(false);

            }
        });
        //*** setOnQueryTextListener ***
        theAlertSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                theSearchValue = query;
                theAlertListArray = getAlertListSearchResultForFirstPage(query);
                setAlertListView(theAlertListArray, "No matching alerts found");
                if (theAlertListArray.size() == 0) {
                    theAlertCountTextView.setText(null);
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                theSearchValue = newText;
                theAlertListArray = getAlertListSearchResultForFirstPage(newText);
                setAlertListView(theAlertListArray, "No matching alerts found");
                if (theAlertListArray.size() == 0) {
                    theAlertCountTextView.setText(null);
                }
                return false;
            }
        });
        theAlertSearchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                theSearchValue = "";
                theListSearching = false;
                return false;
            }
        });

    }

    protected void hideKeyboard(View view) {
        InputMethodManager myInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        myInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }


    /*
    * Usage:
    *       Function to stop the Alert Service
    * Params:
    *
    * */

    private void stopAlertService() {
        AlertSubscriptionSetting mySettings = new AlertSubscriptionSetting(null);
        mySettings.deleteSubscription(AlertListActivity.this);
        if (isServiceRunning("nl.weintegrate.wealert.app.messaging.AlertService") == false) {
            Toast.makeText(this, "Unable to stop service because it is not running\n", Toast.LENGTH_LONG).show();
        } else {
            Intent myIntentToStopAlertService = new Intent(AlertListActivity.this, AlertService.class);
            Intent myIntentToStopMqttService = new Intent(AlertListActivity.this, MqttService.class);
            if (stopService(myIntentToStopAlertService) && stopService(myIntentToStopMqttService)) {

                Log.i(CLASS_NAME, "AlertService is stopped from alert list activity.");
            } else {
                Log.e(CLASS_NAME, "AlertService is not stopped from alert list activity");
            }
        }
    }

    /*
   *
   * to get result array list for search result on first page
   *
   */
    private ArrayList<AlertDTO> getAlertListSearchResultForFirstPage(String aSearchValue) {
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {

            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            myAlertList = mySqliteAlertDao.searchAlertToGetFirstPageResult(aSearchValue);
        } catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to search alerts. Please try again.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to search alerts. Please try again.", Toast.LENGTH_LONG).show();
        }
        return myAlertList;
    }

    /*
   *
   * to get result array list for search result on current page
   *
   */
    private ArrayList<AlertDTO> getAlertListSearchResultForCurrentPage(String aSearchValue, int aPageStartIndex) {
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {

            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            myAlertList = mySqliteAlertDao.searchAlertToGetCurrentPageResult(aSearchValue, aPageStartIndex);
        } catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to search alerts. Please try again.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to search alerts. Please try again.", Toast.LENGTH_LONG).show();
        }
        return myAlertList;
    }

    private int getLastAlertRowId(String anAlertId) {
        int myLastAlertRowId = 0;
        try {

            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            myLastAlertRowId = mySqliteAlertDao.getRowId(anAlertId);
        } catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_LONG).show();
        }
        return myLastAlertRowId;
    }

    /*
    *
    *  to delete alert from database
    *
     */
    private void deleteAlertFromDatabase(String anAlertId) {
        try {

            theSqliteAlertDao.deleteAlert(anAlertId);
        } catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to delete alerts. Please try again.", Toast.LENGTH_LONG).show();
        }
    }

    private int getTotalNumberOfAlerts() {
        int myTotalAlertCount = 0;
        try {

            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            myTotalAlertCount = mySqliteAlertDao.getTotalNumberOfAlerts();
        } catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_SHORT).show();
        }
        return myTotalAlertCount;
    }

    /*
    *
    *  to remove tha user password on sign out
    *
     */
    private void deleteUserPasswordFromDatabase() throws WeAlertException {
        try {
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySqliteDaoFactory.getUserDAO();
            myUserDao.deleteUserPassword();
        } catch (WeAlertException myWeAlertException) {
            throw myWeAlertException;
        } catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
    }

    /*
    *
    *  to delete the user profile on disconnect and sign out
    *
     */
    private void deleteUserProfileFromDatabase() throws WeAlertException {
        try {
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySqliteDaoFactory.getUserDAO();
            myUserDao.deleteUserProfile();
        } catch (WeAlertException myWeAlertException) {
            throw myWeAlertException;
        } catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
    }

    /*
    *
    *  to get alert list for first page because of descending order
    *
     */
    private ArrayList<AlertDTO> getAlertListArrayForFirstPage() {
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();

        try {
            myAlertList = theSqliteAlertDao.listAlertForFirstPage();
        } catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_LONG).show();
        }
        return myAlertList;
    }

    /*
    *
    *  to get alert list for current page
    *
     */
    private ArrayList<AlertDTO> getAlertListArrayForCurrentPage(int aStartIndex) {
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            myAlertList = mySqliteAlertDao.listAlertForOnePage(aStartIndex);
        } catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_LONG).show();
        }
        return myAlertList;
    }

    /*
    *
    *  to get new alert from database
    *
     */
    private AlertDTO getNewAlertFromDatabase() {
        AlertDTO myNewAlert = new AlertDTO();
        try {
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            myNewAlert = mySqliteAlertDao.getNewAlert();
        } catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            Toast.makeText(this, "Unable to access mobile storage. Please try restarting the app or contact your administrator.", Toast.LENGTH_LONG).show();
        }
        return myNewAlert;
    }

    /*
     * Usage:
     *       function to delete app directory in case of Signout and Disconnect.
     * Params:
     *       dir: the app directory
     * */
    public boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int counter = 0; counter < children.length; counter++) {
                boolean isDirDeleteSuccess = deleteDir(new File(dir, children[counter]));
                if (!isDirDeleteSuccess) {
                    return false;
                }
            }
        }

        return dir.delete();
    }

     /*
     * Usage:
     *       Function to delete app data and cache in case of SignOut and Disconnect.
     * Params:
     *
     * */

    public void clearApplicationData() {
        File cache = getCacheDir();
        File appDir = new File(cache.getParent());
        if (appDir.exists()) {
            String[] children = appDir.list();
            for (String listDir : children) {
                if (!listDir.equals("lib")) {
                    deleteDir(new File(appDir, listDir));
                    Log.i("TAG", "File /data/data/APP_PACKAGE/" + listDir + " DELETED");
                }
            }
        }
    }

    class AlertDeleteThread extends AsyncTask {

        private ArrayList<String> theSelectedAlertList;

        public AlertDeleteThread(ArrayList<String> aSelectedAlertList){

            theSelectedAlertList = aSelectedAlertList;
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            for (int j = 0; j < theSelectedAlertList.size(); j++) {
                deleteAlertFromDatabase(theSelectedAlertList.get(j));
            }

            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);


            if (getAlertListArrayForFirstPage().size() == 0) {
                theAlertCheckboxVisibility = false;
                theCancelButton.setVisibility(View.GONE);
                findViewById(R.id.button_deleteSelected).setVisibility(View.GONE);
                findViewById(R.id.button_selectAll).setVisibility(View.GONE);
                findViewById(R.id.layout_multiple_view).setVisibility(View.GONE);
                theSelectedAlertCount.setVisibility(View.GONE);
                theAlertCountTextView.setText(null);
                theAllCheckboxSelection = false;
                findViewById(R.id.searchView_alerts).setVisibility(View.VISIBLE);
                refreshAlertList();
            } else {
                theCancelButton.setText("Done");
                theAllCheckboxSelection = false;
                refreshAlertList();
            }

            onCancelButton(null);
            theDeleteAlertProgressDialog.dismiss();
            theDeleteConfirmationDialog.dismiss();
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);

        }
    }
}
