package nl.weintegrate.wealert.app.ui;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Code behind the login activity
 *
 *	@Known Issues:
 *          1. ://TODO make a separate class for login operation
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 Added async task for api calls
 *		    01.003 Added username and password field validations
 *		    01.004 Move to alert list screen when Subscription is added. - Mehak Zia (04-06-2018)
 *		    01.005 Added "ForgetPasswordText" and its intent - Ghilman Anjum (27-06-2018)
 *
 *
 */
/* Android Imports  */
import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.regex.Pattern;
import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.api.ClientManagement;
import nl.weintegrate.wealert.app.api.IdentityAndAccessManagement;
import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.dto.UserDTO;
import nl.weintegrate.wealert.app.messaging.AlertSubscriptionSetting;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.EnvironmentConstants;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import nl.weintegrate.wealert.app.utils.WeAlertURLs;
/* Weintegrate Imports  */
public class LoginActivity extends AppCompatActivity {
    /***************************************************************
     VARIABLES
     ****************************************************************/
    private EditText theUsernameField;
    private EditText thePasswordField;
    private EditText theTokenField;
    private TextView theForgetPasswordText;
    private String theUsername;
    private String thePassword;
    private String theToken;
    private ProgressBar theProgressBar;
    private final String CLASS_NAME = "LoginActivity";
    private int STORAGE_PERMISSION_CODE = 23;
    /***************************************************************
     PROTECTED - METHODS
     ****************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= STORAGE_PERMISSION_CODE) {
            if (!isWriteStorageAllowed()) {
                requestStoragePermission();
            }
        }

        //to clear preferences if user comes from logout screen

        /*
        if(Constant.IS_FROM_SIGNOUT){

            SharedPreferences myPreferences= PreferenceManager.getDefaultSharedPreferences(this);
            myPreferences.edit().commit();
            myPreferences.edit().putString("UserName","");
            myPreferences.edit().putString("Token","");
            myPreferences.edit().commit();
        }
           */

        boolean myCheck = checkIfUserLoggedIn();
        if(myCheck)
        {
            Intent myIntentToStartAlertListActivity = new Intent(LoginActivity.this,AlertListActivity.class);
            startActivity(myIntentToStartAlertListActivity);
            this.finish();
        }
        setContentView(R.layout.activity_login);
        //to set the input keyboard state
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        //accessing the username and password field
        theUsernameField = (EditText) findViewById(R.id.editText_username);
        thePasswordField = (EditText) findViewById(R.id.editText_password);
        theTokenField = (EditText) findViewById(R.id.editText_Token);
        theForgetPasswordText = (TextView) findViewById(R.id.textView_forget_password);
        //placeholder settings for username & password field
        theUsernameField.setHint(" Username@Domain");
        thePasswordField.setHint(" Password");
        theTokenField.setHint(" Subscription Key");

        //changed
        if(!Constant.IS_FROM_SIGNOUT){
            SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(this);
            String myUserName= preferences.getString("UserName","");
            if(myUserName=="") {
                String myTokenCheck = preferences.getString("DemoToken","");
                if(myTokenCheck == "true")
                {
                    theTokenField.setVisibility(View.INVISIBLE);
                }
                else
                {
                    theTokenField.setVisibility(View.VISIBLE);
                }
            }
        }
        else{
            theTokenField.setVisibility(View.VISIBLE);
            Constant.IS_FROM_SIGNOUT = false;
        }



        //getting progress bar
        theProgressBar = (ProgressBar) findViewById(R.id.progressBar_login);
        //setting validation
        theUsernameField.addTextChangedListener(new MyInputValidator());
        theUsernameField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    validateUsername(theUsernameField.getText().toString().trim());
                    theUsernameField.setHint(" Username@Domain");
                }
                else
                {
                    theUsernameField.setHint("");
                }
            }
        });
        //setting validation on password field
        thePasswordField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(thePasswordField.length()<6)
                {
                    thePasswordField.setError("Password must contain at least 8 characters including upper-case, lower-case, special characters and numbers.");
                }
                else if(thePasswordField.length()==0|| thePasswordField.length()>=8)
                {
                    thePasswordField.setError(null);
                }
            }
        });
        thePasswordField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    thePasswordField.setHint(" Password");
                    if(thePasswordField.length()<8)
                    {
                        thePasswordField.setError("Password must contain at least 8 characters including upper-case, lower-case, special characters and numbers.");
                    }
                    else if(thePasswordField.length()==0 || thePasswordField.length()>=8)
                    {
                        thePasswordField.setError(null);
                    }
                }
                else
                {
                    thePasswordField.setHint("");
                    if(thePasswordField.length()==0 || thePasswordField.length()>=6)
                    {
                        thePasswordField.setError(null);
                    }
                }
            }
        });
        theTokenField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    theTokenField.setHint(" Subscription Key");
                }
                else
                {
                    theTokenField.setHint("");
                }
            }
        });
        theForgetPasswordText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntentToStartAlertListActivity = new Intent(LoginActivity.this, VerifyUsernameActivity.class);
                myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(myIntentToStartAlertListActivity);
                finish();
            }
        });
        // keyboard settings
        LinearLayout myLoginLayout = (LinearLayout) findViewById(R.id.content_login);
        myLoginLayout.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View view, MotionEvent ev)
            {
                hideKeyboard(view);
                return false;
            }
        });


    }
    /**
     * Hides virtual keyboard
     *
     */
    protected void hideKeyboard(View view)
    {
        InputMethodManager myInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        myInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        theUsernameField.setText("");
        thePasswordField.setText("");
        theTokenField.setText("");
    }
    @Override
    protected void onResume() {
        super.onResume();
        checkDemoUser(theUsernameField.getText().toString().trim());
    }
    /***************************************************************
     PRIVATE - METHODS
     ****************************************************************/
    /*
     *
     *  to check if the user password is saved in the database
     *
     */
    private boolean checkIfUserLoggedIn()
    {
        boolean myLogin = false;
        DAOFactory mySqliteDaoFactory = null;
        try {
            if(getNumberOfUsers()>0) {
                mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
                mySqliteDaoFactory.setContext(this);
                IUserDAO mySqliteUserDao = mySqliteDaoFactory.getUserDAO();
                UserDTO myUserProfile = mySqliteUserDao.getUserProfile();
                if (myUserProfile.getTheUserPassword() != null) {
                    String myUserPassword = myUserProfile.getTheUserPassword();
                    if (!myUserPassword.equals("0")) {
                        myLogin = true;
                    } else {
                        myLogin = false;
                    }
                }
            }
        }
        catch (WeAlertException e)
        {
            Toast.makeText(this,"Unable to check if user is already signed in",Toast.LENGTH_LONG).show();
        }
        catch (Exception e)
        {
            Toast.makeText(this,"Unable to check if user is already signed in",Toast.LENGTH_LONG).show();
        }
        finally
        {
            return myLogin;
        }
    }
    /*
     *
     *  to check if the user profile exists
     *
     */
    private boolean checkIfUserProfileExists(String aUsername) throws WeAlertException
    {
        boolean myRegistration = false;
        DAOFactory mySqliteDaoFactory = null;
        try {
            mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IUserDAO mySqliteUserDao = mySqliteDaoFactory.getUserDAO();
            UserDTO myUserProfile = mySqliteUserDao.getUserProfile();
            if(myUserProfile.getTheUserName() != null) {
                String myUserName = myUserProfile.getTheUserName();
                if (myUserName.equals(aUsername)) {
                    myRegistration = true;
                } else {
                    myRegistration = false;
                }
            }
        }
        catch (WeAlertException myWeAlertException)
        {
            throw myWeAlertException;
        }
        catch (Exception e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
        finally
        {
            return myRegistration;
        }
    }
    /*
     *
     *  to insert user password to user table in database
     *
     */
    private void insertUserPasswordToDatabase(String aPassword) throws WeAlertException {
        try {
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySqliteDaoFactory.getUserDAO();
            myUserDao.insertUserPassword(aPassword);
        }
        catch (WeAlertException myWeAlertException) {
            throw myWeAlertException;
        }
        catch (Exception e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
    }
    /*
     *
     * number of users
     *
     */
    private int getNumberOfUsers() throws WeAlertException {
        int myUserCount = 0;
        try{
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySqliteDaoFactory.getUserDAO();
            myUserCount = myUserDao.getUserCount();
        } catch (WeAlertException myWeAlertException) {
            throw myWeAlertException;
        }
        catch (Exception e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
        return  myUserCount;
    }
    /*
     *
     *  to validate username
     *
     */
    @RequiresApi(api = Build.VERSION_CODES.FROYO)
    private void validateUsername(String aUsername) {
        boolean myValidation;
        if (!aUsername.equals("")) {
            myValidation = Pattern.matches("^[_A-Za-z0-9-+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", aUsername);
            checkDemoUser(theUsernameField.getText().toString().trim());
            if(theUsernameField.length()<11)
            {
                theUsernameField.setError("Username must have at least 11 characters");
            }
            else if(!myValidation)
            {
                theUsernameField.setError("Invalid username");
            }
            else if(myValidation && theUsernameField.length()>10)
            {
                theUsernameField.setError(null);
            }
        }
    }
    private void checkDemoUser(String aUsername) {
        if (aUsername.contains("@w-alertdemo.com")) {
            theTokenField.setVisibility(View.INVISIBLE);
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("Token","24f7f52a-758a-30ac-9d24-1343ab3ba2bc");//c505e8f7-ecb3-346f-8216-f906965edc17"");
            editor.putString("DemoToken","true");
            editor.commit();
        }
        else
        {
            SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(this);
            String myUserName= preferences.getString("UserName","");
            if(myUserName=="") {
                theTokenField.setVisibility(View.VISIBLE);
            }else if(myUserName.equals(aUsername))
            {
                theTokenField.setVisibility(View.INVISIBLE);
            }
            else
            {
                theTokenField.setVisibility(View.VISIBLE);
            }
        }
    }
    /*
     *
     *  to save user profile in database
     *
     */
    private void saveUserProfile(JSONObject aJSONUserProfile) throws WeAlertException {
        UserDTO myUserProfile = new UserDTO();
        try {
            JSONObject myJSONUser = aJSONUserProfile.getJSONObject("GetUserResponse").getJSONObject("User");
            JSONObject myJSONClient = aJSONUserProfile.getJSONObject("GetUserResponse").getJSONObject("Client");
            JSONObject myUserMobile = (JSONObject)myJSONUser.getJSONArray("ContactDetail").get(0);
            JSONObject myUserEmail = (JSONObject)myJSONUser.getJSONArray("ContactDetail").get(1);
            //make the user dto from json response payload
            myUserProfile.setTheUserId(myJSONUser.getString("UserId"));
            myUserProfile.setTheUserName(myJSONUser.getString("UserName"));
            myUserProfile.setTheUserPassword(thePassword);
            myUserProfile.setTheUserFirstName(myJSONUser.getJSONObject("PersonalDetail").getString("FirstName"));
            myUserProfile.setTheUserLastName(myJSONUser.getJSONObject("PersonalDetail").getString("LastName"));
            myUserProfile.setTheUserMobileNo(myUserMobile.getString("ChannelCode"));
            myUserProfile.setTheUserEmail(myUserEmail.getString("ChannelCode"));
            myUserProfile.setTheUserRoleId(myJSONUser.getString("RoleId"));
            myUserProfile.setTheOrganizationId(myJSONClient.getString("OrganizationId"));
            myUserProfile.setTheOrganizationName(myJSONClient.getString("OrganizationName"));
            myUserProfile.setTheOrganizationDomain(myJSONClient.getString("OrganizationDomain"));
            //save in database
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IUserDAO mySqliteUserDao = mySqliteDaoFactory.getUserDAO();
            mySqliteUserDao.insertUserProfile(myUserProfile);
        } catch (WeAlertException myWeAlertException) {
            throw myWeAlertException;
        }
        catch (Exception e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
    }
    /*
     *
     * to validate input
     *
     */
    private class MyInputValidator implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
        @Override
        public void afterTextChanged(Editable s) {
            validateUsername(theUsernameField.getText().toString().trim());
            checkDemoUser(theUsernameField.getText().toString().trim());
        }
    }
    private UserDTO getUserDetail(){
        UserDTO myUserProfile = new UserDTO();
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySQLLiteDaoFactory.getUserDAO();
            myUserProfile = myUserDao.getUserProfile();
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),"AlertService",myWeAlertException.getMessage());
        }
        return myUserProfile;
    }
    private boolean isWriteStorageAllowed() {
        //Getting the permission status
        int myResult = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        //If permission is granted returning true
        if (myResult == PackageManager.PERMISSION_GRANTED)
            return true;
        //If permission is not granted returning false
        return false;
    }
    //Requesting permission
    private void requestStoragePermission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)){
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},STORAGE_PERMISSION_CODE);
    }
    /***************************************************************
     PUBLIC - METHODS
     ****************************************************************/
    //This method will be called when the user will tap on allow or deny
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //Checking the request code
        if(requestCode == STORAGE_PERMISSION_CODE){
            //If permission is granted
            if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            }else{
            }
        }
    }
    /*
     *
     * onClick function for sign in button
     *
     */
    public void onSignInButtonClick(View view) {
        theUsername = theUsernameField.getText().toString();
        thePassword = thePasswordField.getText().toString();
        theToken= theTokenField.getText().toString();
        if (!theUsername.trim().equals("") && !thePassword.trim().equals("")) {
            if(theUsernameField.getError() == null && thePasswordField.getError() == null) {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
                String myTokenCheck = preferences.getString("DemoToken","");
                SharedPreferences.Editor editor;
                String myUserName= preferences.getString("UserName","");
                if (theUsername.contains("@w-alertdemo.com")) {
                    theTokenField.setVisibility(View.INVISIBLE);
                    editor = preferences.edit();
                    editor.putString("Token", EnvironmentConstants.SUBSCRIPTION_TOKEN);//c505e8f7-ecb3-346f-8216-f906965edc17"");
                    editor.putString("DemoToken","true");
                    editor.commit();
                }
                if(myUserName=="") {
                    if(myTokenCheck.contains("false"))
                    {
                        editor = preferences.edit();
                        editor.putString("Token",theToken);
                        editor.commit();
                    }
                    else if(myTokenCheck.contains("true")&&myUserName==""&&!theUsername.contains("w-alertdemo.com"))
                    {
                        editor = preferences.edit();
                        editor.putString("UserName",theUsername.toString().trim());
                        editor.putString("Token",theToken);
                        editor.commit();
                    }
                    else if(myTokenCheck==""&&myUserName=="")
                    {
                        editor = preferences.edit();
                        editor.putString("UserName",theUsername.toString().trim());
                        editor.putString("Token",theToken);
                        editor.commit();
                    }
                }else if(theUsername.toString().trim().equals(myUserName))
                {
                    theTokenField.setVisibility(View.INVISIBLE);
                }
                else
                {
                    if(myTokenCheck.contains("true")&&myUserName=="")
                    {
                        editor = preferences.edit();
                        editor.putString("UserName",theUsername.toString().trim());
                        editor.putString("Token",theToken);
                        editor.commit();
                    }
                    else if (myTokenCheck.contains("true")&& theUsername.contains("w-alertdemo.com"))
                    {
                        editor = preferences.edit();
                        editor.putString("UserName",theUsername.toString().trim());
                        editor.commit();
                    }
                    else
                    {
                        editor = preferences.edit();
                        editor.putString("UserName",theUsername.toString().trim());
                        editor.putString("Token",theToken);
                        editor.commit();
                    }
                }
                //start the login operation for api call
                Object []myObjects = new Object[2];
                myObjects[0] = preferences;
                LoginOperation myLoginOperation = new LoginOperation();
                myLoginOperation.execute(myObjects);
            }
            else
            {
                Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
            }
        }
        else if (theUsername.trim().equals("") && !(thePassword.trim().equals(""))) {
            theUsernameField.requestFocus();
            theUsernameField.setError("Username is required");
        } else if (!(theUsername.trim().equals("")) && thePassword.trim().equals("")) {
            thePasswordField.requestFocus();
            thePasswordField.setError("Password is required");
        } else {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
        }
    }
    /***************************************************************
     PRIVATE - METHODS
     ****************************************************************/
    /*
     *
     *  to manage the api calls for login
     *
     */
    private class LoginOperation extends AsyncTask {
        @Override
        protected void onPreExecute() {
            theProgressBar.setVisibility(View.VISIBLE);
        }
        @Override
        protected Object doInBackground(Object[] params) {

            SharedPreferences myPreference = null;
            try{
                myPreference = (SharedPreferences) params[0];
            }
            catch (Exception e){
                Toast.makeText(LoginActivity.this, "Cannot access shared preferences.", Toast.LENGTH_LONG).show();
            }

            IdentityAndAccessManagement myIAMApi = new IdentityAndAccessManagement();
            ClientManagement myClientManagementApi = new ClientManagement();
            Context aContext = LoginActivity.this;
            String myResponse = null;
            try {
                if (getNumberOfUsers() == 1) {
                    if (checkIfUserProfileExists(theUsername)) {
                        String myAuthentication = myIAMApi.sendAuthenticateRequest(WeAlertURLs.AUTHENTICATE_USER_URL, theUsername, thePassword, aContext);
                        if (myAuthentication.equals("true")) {
                            myResponse = "UserAuthenticated";
                        }
                        else if(myAuthentication.equals("false")) {
                            myResponse = "Unauthenticated";
                        }
                        else if(myAuthentication.equals("token")) {
                            myResponse = "FalseToken";
                        }
                    }
                    else {
                        myResponse = "UserProfileExists";
                    }
                } else {
                    String myAuthentication = myIAMApi.sendAuthenticateRequest(WeAlertURLs.AUTHENTICATE_USER_URL, theUsername, thePassword, aContext);
                    if (myAuthentication.equals("true")) {
                        myResponse = "Authenticated";
                        JSONObject myJSONUserProfile = myClientManagementApi.sendGetUserRequest(WeAlertURLs.GET_USER_URL, theUsername,aContext);
                        String myGetUserResponse = myJSONUserProfile.getJSONObject("GetUserResponse").getJSONObject("Result").getString("ResponseCode");
                        if(myGetUserResponse.equals("CM-N-0000")) {
                            String myRoleId = myJSONUserProfile.getJSONObject("GetUserResponse").getJSONObject("User").getString("RoleId");
                            if (myRoleId.equals("Member") || myRoleId.equals("Manager")) {
                                myResponse = "AuthorizedUser";
                                String myRegistration = myIAMApi.sendRegisterDeviceRequest(WeAlertURLs.REGISTER_DEVICE_URL, theUsername, aContext);
                                if (myRegistration.equals("true")) {
                                    myResponse = "Registered";
                                    saveUserProfile(myJSONUserProfile);
                                } else if (myRegistration.equals("false")) {
                                    myResponse = "Unregistered";
                                }
                                else if(myAuthentication.equals("token")) {
                                    myResponse = "FalseToken";
                                }
                            }
                        }
                        else if(myGetUserResponse.equals("CM-E-9999"))
                        {
                            myResponse = "UnauthorizedUser";
                        }
                    } else if(myAuthentication.equals("false")) {
                        myResponse = "Unauthenticated";
                    } else if(myAuthentication.equals("token")) {
                        myResponse = "FalseToken";
                    }
                }
            } catch (Exception e) {
                WeAlertLogger myLogger = new WeAlertLogger();
                myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to connect to the backend service. Please try again.");
                myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                myResponse = null;
            }

            if(myResponse.equals("FalseToken") || myResponse.equals("") || myResponse.equals("") || myResponse.equals("") || myResponse.equals("")){

            }

            if(myResponse.equals("FalseToken")){
                SharedPreferences.Editor editor;
                editor = myPreference.edit();
                editor.clear();
                editor.commit();
            }
            return myResponse;
        }
        @Override
        protected void onPostExecute(Object o) {
            theProgressBar.setVisibility(View.GONE);
            try {
                String myResponse = o.toString();
                if (myResponse != null) {
                    if (myResponse.equals("UserAuthenticated")) {
                        insertUserPasswordToDatabase(thePassword);
                        UserEncryption userEncryption = new UserEncryption();
                        userEncryption.insertEncryptedUserPasswordToDatabase(getApplicationContext());
                        Intent myIntentToStartAlertListActivity = new Intent(LoginActivity.this, AlertListActivity.class);
                        myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(myIntentToStartAlertListActivity);
                        LoginActivity.this.finish();
                    } else if (myResponse.equals("UserProfileExists")) {
                        Toast.makeText(LoginActivity.this, "Please sign in with the user you used previously, use Sign Out and Disconnect to switch user.", Toast.LENGTH_LONG).show();
                    }else if (myResponse.equals("FalseToken")) {
                        Toast.makeText(LoginActivity.this, "Please enter correct Token.", Toast.LENGTH_LONG).show();
                        theTokenField.setVisibility(View.VISIBLE);
                        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences( LoginActivity.this);
                        preferences.edit().remove("Token").commit();
                    }
                    else if (myResponse.equals("Registered")) {
                        final AlertSubscriptionSetting setting= new AlertSubscriptionSetting(getApplicationContext());
                        UserDTO user= getUserDetail();
                        Runnable myRegisterDeviceDialogue = new Runnable() {
                            @Override
                            public void run() {
                                if (setting.isSubscriptionSaved(LoginActivity.this)) {
                                    Log.i(CLASS_NAME,"Subscription details are saved.");
                                    AlertDialog.Builder mySignInConfirmationDialog = new AlertDialog.Builder(LoginActivity.this, R.style.Mytheme);
                                    mySignInConfirmationDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            Intent myIntentToStartAlertListActivity = new Intent(LoginActivity.this, AlertListActivity.class);
                                            myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            startActivity(myIntentToStartAlertListActivity);
                                            LoginActivity.this.finish();
                                        }
                                    });
                                    AlertDialog mySignInDialog = mySignInConfirmationDialog.create();
                                    mySignInDialog.setMessage("Your device has been registered.");
                                    mySignInDialog.show();
                                    mySignInDialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                                    mySignInDialog.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
                                    mySignInDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorWhite));
                                    mySignInDialog.setCancelable(false);
                                    mySignInDialog.setCanceledOnTouchOutside(false);
                                }
                            }
                        };
                        setting.getSubscriptionDetail(user.getTheUserId(),user.getTheOrganizationId(),myRegisterDeviceDialogue);
                    } else if (myResponse.equals("Unregistered")) {
                        Toast.makeText(LoginActivity.this, "Unable to login because the user is not assigned to any group", Toast.LENGTH_LONG).show();
                    } else if (myResponse.equals("Authenticated")) {
                        Toast.makeText(LoginActivity.this, "Unable to login because the user is not a member or manager", Toast.LENGTH_LONG).show();
                    }
                    else if(myResponse.equals("UnauthorizedUser")){
                        Toast.makeText(LoginActivity.this,"Unable to get user details",Toast.LENGTH_LONG).show();
                    }
                    else if (myResponse.equals("Unauthenticated")){
                        Toast.makeText(LoginActivity.this, "Username or Password is incorrect. Please try again.", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Unable to connect to the backend service. Please try again.", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                WeAlertLogger myWeAlertLogger = new WeAlertLogger();
                myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to connect to the backend service. Please try again.");
                Toast.makeText(LoginActivity.this, "Unable to connect to the backend service. Please try again.", Toast.LENGTH_LONG).show();
            }
        }
    }
}