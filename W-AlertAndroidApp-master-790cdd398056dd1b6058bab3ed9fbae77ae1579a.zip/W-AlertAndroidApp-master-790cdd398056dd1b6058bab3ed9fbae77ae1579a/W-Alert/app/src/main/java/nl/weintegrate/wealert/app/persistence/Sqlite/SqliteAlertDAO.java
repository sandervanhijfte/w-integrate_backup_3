package nl.weintegrate.wealert.app.persistence.Sqlite;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Implementing Sqlite database queries for alerts
 *
 *	@Known Issues:
 *          1. ://TODO Queries can be defined separately
 *          2. ://TODO Log the stack trace
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *			01.002 Added getTotalNumberOfAlerts function
 *		    01.003 Added updateAlertStatusToRead and searchAlert function
 *		    01.004 Added the SqliteDB parameter in the constructor
 */

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.content.LocalBroadcastManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import nl.weintegrate.wealert.app.dto.AlertDTO;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

public class SqliteAlertDAO implements IAlertDAO {

    private static final String CLASS_NAME = "SqliteAlertDAO";
    private static final String DATABASE_TABLE = "T_ALERT";
    private SqliteDB theSqliteDB;
    private Context theCurrentContext;
    public SqliteAlertDAO(SqliteDB aSqliteDB, Context aCurrentContext){
        this.theSqliteDB = aSqliteDB;
        this.theCurrentContext = aCurrentContext;
    }

    /*
     *
     * @Usage:
     *      1. To get access to the result set retrieved from database and prepare an AlertDTO
     * @params:
     *      1. aDatabaseCursor : a cursor object having a result set retrieved from database through a query
     *
     */
    private AlertDTO getAlertDTOFromRetrieveCursor(Cursor aDatabaseCursor) throws WeAlertException {
        AlertDTO myTemporaryAlertDTO = new AlertDTO();
        Date  myAlertTimestamp= null;
        boolean myAlertUnreadStatus;
        try {
            if(aDatabaseCursor.getString(0)!=null ) {
                String myAlertId = aDatabaseCursor.getString(0);
                myTemporaryAlertDTO.setTheAlertId(myAlertId);
            }
            if(aDatabaseCursor.getString(1)!=null){
                String myAlertTime = aDatabaseCursor.getString(1);
                myAlertTimestamp = new SimpleDateFormat(Constant.ALERT_TIMESTAMP_FORMAT).parse(myAlertTime);
                myTemporaryAlertDTO.setTheTimestamp(myAlertTimestamp);
            }
            if(aDatabaseCursor.getString(2)!=null){
                myTemporaryAlertDTO.setTheSeverity(aDatabaseCursor.getString(2));
            }
            if(aDatabaseCursor.getString(3)!=null){
                myTemporaryAlertDTO.setTheAlertType(aDatabaseCursor.getString(3));
            }
            if(aDatabaseCursor.getString(4)!=null) {
                myTemporaryAlertDTO.setTheAlertTitle(aDatabaseCursor.getString(4));
            }
            if(aDatabaseCursor.getString(5)!=null) {
                myTemporaryAlertDTO.setTheAlertMessage(aDatabaseCursor.getString(5));
            }
            if(aDatabaseCursor.getString(6)!=null) {
                myTemporaryAlertDTO.setTheHost(aDatabaseCursor.getString(6));
            }
            if(aDatabaseCursor.getString(7)!=null) {
                myTemporaryAlertDTO.setTheComponentName(aDatabaseCursor.getString(7));
            }
            if(aDatabaseCursor.getString(8)!=null) {
                int myUnreadStatus = aDatabaseCursor.getInt(8);
                if (myUnreadStatus == 1) {
                    myAlertUnreadStatus = true;
                } else {
                    myAlertUnreadStatus = false;
                }
                myTemporaryAlertDTO.setTheUnreadStatus(myAlertUnreadStatus);
            }
            if(aDatabaseCursor.getString(9)!=null) {
                myTemporaryAlertDTO.setTheEnvironmentName(aDatabaseCursor.getString(9));
            }
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while preparing AlertDTO from retrieve database cursor");
            throw myWeAlertException;
        }
        return myTemporaryAlertDTO;
    }
    /*
    *
    *   @Usage:
    *       1. Returns the total number of alerts saved in the database
    *
     */
	@Override
    public int getTotalNumberOfAlerts() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        int myRowCount = 0;
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT COUNT(*) FROM T_ALERT", null);

            myCursor.moveToFirst();
            myRowCount = myCursor.getInt(0);

        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while counting rows in alert table of sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }

        return myRowCount;
    }
    /*
    *
    *   @Usage:
    *       1. Updates the alert status from unread to read in the database
    *   @params:
    *       1. anAlertId: The id of the alert to be updated
    *
     */
    @Override
    public void updateAlertStatusToRead(String anAlertId) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        ContentValues myAlertStatus = null;
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myAlertStatus = new ContentValues();
            myAlertStatus.put("C_UNREAD", false);
            myWeAlertDB.update(DATABASE_TABLE, myAlertStatus, "C_ALERT_ID=?", new String[]{anAlertId});
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while updating alert status from unread to read in sqlite database");
            throw myWeAlertException;
        }
        finally {
            myAlertStatus.clear();
            theSqliteDB.CloseDatabase();
        }
    }
    /*
    *
    *   @Usage:
    *       1. Searches alert table for the given value and returns all matching results in an AlertDTO list
    *   @params:
    *       1. aSearchValue : A String value against which the table is searched
    *
     */
    @Override
    public ArrayList<AlertDTO> searchAlert(String aSearchValue) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT WHERE C_ALERT_TITLE LIKE ? OR C_ALERT_TYPE LIKE ? OR C_SEVERITY LIKE ? OR C_TIME_STAMP LIKE ? OR C_ALERT_ID LIKE ? OR C_COMPONENT_NAME LIKE ? OR C_HOST_NAME LIKE ? OR C_ALERT_MESSAGE LIKE ? ORDER BY datetime(C_TIME_STAMP) DESC", new String[]{"%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%"});
            myCursor.moveToFirst();
            if (myCursor.moveToFirst()) {
                do {
                    AlertDTO myAlert = getAlertDTOFromRetrieveCursor(myCursor);
                    myAlertList.add(myAlert);

                } while (myCursor.moveToNext());
            }

        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while searching alerts from sqlite database");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while searching alerts from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }

        return myAlertList;
    }

    /*
    *
    *   @Usage:
    *       1. Searches alert table for the given value and returns results for first page in an AlertDTO list
    *   @params:
    *       1. aSearchValue : A String value against which the table is searched
    *
     */
    @Override
    public ArrayList<AlertDTO> searchAlertToGetFirstPageResult(String aSearchValue) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT WHERE C_ALERT_TITLE LIKE ? OR C_ALERT_TYPE LIKE ? OR C_SEVERITY LIKE ? OR C_TIME_STAMP LIKE ? OR C_ALERT_ID LIKE ? OR C_COMPONENT_NAME LIKE ? OR C_HOST_NAME LIKE ? OR C_ALERT_MESSAGE LIKE ? ORDER BY ROWID DESC LIMIT ?", new String[]{"%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%",Integer.toString(Constant.ALERT_LIST_PAGE_SIZE)});
            myCursor.moveToFirst();
            if (myCursor.moveToFirst()) {
                do {
                    AlertDTO myAlert = getAlertDTOFromRetrieveCursor(myCursor);
                    myAlertList.add(myAlert);

                } while (myCursor.moveToNext());
            }

        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting search results for first page of alert list from sqlite database");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting search results for first page of alert list from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }

        return myAlertList;
    }
    /*
   *
   *   @Usage:
   *       1. Searches alert table for the given value and returns results for current page in an AlertDTO list
   *   @params:
   *       1. aSearchValue : A String value against which the table is searched
   *       2. aStartIndex : An index from where the current page should start
   *
    */
    @Override
    public ArrayList<AlertDTO> searchAlertToGetCurrentPageResult(String aSearchValue, int aStartIndex) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT WHERE ROWID<? AND (C_ALERT_TITLE LIKE ? OR C_ALERT_TYPE LIKE ? OR C_SEVERITY LIKE ? OR C_TIME_STAMP LIKE ? OR C_ALERT_ID LIKE ? OR C_COMPONENT_NAME LIKE ? OR C_HOST_NAME LIKE ? OR C_ALERT_MESSAGE LIKE ?) ORDER BY ROWID DESC LIMIT ?", new String[]{Integer.toString(aStartIndex),"%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%","%"+aSearchValue+"%",Integer.toString(Constant.ALERT_LIST_PAGE_SIZE)});
            myCursor.moveToFirst();
            if (myCursor.moveToFirst()) {
                do {
                    AlertDTO myAlert = getAlertDTOFromRetrieveCursor(myCursor);
                    myAlertList.add(myAlert);

                } while (myCursor.moveToNext());
            }

        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting search results for first page of alert list from sqlite database");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting search results for first page of alert list from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }

        return myAlertList;
    }


    /*
    *
    *   @Usage:
    *       1. Inserts a new alert to the alert table in the database
    *   @params:
    *       1. anAlertDTO: The AlertDTO which is saved to the database
    *
     */
    @Override
    public void insertAlert(AlertDTO anAlertDTO) throws WeAlertException {
        // TODO Auto-generated method stub
        SQLiteDatabase myWeAlertDB;
        ContentValues myNewAlertValues = null;
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myNewAlertValues = new ContentValues();
            if (anAlertDTO.getTheAlertId() != null) {

                myNewAlertValues.put("C_ALERT_ID", anAlertDTO.getTheAlertId());

            }

            if (anAlertDTO.getTheTimestamp() != null) {
                Date myTimestamp = anAlertDTO.getTheTimestamp();
                String myAlertTimestamp = new SimpleDateFormat(Constant.ALERT_TIMESTAMP_FORMAT).format(myTimestamp);
                myNewAlertValues.put("C_TIME_STAMP", myAlertTimestamp);


            }
            else
            {
                Date myTimestamp = new Date();
                String myAlertTimestamp = new SimpleDateFormat(Constant.ALERT_TIMESTAMP_FORMAT).format(myTimestamp);
                myNewAlertValues.put("C_TIME_STAMP", myAlertTimestamp);
            }

            if (anAlertDTO.getTheSeverity() != null) {

                myNewAlertValues.put("C_SEVERITY", anAlertDTO.getTheSeverity());


            }

            if (anAlertDTO.getTheAlertType() != null) {

                myNewAlertValues.put("C_ALERT_TYPE", anAlertDTO.getTheAlertType());

            }

            if (anAlertDTO.getTheAlertTitle() != null) {

                myNewAlertValues.put("C_ALERT_TITLE", anAlertDTO.getTheAlertTitle());

            }

            if (anAlertDTO.getTheAlertMessage() != null) {

                myNewAlertValues.put("C_ALERT_MESSAGE", anAlertDTO.getTheAlertMessage());
            }

            if (anAlertDTO.getTheHost() != null) {

                myNewAlertValues.put("C_HOST_NAME", anAlertDTO.getTheHost());
            }

            if (anAlertDTO.getTheComponentName() != null) {

                myNewAlertValues.put("C_COMPONENT_NAME", anAlertDTO.getTheComponentName());
            }

            myNewAlertValues.put("C_UNREAD", true);
            if (anAlertDTO.getTheEnvironmentName() != null) {

                myNewAlertValues.put("C_ENVIRONMENT_NAME", anAlertDTO.getTheEnvironmentName());
            }
            long myResponse = myWeAlertDB.insertOrThrow(DATABASE_TABLE, null, myNewAlertValues);
       } catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while saving new alert to sqlite database");
            throw myWeAlertException;
        }
        finally {
            myNewAlertValues.clear();
            theSqliteDB.CloseDatabase();
        }
    }
    /*
    *
    *   @Usage:
    *       1. Get the detail of an alert
    *   @params:
    *       1. anAlertId: the alert id of the alert which we want to retrieve
    *
     */
    @Override
    public AlertDTO getAlert(String anAlertId) throws WeAlertException {
        // TODO Auto-generated method stub
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        AlertDTO myAlert = new AlertDTO();
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT WHERE C_ALERT_ID=?", new String[]{anAlertId});
            myCursor.moveToFirst();
            myAlert = getAlertDTOFromRetrieveCursor(myCursor);
            // Updating the alert status from unread to read
            updateAlertStatusToRead(anAlertId);
        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting alert detail from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myAlert;
    }
    /*
    *
    *   @Usage:
    *       1. Gets all the alerts saved in the alert table of database
    *
     */
    @Override
    public ArrayList<AlertDTO> listAlert() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT ORDER BY datetime(C_TIME_STAMP) DESC", null);
            myCursor.moveToFirst();
            if (myCursor.moveToFirst()) {
                do {
                    AlertDTO myAlert = getAlertDTOFromRetrieveCursor(myCursor);
                    myAlertList.add(myAlert);

                } while (myCursor.moveToNext());
            }
        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting alert list from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myAlertList;

    }
    /*
    *
    *   @Usage:
    *       1. Deletes an alert from the alert table in database
    *   @params:
    *       1. anAlertId : the alert id of the alert which we want to delete
    *
     */
    @Override
    public void deleteAlert(String anAlertId) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myWeAlertDB.delete(DATABASE_TABLE,"C_ALERT_ID=?",new String[] {anAlertId});
        }
        catch (Exception e) {

            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while deleting the alert from sqlite database");
            throw myWeAlertException;

        } finally {
            theSqliteDB.CloseDatabase();
        }

    }

    /*
    *
    *   @Usage:
    *       1. Deletes oldest alerts from the database
    *   @params:
    *
    *
    */
    public void cleanupDatabase(int aNumberOfAlertsToDelete) throws WeAlertException {

        SQLiteDatabase myWeAlertDB;

        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            Cursor myCursor = myWeAlertDB.rawQuery("DELETE FROM T_ALERT WHERE C_ALERT_ID IN (SELECT C_ALERT_ID FROM T_ALERT ORDER BY C_TIME_STAMP ASC LIMIT "+aNumberOfAlertsToDelete+")", null);
            //WeAlertLogger myLogger = new WeAlertLogger();

            myCursor.moveToFirst();
//            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Deleted Messages"+myCursor.getCount());
        }
        catch (Exception e) {

            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while deleting old alerts from sqlite database");
            throw myWeAlertException;

        } finally {

            theSqliteDB.CloseDatabase();
        }

    }

    @Override
    public int getUnreadMessageCount() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        int myUnreadMessages = 0;
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT COUNT(*) FROM T_ALERT WHERE C_UNREAD = 1", null);

            myCursor.moveToFirst();
            myUnreadMessages = myCursor.getInt(0);

        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while counting rows in alert table of sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myUnreadMessages;
    }
    /*
    *
    * @Usage :
    *       1. To get the alert list for one page on the basis of starting index
    *
     */
    @Override
    public ArrayList<AlertDTO> listAlertForOnePage(int aStartIndex) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT WHERE ROWID<? ORDER BY ROWID DESC LIMIT ?", new String[]{Integer.toString(aStartIndex),Integer.toString(Constant.ALERT_LIST_PAGE_SIZE)});
            myCursor.moveToFirst();
            if (myCursor.moveToFirst()) {
                do {
                    AlertDTO myAlert = getAlertDTOFromRetrieveCursor(myCursor);
                    myAlertList.add(myAlert);

                } while (myCursor.moveToNext());
            }
        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting alert list for first page from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myAlertList;
    }
    /*
    *
    *  @Usage:
    *       1. To get the top alerts in descending order for first page
    *
     */

    @Override
    public ArrayList<AlertDTO> listAlertForFirstPage() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        ArrayList<AlertDTO> myAlertList = new ArrayList<AlertDTO>();
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT ORDER BY ROWID DESC LIMIT ?", new String[]{Integer.toString(Constant.ALERT_LIST_PAGE_SIZE)});
            myCursor.moveToFirst();
            if (myCursor.moveToFirst()) {
                do {
                    AlertDTO myAlert = getAlertDTOFromRetrieveCursor(myCursor);
                    myAlertList.add(myAlert);

                } while (myCursor.moveToNext());
            }
        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting alert list for the current page from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myAlertList;
    }

    /*
    *
    *  @Usage:
    *       1. To get the ROWID from alert table to decide the starting index of the page
    *
     */
    @Override
    public int getRowId(String anAlertId) throws WeAlertException
    {
        int myAlertRowId = 0 ;
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT ROWID FROM T_ALERT WHERE C_ALERT_ID=?", new String[]{anAlertId});
            myCursor.moveToFirst();
            myAlertRowId = myCursor.getInt(0);
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting ROWID of the alert from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myAlertRowId;
    }

    @Override
    public boolean checkIfAlertExists(String anAlertId) throws WeAlertException {
        boolean myCheckIfAlertExists = false;
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT WHERE C_ALERT_ID=?", new String[]{anAlertId});
            myCursor.moveToFirst();
            if(!(myCursor.getCount() ==0))
            {
                if (myCursor.getString(0).equals(anAlertId)) {
                    myCheckIfAlertExists = true;
                }
            }
            else
            {
                myCheckIfAlertExists = false;
            }
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while checking if alert already exists in sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myCheckIfAlertExists;
    }

    @Override
    public AlertDTO getNewAlert() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        AlertDTO myAlert = new AlertDTO();
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_ALERT ORDER BY ROWID DESC LIMIT ?", new String[]{Integer.toString(1)});
            myCursor.moveToFirst();
            myAlert = getAlertDTOFromRetrieveCursor(myCursor);
        }
        catch (WeAlertException e){
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting new alert from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myAlert;
    }


}
