package nl.weintegrate.wealert.app.ui;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Code behind the alert detail view
 *
 *	@Known Issues:
 *          1. ://TODO Add the delete button
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 Added back button
 *		    01.003 Changed activity title from notification detail to the actual alert title
 *
 *
 */
/* Android Imports  */
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
/* Java Imports  */
import java.text.SimpleDateFormat;
/* Weintegrate Imports  */
import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.dto.AlertDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;


public class AlertDetailActivity extends AppCompatActivity {
    /***************************************************************
     VARIABLES
     ****************************************************************/
    private final String CLASS_NAME = "AlertDetailActivity";
    String myAlertId;
    private String theTitle ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //to set back button on the top of  screen
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setDisplayShowHomeEnabled(true);

        //get Alert id from alert list page
        final Bundle bundle = getIntent().getExtras();
        myAlertId = bundle.getString("theAlertId");
        setAlertDetailTextView(myAlertId);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });
        //to set title of page
        getSupportActionBar().setTitle(theTitle);
    }
    /***************************************************************
     PUBLIC - METHODS
     ****************************************************************/
    /*
   * Usage:
   *       Callback method for android back button
   *
   */
    @Override
    public void onBackPressed() {
        Intent myIntentToStartAlertList = new Intent();
        myIntentToStartAlertList.putExtra("theAlertId",myAlertId);
        setResult(RESULT_OK, myIntentToStartAlertList);
        finish();
        super.onBackPressed();
    }
    public void onDeleteAlertButton(View view) {
        final AlertDialog myDeleteConfirmationDialog = new AlertDialog.Builder(this, R.style.Mytheme).create();
        LayoutInflater myLayoutInflater = this.getLayoutInflater();
        View myDeleteDialogView = myLayoutInflater.inflate(R.layout.layout_delete_dialog,null);
        myDeleteConfirmationDialog.setView(myDeleteDialogView);
        myDeleteConfirmationDialog.setCancelable(true);
        Button myPositiveButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_yes);
        Button myNegativeButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_cancel_delete);

        myPositiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteAlertFromDatabase(myAlertId);
                Intent myIntentToStartAlertListActivity = new Intent(AlertDetailActivity.this, AlertListActivity.class);
                myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(myIntentToStartAlertListActivity);
                finish();
            }
        });
        myNegativeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDeleteConfirmationDialog.dismiss();
            }
        });
        myDeleteConfirmationDialog.setMessage("Are you sure you want to delete?");
        myDeleteConfirmationDialog.show();
    }

    /***************************************************************
     PRIVATE- METHODS
     ****************************************************************/
    /*
   * Usage:
   *       Sets the details of alert in the alert detail view
   * Params:
   *       anAlertId: the alert whose details are to be displayed
   * */
    private void setAlertDetailTextView(String anAlertId)
    {
        AlertDecryption alert= new AlertDecryption();

        AlertDTO myAlert = new AlertDTO();
        try {

            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            myAlert = mySqliteAlertDao.getAlert(anAlertId);
            TextView myAlertTextView = (TextView) findViewById(R.id.textView_alertDetail);

            TextView myComponentNameTextView = (TextView) findViewById(R.id.textView_componentName);
            TextView myEnvironmentTextView = (TextView) findViewById(R.id.textView_environment);

            TextView myAlertIdTextView = (TextView) findViewById(R.id.textView_alertId);

            TextView myTimeTextView = (TextView) findViewById(R.id.textView_time);
            TextView myDateTextView = (TextView) findViewById(R.id.textView_date);

            String myAlertTimestamp ="";
            if(myAlert.getTheTimestamp()!=null)
            {
                myAlertTimestamp = new SimpleDateFormat(Constant.ALERT_TIMESTAMP_FORMAT).format(myAlert.getTheTimestamp());
            }
            String myAlertId = "unknown";
            String myAlertTitle = "unknown";
            String myComponentName = "unknown";
            String myEnvironmentName = "unknown";
            String mySeverity = "unknown";
            String myAlertType = "unknown";
            String myAlertMessage = "unknown";
            if(myAlert.getTheAlertId() != null)
            {
                myAlertId = myAlert.getTheAlertId();
            }
            if(myAlert.getTheAlertTitle() != null)
            {
                myAlertTitle = myAlert.getTheAlertTitle();
            }
            if(myAlert.getTheComponentName() != null)
            {
                myComponentName = myAlert.getTheComponentName();
            }
            if(myAlert.getTheEnvironmentName() != null)
            {
                myEnvironmentName = myAlert.getTheEnvironmentName();
            }
            if(myAlert.getTheSeverity() != null)
            {
                mySeverity = myAlert.getTheSeverity();
            }
            if(myAlert.getTheAlertType() != null)
            {
                myAlertType = myAlert.getTheAlertType();
            }
            if(myAlert.getTheAlertMessage() != null)
            {
                myAlertMessage = alert.decryptAlertMessage(myAlert.getTheAlertMessage(),this);
            }
            theTitle = myAlertTitle;
            String myAlertText = myAlertType.toUpperCase() + ": </b>"+ myAlertMessage ;
            myAlertTextView.setText(convertToHTML(myAlertText));

            LinearLayout myLayoutSeverity = (LinearLayout) findViewById(R.id.linearLayout_severity);
            if (mySeverity.contains("Low")) {

                myLayoutSeverity.setBackgroundColor(this.getResources().getColor(R.color.colorGreen));
            } else if (mySeverity.contains("High")) {

                myLayoutSeverity.setBackgroundColor(this.getResources().getColor(R.color.colorRed));
            } else {

                myLayoutSeverity.setBackgroundColor(this.getResources().getColor(R.color.colorOrange));
            }

            myComponentNameTextView.setText(convertToHTML(myComponentName));
            myEnvironmentTextView.setText(convertToHTML("From: "+myEnvironmentName));
            myAlertIdTextView.setText(convertToHTML("<br/><b>ID: </b>" +myAlertId));

            String[] myTempDateTime = myAlertTimestamp.split("\\s");
            String myAlertDate = myTempDateTime[0];
            String myAlertTime = myTempDateTime[1];
            myTimeTextView.setText(convertToHTML(myAlertTime.substring(0,5)));
            myDateTextView.setText(convertToHTML(myAlertDate));

        }  catch (Exception e) {
            Toast.makeText(this,"Unable to retrieve alert details. Please try again later or contact your administrator.",Toast.LENGTH_LONG).show();
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,e);
        }
    }

    private void deleteAlertFromDatabase(String anAlertId)
    {
        try {
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(this);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            mySqliteAlertDao.deleteAlert(anAlertId);
        }
        catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,e);
            Toast.makeText(this,"Unable to delete the alert. Please try again.",Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,e);
            Toast.makeText(this,"Unable to delete the alert. Please try again.",Toast.LENGTH_LONG).show();
        }
    }
    /*
    * Usage:
    *       To convert
    * Params:
    *       anHTMLCode : the string html code that has to be converted.
    * */
    @SuppressWarnings("deprecation")
    private Spanned convertToHTML(String anHTMLCode)
    {
        Spanned myHTMLCode;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            myHTMLCode = Html.fromHtml(anHTMLCode,Html.FROM_HTML_MODE_LEGACY);
        } else {
            myHTMLCode = Html.fromHtml(anHTMLCode);
        }
        return myHTMLCode;
    }
}
