package nl.weintegrate.wealert.app.ui;

/* Java Imports  */
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.regex.Pattern;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.api.ClientManagement;
import nl.weintegrate.wealert.app.dto.UserDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import nl.weintegrate.wealert.app.utils.WeAlertURLs;

/* Weintegrate Imports  */

public class UserProfileActivity extends AppCompatActivity {
    /***************************************************************
     * VARIABLES
     ****************************************************************/
    private final String CLASS_NAME = "UserProfileActivity";
    private EditText theUsername;
    private EditText theFirstName;
    private EditText theLastName;
    private EditText theEmail;
    boolean theEditProfileViewEnabled = false;
    private String theUserEmail;
    private String theUserLastName;
    private String theUserFirstName;
    private String theOrganizationDomain;
    private String theUserNameWithoutDomain;
    private ImageButton theEditProfileButton;
    private Button theCancelButton;
    private View theDialogBoxView;
    private boolean isFromCancel;
    private AlertDialog theUpdateConfirmationDialog;
    private AlertDialog theCancelConfirmationDialog;
    private AlertDialog theBackConfirmationDialog;

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    /***************************************************************
     * PROTECTED - METHODS
     ****************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //to set back button in toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        isFromCancel = true;
        theCancelButton = (Button) findViewById(R.id.button_cancel);
        theUsername = (EditText) findViewById(R.id.editText_username);
        theFirstName = (EditText) findViewById(R.id.editText_firstName);
        theLastName = (EditText) findViewById(R.id.editText_lastName);
        theEmail = (EditText) findViewById(R.id.editText_email);
        theEditProfileButton = (ImageButton) findViewById(R.id.imageButton_editProfile);
        theUsername.setText(null);
        theFirstName.setText(null);
        theLastName.setText(null);
        theEmail.setText(null);

        //keyboard settings
        LinearLayout myProfileLayout = (LinearLayout) findViewById(R.id.content_user_profile);
        myProfileLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent ev) {
                hideKeyboard(view);
                return false;
            }
        });

        //get user profile
        new GetUserOperation().execute();


        //set validations for text fields
        theFirstName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    theFirstName.setHint("Enter your first name");
                    validateFirstName();
                } else {
                    theFirstName.setHint("");
                }
            }
        });
        theFirstName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                theFirstName.setHint("Enter your first name");
                validateFirstName();
            }
        });
        theLastName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    theLastName.setHint("Enter your last name");
                    validateLastName();
                } else {
                    theLastName.setHint("");
                }
            }
        });
        theLastName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                validateLastName();
                /*
                //changed
                String myLastName = s.toString();
                Pattern mPattern = Pattern.compile("^([a-zA-Z-]+( [a-zA-Z-]+)*)$");


                validateLastName();
                boolean isMatch = mPattern.matcher(myLastName).matches();
                //System.out.println("\ninvalid text\n");
                if(isMatch){
                    theLastName.setError(null);
                }
                else{
                   // theLastName.setError("It must consist of alphabets. Only hyphens and space are allowed, no other special characters are allowed.");
                }
                */

            }

            @Override
            public void afterTextChanged(Editable s) {
                //theLastName.setHint("Enter your last name");
                //validateLastName();
            }
        });


        theEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    theEmail.setHint("Enter your email");
                    validateEmail();
                } else {
                    theEmail.setHint("");
                }
            }
        });
        theEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                theEmail.setHint("Enter your email");
                validateEmail();
            }
        });
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    /*
     *
     * Hides virtual keyboard
     *
     */
    protected void hideKeyboard(View view) {
        InputMethodManager myInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        myInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    /***************************************************************
     * PRIVATE - METHODS
     ****************************************************************/
    /*
    *
    *  to validate first name field
    *
     */
    private void validateFirstName() {
        String myFirstName = theFirstName.getText().toString();
        Pattern mPattern = Pattern.compile("^([a-zA-Z-]+( [a-zA-Z-]+)*)$");
        boolean isMatch = mPattern.matcher(myFirstName).matches();
        if(isMatch){
            theFirstName.setError(null);
        }
        else{
            theFirstName.setError("It must consist of alphabets. Only hyphens and space are allowed, no other special characters are allowed.");
        }
    }

    /*
    *
    *  to validate last name field
    *
     */
    private void validateLastName() {

        String myLastName = theLastName.getText().toString();
        Pattern mPattern = Pattern.compile("^([a-zA-Z-]+( [a-zA-Z-]+)*)$");
        boolean isMatch = mPattern.matcher(myLastName).matches();
        if(isMatch){
            theLastName.setError(null);
        }
        else{
            theLastName.setError("It must consist of alphabets. Only hyphens and space are allowed, no other special characters are allowed.");
        }

    }

    /*
    *
    *  to validate email field
    *
     */
    private void validateEmail() {
        boolean isEmailPatternMatched = Pattern.matches("^[_A-Za-z0-9-+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", theEmail.getText().toString());  //EMAIL_ADDRESS.matcher(theEmail.getText().toString()).matches();
        if (theEmail.length() == 0) {
            theEmail.setError(null);
        } else {
            if (isEmailPatternMatched) {
                theEmail.setError(null);
            } else {
                theEmail.setError("1. It can be alpha numeric data. 2. Only full stops, hyphens ,underscores & one \"@\" must be allowed, no other special characters are allowed.");
            }
        }
    }

    /*
   *
   *  to get user profile
   *
    */
    private UserDTO getUserDetail() {
        UserDTO myUserProfile = new UserDTO();
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(this);
            IUserDAO myUserDao = mySQLLiteDaoFactory.getUserDAO();
            myUserProfile = myUserDao.getUserProfile();
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, myWeAlertException.getMessage());
        }
        return myUserProfile;
    }

    /***************************************************************
     * PUBLIC - METHODS
     ****************************************************************/
    @Override
    public void onBackPressed() {
        if (!theEditProfileViewEnabled) {
            Intent myIntentToStartAlertListActivity = new Intent(UserProfileActivity.this, AlertListActivity.class);
            myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(myIntentToStartAlertListActivity);
            this.finish();
        } else {
            if(isFromCancel) {
                showBackConfirmationBox();
            }
            else{
                goBack();
            }
            isFromCancel = true;
        }
    }
    public void goBack(){
        theEditProfileViewEnabled = false;
        //set text in fields
        theFirstName.setText(theUserFirstName);
        theFirstName.setEnabled(false);
        theLastName.setText(theUserLastName);
        theLastName.setEnabled(false);
        theEmail.setText(theUserEmail);
        theEmail.setEnabled(false);
        //set edit profile button
        theEditProfileButton.setImageResource(R.drawable.ic_mode_edit_white);
        theCancelButton.setVisibility(View.GONE);
    }
    public void showBackConfirmationBox(){

        LayoutInflater myLayoutInflater = this.getLayoutInflater();
        View myDeleteDialogView = myLayoutInflater.inflate(R.layout.layout_delete_dialog, null);
        theBackConfirmationDialog = new AlertDialog.Builder(this, R.style.Mytheme).create();
        theBackConfirmationDialog.setView(myDeleteDialogView);
        theBackConfirmationDialog.setCancelable(false);
        theBackConfirmationDialog.setCanceledOnTouchOutside(false);
        Button myPositiveButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_yes);
        Button myNegativeButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_cancel_delete);

        myPositiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBack();
                theBackConfirmationDialog.dismiss();
            }
        });
        myNegativeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                theBackConfirmationDialog.dismiss();
            }
        });

        theBackConfirmationDialog.setMessage("Are you sure you want to discard changes?");
        theBackConfirmationDialog.show();

        /*
        try {
            final TextView input = new TextView(this);
            input.setText("Discard Changes?");
            input.setPadding(20,0,0,0);

            float dpi = getResources().getDisplayMetrics().density;
            AlertDialog dialog = (new AlertDialog.Builder(this))
                    .setTitle("Confirmation")
                    .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            goBack();
                            dialog.dismiss();
                        }
                    })
                    .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create();

            dialog.setView(input, (int) (19 * dpi), (int) (5 * dpi), (int) (14 * dpi), (int) (5 * dpi));

            dialog.show();
            try{
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorPrimary));
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.colorPrimary));
            }
            catch (Exception e){

            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        */
    }

    /*
    *
    *  the on click handler for edit profile button
    *
     */
    public void onEditButtonClick(View view) {
        if (!theEditProfileViewEnabled) {
            theEditProfileButton.setImageResource(R.drawable.ic_done_white);
            theEditProfileViewEnabled = true;
            theFirstName.setEnabled(true);
            theLastName.setEnabled(true);
            theEmail.setEnabled(true);
            theCancelButton.setVisibility(View.VISIBLE);
            theFirstName.setHint("Enter your first name");
            theLastName.setHint("Enter your last name");
            theEmail.setHint("Enter your email");
        } else {

            /*to show update confirmation box*/
            showConfirmationBox(view);

        }
    }
    public void saveProfile(View view){
        isFromCancel = false;
        if (theFirstName.getError() == null && theLastName.getError() == null && theEmail.getError() == null) {
            if (theLastName.length() >= 1 && theEmail.length() != 0) {
                new UpdateUserOperation().execute();
            } else {
                Toast.makeText(this, "Please enter required fields", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter valid data", Toast.LENGTH_SHORT).show();
        }
    }

    public void showConfirmationBox(View view){
        theDialogBoxView = view;

        LayoutInflater myLayoutInflater = this.getLayoutInflater();
        View myDeleteDialogView = myLayoutInflater.inflate(R.layout.layout_delete_dialog, null);
        theUpdateConfirmationDialog = new AlertDialog.Builder(this, R.style.Mytheme).create();
        theUpdateConfirmationDialog.setView(myDeleteDialogView);
        theUpdateConfirmationDialog.setCancelable(false);
        theUpdateConfirmationDialog.setCanceledOnTouchOutside(false);
        Button myPositiveButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_yes);
        Button myNegativeButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_cancel_delete);

        myPositiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveProfile(theDialogBoxView);
                theUpdateConfirmationDialog.dismiss();
            }
        });
        myNegativeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                theUpdateConfirmationDialog.dismiss();
            }
        });

        theUpdateConfirmationDialog.setMessage("Are you sure you want to save changes?");
        theUpdateConfirmationDialog.show();
        /*
        try {
            final TextView input = new TextView(this);
            input.setText("Apply Changes?");
            input.setPadding(20,0,0,0);

            float dpi = getResources().getDisplayMetrics().density;
            AlertDialog dialog = (new AlertDialog.Builder(this))
                    .setTitle("Confirmation")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            saveProfile(theDialogBoxView);
                            dialog.dismiss();
                            //finish();
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            //finish();
                        }
                    })
                    .create();

            dialog.setView(input, (int) (19 * dpi), (int) (5 * dpi), (int) (14 * dpi), (int) (5 * dpi));

            dialog.show();
            try{
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorPrimary));
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.colorPrimary));
            }
            catch (Exception e){

            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        */
    }

    public void onProfileCancelClick(View view) {

        /*to show cancel dialod box only if user has clicked edit*/
        if(isFromCancel){
            showCancelConfirmationBox();
        }
        else{
            cancelProfile();
        }
        isFromCancel = true;
    }

    public void cancelProfile(){
        theEditProfileViewEnabled = false;
        //set text in fields
        theFirstName.setText(theUserFirstName);
        theFirstName.setEnabled(false);
        theLastName.setText(theUserLastName);
        theLastName.setEnabled(false);
        theEmail.setText(theUserEmail);
        theEmail.setEnabled(false);
        //set edit profile button
        theEditProfileButton.setImageResource(R.drawable.ic_mode_edit_white);
        theCancelButton.setVisibility(View.GONE);
    }

    public void showCancelConfirmationBox(){

        LayoutInflater myLayoutInflater = this.getLayoutInflater();
        View myDeleteDialogView = myLayoutInflater.inflate(R.layout.layout_delete_dialog, null);
        theCancelConfirmationDialog = new AlertDialog.Builder(this, R.style.Mytheme).create();
        theCancelConfirmationDialog.setView(myDeleteDialogView);
        theCancelConfirmationDialog.setCancelable(false);
        theCancelConfirmationDialog.setCanceledOnTouchOutside(false);
        Button myPositiveButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_yes);
        Button myNegativeButton = (Button) myDeleteDialogView.findViewById(R.id.dialog_btn_cancel_delete);

        myPositiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelProfile();
                theCancelConfirmationDialog.dismiss();
            }
        });
        myNegativeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                theCancelConfirmationDialog.dismiss();
            }
        });

        theCancelConfirmationDialog.setMessage("Are you sure you want to discard changes?");
        theCancelConfirmationDialog.show();

        /*
        try {
            final TextView input = new TextView(this);
            input.setText("Discard Changes?");
            input.setPadding(20,0,0,0);

            float dpi = getResources().getDisplayMetrics().density;
            AlertDialog dialog = (new AlertDialog.Builder(this))
                    .setTitle("Confirmation")
                    .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            cancelProfile();
                            dialog.dismiss();
                        }
                    })
                    .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create();

            dialog.setView(input, (int) (19 * dpi), (int) (5 * dpi), (int) (14 * dpi), (int) (5 * dpi));

            dialog.show();
            try{
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.colorPrimary));
                dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.colorPrimary));
            }
            catch (Exception e){

            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        */
    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("UserProfile Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }

    /***************************************************************
     * PRIVATE - CLASS
     ****************************************************************/
    private class GetUserOperation extends AsyncTask {
        ProgressDialog myGetUserProgressDialog = new ProgressDialog(UserProfileActivity.this, R.style.Mytheme);
        String myUsername;

        @Override
        protected void onPreExecute() {
            UserDTO myUser = getUserDetail();
            myUsername = myUser.getTheUserName();
            myGetUserProgressDialog.setMessage("Connecting with the backend service.");
            myGetUserProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            myGetUserProgressDialog.setIndeterminate(true);
            myGetUserProgressDialog.setCancelable(false);
            myGetUserProgressDialog.show();
        }

        @Override
        protected Object doInBackground(Object[] params) {
            ClientManagement myCMApi = new ClientManagement();
            JSONObject myGetUserJSONResponse = new JSONObject();
            try {
                Context aContext = UserProfileActivity.this;
                myGetUserJSONResponse = myCMApi.sendGetUserRequest(WeAlertURLs.GET_USER_URL, myUsername,aContext);


            } catch (Exception e) {
                WeAlertLogger myLogger = new WeAlertLogger();
                myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to connect to backend Service. Please try again or contact your administrator.");
                myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                myGetUserJSONResponse = null;
            }
            System.out.println(myGetUserJSONResponse.toString());
            return myGetUserJSONResponse;
        }

        @Override
        protected void onPostExecute(Object aResultObject) {
            myGetUserProgressDialog.dismiss();
            try {
                JSONObject myResponse = (JSONObject) aResultObject;
                String myGetUserResponse = myResponse.getJSONObject("GetUserResponse").getJSONObject("Result").getString("ResponseCode");
                if (myGetUserResponse.equals("CM-N-0000")) {
                    JSONObject myJSONUser = myResponse.getJSONObject("GetUserResponse").getJSONObject("User");
                    JSONObject myUserEmail = (JSONObject) myJSONUser.getJSONArray("ContactDetail").get(1);
                    //make the user dto from json response payload
                    String myUsername = myJSONUser.getString("UserName");
                    theUserFirstName = myJSONUser.getJSONObject("PersonalDetail").getString("FirstName");
                    theUserLastName = myJSONUser.getJSONObject("PersonalDetail").getString("LastName");
                    theUserEmail = myUserEmail.getString("ChannelCode");
                    //set text in fields
                    theUsername.setText(myUsername);
                    theFirstName.setText(theUserFirstName);
                    theLastName.setText(theUserLastName);
                    theEmail.setText(theUserEmail);

                    String[] myUsernameSplittedArray = myUsername.split("@");
                    theOrganizationDomain = myUsernameSplittedArray[1];
                    theUserNameWithoutDomain = myUsernameSplittedArray[0];
                } else {
                    onBackPressed();
                    Toast.makeText(UserProfileActivity.this, "Unable to connect to backend Service. Please try again or contact your administrator.", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                onBackPressed();
                Toast.makeText(UserProfileActivity.this, "Unable to connect to backend Service. Please try again or contact your administrator.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /***************************************************************
     * PRIVATE - CLASS
     ****************************************************************/
    private class UpdateUserOperation extends AsyncTask {
        ProgressDialog myGetUserProgressDialog = new ProgressDialog(UserProfileActivity.this, R.style.Mytheme);
        String myUserId;
        String myOrganizationId;
        String myUserFirstName;
        String myUserLastName;
        String myOrganizationDomain;
        String myEmail;
        String myUserName;

        @Override
        protected void onPreExecute() {
            UserDTO myUser = getUserDetail();
            myUserId = myUser.getTheUserId();
            myOrganizationId = myUser.getTheOrganizationId();
            myOrganizationDomain = theOrganizationDomain.toString();
            myUserFirstName = theFirstName.getText().toString();
            myUserLastName = theLastName.getText().toString();
            myEmail = theEmail.getText().toString();
            myUserName = theUserNameWithoutDomain;
            myGetUserProgressDialog.setMessage("Connecting with the backend service.");
            myGetUserProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            myGetUserProgressDialog.setIndeterminate(true);
            myGetUserProgressDialog.setCancelable(false);
            myGetUserProgressDialog.show();
        }

        @Override
        protected Object doInBackground(Object[] params) {
            ClientManagement myCMApi = new ClientManagement();
            boolean myUpdateUserJSONResponse = false;
            try {
                Context aContext = UserProfileActivity.this;
                myUpdateUserJSONResponse = myCMApi.sendUpdateUserRequest(WeAlertURLs.UPDATE_USER_URL, myUserId, myUserName,myUserFirstName, myUserLastName, myEmail, myOrganizationId, theOrganizationDomain ,aContext);
            } catch (Exception e) {
                WeAlertLogger myLogger = new WeAlertLogger();
                myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to update profile. Please try again or contact your administrator.");
                myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
            }
            return myUpdateUserJSONResponse;
        }

        @Override
        protected void onPostExecute(Object aResultObject) {
            myGetUserProgressDialog.dismiss();
            try {
                boolean myResponse = (boolean) aResultObject;
                if (myResponse) {
                    theUserFirstName = myUserFirstName;
                    theUserLastName = myUserLastName;
                    theUserEmail = myEmail;
                    onBackPressed();
                    Toast.makeText(UserProfileActivity.this, "Profile updated successfully.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(UserProfileActivity.this, "Unable to update profile. Please try again or contact your administrator.", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(UserProfileActivity.this, "Unable to update profile. Please try again or contact your administrator.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
