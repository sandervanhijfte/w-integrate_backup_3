package nl.weintegrate.wealert.app.ui;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Custom adapter for alert items to use in alert list
 *		    2. Setting the layout and functionality for each alert item
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 added addMoreItems function
 *
 *
 */
/* Android Imports  */
import android.app.Activity;
import android.content.Context;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
/* Swipe Layout Library Imports  */
import com.daimajia.swipe.SwipeLayout;
import com.daimajia.swipe.adapters.BaseSwipeAdapter;
/* Java Imports  */
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* W-Integrate Packages  */
import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.dto.AlertDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.IAlertDAO;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import static android.view.View.GONE;
import static android.view.View.OnClickListener;
import static android.view.View.VISIBLE;
public class AlertListAdapter extends BaseSwipeAdapter {
    /***************************************************************
     VARIABLES
     ****************************************************************/
    private final String CLASS_NAME= "AlertListAdapter";
    private ArrayList<AlertDTO> theAlertList;
    private Context theCurrentContext;
    private boolean theCheckboxVisibility, theSelectionForAllCheckboxes;
    ArrayList<String> theSelectedItemsList = new ArrayList<String>();
    ArrayList<Integer> theUncheckedItemPositionList = new ArrayList<Integer>();
    ArrayList<Integer> theCheckedItemPositionList = new ArrayList<Integer>();
    /*
   * Usage:
   *       Constructor method
   * Params:
   *       aCurrentContext: the current context of application
   *       anAlertList: the array list having all the alerts
   *       anAlertCheckboxVisibility: a boolean variable to make the checkboxes visible when the user enters delete view
   * */
    public AlertListAdapter(Context aCurrentContext, ArrayList<AlertDTO> anAlertList, boolean anAlertCheckboxVisibility)
    {
        this.theCurrentContext = aCurrentContext;
        this.theAlertList = anAlertList;
        this.theCheckboxVisibility = anAlertCheckboxVisibility;
        updateSelectedAlertCount(theSelectedItemsList.size());
    }
    /***************************************************************
     PUBLIC - METHODS
     ****************************************************************/
    /*
   * Usage:
   *       To select all the currently loaded alerts.
   *       Adds the loaded alerts into theSelectedItemsList array list
   * Params:
   *       selectAllCheckboxes : a boolean variable to select and unselect the alerts
   * */
    public void selectAllLoadedAlerts(boolean selectAllCheckboxes)
    {
        theSelectionForAllCheckboxes = selectAllCheckboxes;
        if(selectAllCheckboxes) {
            theCheckedItemPositionList.clear();
            theUncheckedItemPositionList.clear();
            theSelectedItemsList.clear();
            for(int i=0 ; i<getCount() ; i++)
            {
                theSelectedItemsList.add(theAlertList.get(i).getTheAlertId());
                updateSelectedAlertCount(theSelectedItemsList.size());
            }
        }
        else {
            theCheckedItemPositionList.clear();
            theSelectedItemsList.clear();
            updateSelectedAlertCount(theSelectedItemsList.size());
        }
        notifyDataSetChanged();
    }
    /*
   * Usage:
   *       To update the selected alert count visible to the user on the alert list page when in the delete view
   * Params:
   *       aNumberOfSelectedAlerts : the number of alerts selected at the moment
   * */
    public void updateSelectedAlertCount(int aNumberOfSelectedAlerts)
    {
        TextView mySelectedAlertCountTextView = (TextView) ((Activity)theCurrentContext).findViewById(R.id.textView_selectedAlertCount);
        mySelectedAlertCountTextView.setText("Selected:"+Integer.toString(aNumberOfSelectedAlerts));
    }
    /*
   * Usage:
   *       To update the unread/read status of an alert
   * Params:
   *       anAlertId : the id of the alert whose status needs to be updated
   * */
    public void updateAlertStatus(String anAlertId)
    {
        for(int i=0 ; i<getCount() ; i++)
        {
            AlertDTO myAlertToUpdate = theAlertList.get(i);
            if(myAlertToUpdate.getTheAlertId().equals(anAlertId)) {
                myAlertToUpdate.setTheUnreadStatus(false);
                theAlertList.set(i, myAlertToUpdate);
                notifyDataSetChanged();
            }
        }
    }
    /*
   * Usage:
   *       To add a new alert at the top of list
   *       Used in case of auto refresh when the user is in the alert list activity and a new alert comes in
   * Params:
   *       anAlertDTO: the object containing all the details of new alert
   * */
    public void addNewAlerts(AlertDTO anAlertDTO)
    {
            theAlertList.add(0, anAlertDTO);
            notifyDataSetChanged();
    }
    /*
   * Usage:
   *       To add more items in the already loaded alert list
   *       Used when the user scrolls down and loads new alerts
   * Params:
   *       anAlertDTOList: the array list of new loaded alerts
   * */
    public void addMoreItems(ArrayList<AlertDTO> anAlertDTOList) {
        for (int i = 0; i <= anAlertDTOList.size()-1; i++) {
            theAlertList.add(anAlertDTOList.get(i));
            if(theSelectionForAllCheckboxes) {
                theSelectedItemsList.add(anAlertDTOList.get(i).getTheAlertId());
                updateSelectedAlertCount(theSelectedItemsList.size());
            }
        }
        notifyDataSetChanged();
    }
    /*
   * Usage:
   *       Returns all the alerts in an array list which are selected by the user while he is in delete view
   * */
    public ArrayList<String> getTheSelectedItemsList() {
        return theSelectedItemsList;
    }
    @Override
    public int getCount() {
        return theAlertList.size();
    }
    @Override
    public Object getItem(int position) {
        return theAlertList.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    /*
   * Usage:
   *       To set the layout for swipe to delete functionality
   *
   * */
    @Override
    public int getSwipeLayoutResourceId(int position) {
        return R.id.swipeLayout;
    }
    /*
   * Usage:
   *       Generates the view of an item
   *       Should be only used for generation of view, everything else should be done in the fillValues method
   *
   * */
    @Override
    public View generateView(int position, ViewGroup parent) {
        return LayoutInflater.from(theCurrentContext).inflate(R.layout.listview_each_item, null);
    }
    /*
   * Usage:
   *       Used for getting the view for each item of list view
   *       Used for the same purpose as getView in Base adapter
   *
   * */
    @Override
    public void fillValues(final int position, View convertView) {
        String myAlertType;
        String myAlertMessage = null;
        String myTimestamp;
        String mySeverity;
        String myComponent;
        final String myAlertID;
        boolean myAlertUnreadStatus;
        AlertDTO myAlertDTO;
        LinearLayout myAlertItem;
        LinearLayout myLayoutSeverity;
        final TextView myAlertIdTextView;
        TextView myAlertTextView;
        TextView myAlertTimestampView;
        ImageButton myDeleteAlertButton;
        final CheckBox myAlertSelectionCheckbox;
        String myAlertDate;
        String myAlertTime;
        final SwipeLayout swipeLayout;
        AlertDecryption myAlert= new AlertDecryption();
        //to get element at current position
        myAlertDTO = theAlertList.get(position);
        myAlertID = myAlertDTO.getTheAlertId();
        swipeLayout = (SwipeLayout) convertView.findViewById(R.id.swipeLayout);
        //setting checkbox for alert selection
        myAlertSelectionCheckbox = (CheckBox) convertView.findViewById(R.id.checkBox_alertItem);
        //when the check boxes should be visible and user has not selected all alerts
        if(theCheckboxVisibility && !theSelectionForAllCheckboxes)
        {
            swipeLayout.setEnabled(false);
            myAlertSelectionCheckbox.setVisibility(VISIBLE);
            myAlertSelectionCheckbox.setClickable(true);
            myAlertSelectionCheckbox.isFocusable();
            if(theCheckedItemPositionList.size()!=0)
            {
                if(theCheckedItemPositionList.contains(position))
                {
                    myAlertSelectionCheckbox.setChecked(true);
                }
                else
                {
                    myAlertSelectionCheckbox.setChecked(false);
                }
            }
            else
            {
                myAlertSelectionCheckbox.setChecked(false);
            }
        }
        //when the check boxes should be visible and user wants to select all alerts
        else if(theSelectionForAllCheckboxes && theCheckboxVisibility)
        {
            swipeLayout.setEnabled(false);
            myAlertSelectionCheckbox.setVisibility(VISIBLE);
            myAlertSelectionCheckbox.setClickable(true);
            myAlertSelectionCheckbox.isFocusable();
            if(theUncheckedItemPositionList.size()!=0)
            {
                if(theUncheckedItemPositionList.contains(position))
                {
                    myAlertSelectionCheckbox.setChecked(false);
                }
                else
                {
                    myAlertSelectionCheckbox.setChecked(true);
                }
            }
            else {
                myAlertSelectionCheckbox.setChecked(true);
            }
        }
        else
        {
            swipeLayout.setEnabled(true);
            myAlertSelectionCheckbox.setVisibility(GONE);
            myAlertSelectionCheckbox.setClickable(false);
        }
        //setting color for the unread/read alerts
        myAlertUnreadStatus = myAlertDTO.getTheUnreadStatus();
        myAlertItem = (LinearLayout) convertView.findViewById(R.id.content_alert_item);
        if(myAlertUnreadStatus)
        {
            myAlertItem.setBackgroundColor( theCurrentContext.getResources().getColor(R.color.colorWhite));
        }
        else if(!myAlertUnreadStatus)
        {
            myAlertItem.setBackgroundColor( theCurrentContext.getResources().getColor(R.color.colorLightGrey));
        }
        //setting the image for severity
        if(myAlertDTO.getTheSeverity()!=null) {
            mySeverity = myAlertDTO.getTheSeverity();
            myLayoutSeverity = (LinearLayout) convertView.findViewById(R.id.linearLayout_severity);
            if (mySeverity.contains("Low")) {
                myLayoutSeverity.setBackgroundColor(theCurrentContext.getResources().getColor(R.color.colorGreen));
            } else if (mySeverity.contains("High")) {
                myLayoutSeverity.setBackgroundColor(theCurrentContext.getResources().getColor(R.color.colorRed));
            } else {
                myLayoutSeverity.setBackgroundColor(theCurrentContext.getResources().getColor(R.color.colorOrange));
            }
        }
        //setting alert detail which will appear in the list
        //assigning alert detail values
        myAlertIdTextView = (TextView) convertView.findViewById(R.id.textView_alertId);
        myAlertIdTextView.setText(myAlertID);
        if(myAlertDTO.getTheAlertTitle()!=null && myAlertDTO.getTheAlertTitle()!=null) {
            myAlertType = myAlertDTO.getTheAlertType();
            try {
                myAlertMessage = myAlert.decryptAlertMessage(myAlertDTO.getTheAlertMessage(),theCurrentContext);
            } catch (Exception e) {
                e.printStackTrace();
            }
            myComponent = myAlertDTO.getTheComponentName();
            myAlertTextView = (TextView) convertView.findViewById(R.id.textView_alert);
            myAlertTextView.setText(convertToHTML("<b>" + myComponent + "</b>"));
            myAlertTextView = (TextView) convertView.findViewById(R.id.textView_alertDetail);
            if(myAlertMessage.length()<31) {
                myAlertTextView.setText(convertToHTML("<i>" + myAlertType.toUpperCase() + ":</i> " + myAlertMessage + " ..."));
            }
            else {
                myAlertTextView.setText(convertToHTML("<i>" + myAlertType.toUpperCase() + ":</i> " + myAlertMessage.substring(0, 30) + " ..."));
            }
        }
        if(myAlertDTO.getTheTimestamp()!=null) {
            myTimestamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss:SSS").format(myAlertDTO.getTheTimestamp());
            myAlertTimestampView = (TextView) convertView.findViewById(R.id.textView_timestamp);
            String[] myTempDateTime = myTimestamp.split("\\s");
            myAlertDate = myTempDateTime[0];
            myAlertTime = myTempDateTime[1];
            String [] myAlertTimeA = myAlertTime.split(":");
            String myAlertHour = myAlertTimeA[0];
            String myAlertMin = myAlertTimeA[1];
            String myAlertSec = myAlertTimeA[2];
            SimpleDateFormat myTimeFormatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss:SSS");
            String myCurrentTimestamp = myTimeFormatter.format(System.currentTimeMillis());
            String[] myCurrentDateTime = myCurrentTimestamp.split("\\s");
            String myCurrentDate = myCurrentDateTime[0];
            String myCurrentTime = myCurrentDateTime[1];
            String [] myCurrentTimeA = myCurrentTime.split(":");
            String myCurrentHour = myCurrentTimeA[0];
            String myCurrentMin = myCurrentTimeA[1];
            String myCurrentSec = myCurrentTimeA[2];
            if (myAlertDate.equals(myCurrentDate)) {
                if(Integer.parseInt(myCurrentHour) > Integer.parseInt(myAlertHour)) {
                    myAlertTimestampView.setText(Integer.parseInt(myCurrentHour) - Integer.parseInt(myAlertHour) + " hr ago");
                } else if(Integer.parseInt(myCurrentMin) > Integer.parseInt(myAlertMin)) {
                    myAlertTimestampView.setText(Integer.parseInt(myCurrentMin) - Integer.parseInt(myAlertMin) + " min ago");
                } else {
                    myAlertTimestampView.setText(Integer.parseInt(myCurrentSec) - Integer.parseInt(myAlertSec) + " sec ago");
                }
                //myAlertTimestampView.setText(myAlertTime);
            }
            else if(myAlertDate.substring(0,4).equals(myCurrentDate.substring(0,4)))
            {
                myAlertTimestampView.setText(myAlertDate.substring(5,10));
            }
            else
            {
                myAlertTimestampView.setText(myAlertDate);
            }
        }
        final View finalView = convertView;
        final int finalPosition = position;
        //setting swipe to delete options
        Button myDeleteButton = (Button) convertView.findViewById(R.id.button_delete);
        Button myCancelButton = (Button) convertView.findViewById(R.id.button_cancel);
        //on click handler for the delete button which appears when swiping any item to left
        myDeleteButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView myAlertId = (TextView) finalView.findViewById(R.id.textView_alertId);
                deleteAlertFromDatabase(myAlertId.getText().toString());
                theAlertList.remove(finalPosition);
                notifyDataSetChanged();
                swipeLayout.close();
            }
        });
        //on click handler for the cancel button which appears when swiping any item to left
        myCancelButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                swipeLayout.close();
            }
        });
        //on click listener for the checkbox of each item to get the selected alerts
        myAlertSelectionCheckbox.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                String myAlertId = myAlertIdTextView.getText().toString();
                if(myAlertSelectionCheckbox.isChecked())
                {
                    theSelectedItemsList.add(myAlertId);
                    updateSelectedAlertCount(theSelectedItemsList.size());
                    theCheckedItemPositionList.add(finalPosition);
                }
                else
                {
                    theSelectedItemsList.remove(myAlertId);
                    updateSelectedAlertCount(theSelectedItemsList.size());
                    theUncheckedItemPositionList.add(finalPosition);
                }
            }
        });
    }
    /***************************************************************
     PRIVATE - METHODS
     ****************************************************************/
    /*
   * Usage:
   *       To delete an alert from the database
   * Params:
   *       anAlertId : the alert id of the alert to delete
   * */
    private void deleteAlertFromDatabase(String anAlertId)
    {
        try {
            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(theCurrentContext);
            IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
            mySqliteAlertDao.deleteAlert(anAlertId);
        }
        catch (WeAlertException e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,e);
            Toast.makeText(theCurrentContext,"Unable to delete the alert. Please try again.",Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logStackTrace(Thread.currentThread().getId(),CLASS_NAME,e);
            Toast.makeText(theCurrentContext,"Unable to delete the alert. Please try again.",Toast.LENGTH_LONG).show();
        }
    }
    /*
  * Usage:
  *       To convert
  * Params:
  *       anHTMLCode : the string html code that has to be converted.
  * */
    @SuppressWarnings("deprecation")
    private Spanned convertToHTML(String anHTMLCode)
    {
        Spanned myHTMLCode;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            myHTMLCode = Html.fromHtml(anHTMLCode,Html.FROM_HTML_MODE_LEGACY);
        } else {
            myHTMLCode = Html.fromHtml(anHTMLCode);
        }
        return myHTMLCode;
    }
}