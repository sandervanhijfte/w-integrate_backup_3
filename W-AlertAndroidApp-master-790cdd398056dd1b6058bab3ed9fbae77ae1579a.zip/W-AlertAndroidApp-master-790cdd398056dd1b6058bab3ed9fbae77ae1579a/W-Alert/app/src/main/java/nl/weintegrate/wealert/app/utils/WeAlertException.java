package nl.weintegrate.wealert.app.utils;

public class WeAlertException extends Exception {
	
	private String theExceptionMessage;
	
	public WeAlertException(String anExceptionMessage) {
		theExceptionMessage = anExceptionMessage;
	}

	@Override
	public String getMessage() {
		
		return theExceptionMessage;
	}
	
	
	

}
