package nl.weintegrate.wealert.app.persistence;

/*
*	Author: Maham Imtiaz Hassan
*	Usage:  This class is responsible for deleting older alerts from database after a set interval
*	Known Issues:
*
*
*	Version History:
*
*	01.001 (Initial Implementation)
*   01.002 Refactored the name of the class
*/


/* JAVA Packages  */
import java.util.Timer;
import java.util.TimerTask;

/* Android Packages  */
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

/* W-Integrate Packages  */
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/* Class Declarations start*/

public class AlertRecycleService extends Service {

    /***************************************************************
     VARIABLES
    ****************************************************************/

    private static final String CLASS_NAME = "AlertRecycleService";
    private Timer theTimer = null;
    WeAlertLogger theWeAlertLogger = new WeAlertLogger();

    // run on another Thread to avoid crash
    private Handler theHandler = new Handler();

    /***************************************************************
     PUBLIC - METHOD
    ****************************************************************/

    /*
    *
    * @Usage:
    *      1. Default required method, TODO: Find out what it does
    * @params:
    *      1. anIntent
    *
    */
    @Nullable
    @Override
    public IBinder onBind(Intent anIntent) {
        return null;
    }

    /*
    *
    * @Usage:
    *      1. Start the timer if it is not already started.
    * @params:
    *
    *
    */
    @Override
    public void onCreate() {

        //cancel if already existed
        if(theTimer != null) {

            theTimer.cancel();
        } else {

            // recreate new
            theTimer = new Timer();
        }
        // schedule task
        theTimer.scheduleAtFixedRate(new CleanUpTheDatabaseTask(), 0, Constant.CLEANUP_INTERVAL);
    }

    /* Class Declarations start*/
    class CleanUpTheDatabaseTask extends TimerTask {

        /***************************************************************
         VARIABLES
         ****************************************************************/

        /***************************************************************
         PUBLIC - METHOD
         ****************************************************************/

        /*
        *
        * @Usage:
        *      1.   Checks the number of alerts in the database after a set interval and deletes any
        *           alerts from the database that are above the limit
        * @params:
        *
        *
        */
        @Override
        public void run() {

            // run on another thread
            theHandler.post(new Runnable() {

                @Override
                public void run() {

                    try {

                        DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
                        mySqliteDaoFactory.setContext(getApplicationContext());
                        IAlertDAO mySqliteAlertDao = mySqliteDaoFactory.getAlertDAO();
                        int myTotalNumberOfAlerts = mySqliteAlertDao.getTotalNumberOfAlerts();
                        theWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Total Alerts in database: " + myTotalNumberOfAlerts);

                        if(myTotalNumberOfAlerts > Constant.ALERT_LIMIT)
                        {

                            theWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Alert limit reached.");

                            try {

                                int myNumberOfAlertsToDelete = myTotalNumberOfAlerts-Constant.ALERT_LIMIT;
                                mySqliteAlertDao.cleanupDatabase(myNumberOfAlertsToDelete);
                                theWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Deleted extra alerts");
                            }
                            catch (WeAlertException e) {

                                theWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                                Toast.makeText(getApplicationContext(),"Unable to access mobile storage. Please try restarting the app or contact your administrator.",Toast.LENGTH_LONG).show();
                            }
                            catch(Exception e) {

                                theWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                                Toast.makeText(getApplicationContext(),"Unable to access mobile storage. Please try restarting the app or contact your administrator.",Toast.LENGTH_LONG).show();
                            }

                        }//else do nothing.
                    }
                    catch (WeAlertException e) {

                        theWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                        Toast.makeText(getApplicationContext(),"Unable to access mobile storage. Please try restarting the app or contact your administrator.",Toast.LENGTH_LONG).show();
                    }
                    catch (Exception e){

                        theWeAlertLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                        Toast.makeText(getApplicationContext(),"Unable to access mobile storage. Please try restarting the app or contact your administrator.",Toast.LENGTH_LONG).show();
                    }
                }

            });
        }
    }
}
