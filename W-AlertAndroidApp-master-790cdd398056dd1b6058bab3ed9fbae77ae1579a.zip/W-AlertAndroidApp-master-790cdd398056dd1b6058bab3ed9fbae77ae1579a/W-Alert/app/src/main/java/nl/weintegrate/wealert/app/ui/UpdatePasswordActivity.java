package nl.weintegrate.wealert.app.ui;
/*
 *	@Author: Ghilman Anjum
 *
 *  @Usage:
 *			1. Code behind the update password activity in forget password functionality.
 *
 *	@Known Issues:
 *
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *
 *
 */

/* Android Imports  */

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.regex.Pattern;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.api.IdentityAndAccessManagement;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import nl.weintegrate.wealert.app.utils.WeAlertURLs;

public class UpdatePasswordActivity extends AppCompatActivity {

    /***************************************************************
     VARIABLES
     ****************************************************************/
    private final String CLASS_NAME = "UpdatePasswordActivity";
    private EditText theConfirmationCodeField ;
    private EditText theNewPasswordField;
    private EditText theConfirmPasswordField;
    private Button theSubmitButton;
    private boolean isConfirmationCodeValidated = false;
    private boolean isNewPasswordValidated = false;
    private boolean isConfirmPasswordValidated = false;
    private String myConfirmationCode;
    private String myNewPassword;
    private String myConfirmPassword;
    private String myUsername;


    /***************************************************************
     PROTECTED - METHODS
     ****************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_password);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        theConfirmationCodeField = (EditText) findViewById(R.id.editText_confirmation_code);
        theNewPasswordField = (EditText) findViewById(R.id.editText_new_password);
        theConfirmPasswordField = (EditText) findViewById(R.id.editText_confirm_password);
        Intent myIntent = getIntent();
        Bundle myBundle =myIntent.getExtras();
        myUsername = myBundle.getString("myUsername");
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //to set back button in toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });
        LinearLayout myUpdatePasswordLayout = (LinearLayout) findViewById(R.id.content_update_password);
        myUpdatePasswordLayout.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View view, MotionEvent ev)
            {
                hideKeyboard(view);
                return false;
            }
        });
        theSubmitButton = (Button) findViewById(R.id.button_submit);
        theSubmitButton.setEnabled(false);
        theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
        theConfirmationCodeField.setHint("Confirmation Code");
        theNewPasswordField.setHint("New Password");
        theConfirmPasswordField.setHint("Confirm Password");
        theNewPasswordField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    theNewPasswordField.setHint(" New Password");
                    validateNewPassword();
                }
                else {
                    theNewPasswordField.setHint("");
                }
            }
        });
        theNewPasswordField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                theNewPasswordField.setHint(" New Password");
                validateNewPassword();
                validateConfirmPassword();
            }
        });
        theConfirmPasswordField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    theConfirmPasswordField.setHint(" Confirm Password");
                    validateConfirmPassword();
                }
                else
                {
                    theConfirmPasswordField.setHint("");
                }
            }
        });
        theConfirmPasswordField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                theConfirmPasswordField.setHint(" Confirm Password");
                validateConfirmPassword();
            }
        });
        theConfirmationCodeField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus)
                {
                    theConfirmationCodeField.setHint("Confirmation Code");
                    validateConfirmationCode();
                }
                else
                {
                    theConfirmationCodeField.setHint("");
                }
            }
        });
        theConfirmationCodeField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                theConfirmationCodeField.setHint("Confirmation Code");
                validateConfirmationCode();
            }
        });
    }

    /**
     * Hides virtual keyboard
     *
     */
    protected void hideKeyboard(View view) {

        InputMethodManager myInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        myInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    /***************************************************************
     PRIVATE - METHODS
     ****************************************************************/

    /*
     *
     *  to validate confirmation code
     *
     */
    private void validateConfirmationCode(){

        boolean isPatternMatched = Pattern.matches("^[a-z0-9]{8}[-][a-z0-9]{4}[-][a-z0-9]{4}[-][a-z0-9]{4}[-][a-z0-9]{12}$", theConfirmationCodeField.getText().toString());
        if(theConfirmationCodeField.length() == 0 || !isPatternMatched){
            theConfirmationCodeField.setError("Invalid Confirmation Code");
            isConfirmationCodeValidated = false;
            if(theSubmitButton.isEnabled()) {
                theSubmitButton.setEnabled(false);
                theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
            }
        }
        else if(isPatternMatched){
            theConfirmationCodeField.setError(null);
            isConfirmationCodeValidated = true;
            if(isConfirmPasswordValidated && isNewPasswordValidated) {
                theSubmitButton.setEnabled(true);
                theSubmitButton.setTextColor(getResources().getColor(R.color.colorWhite));
            }
        }
    }

    /*
     *
     *  to validate New Password
     *
     */
    private void validateNewPassword() {

        boolean isPatternMatched = Pattern.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%\\^&*():;<>?/+={}\\[\\]|]).{8,}$",theNewPasswordField.getText().toString());
        if(theNewPasswordField.length()==0)
        {
            theNewPasswordField.setError(null);
            isNewPasswordValidated = false;
            if(theSubmitButton.isEnabled()) {
                theSubmitButton.setEnabled(false);
                theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
            }
        }
        else{
            if( isPatternMatched && theNewPasswordField.length()>=8 ) {
                theNewPasswordField.setError(null);
                isNewPasswordValidated = true;
                if(isConfirmPasswordValidated) {
                    theSubmitButton.setEnabled(true);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorWhite));
                }
            }
            else {
                theNewPasswordField.setError("1. Passwords may contain letters (A-Z, a-z), numbers (0-9) and punctuation marks ( !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~). 2. The new password cannot be the same as the old password.");
                isNewPasswordValidated = false;
                if(theSubmitButton.isEnabled()) {
                    theSubmitButton.setEnabled(false);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
                }
            }
        }
    }

    /*
     *
     *  to validate confirm password
     *
     */
    private void validateConfirmPassword() {

        if(theConfirmPasswordField.length()==0) {
            theConfirmPasswordField.setError(null);
            isConfirmPasswordValidated = false;
            if(theSubmitButton.isEnabled()) {
                theSubmitButton.setEnabled(false);
                theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
            }
        }
        else {
            if(theConfirmPasswordField.getText().toString().equals(theNewPasswordField.getText().toString())) {
                theConfirmPasswordField.setError(null);
                isConfirmPasswordValidated = true;
                if (isNewPasswordValidated) {
                    theSubmitButton.setEnabled(true);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorWhite));
                }
            }
            else {
                theConfirmPasswordField.setError("Must be the same as the new password.");
                isConfirmPasswordValidated = false;
                if (theSubmitButton.isEnabled()) {
                    theSubmitButton.setEnabled(false);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
                }
            }
        }
    }

    /***************************************************************
     PUBLIC - METHODS
     ****************************************************************/
    @Override
    public void onBackPressed() {

        Intent myIntentToLoginActivity = new Intent(UpdatePasswordActivity.this, LoginActivity.class);
        myIntentToLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        myIntentToLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(myIntentToLoginActivity);
        this.finish();
    }

    public void onVerifyUsernameSubmitClick(View view) {

        myConfirmationCode = theConfirmationCodeField.getText().toString();
        myNewPassword = theNewPasswordField.getText().toString();
        System.out.println(isConfirmationCodeValidated+"      "+ isNewPasswordValidated + "         " + isConfirmPasswordValidated);
        if(isConfirmationCodeValidated && isConfirmPasswordValidated && isNewPasswordValidated)
        {
            new UpdatePasswordOperation().execute();
        }
    }

    public void onVerifyUsernameCancelClick(View view) {
        onBackPressed();
    }

    /***************************************************************
     PRIVATE- CLASS
     ****************************************************************/
    private class UpdatePasswordOperation extends AsyncTask {

        ProgressDialog myUpdatePasswordProgressDialog =new ProgressDialog(UpdatePasswordActivity.this, R.style.Mytheme);

        @Override
        protected void onPreExecute() {

            myUpdatePasswordProgressDialog.setMessage("Connecting with the backend service.");
            myUpdatePasswordProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            myUpdatePasswordProgressDialog.setIndeterminate(true);
            myUpdatePasswordProgressDialog.setCancelable(false);
            myUpdatePasswordProgressDialog.show();
        }

        @Override
        protected Object doInBackground(Object[] objects) {

            IdentityAndAccessManagement myIAMApi = new IdentityAndAccessManagement();
            Context myContext = UpdatePasswordActivity.this;
            String myResponse = "false";
            try {
                myResponse = myIAMApi.sendUpdatePasswordRequest(WeAlertURLs.UPDATE_PASSWORD_URL,myUsername, myConfirmationCode, myNewPassword, myContext);
            }
            catch (Exception e) {
                if (myResponse.equals("false")) {
                    WeAlertLogger myLogger = new WeAlertLogger();
                    myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to update password. Please try again or contact your administrator.");
                    myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                    myResponse = "false";
                }
                else if (myResponse.equals(null)) {
                    WeAlertLogger myLogger = new WeAlertLogger();
                    myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Backend service is not responding at the moment. Please try again or contact your system administrator.");
                    myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                    myResponse = null;
                }
            }
            return myResponse;
        }
        @Override
        protected void onPostExecute(Object o) {

            myUpdatePasswordProgressDialog.dismiss();
            String myResponse = o.toString();
            try {
                if (myResponse.equals("true")){
                    Intent myIntentToLoginActivity = new Intent(UpdatePasswordActivity.this, LoginActivity.class);
                    myIntentToLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    myIntentToLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(myIntentToLoginActivity);
                    finish();
                    Toast.makeText(UpdatePasswordActivity.this,"Password is updated successfully.",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(UpdatePasswordActivity.this,"Unable to update password. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e) {
                if(myResponse.equals("false")) {
                    Toast.makeText(UpdatePasswordActivity.this,"Unable to update password. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
                }
                else if(myResponse.equals(null)){
                    Toast.makeText(UpdatePasswordActivity.this,"Backend service is not responding at the moment. Please try again or contact your system administrator.",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

}
