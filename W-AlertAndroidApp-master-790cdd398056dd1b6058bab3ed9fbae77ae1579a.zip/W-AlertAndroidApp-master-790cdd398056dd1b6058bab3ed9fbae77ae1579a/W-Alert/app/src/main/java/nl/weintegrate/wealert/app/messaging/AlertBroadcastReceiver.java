package nl.weintegrate.wealert.app.messaging;

/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. Android system event receiver
 *
 *	@Known Issues:
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 Added Alert Recycle Service, WeAlertLogger and class level logs - MIH
 *
 *
 */

/* Android Packages  */

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import nl.weintegrate.wealert.app.persistence.AlertRecycleService;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/* W-Integrate Packages  */

/* Class Declarations start*/

public class AlertBroadcastReceiver extends BroadcastReceiver {

    /***************************************************************
     VARIABLES
     ****************************************************************/

    private static final String CLASS_NAME = "AlertBroadcastReceiver";

    /***************************************************************
                            PUBLIC - METHOD
     ****************************************************************/
    /*
    * Usage:
    *       Create connection with server to receive new alerts.
    * Params:
    *       aContext: the current context of application
    *       aIntent: Intent to perform action from activity
    * */
    @Override
    public void onReceive(Context aContext, Intent aIntent) {
        if (aIntent.getAction().equalsIgnoreCase(Intent.ACTION_BOOT_COMPLETED)) {
            Intent serviceIntent = new Intent(aContext, AlertService.class);
            aContext.startService(serviceIntent);

            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Alert service started on reboot.");

            Intent myAlertRecycleServiceIntent = new Intent(aContext, AlertRecycleService.class);
            aContext.startService(myAlertRecycleServiceIntent);
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Alert Recycle service started on reboot.");
        }
    }
}
