package nl.weintegrate.wealert.app.persistence.Sqlite;

/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. Implementing Sqlite database queries for user
 *
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *	        01.002 Added getUserCount, deleteUserPassword, insertUserPassword, deleteUserProfile
 *
 */


import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import nl.weintegrate.wealert.app.dto.UserDTO;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

public class SqliteUserDAO implements IUserDAO {
    private final String CLASS_NAME = "SqliteUserDAO";
	private final String DATABASE_TABLE = "T_USER";
	private SqliteDB theSqliteDB;

    public SqliteUserDAO(SqliteDB aSqliteDB){
        this.theSqliteDB = aSqliteDB;
    }

    /*
     *
     * @Usage:
     *      1. To save the user profile in the user table of database
     * @params:
     *      1. aUserDTO : the UserDTO which is saved to the database
     *
     */
    @Override
    public void insertUserProfile(UserDTO aUserDto) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        ContentValues myNewUserValues = null;
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();

            myNewUserValues = new ContentValues();

                if (aUserDto.getTheUserId() != null) {
                    myNewUserValues.put("C_USER_ID", aUserDto.getTheUserId());
                }
                if (aUserDto.getTheUserName() != null) {
                    myNewUserValues.put("C_USER_NAME", aUserDto.getTheUserName());
                }
                if (aUserDto.getTheUserPassword() != null) {
                    myNewUserValues.put("C_USER_PASSWORD", aUserDto.getTheUserPassword());
                }
                if (aUserDto.getTheUserStatus() != null) {
                    myNewUserValues.put("C_USER_STATUS", aUserDto.getTheUserStatus());
                }
                if (aUserDto.getTheUserFirstName() != null) {
                    myNewUserValues.put("C_USER_FIRST_NAME", aUserDto.getTheUserFirstName());
                }
                if (aUserDto.getTheUserLastName() != null) {
                    myNewUserValues.put("C_USER_LAST_NAME", aUserDto.getTheUserLastName());
                }
                if (aUserDto.getTheUserMobileNo() != null) {
                    myNewUserValues.put("C_USER_MOBILE_NO", aUserDto.getTheUserMobileNo());
                }
                if (aUserDto.getTheUserEmail() != null) {
                    myNewUserValues.put("C_USER_EMAIL", aUserDto.getTheUserEmail());
                }
                if (aUserDto.getTheUserRoleId() != null) {
                    myNewUserValues.put("C_USER_ROLE_ID", aUserDto.getTheUserRoleId());
                }
                if (aUserDto.getTheOrganizationId() != null) {
                    myNewUserValues.put("C_ORGANIZATION_ID", aUserDto.getTheOrganizationId());
                }
                if (aUserDto.getTheOrganizationName() != null) {
                    myNewUserValues.put("C_ORGANIZATION_NAME", aUserDto.getTheOrganizationName());
                }
                if (aUserDto.getTheOrganizationDomain() != null) {
                    myNewUserValues.put("C_ORGANIZATION_DOMAIN", aUserDto.getTheOrganizationDomain());
                }
                myWeAlertDB.insertOrThrow(DATABASE_TABLE, null, myNewUserValues);
        }

        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while adding the user profile because a user profile already exists in the database");
            throw myWeAlertException;
        }
        finally {
            myNewUserValues.clear();
            theSqliteDB.CloseDatabase();
        }
    }

    /*
    *
    *  to get the row count of user table
    *
     */
    public int getUserCount() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        int myRowCount = 0;
        try {

            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT COUNT(*) FROM T_USER", null);
            myCursor.moveToFirst();
            myRowCount = myCursor.getInt(0);


        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while counting rows in alert table of sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myRowCount;
    }
    /*
     *
     * @Usage:
     *      1. To get the user profile from the user table of database
     *
     */
    @Override
    public UserDTO getUserProfile() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        Cursor myCursor = null;
        UserDTO myUser = new UserDTO();
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myCursor = myWeAlertDB.rawQuery("SELECT * FROM T_USER",null);
            myCursor.moveToFirst();
            myUser.setTheUserId(myCursor.getString(0));
            myUser.setTheUserName(myCursor.getString(1));
            myUser.setTheUserPassword(myCursor.getString(2));
            myUser.setTheUserStatus(myCursor.getString(3));
            myUser.setTheUserFirstName(myCursor.getString(4));
            myUser.setTheUserLastName(myCursor.getString(5));
            myUser.setTheUserMobileNo(myCursor.getString(6));
            myUser.setTheUserEmail(myCursor.getString(7));
            myUser.setTheUserRoleId(myCursor.getString(8));
            myUser.setTheOrganizationId(myCursor.getString(9));
            myUser.setTheOrganizationName(myCursor.getString(10));
            myUser.setTheOrganizationDomain(myCursor.getString(11));
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while getting user profile from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myCursor.close();
            theSqliteDB.CloseDatabase();
        }
        return myUser;
    }

    @Override
    public void deleteUserPassword() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        ContentValues myUserPassword = null;
        try {
            UserDTO myUserProfile = getUserProfile();
            String myUsername = myUserProfile.getTheUserName();
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myUserPassword = new ContentValues();
            myUserPassword.put("C_USER_PASSWORD", "0");
            myWeAlertDB.update(DATABASE_TABLE, myUserPassword, "C_USER_NAME=?", new String[]{myUsername});
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while deleting user password from sqlite database");
            throw myWeAlertException;
        }
        finally {
            myUserPassword.clear();
            theSqliteDB.CloseDatabase();
        }
    }

    @Override
    public void insertUserPassword(String aUserPassword) throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        ContentValues myUserPassword = null;
        try {
            UserDTO myUserProfile = getUserProfile();
            String myUsername = myUserProfile.getTheUserName();
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myUserPassword = new ContentValues();
            myUserPassword.put("C_USER_PASSWORD", aUserPassword);
            myWeAlertDB.update(DATABASE_TABLE, myUserPassword, "C_USER_NAME=?", new String[]{myUsername});
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while inserting user password in sqlite database");
            throw myWeAlertException;
        }
        finally {
            myUserPassword.clear();
            theSqliteDB.CloseDatabase();
        }
    }

    @Override
    public void deleteUserProfile() throws WeAlertException {
        SQLiteDatabase myWeAlertDB;
        try {
            myWeAlertDB = theSqliteDB.OpenDatabase();
            myWeAlertDB.delete(DATABASE_TABLE,"1",null );
        }
        catch (Exception e) {

            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            WeAlertLogger myLogger = new WeAlertLogger();
            myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Exception occurred while deleting the user profile from sqlite database");
            throw myWeAlertException;

        } finally {
            theSqliteDB.CloseDatabase();
        }
    }
}
