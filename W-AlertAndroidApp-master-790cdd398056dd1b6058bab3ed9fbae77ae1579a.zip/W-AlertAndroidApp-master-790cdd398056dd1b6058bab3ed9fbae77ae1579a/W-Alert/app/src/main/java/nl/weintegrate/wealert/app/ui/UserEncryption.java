package nl.weintegrate.wealert.app.ui;
/*
 *	@Author: Waqas Ali Razzaq
 *
 */
import android.content.Context;

import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.engines.BlowfishEngine;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Base64;
import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;

/**
 * Created by WAQAS on 19/07/2017.
 */

public class UserEncryption {
    public void insertEncryptedUserPasswordToDatabase(Context context) throws WeAlertException {
        try {

            DAOFactory mySqliteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySqliteDaoFactory.setContext(context);

            IUserDAO myUserDao = mySqliteDaoFactory.getUserDAO();
            String password=encryptUserPassword(myUserDao.getUserProfile().getTheUserPassword(),getKey(context));
            myUserDao.insertUserPassword(password);
        }
        catch (WeAlertException myWeAlertException) {
            throw myWeAlertException;
        }
        catch (Exception e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            throw myWeAlertException;
        }
    }
    private static String encryptUserPassword(String value, String keyString) throws Exception {
        BlowfishEngine engine = new BlowfishEngine();
        PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(engine);
        KeyParameter key = new KeyParameter(keyString.getBytes());
        cipher.init(true, key);
        byte in[] = value.getBytes();
        byte out[] = new byte[cipher.getOutputSize(in.length)];
        int len1 = cipher.processBytes(in, 0, in.length, out, 0);
        try {
            cipher.doFinal(out, len1);
        } catch (CryptoException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),"",myWeAlertException.getMessage());
            throw new Exception(exception.getMessage());
        }
        String s = new String(Base64.encode(out));
        return s;
    }
    private static String getKey(Context aContext) {
        SubscriptionDTO mySubscription = null;
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
            mySubscription = mySubscriptionDao.getSubscriptionDetail();

        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),"",myWeAlertException.getMessage());
        }
        return mySubscription.getEncryptionKey();
    }
}
