/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. Alert background service to receive alerts from server
 *
 *	@Known Issues:
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *          01.002 Added exception handling for the MQTT call to make connection. - Omer Khalid (01-03-2018)
 *
 */
package nl.weintegrate.wealert.app.messaging;

/* Android Imports */

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.provider.Settings;
import android.widget.Toast;

/* WeIntegrate Imports */

import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.dto.UserDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.persistence.IUserDAO;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import nl.weintegrate.wealert.app.utils.Constant;



/* Class Declarations start*/
public class AlertService extends Service {

    /***************************************************************
     VARIABLES
     ****************************************************************/

    private AlertMqttSubscriber theSubscriber;
    private static final String CLASS_NAME = "AlertService";

    /***************************************************************
     PUBLIC - METHOD
     ****************************************************************/
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate() {
        theSubscriber = new AlertMqttSubscriber(this);
        super.onCreate();
    }
    @Override
    public void onDestroy(){
        theSubscriber.closeConnection();
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SubscriptionDTO mySubscription;
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(this);
            ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
            mySubscription = mySubscriptionDao.getSubscriptionDetail();
            //TODO : Write proper message
            if(mySubscription.getBrokerUrl() == null || mySubscription.getUserName() == null || mySubscription.getPassword() == null){
                Toast.makeText(this, "Unable to get Subscription. Please restart the W-Alert app.", Toast.LENGTH_SHORT).show();
            }else{
                theSubscriber.makeConnection(this,getDeviceId(),mySubscription.getBrokerUrl(),mySubscription.getUserName(),mySubscription.getPassword());
                Toast.makeText(this, "Connection is successfully established with the server.", Toast.LENGTH_SHORT).show();
            }
        } catch (WeAlertException exception) {
            Toast.makeText(this, "Unable to make connection with the server. Please restart the W-Alert app", Toast.LENGTH_SHORT).show();
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
        }
        return START_STICKY;
    }

    /***************************************************************
     PRIVATE - METHOD
     ****************************************************************/
        /*
    * Usage:
    *       Retrieve device Id of android mobile and concat username
    * Params:
    *       none
    * */
    private String getDeviceId() {
    UserDTO myUserProfile;
    DAOFactory mySQLLiteDaoFactory;
    String myDeviceId = null;
    try {
        mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
        mySQLLiteDaoFactory.setContext(this);
        IUserDAO myUserDao = mySQLLiteDaoFactory.getUserDAO();
        myUserProfile = myUserDao.getUserProfile();
        myDeviceId = Settings.Secure.getString(getApplicationContext().getContentResolver(),Settings.Secure.ANDROID_ID)+myUserProfile.getTheUserName();
    } catch (WeAlertException exception) {
        WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
        myWeAlertLogger.logMessage(Thread.currentThread().getId(),"AlertService",myWeAlertException.getMessage());
    }
    return myDeviceId;
}
}// End Of Class
