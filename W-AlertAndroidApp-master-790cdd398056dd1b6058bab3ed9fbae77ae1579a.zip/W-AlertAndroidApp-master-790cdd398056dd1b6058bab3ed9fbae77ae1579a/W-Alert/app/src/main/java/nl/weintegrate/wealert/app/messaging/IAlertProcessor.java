/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. interface for alert processor
 *
 *	@Known Issues:
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *
 *
 */
package nl.weintegrate.wealert.app.messaging;

/* Android imports */

import android.content.Context;

import org.json.JSONObject;

import nl.weintegrate.wealert.app.utils.WeAlertException;

/* WeIntegrate imports */

/* Interface Deceleration */
public interface IAlertProcessor {

    void processAlert(JSONObject aJsonObject,Context aContext) throws WeAlertException;
}
