package nl.weintegrate.wealert.app.ui;
/*
 *	@Author: Ghilman Anjum
 *
 *  @Usage:
 *			1. Code behind the update password activity in forget password functionality.
 *
 *	@Known Issues:
 *
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *
 *
 */

/* Android Imports  */
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.regex.Pattern;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.api.IdentityAndAccessManagement;
import nl.weintegrate.wealert.app.dto.UserDTO;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import nl.weintegrate.wealert.app.utils.WeAlertURLs;

public class VerifyUsernameActivity extends AppCompatActivity {
    /***************************************************************
     VARIABLES
     ****************************************************************/
    private final String CLASS_NAME = "VerifyUsernameActivity";
    private String myUsername;
    private EditText theUsernameField;
    private Button theSubmitButton;
    boolean isVerifyUsernameValidated = false;


    /***************************************************************
     PROTECTED - METHODS
     ****************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_username);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        theUsernameField = (EditText) findViewById(R.id.editText_username);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //to set back button in toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });
        LinearLayout myVerifyUsernameLayout = (LinearLayout) findViewById(R.id.content_verify_username);
        myVerifyUsernameLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                hideKeyboard(view);
                return false;
            }
        });
        theSubmitButton = (Button) findViewById(R.id.button_submit);
        theSubmitButton.setEnabled(false);
        theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
        theUsernameField.setHint("Username");
        theUsernameField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus)
            {
                if (!hasFocus)
                {
                    theUsernameField.setHint("Username");
                    validateUsername(theUsernameField.getText().toString());
                }
                else
                {
                    theUsernameField.setHint("");
                }
            }
        });
        theUsernameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                validateUsername(theUsernameField.getText().toString());
            }
        });

    }

    /**
     * Hides virtual keyboard
     *
     */
    protected void hideKeyboard(View view) {

        InputMethodManager myInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        myInputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    /***************************************************************
     PRIVATE - METHODS
     ****************************************************************/

    /*
     *
     *  to validate Username
     *
     */
    private void validateUsername(String aUsername) {

        boolean myValidation;
        if (!aUsername.equals("")) {
            myValidation = Patterns.EMAIL_ADDRESS.matcher(aUsername).matches();
            if(theUsernameField.length()<11)
            {

                theUsernameField.setError("Username must have at least 11 characters");
                isVerifyUsernameValidated = false;
                if(theSubmitButton.isEnabled()) {
                    theSubmitButton.setEnabled(false);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
                }
            }
            else if(!myValidation)
            {
                theUsernameField.setError("Invalid username");
                isVerifyUsernameValidated = false;
                if(theSubmitButton.isEnabled()) {
                    theSubmitButton.setEnabled(false);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorDarkGrey));
                }
            }
            else if(myValidation && theUsernameField.length()>10)
            {
                theUsernameField.setError(null);
                isVerifyUsernameValidated = true;
                if(!theSubmitButton.isEnabled()) {
                    theSubmitButton.setEnabled(true);
                    theSubmitButton.setTextColor(getResources().getColor(R.color.colorWhite));
                }
            }

        }
    }

    /***************************************************************
     PUBLIC - METHODS
     ****************************************************************/
    @Override
    public void onBackPressed() {

        Intent myIntentToLoginActivity = new Intent(VerifyUsernameActivity.this, LoginActivity.class);
        myIntentToLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        myIntentToLoginActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(myIntentToLoginActivity);
        this.finish();
    }
    public void onVerifyUsernameCancelClick(View view) {
        onBackPressed();
    }

    public void onVerifyUsernameSubmitClick(View view) {

        myUsername = theUsernameField.getText().toString();
        if(theUsernameField.getError() == null)
        {
            new VerifyUsernameOperation().execute();
        }
    }

    /***************************************************************
     PRIVATE- CLASS
     ****************************************************************/
    private class VerifyUsernameOperation extends AsyncTask{

        ProgressDialog myVerifyUsernameProgressDialog =new ProgressDialog(VerifyUsernameActivity.this, R.style.Mytheme);

        @Override
        protected void onPreExecute() {

            myVerifyUsernameProgressDialog.setMessage("Connecting with the backend service.");
            myVerifyUsernameProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            myVerifyUsernameProgressDialog.setIndeterminate(true);
            myVerifyUsernameProgressDialog.setCancelable(false);
            myVerifyUsernameProgressDialog.show();
        }


        @Override
        protected Object doInBackground(Object[] objects) {

            IdentityAndAccessManagement myIAMApi = new IdentityAndAccessManagement();
            Context myContext = VerifyUsernameActivity.this;
            String myResponse = "false";
            try {
                myResponse = myIAMApi.sendVerifyUsernameRequest(WeAlertURLs.VERIFY_USERNAME_URL,myUsername, myContext);
            }
            catch (Exception e) {
                if(myResponse.equals("false")) {
                    WeAlertLogger myLogger = new WeAlertLogger();
                    myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Unable to verify username. Please try again or contact your administrator.");
                    myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                    myResponse = "false";
                }
                else if(myResponse.equals(null)){
                    WeAlertLogger myLogger = new WeAlertLogger();
                    myLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Backend service is not responding at the moment. Please try again or contact your system administrator.");
                    myLogger.logStackTrace(Thread.currentThread().getId(), CLASS_NAME, e);
                    myResponse = null;
                }
            }
            return myResponse;
        }

        @Override
        protected void onPostExecute(Object o) {

            myVerifyUsernameProgressDialog.dismiss();
            String myResponse = o.toString();
            try {
                if (myResponse.equals("true")){
                    Intent myIntentToUpdatePasswordActivity = new Intent(VerifyUsernameActivity.this, UpdatePasswordActivity.class);
                    myIntentToUpdatePasswordActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    myIntentToUpdatePasswordActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    myIntentToUpdatePasswordActivity.putExtra("myUsername" , myUsername);
                    startActivity(myIntentToUpdatePasswordActivity);
                    finish();
                    Toast.makeText(VerifyUsernameActivity.this,"Username is verified successfully.",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(VerifyUsernameActivity.this,"Unable to verify username. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e) {
                if (myResponse.equals("false")) {
                    Toast.makeText(VerifyUsernameActivity.this,"Unable to verify username. Please try again or contact your administrator.",Toast.LENGTH_SHORT).show();
                }
                else if (myResponse.equals(null)){
                    Toast.makeText(VerifyUsernameActivity.this,"Backend service is not responding at the moment. Please try again or contact your system administrator.",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
