package nl.weintegrate.wealert.app.utils;

/*
 *	@Author: Maham Hassan
 *	
 *	@Usage:  This class contains all the constants used for the app. 
 *	
 *	@KnownIssues: 
 *
 *
 *	@VersionHistory: 
 *
 *					01.001 (Initial Implementation)
 */

public class Constant 
{

	public static final int CONNECTION_TIMEOUT = 30000;
    public static final int ALERT_LIST_PAGE_SIZE = 20;
	public static final String ALERT_TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String WE_ALERT_LOG = "weAlertLog.txt";
	public static final int KEEP_ALIVE_INTERVAL =120;
	public static final int HTTP_STATUS_CODE = 200;
	public static final String EVENT_SUBSCRIPTION_RESPONSE = "GetEventSubscriptionResponse";
	public static final String EVENT_SUBSCRIPTION = "EventSubscription";
	public static final String EVENT_SUBSCRIPTION_DETAIL = "SubscriptionDetail";
	public static final String BROKER_URL = "BrokerUrl";
	public static final String USER_NAME = "UserName";
	public static final String PASSWORD = "Password";
	public static final String TOPIC_NAME = "TopicName";
	public static final String SINGLE_SUBSCRIPTION = "SingleTopic";
	public static final String MULTIPLE_SUBSCRIPTION = "MultipleTopic";
	public static final long CLEANUP_INTERVAL = 30* 60 * 1000; // 30 minutes
	public static final int ALERT_LIMIT = 500; // 10 seconds
	public static final String DATABASE_RETRY = "Unable to connect with the database. Please restart the W-Alert app.";
	public static final String CONNECTION_ESTABLISHED_SERVER = "Connection is successfully established with the server.";
	public static final String SERVER_RETRY ="Unable to make connection with the server. Please restart the W-Alert app";
	public static final String SIGNOUT_DISCONECT_MESSAGE = "WARNING: \nAll alerts stored in the database will be deleted. You will not receive any new alerts. Any alerts generated during the disconnection period will be lost.";
    public static final String SERVER_DISCONNECT_RETRY = "Unable to disconnect with the server, please try again.";
    public static final String SIGNIN_WITH_SAME_USER_MESSAGE = "Please sign in with the user you used previously, use Sign Out and Disconnect to switch user.";
    public static boolean IS_FROM_SIGNOUT = false;
}