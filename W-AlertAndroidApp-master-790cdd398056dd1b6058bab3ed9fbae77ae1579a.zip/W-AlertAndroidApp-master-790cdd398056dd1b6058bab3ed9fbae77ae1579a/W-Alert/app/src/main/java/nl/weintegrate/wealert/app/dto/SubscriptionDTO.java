package nl.weintegrate.wealert.app.dto;




public class SubscriptionDTO {

    // attributes
    private String theSubscriptionId;
    private String theSubscriptionName;
    private String theUserName;
    private String thePassword;
    private String theBrokerUrl;
    private String theTopicName;
    private String theEncryptionKey;

    public String getSubscriptionId() {  return theSubscriptionId;   }
    public void setSubscriptionId(String theSubscriptionId) {    this.theSubscriptionId = theSubscriptionId; }
    public String getSubscriptionName() {  return theSubscriptionName;   }
    public void setSubscriptionName(String theSubscriptionName) {    this.theSubscriptionName = theSubscriptionName; }
    public String getUserName() {    return theUserName; }
    public void setUserName(String theUserName) {    this.theUserName = theUserName; }
    public String getPassword() {    return thePassword; }
    public void setPassword(String thePassword) {    this.thePassword = thePassword; }
    public String getBrokerUrl() {   return theBrokerUrl;    }
    public void setBrokerUrl(String theBrokerUrl) {  this.theBrokerUrl = theBrokerUrl;   }
    public String getTopicName() {   return theTopicName;    }
    public void setTopicName(String theTopicName) {  this.theTopicName= theTopicName;   }
    public String getEncryptionKey() {   return theEncryptionKey;    }
    public void setEncryptionKey(String theEncryptionKey) {  this.theEncryptionKey= theEncryptionKey;   }
}
