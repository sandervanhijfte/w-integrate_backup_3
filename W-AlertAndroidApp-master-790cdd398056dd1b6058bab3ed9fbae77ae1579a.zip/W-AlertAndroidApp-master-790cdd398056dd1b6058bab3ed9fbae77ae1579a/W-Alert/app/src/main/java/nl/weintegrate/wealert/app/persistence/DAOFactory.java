package nl.weintegrate.wealert.app.persistence;

import android.content.Context;

import nl.weintegrate.wealert.app.persistence.Sqlite.SqliteDAOFactory;
import nl.weintegrate.wealert.app.utils.WeAlertException;

// TODO: Review naming and commenting
// TODO: Add TestSqliteDaoFactory 

public abstract class DAOFactory {
	
	public static final int SQLITE = 1;
	public static final int SHARED_PREFERENCE = 2;
	public static final int XML = 3;
	
	// Dao Retrieval functions
	public abstract IAlertDAO getAlertDAO() throws WeAlertException;
	public abstract IUserDAO getUserDAO() throws WeAlertException;
	public abstract ISubscriptionDAO getSubscriptionDAO() throws WeAlertException;
	
	// Functions specific for connection handling of the persistent storage
	public abstract void createConnection(String aConnectionUri) throws WeAlertException;
	public abstract void destroyConnection() throws WeAlertException;
	public abstract void setContext(Context aCurrentContext) throws WeAlertException;
	
	public static DAOFactory getDAOFactory (int aFactoryType) throws WeAlertException {
		
		switch(aFactoryType) {
		
			case SQLITE:
				return new SqliteDAOFactory();
			case XML:
				return null;
			default:
				return null;
		}
		
	}
	
}
