package nl.weintegrate.wealert.app.persistence;

import java.util.ArrayList;

import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.utils.WeAlertException;

/**
 * Created by WAQAS on 14/01/2017.
 */

public interface ISubscriptionDAO {
    boolean insertSubscriptionDetail (SubscriptionDTO aSubscriptionDto) throws WeAlertException;
    SubscriptionDTO getSubscriptionDetail() throws WeAlertException;
    ArrayList<SubscriptionDTO> getSubscriptionList() throws WeAlertException;
    void deleteSubscriptionDetail() throws WeAlertException;
}
