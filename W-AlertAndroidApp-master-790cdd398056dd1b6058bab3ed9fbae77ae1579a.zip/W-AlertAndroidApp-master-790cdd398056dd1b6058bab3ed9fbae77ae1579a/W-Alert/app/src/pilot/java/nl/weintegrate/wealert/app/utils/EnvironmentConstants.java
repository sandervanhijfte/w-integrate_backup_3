package nl.weintegrate.wealert.app.utils;

public class EnvironmentConstants {
    public static String SUBSCRIPTION_TOKEN  =  "b23fe935-d506-3d3d-bfac-139309de4a29";
}
