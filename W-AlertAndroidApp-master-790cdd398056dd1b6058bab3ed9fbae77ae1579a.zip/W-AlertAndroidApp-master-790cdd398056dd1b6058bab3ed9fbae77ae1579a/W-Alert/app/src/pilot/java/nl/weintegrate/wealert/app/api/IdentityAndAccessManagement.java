package nl.weintegrate.wealert.app.api;
/*
 *	@Author: Maira Tul Islam
 *
 *  @Usage:
 *			1. To make the the identity and access management api requests
 *		    2. By design, Token is stored in shared preference.
 *  @Known Issues:
 *          1. ://TODO add change password operation
 *
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 (Adding HTTPS with token in all the end points) Sumayya Shahzad 23/05/2017
 *
 *
 */
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.UUID;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.TrustManagerFactory;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import nl.weintegrate.wealert.app.utils.WeAlertSSLContext;
public class IdentityAndAccessManagement{
    private final String CLASS_NAME = "IdentityAndAccessMangement";
    /*
     *
     * to make the register device json request payload
     *
     */
    private String makeRegisterDeviceJSONRequestPayload(String aDomain, String aUsernameWithoutDomain){
        String myRegisterDeviceRequest = "{\n" +
                "  \"RegisterDeviceRequest\": {\n" +
                "    \"Header\": {\n" +
                "      \"CMMHeader\": { \"CorrelationId\": \""+UUID.randomUUID().toString()+"\" }\n" +
                "    },\n" +
                "    \"ClientContext\": { \"UserName\": \"admin@"+aDomain+"\" },\n" +
                "    \"UserName\": \""+aUsernameWithoutDomain+"\"\n" +
                "  }\n" +
                "}";
        return  myRegisterDeviceRequest;
    }
    /*
     *
     * to make the user authentication json request payload
     *
     */
    private String makeUserAuthenticationJSONRequestPayload(String aUsername, String aUsernameWithoutDomain, String aPassword) {
        String myUserAuthenticationRequest = "{\"AuthenticateRequest\": {\n" +
                "   \"Header\": {\"CMMHeader\": {\"CorrelationId\": \""+UUID.randomUUID().toString()+"\"}},\n" +
                "   \"ClientContext\": {\"UserName\": \""+aUsername+"\"},\n" +
                "   \"UserName\": \""+aUsernameWithoutDomain+"\",\n" +
                "   \"UserPassword\": \""+aPassword+"\"\n" +
                "}}";
        return myUserAuthenticationRequest;
    }
    private String makeChangePasswordJSONRequestPayload(String aUsername,String aUsernameWithoutDomain, String anOldPassword, String aNewPassword)
    {
        String myChangePasswordRequest = "{\n" +
                "  \"ChangePasswordRequest\": {\n" +
                "    \"Header\": {\n" +
                "      \"CMMHeader\": { \"CorrelationId\": \""+ UUID.randomUUID().toString()+"\" }\n" +
                "    },\n" +
                "    \"ClientContext\": { \"UserName\": \""+aUsername +"\" },\n" +
                "    \"UserName\": \""+aUsernameWithoutDomain+"\",\n" +
                "    \"UserOldPassword\": \""+anOldPassword+"\",\n" +
                "    \"UserPassword\": \""+ aNewPassword+"\"\n" +
                "  }\n" +
                "}";
        return myChangePasswordRequest;
    }
    private String makeVerifyUsernameJSONRequestPayload (String aUsername) {
        String myVerifyUsernameRequest = "{\n" +
                "  \"VerifyUsernameRequest\": {\n" +
                "    \"Header\": {\n" +
                "      \"CMMHeader\": { \"CorrelationId\": \""+ UUID.randomUUID().toString()+"\" }\n" +
                "    },\n" +
                "    \"ClientContext\": { \"UserName\": \""+aUsername +"\" },\n" +
                "    \"UserName\": \""+aUsername+"\"\n" +
                "  }\n" +
                "}";
        return myVerifyUsernameRequest;
    }
    private String makeUpdatePasswordJSONRequestPayload (String aUsername, String aConfirmationCode, String aNewPassword) {
        String myUpdatePasswordRequest = "{\n" +
                "  \"UpdatePasswordRequest\": {\n" +
                "    \"Header\": {\n" +
                "      \"CMMHeader\": { \"CorrelationId\": \""+ UUID.randomUUID().toString()+"\" }\n" +
                "    },\n" +
                "    \"ClientContext\": { \"UserName\": \""+aUsername +"\" },\n" +
                "    \"ConfirmationCode\": \""+aConfirmationCode+"\",\n" +
                "    \"UserPassword\": \""+aNewPassword+"\"\n" +
                "  }\n" +
                "}";
        return myUpdatePasswordRequest;
    }
    /*
     *
     *  to send api call for user authentication and get response
     *
     */
    public String sendAuthenticateRequest(String aPath, String aUsername, String aPassword, Context aContext) throws WeAlertException {
        String myAuthentication = "false";
        HttpsURLConnection myConnection = null;
        try {
            String myUsername = aUsername;
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(aContext);
            String myToken = preferences.getString("Token","");
            String[] myTempUsernameArray = myUsername.split("[@]");
            String myUsernameWithoutDomain = myTempUsernameArray[0];
            //making the JSON request payload
            String myUserAuthenticationPayload = makeUserAuthenticationJSONRequestPayload(myUsername,myUsernameWithoutDomain,aPassword);
            WeAlertSSLContext mySSLContext= new WeAlertSSLContext();
            URL myUrl = new URL(aPath);
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            myConnection.setDefaultSSLSocketFactory(mySSLContext.setWeAlertSSLContext(aContext).getSocketFactory());
            //Setting Connection request parameters
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("POST");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Content-Length", Integer.toString(myUserAuthenticationPayload.getBytes().length));
            myConnection.setRequestProperty("Authorization", "Bearer "+myToken);
            System.out.println(myUserAuthenticationPayload);
            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            // Writing the request to the stream writer
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myUserAuthenticationPayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            // Check if the API returns HTTP code 200 OK
            int val = myConnection.getResponseCode();
            if (myConnection.getResponseCode() == 200) {
                // Read the response payload returned from the API
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());
                // Get the authentication status from the response
                String myResponseCode = myResponseJsonObject.getJSONObject("AuthenticateResponse").getJSONObject("Result").getString("ResponseCode");
                if(myResponseCode.equals("IAM-N-0000"))
                {
                    myAuthentication =  myResponseJsonObject.getJSONObject("AuthenticateResponse").getString("AuthenticationStatus");
                }
                else if(myResponseCode.equals("IAM-E-9999"))
                {
                    myAuthentication = "false";
                }
                else
                {
                    myAuthentication = "false";
                }
            } else if (myConnection.getResponseCode()== 401)            {
                myAuthentication="token";
            }
        } catch(SocketTimeoutException e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myAuthentication = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Connection timeout while making authenticate user call");
            throw myWeAlertException;
        } catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myAuthentication = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making AuthenticateUser call");
            throw myWeAlertException;
        } finally {
            // clean up initialised resources
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return myAuthentication;
    }
    public String sendRegisterDeviceRequest(String aPath,String aUsername, Context aContext) throws WeAlertException {
        String myRegistration = "false";
        HttpsURLConnection myConnection = null;
        TrustManagerFactory myTrustManagerFactory = null;
        try {
            //get JSON payload
            //split username
            String[] myTempUsernameArray = aUsername.split("[@]");
            String myUsernameWithoutDomain = myTempUsernameArray[0];
            String myDomain = myTempUsernameArray[1];
            //making the JSON request payload
            String myRegisterDevicePayload = makeRegisterDeviceJSONRequestPayload(myDomain, myUsernameWithoutDomain);
            String myUsername = aUsername;
            String myAuthentication = "false";
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(aContext);
            String myToken = preferences.getString("Token", "");
            //making the JSON request payload
            WeAlertSSLContext mySSLContext= new WeAlertSSLContext();
            // Initialisation of connection to the API
            URL myUrl = new URL(aPath);
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            myConnection.setDefaultSSLSocketFactory(mySSLContext.setWeAlertSSLContext(aContext).getSocketFactory());
            //Setting Connection request parameters
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("POST");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Authorization", "Bearer " +myToken);
            myConnection.setRequestProperty("Access-Control-Allow-Origin", "*");
            myConnection.setRequestProperty("Content-Length", Integer.toString(myRegisterDevicePayload.getBytes().length));
            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            // Writing the request to the stream writer
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myRegisterDevicePayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            // Check if the API returns HTTP code 200 OK
            if (myConnection.getResponseCode() == 200) {
                // Read the response payload returned from the API
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());
                // Get the registration status from the response
                String myResponseCode = myResponseJsonObject.getJSONObject("RegisterDeviceResponse").getJSONObject("Result").getString("ResponseCode");
                if (myResponseCode.equals("IAM-N-0000")) {
                    myRegistration = myResponseJsonObject.getJSONObject("RegisterDeviceResponse").getString("RegistrationStatus");
                } else if (myResponseCode.equals("IAM-E-9999")) {
                    myRegistration = "false";
                } else {
                    myRegistration = "false";
                }
            }
        }
        catch (SocketTimeoutException e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myRegistration = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Connection Timeout while making Register Device call");
            throw myWeAlertException;
        }
        catch (IOException e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myRegistration = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while making RegisterDevice call");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myRegistration = null;
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while making RegisterDevice call");
            throw myWeAlertException;
        }
        finally {
            // clean up initialised resources
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return myRegistration;
    }
    public String sendChangePasswordRequest(String aPath, String aUsername, String anOldPassword, String aNewPassword, Context aContext) throws WeAlertException
    {
        String myPasswordChangeResponse = "false";
        HttpsURLConnection myConnection = null;
        TrustManagerFactory myTrustManagerFactory = null;
        try {
            String[] myTempUsernameArray = aUsername.split("[@]");
            String myUsernameWithoutDomain = myTempUsernameArray[0];
            String myChangePasswordPayload = makeChangePasswordJSONRequestPayload(aUsername,myUsernameWithoutDomain,anOldPassword,aNewPassword);
            //get JSON payload
            //making the JSON request payload
            String myUsername = aUsername;
            String myAuthentication = "false";
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(aContext);
            String myToken = preferences.getString("Token", "");
            //making the JSON request payload
            WeAlertSSLContext mySSLContext=new WeAlertSSLContext();
            // Initialisation of connection to the API
            URL myUrl = new URL(aPath);
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            myConnection.setDefaultSSLSocketFactory(mySSLContext.setWeAlertSSLContext(aContext).getSocketFactory());
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("PUT");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Authorization", "Bearer "+myToken);
            myConnection.setRequestProperty("Content-Length", Integer.toString(myChangePasswordPayload.getBytes().length));
            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myChangePasswordPayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            int myhttpresponse = myConnection.getResponseCode();
            if (myConnection.getResponseCode() == 200) {
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());
                String myResponseCode = myResponseJsonObject.getJSONObject("ChangePasswordResponse").getJSONObject("Result").getString("ResponseCode");
                if(myResponseCode.equals("IAM-N-0000"))
                {
                    myPasswordChangeResponse =  "true";
                }
                else if(myResponseCode.equals("IAM-E-9999"))
                {
                    myPasswordChangeResponse = "false";
                }
                else
                {
                    myPasswordChangeResponse = "false";
                }
            }
        }
        catch(SocketTimeoutException e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myPasswordChangeResponse = "null";
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Connection Timeout while making Change Password call");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myPasswordChangeResponse = "false";
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making Change Password call");
            throw myWeAlertException;
        } finally {
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return myPasswordChangeResponse;
    }
    public String sendVerifyUsernameRequest(String aPath, String aUsername , Context aContext) throws WeAlertException {
        String myVerifyUsernameResponse = "false";
        HttpsURLConnection myConnection = null;
        TrustManagerFactory myTrustManagerFactory = null;
        try{
            //get JSON payload
            String myVerifyUsernamePayload = makeVerifyUsernameJSONRequestPayload(aUsername);
            System.out.println(myVerifyUsernamePayload);
            //making the JSON request payload
            String myUsername = aUsername;
            String myToken;
            String myAuthentication = "false";
            if (aPath.contains("pilot")){
                myToken = "24f7f52a-758a-30ac-9d24-1343ab3ba2bc";
            }
            else {
                myToken = "4d2f3def-4cf0-3c80-8291-98afc246a725";
            }
            WeAlertSSLContext mySSLContext=new WeAlertSSLContext();
            // Initialisation of connection to the API
            URL myUrl = new URL(aPath);
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            //myConnection.setDefaultSSLSocketFactory(mySSLContext.setWeAlertSSLContext(aContext).getSocketFactory());
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("POST");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Authorization", "Bearer "+ myToken);
            myConnection.setRequestProperty("Content-Length", Integer.toString(myVerifyUsernamePayload.getBytes().length));
            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myVerifyUsernamePayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            int myhttpresponse = myConnection.getResponseCode();
            if (myConnection.getResponseCode() == 200) {
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());
                String myResponseCode = myResponseJsonObject.getJSONObject("VerifyUsernameResponse").getJSONObject("Result").getString("ResponseCode");
                if(myResponseCode.equals("IAM-N-0000"))
                {
                    myVerifyUsernameResponse =  "true";
                }
                else if(myResponseCode.equals("IAM-E-9999"))
                {
                    myVerifyUsernameResponse = "false";
                }
                else
                {
                    myVerifyUsernameResponse = "false";
                }
            }
        } catch(SocketTimeoutException e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myVerifyUsernameResponse = "null";
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Connection Timeout while making Change Password call");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myVerifyUsernameResponse = "false";
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making Change Password call");
            throw myWeAlertException;
        } finally {
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return myVerifyUsernameResponse;
    }
    public String sendUpdatePasswordRequest(String aPath, String aUsername , String aConfirmationCode, String aNewPassword, Context aContext) throws WeAlertException {
        String myUpdatePasswordResponse = "false";
        HttpsURLConnection myConnection = null;
        TrustManagerFactory myTrustManagerFactory = null;
        try{
            //get JSON payload
            String myUpdatePasswordPayload = makeUpdatePasswordJSONRequestPayload(aUsername, aConfirmationCode, aNewPassword);
            //making the JSON request payload
            String myToken;
            if (aPath.contains("pilot")){
                myToken = "24f7f52a-758a-30ac-9d24-1343ab3ba2bc";
            }
            else {
                myToken = "675703fd-3d2f-383b-8051-c4a137fa3b82";
            }
            // Initialisation of connection to the API
            URL myUrl = new URL(aPath);
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            //myConnection.setDefaultSSLSocketFactory(mySSLContext.setWeAlertSSLContext(aContext).getSocketFactory());
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            myConnection.setConnectTimeout(Constant.CONNECTION_TIMEOUT);
            myConnection.setRequestMethod("POST");
            myConnection.setRequestProperty("Content-Type", "application/json");
            myConnection.setRequestProperty("Accept", "application/json");
            myConnection.setRequestProperty("Authorization", "Bearer "+ myToken);
            myConnection.setRequestProperty("Content-Length", Integer.toString(myUpdatePasswordPayload.getBytes().length));
            myConnection.setUseCaches(false);
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            DataOutputStream myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myUpdatePasswordPayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            int myhttpresponse = myConnection.getResponseCode();
            if (myConnection.getResponseCode() == 200) {
                InputStream myInputStreamWriter = myConnection.getInputStream();
                BufferedReader myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                String myResponseLine;
                StringBuffer myResponse = new StringBuffer();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponse.append(myResponseLine);
                    myResponse.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
                JSONObject myResponseJsonObject = new JSONObject(myResponse.toString());
                String myResponseCode = myResponseJsonObject.getJSONObject("UpdatePasswordResponse").getJSONObject("Result").getString("ResponseCode");
                if(myResponseCode.equals("IAM-N-0000"))
                {
                    myUpdatePasswordResponse =  "true";
                }
                else if(myResponseCode.equals("IAM-E-9999"))
                {
                    myUpdatePasswordResponse = "false";
                }
                else
                {
                    myUpdatePasswordResponse = "false";
                }
            }
        } catch(SocketTimeoutException e)
        {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myUpdatePasswordResponse = "null";
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Connection Timeout while making Change Password call");
            throw myWeAlertException;
        }
        catch (Exception e) {
            WeAlertException myWeAlertException = new WeAlertException(e.getMessage());
            myUpdatePasswordResponse = "false";
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,"Error while making Change Password call");
            throw myWeAlertException;
        } finally {
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return myUpdatePasswordResponse;
    }
}