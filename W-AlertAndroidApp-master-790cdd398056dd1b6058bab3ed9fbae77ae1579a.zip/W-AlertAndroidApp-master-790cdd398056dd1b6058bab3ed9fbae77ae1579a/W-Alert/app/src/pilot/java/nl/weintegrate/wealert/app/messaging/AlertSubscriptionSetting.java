/*
 *	@Author: Waqas Ali Razzzaq
 *
 *  @Usage:
 *			1. Fetch the Subscription details from server
 *
 *	@Known Issues:
 *              1. make separate class for server call
 *	@VersionHistory:
 *
 *			01.001 (Initial Implementation)
 *		    01.002 delete subscription function added
 *		    01.003 Move to alert list screen when Subscription is added. - Mehak Zia (04-06-2018)
 *
 *
 */
package nl.weintegrate.wealert.app.messaging;

/* Android Imports */

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import nl.weintegrate.wealert.app.R;
import nl.weintegrate.wealert.app.dto.SubscriptionDTO;
import nl.weintegrate.wealert.app.persistence.DAOFactory;
import nl.weintegrate.wealert.app.persistence.ISubscriptionDAO;
import nl.weintegrate.wealert.app.ui.AlertListActivity;
import nl.weintegrate.wealert.app.ui.LoginActivity;
import nl.weintegrate.wealert.app.ui.UserEncryption;
import nl.weintegrate.wealert.app.utils.Constant;
import nl.weintegrate.wealert.app.utils.WeAlertException;
import nl.weintegrate.wealert.app.utils.WeAlertLogger;
import nl.weintegrate.wealert.app.utils.WeAlertSSLContext;
import nl.weintegrate.wealert.app.utils.WeAlertURLs;

/* WeIntegrate Imports */

/* Class Declarations start*/
public class AlertSubscriptionSetting extends AsyncTask {

    /***************************************************************
     VARIABLES
     ****************************************************************/

    private final String CLASS_NAME = "AlertSubscriptionSetting";
    private String theTopicName = null;
    private ArrayList<String> theTopicNameList = null;
    private String theBrokerUrl = null;
    private String theSubscriptionId = null;
    private String theSubscriptionName = null;
    private String theUserId = null;
    private String theUserName = null;
    private String thePassword = null;
    private String theEncryptionKey= null;
    private String theOrganizationId = null;
    private Context theContext;
    private Runnable theRegisterDeviceDialogue;

    public AlertSubscriptionSetting(Context aContext) {
        this.theContext = aContext;
    }
    /***************************************************************
     PUBLIC - METHOD
     ****************************************************************/
    public void getSubscriptionDetail(String aUserId, String aOrganizationId, Runnable aRegisterDeviceDialogue) {
        theUserId = aUserId;
        theOrganizationId = aOrganizationId;
        theRegisterDeviceDialogue = aRegisterDeviceDialogue;
        this.execute();
        }

    /***************************************************************
     PRIVATE - METHOD
     ****************************************************************/

    /*
    * Usage:
    *       Function for making the GetSubscription Json Request
    * Params:
    *       aOrganizationId: ClientId
    * */

    private String makeGetEventSubscriptionJSONRequest(String aOrganizationId) {

        String myGetEventSubscriptionRequest = "{\"GetEventSubscriptionRequest\": {\n" +
                "   \"Header\": {\"CMMHeader\": {\"CorrelationId\": \"" + UUID.randomUUID().toString() + "\"}},\n" +
                "   \"ClientContext\": {\"OrganizationId\": \"" + aOrganizationId + "\"}}}";

        return myGetEventSubscriptionRequest;
    }
    /*
    * Usage:
    *       Function for sending the GetSubscription Json Request to server
    * Params:
    *       aUsername: UserName of current logged in user
    *       aOrganizationId: Client id of current logged in user
    * */
    private JSONObject sendGetEventSubscriptionRequest(String aUsername, String aOrganizationId) throws WeAlertException, JSONException {

        StringBuilder myResponseBuffer = null;
        InputStream myInputStreamWriter;
        DataOutputStream myStreamWriter;
        BufferedReader myResponseReader;
        String myResponseLine;
        String myGetEventSubscriptionPayload;

        HttpsURLConnection myConnection = null;


        try {
            myGetEventSubscriptionPayload = makeGetEventSubscriptionJSONRequest(aOrganizationId);
            WeAlertSSLContext mySSLContext= new WeAlertSSLContext();
             // Initialisation of connection to the API

            URL myUrl = new URL(WeAlertURLs.EVENT_SUBSCRIPTION_API + aUsername);
            myConnection = (HttpsURLConnection) myUrl.openConnection();
            myConnection.setSSLSocketFactory(mySSLContext.setWeAlertSSLContext(theContext).getSocketFactory());
            setHttpsRequestProperties(myConnection, theContext );
            myStreamWriter = new DataOutputStream(myConnection.getOutputStream());
            myStreamWriter.writeBytes(myGetEventSubscriptionPayload);
            myStreamWriter.flush();
            myStreamWriter.close();
            if (myConnection.getResponseCode() == Constant.HTTP_STATUS_CODE) {

                myInputStreamWriter = myConnection.getInputStream();
                myResponseReader = new BufferedReader(new InputStreamReader(myInputStreamWriter));
                myResponseBuffer = new StringBuilder();
                while ((myResponseLine = myResponseReader.readLine()) != null) {
                    myResponseBuffer.append(myResponseLine);
                    myResponseBuffer.append('\r');
                }
                myResponseReader.close();
                myInputStreamWriter.close();
            }
        } catch (Exception exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while making GetEventSubscription call");
            throw myWeAlertException;
        } finally {
            if (myConnection != null) {
                myConnection.disconnect();
            }
        }
        return new JSONObject(myResponseBuffer.toString());
    }
    /*
    * Usage:
    *       Function to get Subscription Detail from JsonObject
    * Params:
    *       aJsonObject: Json request payload for get event subscription
    * */

    private String setSubscriptionDetail(JSONObject aJsonObject) throws JSONException {
        if (aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).optJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL) == null) {

            theBrokerUrl = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONObject(Constant.EVENT_SUBSCRIPTION_DETAIL).get(Constant.BROKER_URL).toString();
            theSubscriptionId= aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("SubscriptionId").toString();
            theSubscriptionName= aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("SubscriptionName").toString();
            theUserName = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONObject(Constant.EVENT_SUBSCRIPTION_DETAIL).get(Constant.USER_NAME).toString();
            thePassword = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONObject(Constant.EVENT_SUBSCRIPTION_DETAIL).get(Constant.PASSWORD).toString();
            theEncryptionKey = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("EventEncryptionKey").toString();
            theTopicName = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONObject(Constant.EVENT_SUBSCRIPTION_DETAIL).get(Constant.TOPIC_NAME).toString();
             return Constant.SINGLE_SUBSCRIPTION;
        } else {
            theTopicNameList= new ArrayList<>();
            theSubscriptionId= aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("SubscriptionId").toString();
            theSubscriptionName= aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("SubscriptionName").toString();
            theBrokerUrl = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL).getJSONObject(0).get(Constant.BROKER_URL).toString();
            theUserName = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL).getJSONObject(0).get(Constant.USER_NAME).toString();
            thePassword = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL).getJSONObject(0).get(Constant.PASSWORD).toString();
            theEncryptionKey = aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).get("EventEncryptionKey").toString();
            theTopicNameList = parseJsonResponse(aJsonObject.getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).getJSONObject(Constant.EVENT_SUBSCRIPTION).getJSONArray(Constant.EVENT_SUBSCRIPTION_DETAIL));
        }
        return Constant.MULTIPLE_SUBSCRIPTION;
    }

    /*
    * Usage:
    *       Utility function for setting the http properties
    * Params:
    *       aHttpConnection: http connection object
    * */

    private void setHttpsRequestProperties(HttpsURLConnection aHttpsConnection, Context aContext) throws WeAlertException {
        try {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(aContext);
            String myToken = preferences.getString("Token", "");
            aHttpsConnection.setRequestMethod("POST");
            aHttpsConnection.setRequestProperty("Content-Type", "application/json");
            aHttpsConnection.setRequestProperty("Accept", "application/json");
            aHttpsConnection.setRequestProperty("Authorization", "Bearer "+myToken);
            aHttpsConnection.setUseCaches(false);
            aHttpsConnection.setDoInput(true);
            aHttpsConnection.setDoOutput(true);
        } catch (ProtocolException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Error while setting HTTP request properties.");
            throw myWeAlertException;
        }
    }

    /***************************************************************
     PROTECTED - METHOD
     ****************************************************************/
    @Override
    protected Object doInBackground(Object[] params) {
        JSONObject myJsonObject;
        String myResponse = null;
        try {

            myJsonObject = sendGetEventSubscriptionRequest(theUserId, theOrganizationId);
            if (myJsonObject .getJSONObject(Constant.EVENT_SUBSCRIPTION_RESPONSE).optJSONObject(Constant.EVENT_SUBSCRIPTION) != null) {

               myResponse = setSubscriptionDetail(myJsonObject);
            }
            else {
                showAlertDialog();
            }
        } catch (Exception exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
        }
        return myResponse;
    }

    private void insertSubscription(SubscriptionDTO aSubscription,String aTopicName,ISubscriptionDAO aSubscriptionDao,WeAlertLogger aWeAlertLogger) {
        try {
            aSubscription.setBrokerUrl(theBrokerUrl);
            aSubscription.setSubscriptionId(theSubscriptionId);
            aSubscription.setSubscriptionName(theSubscriptionName);
            aSubscription.setTopicName(aTopicName);
            aSubscription.setUserName(theUserName);
            aSubscription.setPassword(thePassword);
            aSubscription.setEncryptionKey(theEncryptionKey);
            Handler myHandler = new Handler(Looper.myLooper());
            if (aSubscriptionDao.insertSubscriptionDetail(aSubscription)) {

                aWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Subscription saved to Database.");
                myHandler.post(theRegisterDeviceDialogue);
                UserEncryption userEncryption = new UserEncryption();
                userEncryption.insertEncryptedUserPasswordToDatabase(theContext);
            } else {
                aWeAlertLogger.logMessage(Thread.currentThread().getId(), CLASS_NAME, "Subscription not saved to Database.");
            }
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            aWeAlertLogger.logMessage(Thread.currentThread().getId(),"AlertService",myWeAlertException.getMessage());
        }
    }

    @Override
    protected void onPostExecute(Object aObject) {
        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
        SubscriptionDTO mySubscription = new SubscriptionDTO();
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(theContext);
            ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
            if(aObject.toString() == Constant.MULTIPLE_SUBSCRIPTION) {

                for (int topicIndex = 0; topicIndex < theTopicNameList.size(); topicIndex++) {

                    String myTopicName = theTopicNameList.get(topicIndex);
                    insertSubscription( mySubscription, myTopicName, mySubscriptionDao, myWeAlertLogger);
                }
            } else if (aObject.toString()==Constant.SINGLE_SUBSCRIPTION) {

                insertSubscription( mySubscription, theTopicName, mySubscriptionDao, myWeAlertLogger);
            } else {
                showAlertDialog();
            }
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),"AlertService",myWeAlertException.getMessage());
        }
    }
    /*
    * Usage:
    *       Function to getTopicList from JsonArray
    * Params:
    *       aSubscriptionDetail: subscription detail json array
    * */

    private ArrayList<String> parseJsonResponse(JSONArray aSubscriptionDetail) throws JSONException {
        ArrayList<String> myTopicNameList = new ArrayList<>();
        if (aSubscriptionDetail != null) {
            for (int loop = 0; loop < aSubscriptionDetail.length(); loop++) {
                myTopicNameList.add(aSubscriptionDetail.getJSONObject(loop).getString(Constant.TOPIC_NAME));
            }
        }
        return myTopicNameList;
    }

    private void showAlertDialog() {
        AlertDialog.Builder myDeleteConfirmationDialog = new AlertDialog.Builder(new LoginActivity(), R.style.Mytheme);
        myDeleteConfirmationDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent myIntentToStartAlertListActivity = new Intent(new LoginActivity(), AlertListActivity.class);

                myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                myIntentToStartAlertListActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                theContext.startActivity(myIntentToStartAlertListActivity);
            }
        });

        AlertDialog myDeleteDialog = myDeleteConfirmationDialog.create();
        myDeleteDialog.setTitle("Alert");
        myDeleteDialog.setMessage("No Subscription Found");
        myDeleteDialog.show();
        myDeleteDialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundColor(theContext.getResources().getColor(R.color.colorPrimaryDark));
    }
        /*
        * Usage:
        *       Function to delete Subscription details
        * Params:
        *       aContext: the current application context
        * */
    public void deleteSubscription(Context aContext) {
    DAOFactory mySQLLiteDaoFactory;
    try {
        mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
        mySQLLiteDaoFactory.setContext(aContext);
        ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
        mySubscriptionDao.deleteSubscriptionDetail();
    } catch (WeAlertException exception) {
        WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
        WeAlertLogger myWeAlertLogger = new WeAlertLogger();
        myWeAlertLogger.logMessage(Thread.currentThread().getId(),CLASS_NAME,myWeAlertException.getMessage());
    }
}
    public boolean isSubscriptionSaved(Context aContext) {
        SubscriptionDTO mySubscription;
        DAOFactory mySQLLiteDaoFactory;
        try {
            mySQLLiteDaoFactory = DAOFactory.getDAOFactory(DAOFactory.SQLITE);
            mySQLLiteDaoFactory.setContext(aContext);
            ISubscriptionDAO mySubscriptionDao = mySQLLiteDaoFactory.getSubscriptionDAO();
            mySubscription = mySubscriptionDao.getSubscriptionDetail();
            if(mySubscription.getTopicName()!="" && mySubscription.getTopicName()!=null) {
                return true;
            }
        } catch (WeAlertException exception) {
            WeAlertException myWeAlertException = new WeAlertException(exception.getMessage());
            WeAlertLogger myWeAlertLogger = new WeAlertLogger();
            myWeAlertLogger.logMessage(Thread.currentThread().getId(),"AlertService",myWeAlertException.getMessage());
        }
        return false;
    }
}//End f Class

