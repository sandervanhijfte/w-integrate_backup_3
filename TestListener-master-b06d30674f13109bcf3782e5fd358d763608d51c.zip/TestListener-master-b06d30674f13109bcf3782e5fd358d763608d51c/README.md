This component is only to test the way the mule reacts on an http listener that
listens on port 5050. You can do this test with curl http://localhost:5050/start_event