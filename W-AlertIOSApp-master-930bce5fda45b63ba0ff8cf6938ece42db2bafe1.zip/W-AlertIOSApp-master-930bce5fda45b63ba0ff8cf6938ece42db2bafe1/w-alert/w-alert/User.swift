//
//  Contact.swift
//  SQLiteApp
//
//  Created by deivitaka on 3/28/16.
//
//

import Foundation

class User {
    let id: Int64?
    var userId: String
    var userName: String
    var password: String
    var status: String
    var firstName: String
    var lastName: String
    var mobileNo: String
    var email: String
    var roleId: String
    var organizationId: String
    var organizationName: String
    var organizationDomain:String
    
    init(id: Int64) {
        self.id = id
        userId = ""
        userName = ""
        password = ""
        status = ""
        firstName = ""
        lastName = ""
        mobileNo = ""
        email = ""
        roleId = ""
        organizationId = ""
        organizationName = ""
        organizationDomain = ""
    }
    
    init(id: Int64, userId: String, userName: String, password: String, status: String,firstName: String, lastName: String, mobileNo: String, email: String, roleId: String, organizationId: String, organizationName: String, organzationDomain: String) {
        self.id = id
        self.userId = userId
        self.userName = userName
        self.password = password
        self.status = status
        self.firstName = firstName
        self.lastName = lastName
        self.mobileNo = mobileNo
        self.email = email
        self.roleId = roleId
        self.organizationId = organizationId
        self.organizationName = organizationName
        self.organizationDomain = organzationDomain
    }
}

