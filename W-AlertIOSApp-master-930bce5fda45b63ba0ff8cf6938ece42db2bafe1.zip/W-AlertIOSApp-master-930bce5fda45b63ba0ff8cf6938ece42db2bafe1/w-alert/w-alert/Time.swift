//
//  Time.swift
//  w-alert
//
//  Created by Arqam Amin on 10/28/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation

class Time {
    
    static let DATE_TIME_FORMAT = "yyyy-MM-dd HH-mm-ss"
    
    /* Method : getDateTime
     * Description : This method will be use to date or relative time of the alert
     * Input : String
     */
    static func getRelativeDateTime(_ dateTime: String) -> String {
        let calendar = Calendar.current
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = DATE_TIME_FORMAT
        let alertDate = dateFormatter.date(from: dateTime)
        let alertYear = calendar.component(.year, from: alertDate!)
        let alertMonth = calendar.component(.month, from: alertDate!)
        let alertDay = calendar.component(.day, from: alertDate!)
 
        let date = Date()
        let currentYear = calendar.component(.year, from: date)
        let currentMonth = calendar.component(.month, from: date)
        let currentDay = calendar.component(.day, from: date)
        
        if (currentDay == alertDay && currentMonth == alertMonth && currentYear == alertYear) {
            let alertHour = calendar.component(.hour, from: alertDate!)
            let alertMin = calendar.component(.minute, from: alertDate!)
            let alertSec = calendar.component(.second, from: alertDate!)
            
            let currentHour = calendar.component(.hour, from: date)
            let currentMin = calendar.component(.minute, from: date)
            let currentSec = calendar.component(.second, from: date)
            
            if (currentHour > alertHour) {
                return "\(currentHour - alertHour) hrs ago"
            } else if (currentMin > alertMin) {
                return "\(currentMin - alertMin) min ago"
            } else {
                return "\(currentSec - alertSec) sec ago"
            }
        }
        
        return "\(alertYear)-\(alertMonth)-\(alertDay)"
    }
    
    static func getTime(_ dateTime: String) -> String {
        let calendar = Calendar.current
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = DATE_TIME_FORMAT
        let alertDate = dateFormatter.date(from: dateTime)
        let alertHour = calendar.component(.hour, from: alertDate!)
        let alertMin = calendar.component(.minute, from: alertDate!)
        let alertSec = calendar.component(.second, from: alertDate!)
        
        return "\(alertHour):\(alertMin):\(alertSec)"
    }
    
    static func getDate(_ dateTime: String) -> String {
        let calendar = Calendar.current
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = DATE_TIME_FORMAT
        let alertDate = dateFormatter.date(from: dateTime)
        let alertYear = calendar.component(.year, from: alertDate!)
        let alertMonth = calendar.component(.month, from: alertDate!)
        let alertDay = calendar.component(.day, from: alertDate!)
        
        return "\(alertYear)-\(alertMonth)-\(alertDay)"
    }
}
