//
//  SQLiteConnection.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation
import SQLite

class SQLiteConnection {
    
    private static var instance : SQLiteConnection!
    private let db: Connection?
    
    /* Method : init
     * Description : This is constructer method and is use to construct object and create connection between database
     * Input : void
     */
    private init() throws {
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        
        do {
            db = try Connection("\(path)/W-Alert.sqlite3")
        } catch {
            throw AlertError.UnableToCreateConnection
        }
    }
    
    /* Method : getInstance
     * Description : This method will be use get instence of SQLiteAlertDataBase
     * Input : void
     */
    static func getConnection() throws -> Connection {
        if instance == nil {
            instance = try SQLiteConnection()
        }
        
        return instance.db!
    }
 }
