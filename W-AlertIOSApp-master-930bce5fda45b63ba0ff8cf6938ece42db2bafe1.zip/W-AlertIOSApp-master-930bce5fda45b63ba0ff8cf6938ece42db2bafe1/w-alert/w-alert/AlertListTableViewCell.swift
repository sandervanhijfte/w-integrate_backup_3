//
//  AlertListTableViewCell.swift
//  w-alert
//
//  Created by WeIntegratemac01 on 20/09/2017.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import UIKit

class AlertListTableViewCell: UITableViewCell {

    @IBOutlet weak var AgentName: UILabel!
    @IBOutlet weak var ErrorMessage: UILabel!
    @IBOutlet weak var AlertTime: UILabel!
    @IBOutlet weak var servityColor: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
