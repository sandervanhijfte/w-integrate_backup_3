//
//  SQLiteAlertDataBase.swift
//  w-alert
//
//  Created by Arqam Amin on 10/6/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation
import SQLite
//
//class SQLiteAlertDataBase {
//    
//    /**
//     
//     "CREATE TABLE IF NOT EXISTS T_ALERT (C_ALERT_ID text PRIMARY KEY, C_TIME_STAMP text, C_SEVERITY text, C_ALERT_TYPE text, C_ALERT_TITLE text, C_ALERT_MESSAGE text, C_HOST_NAME text, C_COMPONENT_NAME text, C_UNREAD numeric, C_ENVIRONMENT_NAME)"
//     */
//    
//    private let alertTable = Table("T_ALERT")
//    private let id = Expression<Int64>("id")
//    private let C_TIME_STAMP = Expression<String>("C_TIME_STAMP")
//    private let C_SEVERITY = Expression<String>("C_SEVERITY")
//    private let C_ALERT_TYPE = Expression<String>("C_ALERT_TYPE")
//    private let C_ALERT_TITLE = Expression<String>("C_ALERT_TITLE")
//    private let C_ALERT_MESSAGE = Expression<String>("C_ALERT_MESSAGE")
//    private let C_HOST_NAME = Expression<String>("C_HOST_NAME")
//    private let C_COMPONENT_NAME = Expression<String>("C_COMPONENT_NAME")
//    private let C_UNREAD = Expression<Bool>("C_UNREAD")
//    private let C_ENVIRONMENT_NAME = Expression<String>("C_ENVIRONMENT_NAME")
//    
//    private static var instance : SQLiteAlertDataBase!
//    private let db: Connection?
//    
//    /* Method : init
//     * Description : This is constructer method and is use to construct object and create connection between database
//     * Input : void
//     */
//    private init() throws {
//        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
//        
//        do {
//            db = try Connection("\(path)/W-Alert.sqlite3")
//        } catch {
//            throw AlertError.UnableToCreateConnection
//        }
//    }
//    
//    /* Method : getInstance
//     * Description : This method will be use get instence of SQLiteAlertDataBase
//     * Input : void
//     */
//    static func getInstance() throws -> SQLiteAlertDataBase {
//        if instance == nil {
//            instance = try SQLiteAlertDataBase()
//        }
//        
//        return instance
//    }
//    
//    /* Method : createTable
//     * Description : This method will be use creta Alert table in database
//     * Input : void
//     */
//    func createTable() throws -> Bool {
//        var isExist = true
//        do {
//            try db!.run(alertTable.create(ifNotExists: true) { table in
//                table.column(id, primaryKey: true)
//                table.column(C_TIME_STAMP)
//                table.column(C_SEVERITY)
//                table.column(C_ALERT_TYPE)
//                table.column(C_ALERT_TITLE)
//                table.column(C_ALERT_MESSAGE)
//                table.column(C_HOST_NAME)
//                table.column(C_COMPONENT_NAME)
//                table.column(C_UNREAD)
//                table.column(C_ENVIRONMENT_NAME)
//                isExist = false
//            })
//        } catch {
//            throw AlertError.CreateAlertTableFail
//        }
//        return isExist
//    }
//    
//    /* Method : addAlert
//     * Description : This method will be use to insert alert record in database
//     * Input : Alert
//     */
//    func addAlert(alert: Alert) throws -> Int64? {
//        do {
//            let insert = alertTable.insert(C_TIME_STAMP <- alert.timeStamp, C_SEVERITY <- alert.severity, C_ALERT_TYPE <- alert.alertType, C_ALERT_TITLE <- alert.alertTitle, C_ALERT_MESSAGE <- alert.alertMessage, C_HOST_NAME <- alert.hostName, C_COMPONENT_NAME <- alert.componentName, C_UNREAD <- alert.unread, C_ENVIRONMENT_NAME <- alert.environmentName)
//            
//            return try db!.run(insert)
//        } catch {
//            throw AlertError.InserAlertError
//        }
//    }
//    
//    /* Method : getAllAlerts
//     * Description : This method will be use to delete single record from databse
//     * Input : Int64
//     */
//    func getAllAlerts() throws -> [Alert] {
//        
//        do {
//            return try getAlerts(from: -1, limit: -1)
//        } catch AlertError.ReadAlertsWithRangeFail{
//            throw AlertError.ReadAlertsFail
//        }
//    }
//    
//    /* Method : getAlerts
//     * Description : This method will be use to get latest alerts from database on specific range
//     * Input : Int, Int
//     */
//    func getAlerts(from: Int, limit: Int) throws -> [Alert] {
//        do {
//            
//            let allAlert = try self.db!.prepare(self.alertTable.limit(limit, offset: from).order(C_TIME_STAMP.desc, id.desc))
//            return getAlerts(allAlert)
//        } catch {
//            throw AlertError.ReadAlertsWithRangeFail
//        }
//    }
//    
//    /* Method : deleteAlert
//     * Description : This method will be use to delete single record from databse
//     * Input : Int64
//     */
//    func deleteAlert(cid: Int64) throws {
//        do {
//            try db!.run(self.alertTable.filter(id == cid).delete())
//        } catch {
//            throw AlertError.DeleteAlertFail
//        }
//    }
//    
//    /* Method : multipleDelete
//     * Description : This method will be use to delete multiple records from database
//     * Input : Array<Int64>
//     */
//    func multipleDelete(_ ids:Array<Int64>) throws {
//        do {
//            try db!.run(self.alertTable.filter(ids.contains(id)).delete())
//        } catch {
//            throw AlertError.DeleteMultipleAlertRecordFail
//        }
//    }
//    
//    /* Method : search
//     * Description : This method will be use to get alerts record from database base on match keywords
//     * Input : String
//     */
//    func search(arg : String) throws -> [Alert] {
//
//        do{
//            return try search(arg: arg, from: -1, limit: -1)
//        } catch {
//            throw AlertError.SearchAlertWithFilterFail
//        }
//    }
//    
//    /* Method : search
//     * Description : This method will be use to get alerts record from database base on match keywords and range of records
//     * Input : String
//     */
//    func search(arg : String , from: Int, limit: Int) throws -> [Alert] {
//        
//        let keyword = "%\(arg)%";
//        do{
//            let filterAlerts = try self.db!.prepare(self.alertTable.filter(C_ALERT_TITLE.like(keyword) || C_SEVERITY.like(keyword) || C_ALERT_TYPE.like(keyword) || C_COMPONENT_NAME.like(keyword) || C_TIME_STAMP.like(keyword)).order(C_TIME_STAMP.desc, id.desc).limit(limit, offset: from))
//            
//            return getAlerts(filterAlerts)
//        } catch {
//            throw AlertError.SearchAlertWithFilterRangeFail
//        }
//    }
//    
//    /* Method : getNumberOfRecords
//     * Description : This method will be use to get number of records in data base
//     * Input : Int
//     */
//    func getNumberOfRecords() throws -> Int {
//        
//        do{
//            return try self.db!.scalar(alertTable.count)
//        } catch {
//            throw AlertError.CountAlertRecordFail
//        }
//    }
//    
//    /* Method : getAlerts
//     * Description : This method will be use to convert alerts record from AnySequence object to Alert array onjecct
//     * Input : AnySequence<Row>
//     */
//    private func getAlerts(_ record: AnySequence<Row>) -> [Alert] {
//        var alerts = [Alert]()
//        
//        for alert in record {
//            let myAlert = Alert(id: alert[id], timeStamp: alert[C_TIME_STAMP], severity: alert[C_SEVERITY], alertType: alert[C_ALERT_TYPE], alertTitle: alert[C_ALERT_TITLE], alertMessage: alert[C_ALERT_MESSAGE], hostName: alert[C_HOST_NAME], componentName: alert[C_COMPONENT_NAME], unread: alert[C_UNREAD], environmentName: alert[C_ENVIRONMENT_NAME])
//            
//            alerts.append(myAlert)
//        }
//        
//        return alerts
//    }
//}

