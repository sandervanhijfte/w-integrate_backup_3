//
//  AlertDetail.swift
//  w-alert
//
//  Created by Arqam Amin on 10/28/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation
class AlertDetail : Alert {
    
    var alertId : String
    var alertType: String
    var alertTitle: String
    var hostName: String
    var unread: Bool
    var environmentName: String
    
    init(id: Int64, alertId: String, timeStamp: String, severity: String, alertType: String, alertTitle: String, alertMessage: String, hostName: String, componentName: String, unread: Bool, environmentName: String) {
        self.alertId = alertId
        self.alertType = timeStamp
        self.alertTitle = alertTitle
        self.hostName = hostName
        self.unread = unread
        self.environmentName = environmentName
        super.init(id: id, timeStamp: timeStamp, severity: severity, alertMessage: alertMessage, componentName: componentName)
    }
    
    override init(id: Int64) {
        self.alertId = ""
        self.alertType = ""
        self.alertTitle = ""
        self.hostName = ""
        self.unread = false
        self.environmentName = ""
        super.init(id: id)        
    }
    
    private func initilize(alertId: String, alertType: String, alertTitle: String, hostName: String, unread: Bool,  environmentName: String) {
        self.alertId = alertId
        self.alertType = alertType
        self.alertTitle = alertTitle
        self.hostName = hostName
        self.unread = unread
        self.environmentName = environmentName
    }
    
}
