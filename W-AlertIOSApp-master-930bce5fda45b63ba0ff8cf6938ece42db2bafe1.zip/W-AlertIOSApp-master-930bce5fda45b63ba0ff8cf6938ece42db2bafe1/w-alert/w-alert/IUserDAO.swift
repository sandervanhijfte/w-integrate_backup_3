//
//  IUserDAO.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation

protocol IUserDAO{
    func insert(user: User) throws -> Int64
    func getUserProfile() throws -> User
    func deleteUserPassword(id: Int64) throws
    func insertUserPassword(id: Int64, userPassword: String) throws
    func deleteUserProfile(_ id: Int64) throws
    func getUserCount() throws -> Int
}
