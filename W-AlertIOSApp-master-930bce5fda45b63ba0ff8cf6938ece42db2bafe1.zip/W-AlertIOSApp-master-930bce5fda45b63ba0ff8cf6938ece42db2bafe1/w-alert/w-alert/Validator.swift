/*
 *  Name: Validator.swift
 *  version: 1.0.0
 *  Created by: Waqas Ali Razzaq on 9/19/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

import Foundation
import UIKit

class Validator {

    /* Method : validateUserName
     * Description : This method will be used to validate the user name
     * Input : The input params are username
     */
    
    public func validateUserName(userNameText: CustomTextField) -> Bool{
        
        var valid:Bool = true
        if (userNameText.text?.isEmpty)! {
            
            userNameText.attributedPlaceholder = NSAttributedString(string: Constants.USER_NAME_PLACEHOLDER, attributes: [NSForegroundColorAttributeName: UIColor.red])
            valid = false
            userNameText.awakeForError()
            userNameText.shake()
        }
        else {
            
            valid = validateEmail(email: userNameText.text!)
            if (!valid) {
            
                userNameText.awakeForError()
                userNameText.shake()
            }
        }
        return valid
    }
    
    /* Method : validatePassword
     * Description : This method will be used to validate the password
     * Input : The input params are password
     */
    
    public func validatePassword(passwordText: CustomTextField) -> Bool{
        
        var valid:Bool = true
        
        if ((passwordText.text?.isEmpty)! || (passwordText.text!.characters.count)<3) {
            
            passwordText.attributedPlaceholder = NSAttributedString(string: Constants.PASSWORD_PLACEHOLDER, attributes: [NSForegroundColorAttributeName: UIColor.red])
            passwordText.awakeForError()
            passwordText.shake()
            valid = false
        }
        return valid
    }
    
    /* Method : validateEmail
     * Description : This method will be used to validate the email
     * Input : The input value is message string
     */
    
    func validateEmail(email:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailString = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailString.evaluate(with: email)
        return result
    }
    
    
    
    func validateFirstName(firstName: String) -> Bool {
        let firstNameRegEx = "[a-zA-Z-]*"
        let firstNameString = NSPredicate(format:"SELF MATCHES %@", firstNameRegEx)
        let result = firstNameString.evaluate(with: firstName)
        return result
    }
    
    
    func validateLastName(lastName: String) -> Bool {
        let lastNameRegEx = "[a-zA-Z-][a-zA-Z-]*"
        let lastNameString = NSPredicate(format:"SELF MATCHES %@", lastNameRegEx)
        let result = lastNameString.evaluate(with: lastName)
        return result
    }
}
