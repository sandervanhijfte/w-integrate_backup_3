//
//  AboutWAlertController.swift
//  w-alert
//
//  Created by WeIntegratemac01 on 28/09/2017.
//  Copyright © 2017 WeIntegrate. All rights reserved.
//  Initial implementation :mehak zia cheema
//

import UIKit

class AboutAppController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
