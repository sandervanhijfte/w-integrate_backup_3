/*
 *  Constant.swift
 *  Created by: Waqas Ali Razzaq on 9/15/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

import Foundation

struct Constants {
    
    //   Constant Variables.
    static let AUTHENTICATE_USER_URL         =  "https://pilot.w-alert.com/wealert/iam/1.0/identityandaccessmanagement_01/users/authenticate"
    
    static let REGISTER_DEVICE_URL           =  "https://pilot.w-alert.com/wealert/iam/1.0/identityandaccessmanagement_01/users/registerdevice"
    
    static let GET_USER_URL                  =  "https://pilot.w-alert.com/wealert/client/1.0/clientmanagement_01/users"
    
    static let GET_SUBSCRIPTION_URL          =  "https://pilot.w-alert.com/wealert/subscription/1.0/eventsubscriptionmanagement_01/eventsubscriptions/"
    
    static let UPDATE_USER_URL               =  "https://pilot.w-alert.com/wealert/client/1.0/clientmanagement_01/users"
    
    static let ACCESS_TOKEN                  =  "Bearer 24f7f52a-758a-30ac-9d24-1343ab3ba2bc"
    
    static let TIME_OUT: Double              =  30 //seconds
    
    static let ACCEPT_HEADER                 =  "application/json"
    
    static let Content_Type                  =  "application/json"
    
    static let REGISTER_DEVICE_MESSAGE       =  "Your device has been registered"
    
    static let REGISTER_DEVICE_ERROR_MESSAGE =  "Device is not registered. User doesn't have any assigned application group"
    
    static let USER_NAME_PLACEHOLDER         =  "Please enter the username"
    
    static let PASSWORD_PLACEHOLDER          =  "Please enter the password"
    
    static let LOGIN_ERROR_MESSAGE           =  "Username or Password is incorrect. Please try again"
    
    static let UNEXPECTED_ERROR_MESSAGE      =  "Unexpected error has occurred. Please try again later"
    
    static let SERVICE_UNAVAILABLE_MESSAGE   =  "Unable to connect the backend service. Please try again later"
    
    static let CONTACT_ADMINISTRATOR_MESSAGE   =  " or contact your administrator"
    
    static let USER_NOT_FOUND_MESSAGE        =  "Unable to get user details. Please contact your administrator"
    
    static let USER_UPDATE_SUCCESSFULLY_MESSAGE = "Profile updated successfully"
    
    static let VALID_DATA_MESSAGE = "Please enter valid Data"
    
    static let FILL_REQUIRED_FIELDS = "Please enter required fields"
    
    static let SIGN_OUT_TITLE = "Are you sure you want to sign out?"
    
    static let SIGN_OUT_MESSAGE = "Please note that you will continue to recieve alerts. If you do not wish to recieve alerts, press the disconnect device button "
    
    static let FIRST_NAME_MESSAGE = "It must consist of alphabets. Only hyphens are allowed, no other special characters are allowed"
    
    static let lAST_NAME_MESSAGE = "It must consist of alphabets. Only hyphens are allowed, no other special characters are allowed"
    
    static let EMAIL_MESSAGE = "It can be alpha numeric data. Only full stops, hyphens, underscores & one \"@\" must be allowed, no other special characters are allowed."
    
    static let CANCEL = "Cancel"
    
    static let DISCONNECT_AND_SIGN_OUT = "Disconnect & Sign Out"
    
    static let SIGN_OUT = "Sign Out"
    
}
