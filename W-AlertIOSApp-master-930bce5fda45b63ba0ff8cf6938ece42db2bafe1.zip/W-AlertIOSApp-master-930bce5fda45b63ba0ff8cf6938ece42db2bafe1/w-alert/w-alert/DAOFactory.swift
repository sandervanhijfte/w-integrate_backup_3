//
//  DAOFactory.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation

class DAOFactory{
    
    static let SQLITE = 1
    static let XML = 2
    
    func getAlertDAO() throws -> AlertDAO {
         fatalError()
    }
    
    func getUserDAO() throws -> UserDAO {
        fatalError()
    }
    
    static func getDAOFactory(factoryType: Int) -> DAOFactory {
        switch factoryType {
        case SQLITE:
            return SqliteDAOFactory()
        default:
            return SqliteDAOFactory()
        }
    }
}
