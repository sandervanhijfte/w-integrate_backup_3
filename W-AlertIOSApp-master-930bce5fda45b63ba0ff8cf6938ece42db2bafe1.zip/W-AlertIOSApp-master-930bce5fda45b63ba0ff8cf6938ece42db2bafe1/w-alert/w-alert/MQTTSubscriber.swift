/*
 *  Name: MQTTManager.swift
 *  version: 1.0.0
 *  Created by: Waqas Ali Razzaq on 10/16/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

import Foundation
import CocoaMQTT
import UserNotifications
import SwiftyJSON

class MQTTManager: NSObject, CocoaMQTTDelegate {
    
    static let sharedInstance = MQTTManager()
    var host = ""
    var port = 0
    var subscriptions = [Subscription]()
    var delegate:MQTTManagerDelegate?
    let daoFactorry : DAOFactory = SqliteDAOFactory()
    var alertDAO : IAlertDAO!
    var  mqtt = CocoaMQTT(clientID: "client-" + String(ProcessInfo().processIdentifier), host: "185.3.211.68", port: 1884)
    var connected = false {
        didSet {
            delegate?.mqttManagerConnectionChanged(mqttManager: self)
        }
    }
    
    override init() {
        
        super.init()
        print ("client-" + String(ProcessInfo().processIdentifier))
        
        do {
            self.alertDAO = try self.daoFactorry.getAlertDAO()
            
        } catch {
            
            print (error)
        }
        print("Init MQTT manager")
        
        mqtt.keepAlive = 120
        mqtt.cleanSession = false
        mqtt.autoReconnect = true
        mqtt.delegate = self
        connect()
    }
    
    func connect() {
        
        if mqtt.connState != .connected && mqtt.connState != .connecting {
            mqtt.connect();
            
        }
    }
    
    func setHost() -> String {
        subscriptions = SQLiteDataStore.instance.getSubscription()
        subscriptions.forEach() { data in
            print (data.topicName)
            let url = data.brokerURL.components(separatedBy: "//")[1]
            host = url.components(separatedBy: ":")[0]
            
            
        }
        return host
    }
    
    func setPort() -> Int {
        subscriptions = SQLiteDataStore.instance.getSubscription()
        subscriptions.forEach() { data in
            print (data.topicName)
            let url = data.brokerURL.components(separatedBy: "//")[1]
            port = Int(url.components(separatedBy: ":")[1])!
            
            
        }
        return port
    }
}

// CocoaMQTTDelegate Methods
extension MQTTManager {
    
    func mqtt(_ mqtt: CocoaMQTT, didConnectAck ack: CocoaMQTTConnAck) {
        if (mqtt.connState == .connected) {
            
            subscriptions = SQLiteDataStore.instance.getSubscription()
            subscriptions.forEach() { data in
                subscribeToTopic(topic: data.topicName)
            }
            
            print ("connect ack")
        }
        
    }
    
    @objc(mqtt:didReceiveMessage:id:) func mqtt(_ mqtt: CocoaMQTT, didReceiveMessage message: CocoaMQTTMessage, id: UInt16) {
        
        print("didReceivedMessage: \(message.string ?? "")")
        
        let content = UNMutableNotificationContent()
        content.title = "W-Alert"
        content.subtitle = "New Alert"
        content.body = "Notification Received"
        content.badge = 1
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: "timerDone", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        print ("notificaation sent")
        var json = JSON(message.string)
        
        var alert: Alert
        getAlertFromJson(alert: message)
        //addAlert(alert)
        var alertList = [Alert]()
        
        
        do {
            try alertList = alertDAO.getAllAlerts()
            
        } catch {
            
            print (error)
        }
        
        alertList.forEach() {data in
            
            // print(data.alertMessage)
        }
    }
    
    func getAlertFromJson(alert: CocoaMQTTMessage) -> Alert {
        var myalert = JSON(data: alert.string!.data(using: .utf8)!)

        let alertRecord = myalert["Alert"]
        let timeStamp = alertRecord["TimeStamp"].stringValue
        let severity = alertRecord["Severity"].stringValue
        let alertType = alertRecord["AlertType"].stringValue
        let alertTitle = alertRecord["AlertTitle"].stringValue
        let alertMessage = alertRecord["AlertMessage"].string
        let hostName = alertRecord["HostName"].stringValue
        let componentName = alertRecord["ComponentName"].stringValue
        let environmentName = alertRecord["EnvironmentName"].stringValue
        
        var alert = Alert(id: 1, timeStamp: timeStamp, severity: severity, alertType: alertType, alertTitle: alertTitle, alertMessage: alertMessage!, hostName: hostName, componentName: componentName, unread: true, environmentName: environmentName)
       
        return alert
    }

    
    //temprary helper function which will remove in future
    private func addAlert(_ alert: Alert) {
        do {
            try alertDAO.insertAlert(alert: alert)
        }catch {
            print ("\(error)")
        }
    }
    func mqtt(_ mqtt: CocoaMQTT, didPublishAck id: UInt16) {}
    
    func mqtt(_ mqtt: CocoaMQTT, didSubscribeTopic topic: String) {
        print("Subscribed to topic: ", topic)
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didUnsubscribeTopic topic: String) {}
    
    func mqttDidPing(_ mqtt: CocoaMQTT) {
        print("Ping!")
    }
    
    func mqttDidReceivePong(_ mqtt: CocoaMQTT) {
        print("Pong!")
        
    }
    
    func mqttDidDisconnect(_ mqtt: CocoaMQTT, withError err: Error?) {
        print("Disconnected from MQTT!",err ?? "disconnected")
        connected = false
        connect()
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didConnect host: String, port: Int) {
        print("Connected to MQTT server.")
        connected = true
    }
    
    @objc(mqtt:didPublishMessage:id:) func mqtt(_ mqtt: CocoaMQTT, didPublishMessage message: CocoaMQTTMessage, id: UInt16) {
        
    }
    
    
    func subscribeToTopic(topic:String) {
        if mqtt.connState == .connected {
            print("Subscribe to: ", topic)
            
            
            mqtt.subscribe(topic, qos: CocoaMQTTQOS.qos1)
        } else {
            print("Can't subscribe to \(topic). Not connected.")
        }
        
    }
    
    func publishToTopic(topic:String, payload:String) {
        
    }
    
    
}

protocol MQTTManagerDelegate {
    func mqttManagerConnectionChanged(mqttManager:MQTTManager)
}
