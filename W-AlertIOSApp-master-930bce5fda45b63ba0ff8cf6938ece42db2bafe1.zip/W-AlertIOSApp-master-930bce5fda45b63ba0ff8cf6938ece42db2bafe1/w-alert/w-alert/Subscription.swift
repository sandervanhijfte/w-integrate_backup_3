/*
 *  Name: Subscription.swift
 *  version: 1.0.0
 *  Created by: Waqas Ali Razzaq on 10/13/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

import Foundation
class Subscription {
    let id: Int64?
    var subscriptionId: String
    var subscriptionName: String
    var subscriptionKey: String
    var topicName: String
    var brokerURL: String
    var brokerUserName: String
    var brokerPassword: String
    
    init(id: Int64) {
        self.id = id
        subscriptionId = ""
        subscriptionName = ""
        subscriptionKey = ""
        topicName = ""
        brokerURL = ""
        brokerUserName = ""
        brokerPassword = ""
    }
    
    init(id: Int64, subscriptionId: String,subscriptionName: String, subscriptionKey: String,topicName: String,brokerURL: String, brokerUserName: String, brokerPassword: String) {
        self.id = id
        self.subscriptionId = subscriptionId
        self.subscriptionName = subscriptionName
        self.subscriptionKey = subscriptionKey
        self.topicName = topicName
        self.brokerURL = brokerURL
        self.brokerUserName = brokerUserName
        self.brokerPassword = brokerPassword
    }
}
