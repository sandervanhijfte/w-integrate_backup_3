/*
 *  Name: ViewController.swift
 *  version: 1.0.0
 *  Created by: Waqas Ali Razzaq on 9/13/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

//imports
import UIKit
import Alamofire
import SwiftyJSON

/* Class : LoginController
 * Description : This class is controller login view. It is responsible of authentication and registration of user.
 * Input : none
 */

class LoginController: UIViewController, UITextFieldDelegate {
    private var user = [User]()
    //Variables
    @IBOutlet var loginButton: CustomButton!
    @IBOutlet var passwordText: CustomTextField!
    @IBOutlet var userNameText: CustomTextField!
    @IBOutlet var subscriptionKeyText: CustomTextField!
    private var spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    private var loadingView: UIView = UIView()
    var alamoFireManager : SessionManager?
    
    let daoFactorry : DAOFactory = SqliteDAOFactory()
    var userDAO : UserDAO!
    var userPassword : String = ""
    
    override func viewDidAppear(_ animated: Bool) {
        do {
            self.userDAO = try self.daoFactorry.getUserDAO()
        } catch {
            
        }
        //  self.performSegue(withIdentifier: "goto_list", sender: self)
        // redirect()
    }
    /* Method : viewDidLoad
     * Description : This method is overrided to load the ui
     * Input : none
     */
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        userNameText.tag = 0
        passwordText.tag = 1
        loginButton.isEnabled = false
        self.userNameText.delegate = self
        self.passwordText.delegate = self
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    func redirect() {
        do{
            self.user = try [self.userDAO.getUserProfile()]
        } catch {
            print("user not found")
        }
        
        if (self.user.count == 1) {
           self.performSegue(withIdentifier: "goto_list", sender: self)
        }
    }
    
    /* Method : didReceiveMemoryWarning
     * Description : This method is overrided to handle memory leakages
     * Input : none
     */
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    /* Method : showActivityIndicator
     * Description : This method will be used to display the progress spinner
     * Input : none
     */
    
    func showActivityIndicator() {
        
        DispatchQueue.main.async() {
            self.loadingView = UIView()
            self.loadingView.frame = CGRect(x: 0.0, y: 0.0, width: 50.0, height: 50.0)
            self.loadingView.center = self.view.center
            self.loadingView.backgroundColor = UIColor(red: 0.26, green: 0.26, blue: 0.26, alpha: 0.7)
            self.loadingView.alpha = 0.7
            self.loadingView.clipsToBounds = true
            self.loadingView.layer.cornerRadius = 10
            self.spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
            self.spinner.frame = CGRect(x: 0.0, y: 0.0, width: 80.0, height: 80.0)
            self.spinner.center = CGPoint(x:self.loadingView.bounds.size.width / 2, y:self.loadingView.bounds.size.height / 2)
            self.loadingView.addSubview(self.spinner)
            self.view.addSubview(self.loadingView)
            self.spinner.startAnimating()
        }
    }
    
    /* Method : hideActivityIndicator
     * Description : This method will be used to hide the progress spinner
     * Input : none
     */
    func hideActivityIndicator() {
        
        DispatchQueue.main.async() {
            self.spinner.stopAnimating()
            self.loadingView.removeFromSuperview()
        }
    }
    
    /* Method : loginPressed
     * Description : This method will be invoked on Sign in button pressed
     * Input : The input param is touch event
     */
    @IBAction func loginPressed(_ sender: Any) {
        let userName: String = userNameText.text!
        let password: String = passwordText.text!
        
        if (Validator().validatePassword(passwordText: passwordText) && (Validator().validateUserName(userNameText: userNameText))) {
            showActivityIndicator()
            self.userPassword = password
            login(userName: userName, password: password)
        }
    }
    
    /* Method : login
     * Description : This method will be used to authenticate the user
     * Input : The input params are username and password
     */
    func login(userName: String, password: String) -> Void {
        
        IdentityandAccessManagement.authenticate(userName: userName, password: password) { (result) in
            
            if(result == "authenticated") {
                do {try ClientManagement.getUser(userName: userName) { (result) in
                    
                    if result["GetUserResponse"]["Result"]["ResponseCode"].stringValue == "CM-N-0000" {
                        print (result)
                        
                        let user = User(id: 1,
                                        userId: result["GetUserResponse"]["User"]["UserId"].stringValue,
                                        userName: result["GetUserResponse"]["User"]["UserName"].stringValue,
                                        password: self.userPassword,
                                        status: result["GetUserResponse"]["User"]["UserStatus"].stringValue,
                                        firstName: result["GetUserResponse"]["User"]["PersonalDetail"]["FirstName"].stringValue,
                                        lastName: result["GetUserResponse"]["User"]["PersonalDetail"]["LastName"].stringValue,
                                        mobileNo: "",
                                        email: result["GetUserResponse"]["User"]["ContactDetail"][1]["ChannelCode"].stringValue,
                                        roleId: result["GetUserResponse"]["User"]["UserId"].stringValue,
                                        organizationId: result["GetUserResponse"]["Client"]["OrganizationId"].stringValue,
                                        organizationName: result["GetUserResponse"]["Client"]["OrganizationName"].stringValue,
                                        organzationDomain: result["GetUserResponse"]["Client"]["OrganizationDomain"].stringValue)
                        
                        let userId = result["GetUserResponse"]["User"]["UserId"].stringValue
                        let organizationId = result["GetUserResponse"]["Client"]["OrganizationId"].stringValue
                        
                        do{
                            try self.userDAO.insert(user: user)
                        } catch {
                            self.alertDialog(message: "Error occur while save user record", title: "Error")
                            return
                        }
                        
                        EventSubscriptionManagement.getSubscriptionDetail(userName: userName, organizationId: organizationId, userId: userId) { (result) in
                            print(result)
                        }
                        self.registerDevice(userName: userName.components(separatedBy: "@")[0], clientContextUser: "admin@\(userName.components(separatedBy: "@")[1])")
                    }
                        
                    else if result["GetUserResponse"]["Result"]["ResponseCode"].stringValue == "CM-W-0001" {
                        
                        self.hideActivityIndicator()
                        self.alertDialog(message: Constants.USER_NOT_FOUND_MESSAGE,title: "Error")
                    }
                        
                    else {
                        
                        self.hideActivityIndicator()
                        self.alertDialog(message: Constants.UNEXPECTED_ERROR_MESSAGE,title: "Error")                        
                    }
                    }
                } catch {self.alertDialog(message: Constants.UNEXPECTED_ERROR_MESSAGE,title: "Error")}
                
            }
            else if (result == "unathenticated") {
                
                self.hideActivityIndicator()
                self.alertDialog(message: Constants.LOGIN_ERROR_MESSAGE,title: "Error")
            }
                
            else if (result == "timeOut") {
                
                self.hideActivityIndicator()
                self.alertDialog(message: Constants.SERVICE_UNAVAILABLE_MESSAGE,title: "Error")
            }
            else {
                
                self.hideActivityIndicator()
                self.alertDialog(message: Constants.UNEXPECTED_ERROR_MESSAGE,title: "Error")
            }
        }
    }
    
    /* Method : registerDevice
     * Description : This method will be used to regsiter the mobile device
     * Input : The input params are username and clientContext username
     */
    
    func registerDevice(userName: String, clientContextUser: String) -> Void {
        
        IdentityandAccessManagement.registerDevice(userName: userName, clientContextUser: clientContextUser) { (result) in
            if(result == "registered") {
                
                self.hideActivityIndicator()
                let alertController = UIAlertController(title: "Success", message: Constants.REGISTER_DEVICE_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
                let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {
                    (result : UIAlertAction) -> Void in
                    self.performSegue(withIdentifier: "goto_list", sender: self)
                }
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
            }
            else if (result == "unauthorized") {
                
                self.hideActivityIndicator()
                self.alertDialog(message: Constants.REGISTER_DEVICE_ERROR_MESSAGE,title: "Error")
            }
                
            else if (result == "timeOut") {
                
                self.hideActivityIndicator()
                self.alertDialog(message: Constants.SERVICE_UNAVAILABLE_MESSAGE,title: "Error")
            }
            else {
                
                self.hideActivityIndicator()
                self.alertDialog(message: Constants.UNEXPECTED_ERROR_MESSAGE,title: "Error")
            }
        }
    }
    
    /* Method : alertDialog
     * Description : This method will be used to display the Alert dialog
     * Input : The input value is message string
     */
    
    func alertDialog(message: String, title: String) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {
            (result : UIAlertAction) -> Void in
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    /* Method : textFieldDidEndEditing
     * Description : This method is overrided to handle the text field input validation
     * Input : name of text field
     */
    
    //TODO: improve the if/else
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if (textField.tag == 0 && userNameText.text!.contains("@w-alertdemo")) {
            
            self.subscriptionKeyText.isHidden = true
            if (Validator().validateUserName(userNameText: userNameText)) {
                loginButton.isEnabled = true
                userNameText.awakeFromNib()
            }
            else {
                loginButton.isEnabled = false
            }
        }
        else if (textField.tag == 0 && !userNameText.text!.contains("@w-alertdemo")) {
            
            self.subscriptionKeyText.isHidden = false
            if (Validator().validateUserName(userNameText: userNameText)) {
                loginButton.isEnabled = true
                userNameText.awakeFromNib()
            }
            else {
                loginButton.isEnabled = false
            }
        }
        if (textField.tag == 1 && userNameText.text!.contains("@w-alertdemo")) {
            
            self.subscriptionKeyText.isHidden = true
            if (Validator().validatePassword(passwordText: passwordText)) {
                loginButton.isEnabled = true
                passwordText.awakeFromNib()
            }
            else {
                
                loginButton.isEnabled = false
            }
        }
            
        else if (textField.tag == 1 && !userNameText.text!.contains("@w-alertdemo")) {
            
            self.subscriptionKeyText.isHidden = false
            if (Validator().validatePassword(passwordText: passwordText)) {
                loginButton.isEnabled = true
                passwordText.awakeFromNib()
            }
            else {
                
                loginButton.isEnabled = false
            }
        }
    }
    //(BOOL)textFieldShouldReturn:(UITextField *)textField;
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        print ("text return")
        if (textField.tag == 0) {
            userNameText.resignFirstResponder()
            
            return false
        }
        else if(textField.tag == 1) {
            passwordText.resignFirstResponder()
            return false
        }
        return true
    }
}
