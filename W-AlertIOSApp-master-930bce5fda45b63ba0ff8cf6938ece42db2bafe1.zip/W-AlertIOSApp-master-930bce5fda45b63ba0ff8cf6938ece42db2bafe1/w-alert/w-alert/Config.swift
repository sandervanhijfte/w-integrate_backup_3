//
//  Config.swift
//  w-alert
//
//  Created by Waqas Ali on 10/17/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation

struct Config {
    
    static let MQTTUsername = "user"
    static let MQTTPassword = "pass"
    static let MQTTHostname = "213.187.243.177"
    static let MQTTPort:UInt16 = 1883
    
}
