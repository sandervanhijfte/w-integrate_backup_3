/*
 *  Name: IdentityandAccessManagement.swift
 *  version: 1.0.0
 *  Created by: Waqas Ali Razzaq on 9/20/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

//imports
import Foundation
import Alamofire
import SwiftyJSON

class IdentityandAccessManagement : NSObject {
    
    /* Method      : login
     * Description : This method will be used to call the IdentityandAccessManagement API authenticate operation
     * Input       : The input params are username and password, completionHandler
     * Output      : String flag with status of authentication
     */
    
    class func authenticate(userName: String, password: String, completionHandler: @escaping (_ result: String) -> ()) {
        let headers: HTTPHeaders = [
            "Authorization": Constants.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER
        ]
        let parameters: Parameters = [
            "AuthenticateRequest": ["Header":["CMMHeader":["CorrelationId": UUID().uuidString]],"ClientContext":["UserName": userName],
                                    "UserName": userName.components(separatedBy: "@")[0],"UserPassword": password]]
         Alamofire.request(Constants.AUTHENTICATE_USER_URL, method: .post, parameters: parameters, encoding: JSONEncoding.default,headers: headers).responseJSON {
            response in
            
            switch(response.result){
            case .success:
                var json = JSON(response.result.value!)
                if json["AuthenticateResponse"]["AuthenticationStatus"].stringValue == "true" {
                    
                    completionHandler("authenticated")
                } else {
                    
                   completionHandler("unathenticated")
                }
            case .failure(let error):
                if error._code == NSURLErrorTimedOut {
                    
                  completionHandler("timeOut")
                } else {
                    
                  completionHandler("unexpectedError")
                }
            }
        }
    }
    
    /* Method      : registerDevice
     * Description : This method will be used to call the IdentityandAccessManagement API registerDevice operation
     * Input       : The input params are username and client context, completionHandler
     * Output      : String flag with status of registration
     */
    
    class func registerDevice(userName: String, clientContextUser: String, completionHandler: @escaping (_ result: String) -> ()) {
        
        let headers: HTTPHeaders = [
            "Authorization": Constants.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER
        ]
        let parameters: Parameters = [
            "RegisterDeviceRequest": ["Header":["CMMHeader":["CorrelationId": UUID().uuidString]],"ClientContext":["UserName": clientContextUser],
                                      "UserName": userName]]
        Alamofire.request(Constants.REGISTER_DEVICE_URL, method: .post, parameters: parameters, encoding: JSONEncoding.default,headers: headers).responseJSON {
            response in
            
            switch(response.result){
            case .success:
                var json = JSON(response.result.value!)
                if json["RegisterDeviceResponse"]["RegistrationStatus"].stringValue == "true" {
                    
                    completionHandler("registered")
                } else {
                    
                    completionHandler("unauthorized")
                }
            case .failure(let error):
                if error._code == NSURLErrorTimedOut {
                    
                    completionHandler("timeOut")
                } else {
                    
                    completionHandler("unexpectedError")
                }
            }
        }
    }
}
