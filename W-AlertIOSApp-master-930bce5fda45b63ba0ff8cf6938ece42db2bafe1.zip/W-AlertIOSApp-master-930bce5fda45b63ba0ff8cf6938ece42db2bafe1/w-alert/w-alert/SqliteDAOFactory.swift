//
//  SqliteDAOFactory.swift
//  w-alert
//
//  Created by Arqam Amin on 10/11/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation

class SqliteDAOFactory: DAOFactory {
    
    override func getAlertDAO() throws -> AlertDAO {
        return try SqliteAlertDAO(connection: try SQLiteConnection.getConnection())
    }
    
    override func getUserDAO() throws -> UserDAO {
        return try SqliteUserDAO(connection: try SQLiteConnection.getConnection())
    }
}
