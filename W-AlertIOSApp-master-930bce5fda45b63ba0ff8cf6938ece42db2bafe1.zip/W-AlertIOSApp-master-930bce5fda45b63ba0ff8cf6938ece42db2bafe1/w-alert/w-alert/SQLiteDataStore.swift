/*
 *  Name: SQLiteDataStore.swift
 *  version: 1.0.0
 *  Created by: Waqas Ali Razzaq on 9/17/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

import Foundation
import SQLite

//class SQLiteDataStore {

//    private let user = Table("t_user")
//    private let id = Expression<Int64>("id")
//    private let userId = Expression<String>("userId")
//    private let lastName = Expression<String>("lastName")
//    private let firstName = Expression<String>("firstName")
//    private let email = Expression<String>("email")
//    private let userName = Expression<String>("userName")
//    private let roleId = Expression<String>("roleId")
//
//    static let instance = SQLiteDataStore()
//    private let db: Connection?
//
//    private init() {
//        let path = NSSearchPathForDirectoriesInDomains(
//            .documentDirectory, .userDomainMask, true
//            ).first!
//
//        do {
//            db = try Connection("\(path)/W-Alert.sqlite3")
//            createTable()
//        } catch {
//            db = nil
//            print ("Unable to open database")
//        }
//    }
//
//    func createTable() {
//        do {
//            try db!.run(user.create(ifNotExists: true) { table in
//                table.column(id, primaryKey: true)
//                table.column(userId)
//                table.column(lastName)
//                table.column(userName)
//                table.column(firstName)
//                table.column(email, unique: true)
//                table.column(roleId)
//            })
//        } catch {
//            print("Unable to create table")
//        }
//    }
//
//    func addUser(cUserId: String, cLastName: String, cUserName: String, cFirstName: String, cEmail: String, cRoleId: String) -> Int64? {
//        do {
//            let insert = user.insert(userId <- cUserId, lastName <- cLastName, userName <- cUserName, firstName <- cFirstName, email <- cEmail, roleId <- cRoleId)
//            let id = try db!.run(insert)
//
//            return id
//        } catch {
//            print("Insert failed")
//            return nil
//        }
//    }
//    func getUserProfile() -> User
//    {
//        let myUser = self.getUser()[getUser().count - 1]
//        return myUser
//    }
//
////    func getUser() -> [User] {
////        var users = [User]()
////
////        do {
////            for user in try db!.prepare(self.user) {
////                users.append(User(
////                    id: user[id],
////                    userId: user[userId],
////                    lastName: user[lastName],
////                    userName: user[userName],
////                    firstName: user[firstName],
////                    email: user[email],
////                    roleId: user[roleId]))
////            }
////        } catch {
////            print("Select failed")
////        }
////
////        return users
////    }
//
//    func deleteContact(cid: Int64) -> Bool {
//        do {
//            let myUser = user.filter(id == cid)
//            try db!.run(myUser.delete())
//            return true
//        } catch {
//
//            print("Delete failed")
//        }
//        return false
//    }
//    
 /*   func updateContact(cid:Int64, newContact: Contact) -> Bool {
        let contact = contacts.filter(id == cid)
        do {
            let update = contact.update([
                name <- newContact.name,
                username <- newContact.username,
                address <- newContact.address
                ])
            if try db!.run(update) > 0 {
                return true
            }
        } catch {
            print("Update failed: \(error)")
        }
        
        return false
    }*/
//}

