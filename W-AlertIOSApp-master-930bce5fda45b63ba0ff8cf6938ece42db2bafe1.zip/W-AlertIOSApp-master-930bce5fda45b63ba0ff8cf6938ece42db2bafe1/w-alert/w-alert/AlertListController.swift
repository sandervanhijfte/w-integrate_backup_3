//
//  AlertListController.swift
//  Login
//
//  Created by Waqas Ali Razzaq on 8/24/17.
//  Copyright © 2017 Waqas Ali Razzaq. All rights reserved.
//  Initial implementation :mehak zia cheema
//
import UIKit

class AlertListController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    @IBOutlet weak var menuBarButton: UIBarButtonItem!
    @IBOutlet var tapGesture: UITapGestureRecognizer!
    @IBOutlet weak var colorLabel: UILabel!
    @IBOutlet weak var severity: UILabel!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var alertCount: UILabel!
    
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var alertSelectCount: UILabel!
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var alerListView: UIView!
    @IBOutlet weak var cancelButton: UIButton!
    
    
    @IBOutlet weak var help: UIButton!
    @IBOutlet weak var deleteView: UIView!
    @IBOutlet weak var alertTable: UITableView!
    
    // use to save select alerts id for delete record
    var set = NSMutableSet()
    
    // use to track range and limit of record
    var alertOffset = 0
    var alertLimit = 10
    var alertsSelect = 0
    
    var numberOfAlerts: Int?
    
    let daoFactorry : DAOFactory = SqliteDAOFactory()
    
    // alert database object use for apply operation on database
    var alertDAO : AlertDAO!
    var userDAO : UserDAO!
    
    // list of records that get from database
    var alertList = [Alert]()
    
    var isNewDataLoading = false

    var selectView = false
    
    var searchActive : Bool = false
    
    private var severtyColor:UIColor!
    
    private let refreshControl = UIRefreshControl()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        initializeView()
        alertTable.delegate = self
        searchBar.delegate = self
        searchBar.layer.borderWidth = 1
        searchBar.layer.borderColor = UIColor.lightGray.cgColor
        searchBar.layer.cornerRadius = 5
        searchBar.layer.masksToBounds = true
        searchBar.barTintColor = UIColor.white
        searchBar.frame = CGRect(x: searchBar.frame.origin.x, y: searchBar.frame.origin.y, width: searchBar.frame.size.width, height: 37)
        menuView.layer.shadowOpacity = 0.4
        menuView.isHidden = true
        alertTable.tableFooterView = UIView(frame: .zero)
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.title = "W-Alert"
        tapGesture.isEnabled = false
        navigationItem.rightBarButtonItem = menuBarButton
        alertTable.isScrollEnabled = true
        
        if #available(iOS 10.0, *) {
            alertTable.refreshControl = refreshControl
        } else {
            alertTable.addSubview(refreshControl)
        }
        
        refreshControl.addTarget(self, action: #selector(refreshAlertData(_:)), for: .valueChanged)
        refreshControl.tintColor = UIColor(red:0.25, green:0.72, blue:0.85, alpha:1.0)
        refreshControl.attributedTitle = NSAttributedString(string: "Fetching New Alerts Data ...")
    }
    
    @objc private func refreshAlertData(_ sender: Any) {
        do{
            try refreshAlerts()
        }
        catch{}
    }
    
    //temprary helper function which will remove in future
    private func initializeView() {
        
        do {
            self.alertDAO = try self.daoFactorry.getAlertDAO()

        //    for i in 1...50 {
                insertRecord(1)
            
        //}
            self.alertList = try alertDAO.getAlerts(from: alertOffset, limit: alertLimit)
            self.alertOffset += self.alertLimit
            self.numberOfAlerts = try self.alertDAO.getTotalNumberOfAlerts()
            updateAlertsInfo()
        } catch AlertError.UnableToCreateConnection {
            printErrorMessage(errorMessage: "unable to create database object.")
        } catch AlertError.CreateAlertTableFail {
            printErrorMessage(errorMessage: "unable to create database object")
        } catch AlertError.ReadAlertsFail {
            printErrorMessage(errorMessage: "error occure while get all records.")
        } catch AlertError.CountAlertRecordFail {
            printErrorMessage(errorMessage: "error occure while get all records.")
        } catch {
            printErrorMessage(errorMessage: "unknown error occure. Because of \(error)")
        }
    }
    
    //temprary helper function which will remove in future
    private func insertRecord (_ idNum: Int) {
        var alert = AlertDetail(id: 1, alertId:"some id # \(idNum + 1)", timeStamp: "2017-10-24 14:21:38", severity: "high", alertType: "cretical", alertTitle: "Tomcat", alertMessage: "Error: - Request Exception javax.xml.ws.WebServiceException", hostName: "linux", componentName: "Wso2", unread: true, environmentName: "Linux")
        addAlert(alert)
        
        alert = AlertDetail(id: 1, alertId:"some id # \(idNum + 2)", timeStamp: "2017-10-24 14:22:38", severity: "low", alertType: "high", alertTitle: "wso2", alertMessage: "Error: - Request Exception javax.xml.ws.WebServiceException", hostName: "linux", componentName: "Java", unread: true, environmentName: "Linux")
        addAlert(alert)
        
        alert = AlertDetail(id: 1, alertId:"some id # \(idNum + 3)", timeStamp: "2017-10-18 14:21:38", severity: "low", alertType: "high", alertTitle: "wso2", alertMessage: "Error: - Request Exception javax.xml.ws.WebServiceException", hostName: "linux", componentName: "Eclipse", unread: true, environmentName: "Linux")
        addAlert(alert)
        
        alert = AlertDetail(id: 1, alertId:"some id # \(idNum + 4)", timeStamp: "2017-10-18 14:21:38", severity: "normal", alertType: "high", alertTitle: "wso2", alertMessage: "Error: - Request Exception javax.xml.ws.WebServiceException", hostName: "linux", componentName: "Xcode", unread: true, environmentName: "Linux")
        addAlert(alert)
    }
    
    //temprary helper function which will remove in future
    private func addAlert(_ alert: AlertDetail) {
        do {
           _ =  try alertDAO.insertAlert(alert: alert)
        }catch {
            print ("\(error)")
        }
    }
    
    /* Method : cancelDelete
     * Description : This method will be used to disable the delete view
     * Input : none
     */
    @IBAction func cancelDelete(_ sender: Any) {
        deleteView.isHidden = true
        deleteView.isUserInteractionEnabled = false
        searchView.isHidden = false
        searchView.isUserInteractionEnabled = true
        searchBar.isUserInteractionEnabled = true
        help.isEnabled = true
        
        _ = self.alertTable.visibleCells.enumerated().map{$0.element.isSelected = false;$0.element.accessoryType = .none}
        set.removeAllObjects()
    }
    
    /* Method : deleteButton
     * Description : This method will be used to delete selected alerts
     * Input : Any
     */
    @IBAction func deleteButton(_ sender: Any) {
        deleteView.isHidden = true
        deleteView.isUserInteractionEnabled = false
        searchView.isHidden = false
        searchView.isUserInteractionEnabled = true
        searchBar.isUserInteractionEnabled = true
        help.isEnabled = true
        do {
            let rmIndexis = set.allObjects as! [Int]
            let v:[Int64] = self.alertList.enumerated().filter{  rmIndexis.contains($0.offset) }.map{
               print($0.element.id!); return $0.element.id!
            }
            try self.alertDAO.deleteMultipleAlerts(alertIds: v)
            let numberOfDeleteAlerts = set.count
            if (numberOfDeleteAlerts > alertOffset) {
                alertOffset = 0
            } else {
                alertOffset -= numberOfDeleteAlerts
                self.numberOfAlerts! -= numberOfDeleteAlerts
            }
            updateAlertsInfo()
            
            self.alertList = self.alertList.enumerated().filter{ !rmIndexis.contains($0.offset)}.map{$0.element}
            set.removeAllObjects()
            setAccessoryType(type: .none)
            self.alertTable.reloadData()
        } catch {
            printErrorMessage(errorMessage: "unable to search records with keywords")
        }
    }
    
    /* Method : selectAllButton
     * Description : This method will be used to select all the alerts that are present in ui
     * Input : Any
     */
    @IBAction func selectAllButton(_ sender: Any) {
        setAccessoryType(type: .checkmark)
        set.addObjects(from: Array(0...alertList.count))
        self.alertSelectCount.text = "Select: \(alertList.count)"
        changeDeleteButtonState()
    }
    
    /* Method : tableView: numberOfRowsInSection
     * Description : This method will be used to get total number of rows
     * Input : none
     */
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return(alertList.count)
    }
    
    /* Method : tableView: didSelectRowAt
     * Description : This method will be used to perform action when a row is seleted
     * Input : none
     */
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = alertTable.cellForRow(at: indexPath) as! AlertListTableViewCell
        if(deleteView.isHidden == true) {
            cell.isSelected = false
            let viewController = self.storyboard?.instantiateViewController(withIdentifier: "AlertDetailControllerId") as! AlertDetailController
            //viewController.alert = alertList[indexPath.row]
            viewController.indexPath = indexPath
            viewController.delegate = self
            self.navigationController?.pushViewController(viewController, animated: true)
        }
        else {
            if(cell.accessoryType == UITableViewCellAccessoryType.none) {
                cell.accessoryType = UITableViewCellAccessoryType.checkmark
            }
            cell.servityColor.backgroundColor = severtyColor
            set.add(indexPath.row)
            self.alertsSelect = set.count
            self.alertSelectCount.text = "Select : \(set.count)"
            updateAlertsInfo()
            changeDeleteButtonState()
        }
    }
    
    /* Method : tableView: willSelectRowAt
     * Description : This method used to get the servity color
     * Input : none
     */
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath?
    {
        let cell = tableView.cellForRow(at: indexPath) as! AlertListTableViewCell
        
        severtyColor = cell.servityColor.backgroundColor
        
        return indexPath;
    }
    
    /* Method : tableView: didDeselectRowAt
     * Description : This method used to disable delete view
     * Input : none
     */
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if(deleteView.isHidden == false) {
            if(alertTable.cellForRow(at: indexPath)?.accessoryType == UITableViewCellAccessoryType.checkmark) {
                alertTable.cellForRow(at: indexPath)?.accessoryType = UITableViewCellAccessoryType.none
            }
            set.remove(indexPath.row)
            self.alertsSelect = set.count
            self.alertSelectCount.text = "Select : \(alertsSelect)"
            updateAlertsInfo()
            changeDeleteButtonState()
        }
    }
    
    /* Method : setAccessoryType
     * Description : This method used to set the table view cell
     * Input : none
     */
    func setAccessoryType(type: UITableViewCellAccessoryType) {
       _ = self.alertTable.visibleCells.enumerated().map{$0.element.isSelected = true;$0.element.accessoryType = type}
    }
    
    /* Method : handleLogPressGesture
     * Description : This method used to enable delete view
     * Input : none
     */
    func handleLogPressGesture(longPressGesture: UILongPressGestureRecognizer) {
        searchView.isHidden = true
        searchView.isUserInteractionEnabled = false
        searchBar.isUserInteractionEnabled = false
        help.isEnabled = false
        deleteView.isHidden = false
        deleteView.isUserInteractionEnabled = true
    }
    
    /* Method : tableView: commit: forRowAt
     * Description : This method will be use to delete alert
     * Input : UITableView, UITableViewCellEditingStyle, IndexPath
     */
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            deleteAlertItem(indexPath: indexPath)
        }
    }
    
    /* Method : deleteAlertItem
     * Description : This method will be use to delete single alert from database and from ui
     * Input : none
     */
    func deleteAlertItem(indexPath: IndexPath) {
        // remove from database
        do{
            try self.alertDAO.deleteAlert(alertId: alertList[indexPath.row].id!)
        }catch {
            printErrorMessage(errorMessage: "unable to delete record")
        }
        
        // remove the item from the data model
        alertList.remove(at: indexPath.row)
        // delete the table view row
        alertTable.deleteRows(at: [indexPath], with: .fade)
        changeDeleteButtonState()
    }
    
    
    /* Method : cellForRowAt
     * Description : This method will be used to enter the data in cell
     * Input : none
     */
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector((AlertListController.handleLogPressGesture)))
        longPressGesture.numberOfTouchesRequired = 1
        longPressGesture.minimumPressDuration = 1.0
        alertTable.addGestureRecognizer(longPressGesture)
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "AlertTableCell", for: indexPath) as! AlertListTableViewCell
        let myAlert = alertList[indexPath.row]
        initializeCellWithValues(cell: cell, alert: myAlert)
        return (cell)
    }
    
    private func initializeCellWithValues(cell: AlertListTableViewCell, alert: Alert) {
        cell.AgentName.text = alert.componentName
        cell.ErrorMessage.text = alert.alertMessage
        cell.AlertTime.text = Time.getRelativeDateTime(alert.timeStamp)
        cell.servityColor.backgroundColor = SeverityColor.getRGBColor(fromType: alert.severity)
        
    }
    
    /* Method : handleTapGesture
     * Description : This method is used to hide the menu
     * Input : none
     */
    @IBAction func handleTapGesture(_ sender: Any) {
        if(tapGesture.isEnabled == true)
        {
            viewMenu((Any).self)
        }
    }
    
    /* Method : ViewMenu
     * Description : This method will be used to view the menu
     * Input : none
     */
    @IBAction func viewMenu(_ sender: Any) {
        
        selectView = !selectView
        menuView.isHidden = !menuView.isHidden
        menuView.alpha = 1.0
        if(menuView.isHidden == false) {
            searchView.isUserInteractionEnabled = false
            alertTable.isUserInteractionEnabled = false
            alertCount.alpha = 0.2
            alertTable.alpha = 0.2
            searchView.alpha = 0.2
            deleteView.alpha = 0.2
            tapGesture.isEnabled = true
        }
        else {
            searchView.isUserInteractionEnabled = true
            alertTable.isUserInteractionEnabled = true
            alertCount.alpha = 1.0
            alertTable.alpha = 1.0
            searchView.alpha = 1.0
            deleteView.alpha = 1.0
            tapGesture.isEnabled = false
        }
    }
    
    /* Method : ViewMenu
     * Description : This method will be called when press question mark.
     * Input : none
     */
    @IBAction func helpButtonPressed(_ sender: Any) {
        let signOutDialog = UIAlertController(title: "Search Criteria", message: "Search is working on:\nTitle, Severity, Alert type, Component name, Date/time.\n\n*Search on message detail is comming soon.", preferredStyle: UIAlertControllerStyle.alert)
        
        signOutDialog.addAction(UIAlertAction(title: "cancel", style: UIAlertActionStyle.default, handler: { (action) in
        }))
        
        self.present(signOutDialog, animated: false, completion: nil)
    }
    
    @IBAction func signOutButtonPressed(_ sender: Any) {
        
        
        let signOutDialog = UIAlertController(title: Constants.SIGN_OUT_TITLE, message: Constants.SIGN_OUT_MESSAGE, preferredStyle: UIAlertControllerStyle.alert)
        
        
        signOutDialog.addAction(UIAlertAction(title: Constants.CANCEL, style: UIAlertActionStyle.default, handler: { (action) in
        }))
        
        signOutDialog.addAction(UIAlertAction(title: Constants.DISCONNECT_AND_SIGN_OUT, style: UIAlertActionStyle.default, handler: { (action) in
            
            //TODO: Disconnect & Sign Out implementatiom

        }))
        
        
        signOutDialog.addAction(UIAlertAction(title: Constants.SIGN_OUT, style: UIAlertActionStyle.default, handler: { (action) in
            
            //Sign Out implementatiom

        }))
        
        let widthConstraint: NSLayoutConstraint = NSLayoutConstraint(item: signOutDialog.view, attribute: NSLayoutAttribute.width, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: NSLayoutAttribute.notAnAttribute , multiplier: 1, constant: 480.0)
        signOutDialog.view.addConstraint(widthConstraint)
        //signOutDialog.
        
        self.present(signOutDialog, animated: false, completion: nil)
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        //Bottom Refresh
        print("load scroll")
        // if scrollView == alerListView {
        
        if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height)
        {
            if !isNewDataLoading {
                
                if isHasMoreData() {
                    
                    isNewDataLoading = true
                    loadMoreAlerts()
                }
            }
        }
        // }
    }
    
    
    /* Method : isHasMoreData
     * Description : This method will be use to check is more alerts are present in databse or not
     * Input : void
     */
    func isHasMoreData() -> Bool {
        if (alertOffset + alertLimit) < numberOfAlerts! {
            return true
        }
        return false
    }
    
    /* Method : loadMoreAlerts
     * Description : This method will be use to load alerts from database for specified range
     * Input : void
     */
    func loadMoreAlerts() {
        
        do{
            var newAlerts : [Alert]!

            if (searchActive == true) {
                newAlerts = try self.alertDAO.searchAlert(searchValue: searchBar.text!, from: alertOffset, limit: alertLimit)
            }
            else {
                newAlerts = try self.alertDAO.getAlerts(from: alertOffset, limit: alertLimit)
            }
            self.alertOffset += self.alertLimit
            self.alertList += newAlerts
            updateAlertsInfo()
            self.alertTable.reloadData()
        } catch {
            printErrorMessage(errorMessage: "unable to load more Alerts. Because of \(error)")
        }
        isNewDataLoading = false
    }
    
    
    /* Method : searchBarTextDidEndEditing
     * Description : This method will be called when user stop editing text in UISearchBar
     * Input : UISearchBar
     */
    // may be we need in future
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        print("\nend calling")
    }
    
    /* Method : searchBarCancelButtonClicked
     * Description : This method will be called when user click X button of UISearchBar
     * Input : UISearchBar
     */
    // Due to bug in ios this method is not call
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        print("searchBarCancelButtonClicked")
    }
    
    /* Method : searchBar:textDidChange
     * Description : This method will be called when text is change in UISearchBar if user clear the text than hide the keybord
     * Input : UISearchBar, String
     */
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBar.text == nil || searchBar.text == "" {
            do {
                try refreshAlerts()
                searchBar.perform(#selector(self.resignFirstResponder), with: nil, afterDelay: 0.1)
            } catch {
                printErrorMessage(errorMessage: "unable to search records. Because of \(error)")
            }
        } else {
            searchAlertWithMatchKeyword(keyword: searchText)
        }
    }
    
    func refreshAlerts() throws {
        alertInfoReset()
        self.alertList = try self.alertDAO.getAlerts(from: alertOffset, limit: alertLimit)
        updateAlertsInfo()
        alertTable.reloadData()
        searchActive = false
        refreshControl.endRefreshing()
    }
    
    /* Method : searchBarSearchButtonClicked
     * Description : This method will be called whenn user clink search button to search/filter alerts
     * Input : UISearchBar
     */
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        searchAlertWithMatchKeyword(keyword: searchBar.text!)
        searchBar.resignFirstResponder()
    }
    
    /* Method : searchAlertWithMatchKeyword
     * Description : This method will be use to get search/filtered alerts from database and update table view
     * Input : String
     */
    private func searchAlertWithMatchKeyword(keyword: String) {
        do {
            alertInfoReset()
            self.numberOfAlerts = try alertDAO.getTotalNumberOfSearchAlerts(searchValue: keyword)
            self.alertList = try alertDAO.searchAlert(searchValue: keyword, from: alertOffset, limit: alertLimit)
            updateAlertsInfo()
            searchActive = true
            self.alertTable.reloadData()
        }catch {
            printErrorMessage(errorMessage: "unable to search records with keywords. Because of \(error)")
        }
    }
    
    /* Method : alertInfoReset
     * Description : This method will be use to reset the alerts trck info
     * Input : void
     */
    private func alertInfoReset() {
        self.numberOfAlerts = 0
        self.alertOffset = 0
        self.alertLimit = 10
        self.alertList.removeAll()
        self.alertTable.reloadData()
        isNewDataLoading = false
    }
    
    /* Method : updateAlertsInfo
     * Description : This method will be use to update number of logs info
     * Input : void
     */
    private func updateAlertsInfo() {
        self.alertCount.text = "1 to \(alertList.count) of \(String(describing: numberOfAlerts!))";
    }
    
    /* Method : changeDeleteButtonState
     * Description : This method will be use to enable or disable the delete button
     * Input : void
     */
    private func changeDeleteButtonState() {
        
        deleteButton.isEnabled = self.set.count > 0
    }
    
    /* Method : printErrorMessage
     * Description : This method will be use to print error message
     * Input : String
     */
    private func printErrorMessage(errorMessage: String) {
        print(errorMessage)
    }
    
}

