//
//  Alert.swift
//  w-alert
//
//  Created by Arqam Amin on 10/6/17.
//  Copyright © 2017 WeIntegrate B.V. All rights reserved.
//

import Foundation

class Alert {
    let id: Int64?
    var timeStamp: String
    var severity: String
    var alertMessage: String
    var componentName: String
  
    
    init(id: Int64) {
        self.id = id
        timeStamp = ""
        severity = ""
        alertMessage = ""
        componentName = ""
   
    }
    
    init(id: Int64, timeStamp: String, severity: String, alertMessage: String, componentName: String) {
     
        self.id = id
        self.timeStamp = timeStamp
        self.severity = severity
        self.alertMessage = alertMessage
        self.componentName = componentName
    }
}
