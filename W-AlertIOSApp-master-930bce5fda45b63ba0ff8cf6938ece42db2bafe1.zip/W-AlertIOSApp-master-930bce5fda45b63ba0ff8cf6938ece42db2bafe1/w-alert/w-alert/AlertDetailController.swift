//
//  DetailAlertController.swift
//  w-alert
//
//  Created by Mehak Zia on 28/09/2017.
//  Copyright © 2017 WeIntegrate. All rights reserved.
//  Initial implementation :mehak zia cheema
//

import UIKit

class AlertDetailController: UIViewController {

    @IBOutlet weak var detailAlertView: UIView!
    @IBOutlet weak var detailMessage: UITextView!

    
    @IBOutlet var alertLabel: UILabel!
    @IBOutlet weak var type: UILabel!
    @IBOutlet var time: UILabel!
    @IBOutlet var date: UILabel!
    @IBOutlet var severty: UILabel!
    
    let daoFactorry : DAOFactory = SqliteDAOFactory()
    
    // alert database object use for apply operation on database
    var alertDAO : AlertDAO!
    
    var alertDetail : AlertDetail!
    var indexPath : IndexPath?
    weak var delegate : AlertListController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       initView()
        detailAlertView.layer.borderColor = UIColor(red: 132/255, green: 151/255, blue: 176/255, alpha: 255).cgColor
        detailAlertView.layer.borderWidth = 1.0
        detailAlertView.layer.masksToBounds = false
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .trash, target: self, action: #selector(deleteButtonPressed))
        
        detailMessage.text="\n\(String(describing: alertDetail.alertMessage)). It failed with:  \n \n \nID: \(String(describing: alertDetail.alertId))"
        alertLabel.text = alertDetail.componentName
        type.text = "From: \(alertDetail.hostName)"
        time.text = Time.getTime(alertDetail.timeStamp)
        date.text = Time.getDate(alertDetail.timeStamp)
        severty.backgroundColor = SeverityColor.getRGBColor(fromType: alertDetail.severity)

        // Do any additional setup after loading the view.
        
        detailMessage.isScrollEnabled = true
    }
    
    private func initView() {
        do {
        self.alertDAO = try self.daoFactorry.getAlertDAO()
            self.alertDetail = try alertDAO.getAlert(id: delegate.alertList[(indexPath?.row)!].id!)
        }catch {
            
        }
    }
    
    /* Method : deleteButtonPressed
     * Description : This method will be used to delete alert
     * Input : none
     */
    
    @IBAction func deleteButtonPressed(_ sender: Any) {
        let deleteAlertDialog = UIAlertController(title: "", message: "Are you sure you want to delete?", preferredStyle: UIAlertControllerStyle.alert)
        deleteAlertDialog.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: { (action) in
        }))
        
        deleteAlertDialog.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
            
            self.delegate.deleteAlertItem(indexPath: self.indexPath!)
            self.navigationController?.popViewController(animated: true)
            //self.dismiss(animated: true, completion: nil)
        }))
        
        self.present(deleteAlertDialog, animated: false, completion: nil)
    }


}
