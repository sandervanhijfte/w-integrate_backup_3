/*
 *  Name: ClientManagement.swift
 *  version: 1.0.0
 *  Created by: Waqas Ali Razzaq on 9/20/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

import Foundation
import Alamofire
import SwiftyJSON

class ClientManagement: NSObject {

    /* Method : updateUser
     * Description : This method will be used to update the user details
     * Input : UserId, FirstName, ListName, Email, OrganizationId, completionHandler
     */
    
    class func updateUser(userId: String, firstName: String, lastName: String, email: String, organizationId: String ,completionHandler: @escaping (JSON) -> ()) {
        let parameters: Parameters = ["UpdateUserRequest": ["Header":["CMMHeader":["CorrelationId": UUID().uuidString]],"ClientContext":["OrganizationId":organizationId],"UserId": userId,"User":["FirstName":firstName,"LastName":lastName,"ContactDetail":["ChannelCode": email,"ChannelType": "Email"]]]]
        
        let headers: HTTPHeaders = [
            "Authorization": Constants.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER,
            "Content-Type": Constants.Content_Type]
        print(parameters)
        Alamofire.request(Constants.UPDATE_USER_URL, method: .put, parameters: parameters, encoding: JSONEncoding.default,headers: headers).responseJSON {
            response in
            print(response)
            switch(response.result){
            case .success:
                var json = JSON(response.result.value!)
                print (json)
                if json["UpdateUserResponse"]["Result"]["ResponseCode"].stringValue == "CM-N-0000" {
                    
                    completionHandler("true")
                } else if json["UpdateUserResponse"]["Result"]["ResponseCode"].stringValue == "CM-E-9999" {
                    
                    completionHandler("false")
                } else {
                    completionHandler("false")
                }
            case .failure(let error):
                if error._code == NSURLErrorTimedOut {
                    
                    completionHandler("false")
                } else {
                    
                    completionHandler("false")
                }
            }
        }
    }
    
    /* Method : getUser
     * Description : This method will be used to get the user details
     * Input : UserName, completionHandler
     */
    
    class func getUser(userName: String ,completionHandler: @escaping (JSON) -> ()) {
        
        let headers: HTTPHeaders = [
                "Authorization": Constants.ACCESS_TOKEN,
                "Accept": Constants.ACCEPT_HEADER
        ]
        let parameters = "?UserName=\(userName)&CorrelationId=\(UUID().uuidString)&OrganizationId=1234"
        let allowedCharacterSet = (CharacterSet(charactersIn: "@").inverted)
        let escapedString = parameters.addingPercentEncoding(withAllowedCharacters: allowedCharacterSet)
        Alamofire.request(Constants.GET_USER_URL+escapedString!, method: .get, encoding: URLEncoding.default,headers: headers).responseJSON {  response in
            
            switch(response.result){
            case .success:
                let json = JSON(response.result.value!)
                completionHandler(json)
            case .failure(let error):
                if error._code == NSURLErrorTimedOut {
                    let json = JSON(["error": "timeOut"])
                    completionHandler(json)
                } else {
                    let json = JSON(["error": "unexpectedError"])
                    completionHandler(json)
                    print (error)
                }
                //completionHandler(JSON(response.result.value!))
            }
        }
    }
}
