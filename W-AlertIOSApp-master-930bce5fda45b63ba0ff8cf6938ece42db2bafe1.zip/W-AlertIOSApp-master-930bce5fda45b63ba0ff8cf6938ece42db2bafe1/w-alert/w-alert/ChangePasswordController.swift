//
//  CreatePasswordController.swift
//  w-alert
//
//  Created by Mehak Zia on 27/09/2017.
//  Copyright © 2017 WeIntegrate. All rights reserved.
//  Initial implementation :mehak zia cheema
//

import UIKit

class ChangePasswordController: UIViewController {


    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cancelButtonPressed(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
}
