/*
 *  Name: EventSubscriptionManagement.swift
 *  version: 1.0.0
 *  Created by: Waqas Ali Razzaq on 10/05/17.
 *  Copyright © 2017 WeIntegrate B.V. All rights reserved.
 */

//imports
import Foundation
import Alamofire
import SwiftyJSON


class EventSubscriptionManagement {

    /* Method : getSubscriptionDetail
     * Description : This method will be used to get the getSubscriptionDetail
     * Input : UserName, completionHandler
     */
    
    class func getSubscriptionDetail(userName: String, organizationId: String, userId: String ,completionHandler: @escaping (JSON) -> ()) {
        
        let headers: HTTPHeaders = [
            "Authorization": Constants.ACCESS_TOKEN,
            "Accept": Constants.ACCEPT_HEADER
        ]
        let parameters: Parameters = [
            "GetEventSubscriptionRequest": ["Header":["CMMHeader":["CorrelationId": UUID().uuidString]],"ClientContext":["OrganizationId": organizationId],"UserId": userId]]
        let allowedCharacterSet = (CharacterSet(charactersIn: "@").inverted)
        let escapedString = userId.addingPercentEncoding(withAllowedCharacters: allowedCharacterSet)
        Alamofire.request(Constants.GET_SUBSCRIPTION_URL+escapedString!, method: .post, parameters: parameters, encoding: JSONEncoding.default,headers: headers).responseJSON {  response in
            
            switch(response.result){
            case .success:
                let json = JSON(response.result.value!)
                completionHandler(json)
            case .failure(let error):
                if error._code == NSURLErrorTimedOut {
                    
                } else {
                    print (error)
                }
                completionHandler(JSON(response.result.value!))
            }
        }
        
    }

}
