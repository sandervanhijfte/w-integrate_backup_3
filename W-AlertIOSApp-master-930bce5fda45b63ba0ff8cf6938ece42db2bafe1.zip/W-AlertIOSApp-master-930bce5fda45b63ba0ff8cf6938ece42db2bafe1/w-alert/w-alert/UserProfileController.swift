//
//  ProfileController.swift
//  w-alert
//
//  Created by Mehak Zia on 27/09/2017.
//  Copyright © 2017 WeIntegrate. All rights reserved.
//  Initial implementation :mehak zia cheema
//

import UIKit

class UserProfileController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var userNameText: CustomTextField!
    @IBOutlet weak var firstNameText: CustomTextField!
    @IBOutlet weak var lastNameText: CustomTextField!
    @IBOutlet weak var emailText: CustomTextField!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var firstNameHelpButton: UIButton!
    @IBOutlet weak var lastNameHelpButton: UIButton!
    @IBOutlet weak var emailHelpButton: UIButton!
    var enableEdit = false
    var rightBarButton: UIBarButtonItem?
    var firstName = ""
    var lastName = ""
    var email = ""
    private var spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    private var loadingView: UIView = UIView()

    
    let daoFactorry : DAOFactory = SqliteDAOFactory()
    var userDAO : UserDAO!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do {
            self.userDAO = try self.daoFactorry.getUserDAO()
        } catch {
            
        }
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .compose, target: self, action: #selector(editButtonPressed))
        self.title = "Profile"
        self.firstNameText.delegate = self
        self.lastNameText.delegate = self
        self.emailText.delegate = self
        userNameText.tag = 0
        firstNameText.tag = 1
        lastNameText.tag = 2
        emailText.tag = 3
        //self.userNameText.delegate = self

        getUser()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    /* Method : backButton
     * Description : This method will be used to perform the functionality of backButton
     * Input : none
     */
    
    func backButton(_ sender: Any) {
        if(enableEdit == true) {
            enableEdit = !enableEdit
            viewProfile()
        }
        else
        {
            navigationController?.popViewController(animated: true)
        }
    }
    
    /* Method : cancelButtonPressed
     * Description : This method will be used to cancel the updation of edit
     * Input : none
     */
    
    @IBAction func cancelButtonPressed(_ sender: Any) {
        enableEdit = !enableEdit
        viewProfile()
    }
    
    /* Method : editButtonPressed
     * Description : use to enable or disable editing of user information
     * Input : none
     */
    
    func editButtonPressed(_ sender: Any) {
        
        if(enableEdit == false) {
            editProfile()
            enableEdit = !enableEdit
            self.navigationItem.backBarButtonItem?.isEnabled = false
        }
        else
        {
            do{
           try updateUser()
            } catch{
                
            }
        }
    }
    
    @IBAction func firstNameHelpButtonPressed(_ sender: UIButton) {
        
        self.alertDialog(message: Constants.FIRST_NAME_MESSAGE, title: "")
    }
    
    @IBAction func lastNameHelpButtonPressed(_ sender: UIButton) {
        self.alertDialog(message: Constants.lAST_NAME_MESSAGE, title: "")

    }
    
    @IBAction func emailHelpButtonPressed(_ sender: UIButton) {
        self.alertDialog(message: Constants.EMAIL_MESSAGE, title: "")

    }
    
    /* Method : getUser
     * Description : get user using client management api and view user profile
     * Input : none
     */
    
    func updateUser() throws {
        showActivityIndicator()
        if(lastNameText.text != "" && emailText.text != "") {
            if(Validator().validateFirstName(firstName: firstNameText.text!) && Validator().validateLastName(lastName: lastNameText.text!) && Validator().validateEmail(email: emailText.text!)){
                
                let organizationId = "14"
                
                let user = try self.userDAO.getUserProfile()
                let userId = user.userId
                ClientManagement.updateUser(userId: userId, firstName: firstNameText.text!, lastName: lastNameText.text!,email: emailText.text!, organizationId: organizationId) { (result) in
                    if result.stringValue == "true"{
                        self.alertDialogWithFunction(message: "Profile updated successfully" ,title: "Success")
                        self.hideActivityIndicator()
                        
                    } else {
                        self.alertDialog(message: Constants.SERVICE_UNAVAILABLE_MESSAGE + Constants.CONTACT_ADMINISTRATOR_MESSAGE ,title: "Error")
                        self.hideActivityIndicator()
                    }
                }
            }
            else
            {
                self.alertDialog(message: Constants.VALID_DATA_MESSAGE, title: "Error")
                self.hideActivityIndicator()
            }
        }
        else
        {
            self.alertDialog(message: Constants.FILL_REQUIRED_FIELDS, title: "Error")
            self.hideActivityIndicator()
        }
        
    }
    
    func textViewDidChange(_ textView: CustomTextField) {
        print ("textchange")
    }
    
    func textFieldDidBeginEditing(_ textField: CustomTextField) {
        if (textField.tag == 1 ) {
            firstNameText.textColor = UIColor.black

        }
        else if (textField.tag == 2 ) {
            lastNameText.textColor = UIColor.black
            
        }
        else if (textField.tag == 3 ) {
            emailText.textColor = UIColor.black
            
        }
    }
    
    func textFieldDidEndEditing(_ textField: CustomTextField) {
        print ("didend")
        if (textField.tag == 1 ) {
            firstNameText.textColor = UIColor.lightGray
            print ("tag 1 match")
            if (Validator().validateFirstName(firstName: firstNameText.text!)) {
                firstNameText.awakeFromNib()
                //navigationItem.rightBarButtonItem?.isEnabled = true
                print ("validate true")
            }
            else {
                firstNameText.awakeForError()
                //navigationItem.rightBarButtonItem?.isEnabled = false
                print ("validate false")
            }
        }
       else if (textField.tag == 2) {
            lastNameText.textColor = UIColor.lightGray
            print ("tag 2 match")
            if (Validator().validateLastName(lastName: lastNameText.text!)) {
                lastNameText.awakeFromNib()
                //navigationItem.rightBarButtonItem?.isEnabled = true
                print ("validate true")
            }
            else {
                lastNameText.awakeForError()
                //navigationItem.rightBarButtonItem?.isEnabled = false
                print ("validate false")
            }
        }
        else if (textField.tag == 3 ) {
        emailText.textColor = UIColor.lightGray
        print ("tag 3 match")
        if (Validator().validateEmail(email: emailText.text!)) {
            emailText.awakeFromNib()
            //navigationItem.rightBarButtonItem?.isEnabled = true
            print ("validate true")
        }
        else {
            emailText.awakeForError()
            //navigationItem.rightBarButtonItem?.isEnabled = false
            print ("validate false")
        }
    }
        print ("didend end")
    }
    
    /* Method : editProfile
     * Description : logic to enable profile edit
     * Input : none
     */
    
    func editProfile() -> Void {
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "ic_done_white"), style: .plain, target: self, action: #selector(editButtonPressed))
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "ic_action_name_back"), style: .plain, target: self, action: #selector(cancelButtonPressed))
        cancelButton.isHidden = false
        firstNameText.isEnabled = true
        lastNameText.isEnabled = true
        emailText.isEnabled = true
        firstNameHelpButton.isHidden = false
        lastNameHelpButton.isHidden = false
        emailHelpButton.isHidden = false
        firstNameText.bottomBorder.backgroundColor = UIColor(red: 132/255, green: 151/255, blue: 176/255, alpha: 255)
        lastNameText.bottomBorder.backgroundColor = UIColor(red: 132/255, green: 151/255, blue: 176/255, alpha: 255)
        emailText.bottomBorder.backgroundColor = UIColor(red: 132/255, green: 151/255, blue: 176/255, alpha: 255)
        firstNameText.textColor = UIColor.black
        lastNameText.textColor = UIColor.black
        emailText.textColor = UIColor.black
        firstNameText.isSelected = true
    }
    /* Method : viewProfile
     * Description : logic to disable profile edit
     * Input : none
     */
    
    func viewProfile() -> Void {
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .compose, target: self, action: #selector(editButtonPressed))
        navigationItem.leftBarButtonItem = navigationItem.backBarButtonItem
        cancelButton.isHidden = true
        firstNameText.isEnabled = false
        lastNameText.isEnabled = false
        emailText.isEnabled = false
        firstNameHelpButton.isHidden = true
        lastNameHelpButton.isHidden = true
        emailHelpButton.isHidden = true
        firstNameText.bottomBorder.backgroundColor = UIColor(white:231 / 256,alpha: 1)
        lastNameText.bottomBorder.backgroundColor = UIColor(white:231 / 256,alpha: 1)
        emailText.bottomBorder.backgroundColor = UIColor(white:231 / 256,alpha: 1)
        firstNameText.textColor = UIColor.lightGray
        lastNameText.textColor = UIColor.lightGray
        emailText.textColor = UIColor.lightGray
        firstNameText.text = firstName
        lastNameText.text = lastName
        emailText.text = email
        //getUser()
    }
   
    /* Method : getUser
     * Description : get user using client management api and view user profile
     * Input : none
     */
    
    func getUser() {
        showActivityIndicator()
        var userName : String!
        do{
         userName = try self.userDAO.getUserProfile().userName //getUserDetail()
            print (userName)
} catch {
            
        }
        ClientManagement.getUser(userName: userName) { (result) in
            if result["GetUserResponse"]["Result"]["ResponseCode"].stringValue == "CM-N-0000"{
                print (result)
                //TODO: implment the DAO
                self.userNameText.text = result["GetUserResponse"]["User"]["UserName"].stringValue
                self.firstName = result["GetUserResponse"]["User"]["PersonalDetail"]["FirstName"].stringValue
                self.firstNameText.text = self.firstName
                
                self.lastName = result["GetUserResponse"]["User"]["PersonalDetail"]["LastName"].stringValue
                self.lastNameText.text = self.lastName
                self.email = result["GetUserResponse"]["User"]["ContactDetail"][1]["ChannelCode"].stringValue
                self.emailText.text = self.email
                self.hideActivityIndicator()
            } else {
                self.hideActivityIndicator()
                self.alertDialogWithFunction(message: Constants.SERVICE_UNAVAILABLE_MESSAGE + Constants.CONTACT_ADMINISTRATOR_MESSAGE ,title: "Error")
            }
        }
        
    }
    
    /* Method : showActivityIndicator
     * Description : This method will be used to display the progress spinner
     * Input : none
     */
    
    func showActivityIndicator() {
        
        DispatchQueue.main.async() {
            self.loadingView = UIView()
            self.loadingView.frame = CGRect(x: 0.0, y: 0.0, width: 50.0, height: 50.0)
            self.loadingView.center = self.view.center
            self.loadingView.backgroundColor = UIColor(red: 0.26, green: 0.26, blue: 0.26, alpha: 0.7)
            self.loadingView.alpha = 0.7
            self.loadingView.clipsToBounds = true
            self.loadingView.layer.cornerRadius = 10
            self.spinner = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
            self.spinner.frame = CGRect(x: 0.0, y: 0.0, width: 80.0, height: 80.0)
            self.spinner.center = CGPoint(x:self.loadingView.bounds.size.width / 2, y:self.loadingView.bounds.size.height / 2)
            self.loadingView.addSubview(self.spinner)
            self.view.addSubview(self.loadingView)
            self.spinner.startAnimating()
        }
    }
    
    /* Method : hideActivityIndicator
     * Description : This method will be used to hide the progress spinner
     * Input : none
     */
    
    func hideActivityIndicator() {
        
        DispatchQueue.main.async() {
            self.spinner.stopAnimating()
            self.loadingView.removeFromSuperview()
        }
    }
    
    /* Method : alertDialog
     * Description : This method will be used to display the alert
     * Input : none
     */
    
    func alertDialogWithFunction(message: String, title: String) {
        
        let errorAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        
        errorAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
            self.backButton(self)
        }))
        self.present(errorAlert, animated: true, completion: nil)
    }
    
    /* Method : alertDialog
     * Description : This method will be used to display the alert
     * Input : none
     */
    
    func alertDialog(message: String, title: String) {
        
        let errorAlert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        
        errorAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
        }))
        self.present(errorAlert, animated: true, completion: nil)
    }
    
}
