/*
 *  Author : Amna Tariq
 *  Usage : This class is used to connect to the Redis server and insert key value pair passed though the MessageContext. 
 *  	It can be exported as a deployable archive to be used as a custom mediator in WSO2 ESB.
 *  
 *  
 *  Version History:
 *  
 * 	01.001 - Initial Implementation
 *  
*/

// 	PACKAGE NAME
package nl.weintegrate.wealert.custommediator;

//APACHE SYNAPSE library declarations
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.synapse.MessageContext; 
import org.apache.synapse.mediators.AbstractMediator;

//REDIS CLIENT library declarations
import redis.clients.jedis.Jedis;

//CLASS, METHODS & VARIABLE declarations
public class RedisSender extends AbstractMediator { 
	
	/***************************************************************
						PRIVATE VARIABLES
	****************************************************************/
	private String redisHost = "localhost";
	private int redisPort = 6379;
	private String key;

	/***************************************************************
						PUBLIC METHODS
	****************************************************************/
	public RedisSender(){}
	
	public boolean mediate(MessageContext context) { 
		System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - Going to Initiate Connection with the Redis Server.");
		Jedis jedisClient = new Jedis(redisHost, redisPort);
		System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - Established Connection with the Redis Server.");
		
		String arr[] = new String[2];
  		arr[0] = context.getEnvelope().getBody().getFirstElement().toString();
		arr[1] = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
		jedisClient.lpush(key,arr);
		System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - Pushed Key Value Pair.");
		
		jedisClient.close();
		System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - Closing Connection with the Redis Server.");
		
		return true;
	}
	
	public void setRedisHost(String aRedisHost){
		redisHost = aRedisHost;
	}
	
	public String getRedisHost(){
		return redisHost;
	}
	
	public void setRedisPort(String aRedisPort){
		redisPort = Integer.parseInt(aRedisPort);
	}
	
	public int getRedisPort(){
		return redisPort;
	}
	
	public void setKey(String aKey){
		key = aKey;
	}
	
	public String getKey(){
		return key;
	}

}
